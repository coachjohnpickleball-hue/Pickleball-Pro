window.__CLIENT__={"client":{"id":"coachjohn","name":"Coach John Pickleball","adminEmail":"coachjohnpickleball@gmail.com"},"branding":{"appName":"Pickleball Pro","logoEmoji":"\ud83c\udfd3","primaryColor":"#C6FF00","accentColor":"#FF9800"},"worker":{"name":"pickleball-relay","kvNamespaceId":"faac1bcc30ef4711a9377e60ef70636d"},"limits":{"maxSmsPerDay":200,"maxEmailPerDay":500},"features":{"sms":true,"email":true,"mobileSync":true,"playoffs":true,"season":true,"duprExport":true}};




(function(){
  function isAdmin(){ return !!(window.__ACCESS__ && window.__ACCESS__.isAdmin); }
  function hideAdmin(){
    if (isAdmin()) return;
    try {
      var style = document.getElementById('pb-hard-admin-css');
      if (!style) {
        style = document.createElement('style');
        style.id = 'pb-hard-admin-css';
        style.textContent = '[data-admin-only],#sec-admin,button[onclick*=\"showTab(\\\'admin\\\'\"],button[onclick*=\"showTab(\\\"admin\\\"\"],button[onclick*=\"/admin/\"],a[href^=\"/admin/\"]{display:none!important;visibility:hidden!important;}';
        document.head.appendChild(style);
      }
      document.querySelectorAll('[data-admin-only],#sec-admin,button,a').forEach(function(el){
        var oc=(el.getAttribute&&el.getAttribute('onclick'))||'';
        var href=(el.getAttribute&&el.getAttribute('href'))||'';
        var txt=(el.textContent||'').trim().toLowerCase();
        if(el.hasAttribute&&el.hasAttribute('data-admin-only') || el.id==='sec-admin' || href.indexOf('/admin/')===0 || oc.indexOf('/admin/')>=0 || oc.indexOf("showTab('admin'")>=0 || oc.indexOf('showTab("admin"')>=0 || txt==='admin' || txt==='admin lock'){
          el.style.setProperty('display','none','important');
          el.style.setProperty('visibility','hidden','important');
          el.setAttribute('aria-hidden','true');
        }
      });
    } catch(e) {}
  }
  hideAdmin();
  document.addEventListener('DOMContentLoaded', hideAdmin);
  setTimeout(hideAdmin,50); setTimeout(hideAdmin,250); setTimeout(hideAdmin,1000); setInterval(hideAdmin,2000);
})();


// ── Relay endpoint (declared first — must be assigned before ANY other
// code runs, since standings/SMS/email functions defined further down can
// be invoked during early page load/state restoration, before the script
// has finished executing top-to-bottom) ─────────────────────────────────
// This app and its API now live on the SAME Cloudflare Worker
// (pickleball-relay), at the same origin — e.g.
// https://pickleball-relay.yoursubdomain.workers.dev/api/sms. The Worker
// serves this HTML file directly (see worker/src/index.js) and also
// handles /api/sms, /api/email, /api/standings. One origin means no
// cross-origin fetch() ever happens, which sidesteps a real Cloudflare
// Access limitation: Access's human-login redirect can't be completed by
// fetch() across origins, and pages.dev (Cloudflare Pages' shared domain)
// can't be scoped to a specific path in Access either — both dead ends
// this project hit before landing on "one Worker serves everything."
var RELAY_BASE = '';

// ── State, navigation, utility functions ─────────────────

// ═══════════════════════════════════════════════
//  STATE
// ═══════════════════════════════════════════════
const MAX_COURTS = 17; // bump this (and add a matching court-sel-N tile in the HTML) to support more courts
var state = {
  players: [],
  waitlist: [],
  teams: [],
  roundTeams: [],
  schedule: [],
  activeMatchIdx: null,
  roundHistory: [],
  byeRounds: [],
  selectedCourts: new Set(Array.from({length:MAX_COURTS},(_,i)=>i+1)), // all courts selected by default
  notifiedRounds: new Set(),
  startedRounds: new Set(), // round indices that are locked — play has begun, so adding a player won't reshuffle these matchups
  _skippedPods: [],
  _manualAdjustments: 0,
  _wlEditId: null,
  fixedTeams: [],
  _rrPlayoffPrompted: false,
  partnerLocks: [], // array of [playerIdA, playerIdB] pairs that should always be paired together in upcoming rounds
};

// ── pRating: scheduling uses Club Rating (numeric) when set, falls back to Skill Rating ──
function pRating(p) {
  if(!p) return 0;
  // Priority: Club Rating (numeric) → DUPR → Skill Rating → 0
  if(p.clubRating) {
    const n = parseFloat(p.clubRating);
    if(!isNaN(n) && n > 0) return n;
  }
  if(p.dupr != null) {
    const n = parseFloat(p.dupr);
    if(!isNaN(n) && n > 0) return n;
  }
  if(p.rating != null) {
    const n = parseFloat(p.rating);
    if(!isNaN(n) && n > 0) return n;
  }
  return 0;
}

// Display label: show club rating if set
function pRatingLabel(p) {
  if(!p) return '—';
  if(p.clubRating) return p.clubRating;
  return '—';
}

// ─── Sample Data ───────────────────────────────
function loadSamples() {
  const sample = [
    ["Alice Turner","Female",4.5,"Burlington"],["Bob Martin","Male",4.0,"Hamilton"],
    ["Carol Singh","Female",3.5,"Oakville"],["David Chen","Male",4.5,"Burlington"],
    ["Eva Kowalski","Female",4.0,"Milton"],["Frank Torres","Male",3.5,"Hamilton"],
    ["Grace Kim","Female",5.0,"Burlington"],["Henry Liu","Male",4.5,"Oakville"],
    ["Iris Patel","Female",3.5,"Burlington"],["James O'Brien","Male",4.0,"Hamilton"],
    ["Karen Zhang","Female",4.5,"Burlington"],["Leo Nguyen","Male",3.5,"Milton"],
    ["Mia Santos","Female",4.0,"Oakville"],["Noah Williams","Male",4.5,"Burlington"],
    ["Olivia Brown","Female",3.5,"Hamilton"],["Paul Tremblay","Male",4.0,"Burlington"],
    ["Quinn Lee","Female",4.5,"Milton"],["Ryan Park","Male",3.5,"Oakville"],
    ["Sara Ahmed","Female",4.0,"Burlington"],["Tom Baker","Male",4.5,"Hamilton"],
    ["Uma Johansson","Female",3.5,"Burlington"],["Victor Morin","Male",4.0,"Milton"],
    ["Wendy Zhao","Female",4.5,"Oakville"],["Xavier Dupont","Male",3.5,"Burlington"],
    ["Yasmin Hassan","Female",4.0,"Hamilton"],["Zach Carter","Male",4.5,"Burlington"],
    ["Amy Rodriguez","Female",3.5,"Oakville"],["Ben Larsen","Male",4.0,"Hamilton"],
    ["Chloe Wu","Female",4.5,"Burlington"],["Daniel Ferreira","Male",3.5,"Milton"],
    ["Elena Petrov","Female",4.0,"Oakville"],["Felix Armstrong","Male",4.5,"Burlington"],
  ];
  const beforeCount = state.players.length;
  sample.forEach(([name,gender,rating,club]) => {
    if(state.players.some(p => p.name.toLowerCase() === name.toLowerCase())) return;
    state.players.push({id: Date.now()+Math.random(), name, gender, rating: null, club, dupr: rating ?? null, clubRating: ''});
  });
  const addedCount = state.players.length - beforeCount;
  renderPlayers();
  autoSave();
  toast(addedCount === 32
    ? "32 sample players loaded!"
    : `${addedCount} players added (${32-addedCount} skipped — already on roster)`);
}


function dashboardGetProgress() {
  const rounds = state.schedule || [];
  const totalGames = rounds.reduce((a,r)=>a+(r?r.length:0),0);
  const completeGames = rounds.reduce((a,r)=>a+(r||[]).filter(m=>m.complete).length,0);
  let currentIdx = rounds.findIndex(r => (r||[]).some(m=>!m.complete));
  if(currentIdx < 0 && rounds.length) currentIdx = rounds.length - 1;
  return { rounds, totalGames, completeGames, currentIdx };
}

function renderDashboard() {
  const activePlayers = (state.players || []).filter(p => p.waitlist !== true && p.active !== false && p.checkedIn !== false).length;
  const courts = state.selectedCourts && state.selectedCourts.size ? state.selectedCourts.size : 0;
  const progress = dashboardGetProgress();
  const name = (document.getElementById('tournament-name')?.value || '').trim() || 'Pickleball Tournament';
  const dashName = document.getElementById('dash-tournament-name');
  const status = document.getElementById('dash-status-line');
  const primary = document.getElementById('dash-primary-action');
  if(!dashName) return;
  dashName.textContent = name;
  document.getElementById('dash-players').textContent = activePlayers;
  document.getElementById('dash-courts').textContent = courts;
  document.getElementById('dash-round').textContent = progress.rounds.length ? `${Math.min(progress.currentIdx + 1, progress.rounds.length)}/${progress.rounds.length}` : '—';
  document.getElementById('dash-games').textContent = `${progress.completeGames}/${progress.totalGames || 0}`;
  if(typeof renderSessionHealthDashboard === 'function') renderSessionHealthDashboard();
  if(!progress.rounds.length) {
    status.textContent = activePlayers < 4 ? 'Add players first. Once you have 4+ active players, generate the schedule.' : 'Ready to generate your schedule.';
    primary.textContent = '⚡ Generate Schedule';
  } else if(progress.completeGames >= progress.totalGames && progress.totalGames > 0) {
    status.textContent = 'Tournament rounds are complete. Review standings or export the report.';
    primary.textContent = '📊 View Standings';
  } else if(state.startedRounds && state.startedRounds.has(progress.currentIdx)) {
    status.textContent = `Round ${progress.currentIdx + 1} is live. Enter scores as games finish.`;
    primary.textContent = '📝 Record Scores';
  } else {
    status.textContent = `Round ${progress.currentIdx + 1} is ready. Start it when players are on court.`;
    primary.textContent = `▶ Start Round ${progress.currentIdx + 1}`;
  }
}

function dashboardPrimaryAction() {
  const progress = dashboardGetProgress();
  if(!progress.rounds.length) { promptGenerateSchedule(); return; }
  if(progress.completeGames >= progress.totalGames && progress.totalGames > 0) { showTab('standings'); return; }
  if(progress.currentIdx >= 0 && !(state.startedRounds && state.startedRounds.has(progress.currentIdx))) { lockRound(progress.currentIdx); }
  showTab('schedule');
  renderDashboard();
}


// ═══════════════════════════════════════════════
//  PREMIUM ADD-ONS: QUICK SCORE, CHECK-IN, PUBLIC LINK
// ═══════════════════════════════════════════════
function _checkedInPlayers(){
  return (state.players || []).filter(p => p.waitlist !== true && p.active !== false && p.checkedIn !== false);
}

function recordNextScore(){
  flattenSchedule();
  const next = (state.schedule || []).flat().find(m => m.teamA && m.teamB && !m.complete);
  if(!next){ toast('No unfinished matches found','err'); return; }
  showTab('schedule');
  setTimeout(() => openScoreModal(next.id), 50);
}

function copyPublicStandingsLink(){
  const url = window.location.origin + window.location.pathname + '#public';
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(url).then(() => toast('Public standings link copied'));
  } else {
    prompt('Copy public standings link:', url);
  }
}

function renderCheckin(){
  const list = document.getElementById('checkin-list');
  if(!list) return;
  const q = (document.getElementById('checkin-search')?.value || '').toLowerCase().trim();
  const roster = (state.players || []).filter(p => p.waitlist !== true && p.active !== false);
  const filtered = q ? roster.filter(p => (p.name||'').toLowerCase().includes(q) || (p.club||'').toLowerCase().includes(q)) : roster;
  const checked = roster.filter(p => p.checkedIn !== false).length;
  const setTxt = (id, txt) => { const el=document.getElementById(id); if(el) el.textContent=txt; };
  setTxt('checkin-total', `${roster.length} players`);
  setTxt('checkin-in', `${checked} checked in`);
  setTxt('checkin-out', `${Math.max(0, roster.length-checked)} not checked in`);
  if(!filtered.length){ list.innerHTML = '<div class="empty-state"><div class="big">✅</div>No players found.</div>'; return; }
  list.innerHTML = filtered.map(p => {
    const isIn = p.checkedIn !== false;
    return `<div class="checkin-card ${isIn ? 'checked' : ''}">
      <div><div class="checkin-name">${escHtml(p.name || 'Player')}</div><div class="checkin-meta">${escHtml(p.club || p.gender || 'Roster player')}</div></div>
      <button class="checkin-toggle" onclick="toggleCheckIn(${JSON.stringify(p.id)})">${isIn ? 'Checked In' : 'Absent'}</button>
    </div>`;
  }).join('');
  renderDashboard();
}

function toggleCheckIn(playerId){
  const p = (state.players || []).find(x => String(x.id) === String(playerId));
  if(!p) return;
  p.checkedIn = !(p.checkedIn !== false);
  autoSave();
  renderCheckin();
  renderPlayers();
  toast(`${p.name} marked ${p.checkedIn !== false ? 'checked in' : 'absent'}`);
}

function setAllCheckedIn(value){
  (state.players || []).forEach(p => { if(p.waitlist !== true && p.active !== false) p.checkedIn = !!value; });
  autoSave();
  renderCheckin();
  renderPlayers();
  toast(value ? 'All players checked in' : 'All players marked absent');
}

// ═══════════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════════
function showTab(tab, evt) {
  const e = evt || window.event;
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.nav-group').forEach(g => g.classList.remove('active'));
  const section = document.getElementById('sec-'+tab);
  if(section) section.classList.add('active');
  // Highlight the selected sub-item plus its cleaner top-level menu group.
  const navBtn = e && e.target && e.target.classList.contains('tab-btn')
    ? e.target
    : document.querySelector(`.tab-btn[onclick*="showTab('${tab}'"]`);
  if(navBtn) navBtn.classList.add('active');
  const group = document.querySelector(`.nav-group[data-tabs~="${tab}"]`);
  if(group) {
    group.classList.add('active');
    const primaryBtn = group.querySelector(':scope > .tab-btn');
    if(primaryBtn) primaryBtn.classList.add('active');
  }
  if(tab==='dashboard') renderDashboard();
  if(tab==='courts') renderCourts();
  if(tab==='schedule') { renderSchedule(); updateTimerDisplay(); }
  if(tab==='standings') renderStandings();
  if(tab==='display') renderDisplayTools();
  if(tab==='public') renderPublicStandings();
  if(tab==='checkin') renderCheckin();
  if(tab==='selfcheckin') renderSelfCheckinTools();
  if(tab==='fairness') renderFairnessEngine();
  if(tab==='history') renderTournamentHistory();
  if(tab==='admin') renderAdminLock();
  if(tab==='selfcheckinpublic') renderSelfCheckinPublic();
  if(tab==='playoffs') renderPlayoffs();
  if(tab==='playerstats') { renderPlayerStats(); populateH2HDropdowns(); renderH2H(); }
  if(tab==='sms') renderSmsTab();
  if(tab==='mobilesync') renderMobileSyncTab();
  if(tab==='report') renderReport();
  if(tab==='playerlookup') renderPlayerLookup();
  if(tab==='sessionhealth') renderSessionHealthDashboard();
  if(tab==='endsession') renderEndSessionSummary();
  if(tab==='email') renderEmailTab();
  if(tab==='season') renderSeasonBoard();
}

// ═══════════════════════════════════════════════
//  PLAYERS
// ═══════════════════════════════════════════════
function addPlayer(toWaitlist) {
  const name       = document.getElementById('p-name').value.trim();
  const gender     = document.getElementById('p-gender').value;
  const dupr       = document.getElementById('p-dupr').value.trim();
  const clubRating = document.getElementById('p-club-rating').value.trim();
  const club       = document.getElementById('p-club').value.trim();
  const phone      = document.getElementById('p-phone')?.value.trim() || '';
  const email      = document.getElementById('p-email')?.value.trim() || '';
  if(!name) { toast("Enter a player name","err"); return; }
  const dupKey = name.toLowerCase();
  if(state.players.some(p => p.name.toLowerCase() === dupKey) || state.waitlist.some(p => p.name.toLowerCase() === dupKey)) {
    toast(`"${name}" is already on the roster or waitlist — check spelling or use a different name`,"err"); return;
  }
  const duprNum = dupr ? parseFloat(dupr) : null;
  if(dupr && (isNaN(duprNum)||duprNum<1||duprNum>8)) { toast("DUPR must be between 1.0 and 8.0","err"); return; }
  const player = {id: Date.now()+Math.random(), name, gender, rating: null, dupr: duprNum, clubRating, club, phone, email, checkedIn: true};

  document.getElementById('p-name').value = '';
  document.getElementById('p-dupr').value = '';
  document.getElementById('p-club-rating').value = '';
  if(document.getElementById('p-phone')) document.getElementById('p-phone').value = '';
  if(document.getElementById('p-email')) document.getElementById('p-email').value = '';

  if(toWaitlist) {
    state.waitlist.push(player);
    renderWaitlist();
    autoSave();
    toast(`⏳ ${name} added to waitlist`);
    return;
  }

  state.players.push(player);

  // If a schedule already exists, fold the newcomer into the upcoming rounds
  // right away. Rounds that are played OR already marked "started" are
  // preserved untouched — see protectedRoundCount().
  let rebuilt = 0;
  const keepCount = state.schedule.length ? protectedRoundCount() : 0;
  if(state.schedule.length) {
    rebuilt = rebuildUpcomingRounds();
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
  }

  renderPlayers();
  renderWaitlist();
  autoSave();
  const inProgressNote = keepCount > 0
    ? ` (Round${keepCount>1?'s':''} 1–${keepCount} already underway — left untouched)`
    : '';
  toast(rebuilt > 0
    ? `${name} added — included in ${rebuilt} upcoming round${rebuilt>1?'s':''}${inProgressNote}`
    : `${name} added!${inProgressNote}`);
}

// ── Waitlist ──────────────────────────────────
function renderWaitlist() {
  const card    = document.getElementById('waitlist-card');
  const tbody   = document.getElementById('waitlist-body');
  const countEl = document.getElementById('waitlist-count');
  if(!card || !tbody) return;

  if(!state.waitlist.length) {
    card.style.display = 'none';
    state._wlEditId = null;
    return;
  }
  card.style.display = '';
  if(countEl) countEl.textContent = '(' + state.waitlist.length + ')';
  if(!state._wlSelected) state._wlSelected = new Set();
  if(!state._wlEditId) state._wlEditId = null;

  const fn = s => escHtml(s || '—');

  tbody.innerHTML = state.waitlist.map((p) => {
    const checked   = state._wlSelected.has(p.id) ? 'checked' : '';
    const isEditing = state._wlEditId === p.id;
    const sid       = JSON.stringify(p.id);

    if(isEditing) {
      // Inline edit row
      return `<tr class="edit-row" id="wl-edit-row-${p.id}">
        <td></td>
        <td><input id="wl-edit-name-${p.id}" value="${escHtml(p.name||'')}" placeholder="Name" style="width:130px"></td>
        <td><select id="wl-edit-gender-${p.id}" style="min-width:80px">
          <option ${p.gender==='Male'?'selected':''}>Male</option>
          <option ${p.gender==='Female'?'selected':''}>Female</option>
        </select></td>
        <td><input id="wl-edit-dupr-${p.id}" type="number" step="0.01" min="1" max="8" value="${p.dupr!=null?p.dupr:''}" placeholder="DUPR" style="width:65px"></td>
        <td><input id="wl-edit-cr-${p.id}" value="${escHtml(p.clubRating||'')}" placeholder="CR" style="width:55px"></td>
        <td><input id="wl-edit-club-${p.id}" value="${escHtml(p.club||'')}" placeholder="Club" style="width:100px"></td>
        <td><input id="wl-edit-phone-${p.id}" value="${escHtml(p.phone||'')}" placeholder="Phone" style="width:110px"></td>
        <td><input id="wl-edit-email-${p.id}" type="email" value="${escHtml(p.email||'')}" placeholder="Email" style="width:140px"></td>
        <td style="white-space:nowrap">
          <button class="btn btn-primary btn-sm" onclick="waitlistSaveEdit(${sid})">✓ Save</button>
          <button class="btn btn-secondary btn-sm" onclick="waitlistCancelEdit()">✕</button>
        </td>
      </tr>`;
    }

    return `<tr>
      <td><input type="checkbox" ${checked} onchange="wlToggle(${sid}, this.checked)"></td>
      <td style="font-weight:600">${fn(p.name)}</td>
      <td><span class="badge badge-${(p.gender||'').toLowerCase()}">${fn(p.gender)}</span></td>
      <td style="font-family:monospace">${p.dupr != null ? Number(p.dupr).toFixed(2) : '—'}</td>
      <td style="font-family:monospace">${fn(p.clubRating)}</td>
      <td style="color:var(--txt3)">${fn(p.club)}</td>
      <td style="font-size:0.78rem">${fn(p.phone)}</td>
      <td style="font-size:0.78rem">${fn(p.email)}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-secondary btn-sm" onclick="waitlistStartEdit(${sid})" title="Edit">✏</button>
        <button class="btn btn-primary btn-sm" onclick="waitlistPromoteOne(${sid})" title="Add to tonight's players">➕</button>
        <button class="btn btn-danger btn-sm" onclick="waitlistRemove(${sid})" title="Remove from waitlist">✕</button>
      </td>
    </tr>`;
  }).join('');
}

function waitlistStartEdit(id) {
  state._wlEditId = id;
  renderWaitlist();
  // Focus name field
  setTimeout(() => document.getElementById('wl-edit-name-' + id)?.focus(), 50);
}

function waitlistCancelEdit() {
  state._wlEditId = null;
  renderWaitlist();
}

function waitlistSaveEdit(id) {
  const p = state.waitlist.find(x => x.id === id);
  if(!p) return;
  const name   = document.getElementById('wl-edit-name-' + id)?.value.trim();
  const gender = document.getElementById('wl-edit-gender-' + id)?.value;
  const duprRaw = document.getElementById('wl-edit-dupr-' + id)?.value;
  const cr     = document.getElementById('wl-edit-cr-' + id)?.value.trim();
  const club   = document.getElementById('wl-edit-club-' + id)?.value.trim();
  const phone  = document.getElementById('wl-edit-phone-' + id)?.value.trim();
  const email  = document.getElementById('wl-edit-email-' + id)?.value.trim();

  if(!name) { toast('Name is required', 'err'); return; }

  p.name       = name;
  p.gender     = gender;
  p.dupr       = duprRaw !== '' && !isNaN(parseFloat(duprRaw)) ? parseFloat(duprRaw) : null;
  p.clubRating = cr;
  p.club       = club;
  p.phone      = phone;
  p.email      = email;

  state._wlEditId = null;
  autoSave();
  renderWaitlist();
  toast('✅ Waitlist player updated');
}

function wlToggle(id, checked) {
  if(!state._wlSelected) state._wlSelected = new Set();
  if(checked) state._wlSelected.add(id); else state._wlSelected.delete(id);
}

function waitlistSelectAll(on) {
  state._wlSelected = on ? new Set(state.waitlist.map(p => p.id)) : new Set();
  renderWaitlist();
}

function waitlistRemove(id) {
  state.waitlist = state.waitlist.filter(p => p.id !== id);
  if(state._wlSelected) state._wlSelected.delete(id);
  renderWaitlist();
  autoSave();
  toast('Removed from waitlist');
}

function waitlistPromoteOne(id) {
  const p = state.waitlist.find(x => x.id === id);
  if(!p) return;
  _waitlistAdd([p]);
}

function waitlistPromoteSelected() {
  const sel = state._wlSelected || new Set();
  const toAdd = state.waitlist.filter(p => sel.has(p.id));
  if(!toAdd.length) { toast('No players selected', 'err'); return; }
  _waitlistAdd(toAdd);
}

function _waitlistAdd(players) {
  players.forEach(p => {
    state.waitlist = state.waitlist.filter(x => x.id !== p.id);
    if(state._wlSelected) state._wlSelected.delete(p.id);
    // If this player is already in state.players (moved to waitlist while schedule existed),
    // just reactivate them instead of adding a duplicate entry
    const existing = state.players.find(x => x.id === p.id);
    if(existing) {
      delete existing.active; // reactivate
      delete existing.waitlist; // no longer waitlisted — eligible for scheduling again
    } else {
      state.players.push(p);
    }
  });

  let rebuilt = 0;
  if(state.schedule.length) {
    rebuilt = rebuildUpcomingRounds();
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
  }

  renderPlayers();
  renderWaitlist();
  autoSave();
  const n = players.length;
  const names = players.map(p => p.name.split(' ')[0]).join(', ');
  toast('➕ ' + names + ' added to tonight'
    + (rebuilt > 0 ? ' — included in ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'') : ''));
}

function movePlayerToWaitlist(id) {
  const p = state.players.find(x => x.id === id);
  if(!p) return;

  // Can't move to waitlist if already inactive (already sitting out)
  if(p.active === false) {
    toast('Player is already inactive — use ▶ to reactivate or ✕ to remove', 'err');
    return;
  }

  // Check if already on waitlist
  if(state.waitlist && state.waitlist.some(w => w.id === id)) {
    toast(p.name.split(' ')[0] + ' is already on the waitlist', 'err');
    return;
  }

  const name = p.name.split(' ')[0];

  if(state.schedule.length) {
    // Schedule exists: mark inactive + waitlisted (keeps match history intact,
    // since other code paths still reference this player object by id), and
    // add a display copy to state.waitlist. We tag the original with
    // waitlist=true so the Roster table can hide it instead of showing a
    // confusing "LEFT" ghost row alongside the Waitlist entry.
    p.active = false;
    p.waitlist = true;
    if(!state.waitlist) state.waitlist = [];
    // Only add to waitlist if not already there
    if(!state.waitlist.some(w => w.id === id)) {
      state.waitlist.push({ ...p }); // snapshot current data for display in waitlist
    }
    const rebuilt = rebuildUpcomingRounds();
    renderPlayers();
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
    autoSave();
    toast(`${name} moved to Waitlist — removed from ${rebuilt > 0 ? rebuilt + ' upcoming round' + (rebuilt > 1 ? 's' : '') : 'schedule'}, stats kept`);
  } else {
    // No schedule yet: just move from active list to waitlist cleanly
    if(!state.waitlist) state.waitlist = [];
    state.waitlist.push({ ...p });
    state.players = state.players.filter(x => x.id !== id);
    renderPlayers();
    autoSave();
    toast(`${name} moved to Waitlist`);
  }
}

function removePlayer(id) {
  const p = state.players.find(x => x.id === id);
  if(!p) return;
  // Once a schedule exists, matches reference players by index — removing would
  // corrupt every match. Mark them as Left instead (kept in history & stats).
  if(state.schedule.length) {
    p.active = false;
    const rebuilt = rebuildUpcomingRounds();
    renderPlayers();
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
    autoSave();
    toast(rebuilt > 0
      ? p.name.split(' ')[0] + ' removed from ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'') + '. Past rounds kept for stats — shown with ✕'
      : p.name.split(' ')[0] + ' marked Left — only in completed rounds (stats kept), shown with ✕');
    return;
  }
  state.players = state.players.filter(x => x.id !== id);
  renderPlayers();
  autoSave();
}

function togglePlayerActive(id) {
  const p = state.players.find(x => x.id === id);
  if(!p) return;
  const leaving = p.active !== false; // was active, now leaving
  p.active = leaving ? false : true;

  // If a schedule exists, immediately rebuild the UPCOMING (unplayed) rounds so the
  // change is visible right away. Played rounds (with any score) are preserved.
  let rebuilt = 0;
  if(state.schedule.length) rebuilt = rebuildUpcomingRounds();

  renderPlayers();
  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
  if(typeof smsPopRounds === 'function') smsPopRounds();
  autoSave();

  const fn = p.name.split(' ')[0];
  if(leaving) {
    toast(rebuilt > 0
      ? fn + ' marked Left — removed from ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'') + ', stats kept'
      : fn + ' marked Left — stats kept (no upcoming rounds to update)');
  } else {
    toast(rebuilt > 0
      ? fn + ' is back — added into ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'')
      : fn + ' is back in the active roster');
  }
}

// Check-in: who's actually arrived tonight. Only checked-in players are
// included when generating the schedule or sending SMS/email — but unlike
// "Left" (active=false), checking someone out doesn't touch their past
// stats/history logic differently, since that's governed separately by
// active status, not checkedIn.
function togglePlayerCheckedIn(id) {
  const p = state.players.find(x => x.id === id);
  if(!p) return;
  const wasCheckedIn = p.checkedIn !== false;
  p.checkedIn = !wasCheckedIn;

  let rebuilt = 0;
  if(state.schedule.length) rebuilt = rebuildUpcomingRounds();

  renderPlayers();
  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
  if(typeof smsPopRounds === 'function') smsPopRounds();
  autoSave();

  const fn = p.name.split(' ')[0];
  if(wasCheckedIn) {
    toast(rebuilt > 0
      ? fn + ' marked not-here-yet — removed from ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'')
      : fn + ' marked not-here-yet');
  } else {
    toast(rebuilt > 0
      ? fn + ' checked in — added into ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'')
      : fn + ' checked in!');
  }
}

// Bulk check-in/out for the whole roster — same eligibility rules as the
// per-player toggle, just applied to everyone at once. Skips players marked
// "Left" or on the Waitlist, since check-in is about who's actually playing
// tonight and toggling it for someone who isn't active anyway wouldn't do
// anything meaningful.
function checkInAllPlayers(checkedIn) {
  const affected = state.players.filter(p => p.active !== false && p.waitlist !== true && (p.checkedIn !== false) !== checkedIn);
  if(!affected.length) {
    toast(checkedIn ? 'Everyone is already checked in' : 'Everyone is already checked out');
    return;
  }
  affected.forEach(p => { p.checkedIn = checkedIn; });

  let rebuilt = 0;
  if(state.schedule.length) rebuilt = rebuildUpcomingRounds();

  renderPlayers();
  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
  if(typeof smsPopRounds === 'function') smsPopRounds();
  autoSave();

  const verb = checkedIn ? 'checked in' : 'checked out';
  toast(`✓ ${affected.length} player${affected.length>1?'s':''} ${verb}`
    + (rebuilt > 0 ? ` — ${rebuilt} upcoming round${rebuilt>1?'s':''} updated` : ''));
}

// ── Partner locks ────────────────────────────────────────────────────────
// "Lock" two players so they're always teamed together in upcoming rounds.
// Implemented as a post-processing fixup pass over freshly-built rounds,
// rather than a constraint inside the core pairing algorithm — this keeps
// the proven fairness/variety logic in buildLocalPairs/pairPlayersFromPool
// completely untouched, and just nudges its output afterward when needed.

function getLockPartnerId(playerId) {
  const pair = state.partnerLocks.find(([a, b]) => a === playerId || b === playerId);
  if(!pair) return null;
  return pair[0] === playerId ? pair[1] : pair[0];
}

function lockPartners(idA, idB) {
  if(idA === idB) return;
  // A player can only be locked to one partner at a time — remove any prior locks involving either player
  state.partnerLocks = state.partnerLocks.filter(([a, b]) => a !== idA && b !== idA && a !== idB && b !== idB);
  state.partnerLocks.push([idA, idB]);
}

function unlockPartner(id) {
  state.partnerLocks = state.partnerLocks.filter(([a, b]) => a !== id && b !== id);
  renderPlayers();
  autoSave();
  toast('Lock removed');
}

// ── Lock Partner modal (UI) ─────────────────────────────────────────────
var _lpmPlayerId = null;

function openLockPartnerModal(playerId) {
  const p = state.players.find(p => p.id === playerId);
  if(!p) return;
  _lpmPlayerId = playerId;
  document.getElementById('lpm-player-info').textContent = `Choose who ${p.name} should always team up with going forward.`;

  const candidates = state.players.filter(c => c.id !== playerId && c.active !== false && c.waitlist !== true);
  const select = document.getElementById('lpm-partner-select');
  if(!candidates.length) {
    select.innerHTML = '<option value="">No other active players available</option>';
  } else {
    select.innerHTML = candidates.map(c => {
      const existingLock = getLockPartnerId(c.id);
      const lockNote = existingLock ? ` (currently locked with ${state.players.find(x=>x.id===existingLock)?.name || '?'})` : '';
      return `<option value="${c.id}">${escHtml(c.name)}${lockNote}</option>`;
    }).join('');
  }

  const currentLockId = getLockPartnerId(playerId);
  const unlockBtn = document.getElementById('lpm-unlock-btn');
  if(currentLockId) {
    select.value = String(currentLockId);
    unlockBtn.style.display = '';
  } else {
    unlockBtn.style.display = 'none';
  }

  document.getElementById('lock-partner-modal').style.display = 'flex';
}

function closeLockPartnerModal() {
  document.getElementById('lock-partner-modal').style.display = 'none';
  _lpmPlayerId = null;
}

function confirmLockPartner() {
  const partnerId = parseFloat(document.getElementById('lpm-partner-select').value);
  if(!_lpmPlayerId || !partnerId || isNaN(partnerId)) { closeLockPartnerModal(); return; }
  lockPartners(_lpmPlayerId, partnerId);
  const fixedCount = state.schedule.length ? applyPartnerLocksAndSync() : 0;
  closeLockPartnerModal();
  renderPlayers();
  renderSchedule(); renderTeams(); renderCourtsGrid();
  autoSave();
  toast(`🔗 Locked together for all upcoming rounds` + (fixedCount > 0 ? ` (${fixedCount} match${fixedCount>1?'es':''} adjusted)` : ''));
}

function unlockFromModal() {
  if(!_lpmPlayerId) { closeLockPartnerModal(); return; }
  unlockPartner(_lpmPlayerId); // already calls renderPlayers/autoSave/toast
  closeLockPartnerModal();
}

// Apply locks to the existing schedule immediately (e.g. when a lock is set
// mid-tournament, after rounds already exist) and keep roundTeams in sync —
// same correction generateSchedule/rebuildUpcomingRounds apply automatically
// on their own next run, just triggered here on demand.
function applyPartnerLocksAndSync() {
  const fixedCount = applyPartnerLocks();
  state.roundTeams = state.schedule.map(round =>
    round.map(m => [state.players[m.teamA[0]], state.players[m.teamA[1]]])
      .concat(round.map(m => [state.players[m.teamB[0]], state.players[m.teamB[1]]]))
  );
  state.teams = [];
  state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));
  return fixedCount;
}

// Re-pair locked players onto the same team for every upcoming (incomplete)
// round, regardless of which match/court the scheduling algorithm originally
// placed each of them in. Two cases per round per lock:
//  1. Both already in the SAME match, opposite teams -> swap within the match.
//  2. In DIFFERENT matches that round -> pull B out of their match entirely
//     and swap them into A's match in place of A's current teammate; the
//     displaced teammate takes B's now-vacant slot in B's original match.
// If only one (or neither) is playing that round — a bye — there's nothing
// to fix; the lock simply doesn't apply until they're both on court together.
function applyPartnerLocks() {
  if(!state.partnerLocks.length) return 0;
  let fixedCount = 0;
  state.schedule.forEach(round => {
    if(round.some(m => m.complete)) return; // never touch a played round
    state.partnerLocks.forEach(([idA, idB]) => {
      const iA = state.players.findIndex(p => p.id === idA);
      const iB = state.players.findIndex(p => p.id === idB);
      if(iA === -1 || iB === -1) return; // player no longer exists

      const findSlot = (idx) => {
        for(const m of round) {
          if(!m.teamA || !m.teamB) continue;
          if(m.teamA.includes(idx)) return { match: m, team: m.teamA };
          if(m.teamB.includes(idx)) return { match: m, team: m.teamB };
        }
        return null;
      };

      const locA = findSlot(iA), locB = findSlot(iB);
      if(!locA || !locB) return; // one or both not playing this round (bye)
      if(locA.match === locB.match && locA.team === locB.team) return; // already together

      // Move B into A's match, displacing A's current teammate into B's
      // now-vacant slot. When A and B were already in the same match (just
      // on opposite teams), "B's original match" is simply that same match,
      // so this one path correctly covers both the same-match and
      // different-match cases without needing separate branches.
      const aSlot = locA.team.indexOf(iA);
      const aPartnerSlot = aSlot === 0 ? 1 : 0;
      const displaced = locA.team[aPartnerSlot];
      const bSlot = locB.team.indexOf(iB);
      locA.team[aPartnerSlot] = iB;
      locB.team[bSlot] = displaced;
      fixedCount++;
    });
  });
  return fixedCount;
}

// How many leading rounds of state.schedule must NOT be touched by a rebuild.
// A round is protected once it's either (a) had a score entered (complete match),
// or (b) been explicitly marked started via lockRound/▶ Start Round — so a round
// that's underway on the courts keeps its matchups even if nobody has entered a
// score yet. Returns the count of rounds to keep (i.e. the index of the first
// rebuildable round).
function protectedRoundCount() {
  let lastProtected = -1;
  state.schedule.forEach((r, i) => {
    if(r.some(m => m.complete) || (state.startedRounds && state.startedRounds.has(i))) lastProtected = i;
  });
  return lastProtected + 1;
}

// Mark a round as started — its matchups are now locked in. Adding a new
// player to the roster afterward will fold them into later rounds only,
// never reshuffling courts/teams for a round that's already underway.
function lockRound(roundIdx) {
  if(!state.startedRounds) state.startedRounds = new Set();
  state.startedRounds.add(roundIdx);
  renderSchedule();
  renderDashboard();
  autoSave();
  toast(`🔒 Round ${roundIdx + 1} started — matchups are locked in, even if players are added later`);
  msAnnounceRoundStarted(roundIdx);
}

// Posts an automatic announcement to every scorekeeper's phone the moment
// a round is started — this is the one and only trigger for it, mirroring
// "Start Round" being the one and only gate for court visibility itself
// (see msGetCurrentActiveRound). Deliberately reads msState directly
// rather than calling msSaveConfig() — that function pulls from
// document.getElementById('ms-worker-url')/('ms-code'), DOM elements that
// only exist while the Mobile Sync tab is actually rendered. Start Round
// is normally clicked from the Schedule tab, where those elements don't
// exist, so calling msSaveConfig() here would read null/empty and WRONGLY
// CLEAR the saved worker URL/code — breaking mobile sync entirely until
// the organizer happens to revisit that tab. msState is already loaded
// from localStorage on startup (see msLoadConfig), so it's safe and
// correct to read directly, from any tab.
async function msAnnounceRoundStarted(roundIdx) {
  if(!msState.workerUrl || !msState.code) return; // mobile sync not set up — nothing to announce to
  try {
    await msApi('/announce', { method:'POST', body: JSON.stringify({
      text: `🏓 Round ${roundIdx + 1} has started! Check your court below, or look for your name on the live board / ask the organizer.`,
    })});
  } catch(e) {
    // Best-effort, intentionally silent — a failed announcement must never
    // block or error out the actual "Start Round" action itself. The
    // organizer can always post a manual announcement from the Mobile
    // Sync tab if this happens to fail.
  }
}

// Undo an accidental lock.
function unlockRound(roundIdx) {
  if(!state.startedRounds) return;
  if(!confirm(`Unlock Round ${roundIdx + 1}? If you add new players afterward, this round's matchups could change.`)) return;
  state.startedRounds.delete(roundIdx);
  renderSchedule();
  renderDashboard();
  autoSave();
  toast(`Round ${roundIdx + 1} unlocked`);
}

// Rebuild only the rounds AFTER the last one that has a score, using the current
// active roster. Returns how many rounds were rebuilt. Preserves played rounds,
// history-seeds from them, and honors mixed-gender pairing + Pods divisions.
// Returns -1 (and leaves schedule untouched) for King mode.
function rebuildUpcomingRounds() {
  const mode = document.getElementById('team-mode')?.value;
  if(mode === 'king' || mode === 'shootout') return -1; // advances round-by-round via ▶ Advance Round

  // Cutoff: keep through the last round that's played OR already started
  const keep = protectedRoundCount();
  const futureCount = state.schedule.length - keep;
  if(futureCount <= 0) return 0; // nothing upcoming to change

  const n = state.players.length;
  const activeIdxs = state.players.map((p, i) => i).filter(i => state.players[i].active !== false && state.players[i].waitlist !== true && state.players[i].checkedIn !== false);
  if(activeIdxs.length < 4) {
    // Can't form a match — drop upcoming rounds rather than show a broken one
    state.schedule   = state.schedule.slice(0, keep);
    state.byeRounds  = (state.byeRounds  || []).slice(0, keep);
    state.roundTeams = (state.roundTeams || []).slice(0, keep);
    state.teams = [];
    state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));
    return futureCount;
  }

  const isMixed = mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed';
  const courtList = Array.from(state.selectedCourts).sort((a, b) => a - b);

  // Seed history from kept rounds
  const partner = Array.from({length: n}, () => new Array(n).fill(0));
  const opp     = Array.from({length: n}, () => new Array(n).fill(0));
  const byeCnt  = new Array(n).fill(0);
  const surplusCnt = new Array(n).fill(0);
  const kept     = state.schedule.slice(0, keep);
  const keptByes = (state.byeRounds || []).slice(0, keep);
  let maxId = -1;
  state.schedule.flat().forEach(m => { if(m.id > maxId) maxId = m.id; });
  kept.forEach(round => round.forEach(m => {
    if(!m.teamA || !m.teamB) return;
    const [a, b] = m.teamA, [c, d] = m.teamB;
    if(a != null && b != null) { partner[a][b]++; partner[b][a]++; }
    if(c != null && d != null) { partner[c][d]++; partner[d][c]++; }
    [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => { if(x!=null&&y!=null){ opp[x][y]++; opp[y][x]++; } });
  }));
  keptByes.forEach(byes => byes.forEach(i => { if(byeCnt[i] != null) byeCnt[i]++; }));

  // Groups
  let groups;
  if(mode === 'pods') {
    const pods = buildPods();
    const totalNeeded2 = pods.reduce((s, p) => s + (p.players.length >= 4 ? Math.floor(p.players.length / 4) : 0), 0);
    const skipped2 = [];
    let cursor = 0;
    groups = pods.map((pod, pi) => {
      const playable = pod.players.length >= 4;
      const courtsNeeded = playable ? Math.floor(pod.players.length / 4) : 0;
      let courts = [];
      if(playable) {
        if(cursor + courtsNeeded <= courtList.length) {
          courts = courtList.slice(cursor, cursor + courtsNeeded);
          cursor += courtsNeeded;
        } else {
          skipped2.push('Pod ' + String.fromCharCode(65 + pi));
        }
      }
      return { idxs: pod.players, courts,
               label: 'Pod ' + String.fromCharCode(65 + pi) + ' · ' + pod.label };
    });
    if(skipped2.length) {
      const missing2 = totalNeeded2 - courtList.length;
      toast('⚠️ ' + skipped2.join(', ') + ' skipped — ' + missing2 + ' more court' + (missing2 > 1 ? 's' : '') + ' needed (' + totalNeeded2 + ' required, ' + courtList.length + ' selected). Enable more courts to run all pods.', 'err');
    }
  } else {
    groups = [{ idxs: activeIdxs, courts: courtList, label: null }];
  }

  // Rebuild exactly futureCount rounds (keep schedule length stable).
  // Pods: per-division engine. All other modes: the SAME pairPlayersFromPool +
  // matchPairs engine generateSchedule uses, so each mode keeps its own character
  // (fixed partners, snake, rating-balanced, mixed gender, etc.).
  const newRounds = [], newByes = [], newRoundTeams = [];
  let matchIdx = maxId + 1;
  const usePods = (mode === 'pods');

  for(let r = 0; r < futureCount; r++) {
    const roundMatches = [], roundByes = [], roundPairs = [];

    if(usePods) {
      groups.forEach(g => {
        const m = g.idxs.length;
        if(m < 4 || !g.courts.length) { g.idxs.forEach(i => roundByes.push(i)); return; }
        const cap = g.courts.length * 4;
        const playable = Math.min(m - (m % 4), cap);
        let byes = [];
        if(m - playable > 0) {
          byes = [...g.idxs].sort((a, b) => byeCnt[a] - byeCnt[b] || a - b).slice(0, m - playable);
          byes.forEach(i => byeCnt[i]++);
        }
        byes.forEach(i => roundByes.push(i));
        const act = g.idxs.filter(i => !byes.includes(i));
        if(act.length < 4) { act.forEach(i => roundByes.push(i)); return; }
        const pairs = buildLocalPairs(act, partner);
        pairs.forEach(([a, b]) => { partner[a][b]++; partner[b][a]++; });
        const courtMatches = matchLocalPairs(pairs, opp, g.courts.length, g.courts, matchIdx, keep + r);
        courtMatches.forEach(([a, b, c, d, mid, court]) => {
          [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => { opp[x][y]++; opp[y][x]++; });
          const match = { id: mid, round: keep + r + 1, court, teamA: [a, b], teamB: [c, d],
                          scoreA: '', scoreB: '', complete: false };
          if(g.label) match.podLabel = g.label;
          roundMatches.push(match);
          roundPairs.push([a, b], [c, d]);
          matchIdx++;
        });
      });
    } else {
      // Everyone-together modes: use the real per-mode pairing engine.
      const courts = groups[0].courts;
      const courtsPerRound = Math.min(courts.length, Math.floor(activeIdxs.length / 4));
      if(courtsPerRound < 1) break;

      const cap = courtsPerRound * 4;
      let byes = [], pool, mixedCourtCount = courtsPerRound, surplusCourtCount = 0, surplusPool = [];
      if(isMixed) {
        const males   = activeIdxs.filter(i => state.players[i].gender === 'Male');
        const females = activeIdxs.filter(i => state.players[i].gender === 'Female');
        const pairsPossible = Math.min(males.length, females.length);
        const maxMixedPairs = Math.min(pairsPossible - (pairsPossible % 2), Math.floor(cap / 2));
        mixedCourtCount = Math.floor(maxMixedPairs / 2);

        // Send whoever's had the MOST rounds in the surplus pool back to mixed
        // first, so being surplus rotates fairly rather than always landing
        // on the same players (e.g. always the highest-index of the larger
        // gender, which is what a plain ascending tiebreak would do).
        const sortedM = [...males].sort((a,b) => surplusCnt[b] - surplusCnt[a] || a - b);
        const sortedF = [...females].sort((a,b) => surplusCnt[b] - surplusCnt[a] || a - b);
        const surplusM = sortedM.slice(maxMixedPairs), surplusF = sortedF.slice(maxMixedPairs);
        surplusPool = [...surplusM, ...surplusF];
        surplusPool.forEach(i => surplusCnt[i]++);

        // Of the surplus, however many form full same-gender courts (4 each)
        // actually get to play; any true remainder goes to bye.
        const courtsLeftForSurplus = courtsPerRound - mixedCourtCount;
        const byFew = arr => [...arr].sort((a, b) => byeCnt[a] - byeCnt[b] || a - b);
        let usableSurplus = [], surplusCourtsUsed = 0;
        if(courtsLeftForSurplus > 0) {
          [surplusM, surplusF].forEach(genderPool => {
            if(surplusCourtsUsed >= courtsLeftForSurplus) return;
            const courtsForThisGender = Math.min(Math.floor(genderPool.length / 4), courtsLeftForSurplus - surplusCourtsUsed);
            if(courtsForThisGender > 0) {
              usableSurplus.push(...byFew(genderPool).slice(0, courtsForThisGender * 4));
              surplusCourtsUsed += courtsForThisGender;
            }
          });
        }
        surplusCourtCount = surplusCourtsUsed;
        surplusPool = usableSurplus;
        byes = [...males, ...females].filter(i => !sortedM.slice(0,maxMixedPairs).includes(i) && !sortedF.slice(0,maxMixedPairs).includes(i) && !surplusPool.includes(i));
        pool = [...sortedM.slice(0, maxMixedPairs), ...sortedF.slice(0, maxMixedPairs)];
      } else {
        const playable = Math.min(activeIdxs.length - (activeIdxs.length % 4), cap);
        if(activeIdxs.length - playable > 0) {
          byes = [...activeIdxs].sort((a, b) => byeCnt[a] - byeCnt[b] || a - b).slice(0, activeIdxs.length - playable);
        }
        pool = activeIdxs.filter(i => !byes.includes(i));
      }
      byes.forEach(i => byeCnt[i]++);
      byes.forEach(i => roundByes.push(i));
      if(pool.length < 4 && surplusPool.length < 4) break;

      // pairPlayersFromPool + matchPairs ARE the engine generateSchedule uses.
      // Exception: 'roundrobin-partners' pairs by a positional rotation tied to the
      // original full pool and round index, which can't honor a mid-event roster change —
      // it would repeat partners. Use history-minimizing greedy pairing for its rebuild
      // so its no-repeat goal is still respected against the rounds already played.
      const pairs = pool.length >= 4
        ? ((mode === 'roundrobin-partners')
            ? buildNonRepeatPairs(pool, partner)
            : pairPlayersFromPool(state.players, pool, mode, partner, opp, keep + r))
        : [];
      pairs.forEach(([a, b]) => { partner[a][b]++; partner[b][a]++; });
      const mixedCourts = courts.slice(0, mixedCourtCount);
      const courtMatches = pairs.length >= 2
        ? matchPairs(pairs, opp, mixedCourtCount, mixedCourts, matchIdx, keep + r, mode)
        : [];
      matchIdx += courtMatches.length;

      // Surplus same-gender pairing on whatever courts are left over.
      let surplusPairs = [];
      let surplusCourtMatches = [];
      if(surplusPool.length >= 4) {
        surplusPairs = pairPlayersFromPool(state.players, surplusPool, 'balanced', partner, opp, keep + r);
        if(surplusPairs.length >= 2) {
          surplusPairs.forEach(([a, b]) => { partner[a][b]++; partner[b][a]++; });
          const surplusCourts = courts.slice(mixedCourtCount, mixedCourtCount + surplusCourtCount);
          surplusCourtMatches = matchPairs(surplusPairs, opp, surplusCourtCount, surplusCourts, matchIdx, keep + r, mode);
          matchIdx += surplusCourtMatches.length;
        } else {
          surplusPairs = [];
        }
      }

      [...courtMatches, ...surplusCourtMatches].forEach(([a, b, c, d, mid, court]) => {
        opp[a][c]++; opp[a][d]++; opp[b][c]++; opp[b][d]++;
        opp[c][a]++; opp[c][b]++; opp[d][a]++; opp[d][b]++;
        roundMatches.push({ id: mid, round: keep + r + 1, court, teamA: [a, b], teamB: [c, d],
                            scoreA: '', scoreB: '', complete: false });
        roundPairs.push([a, b], [c, d]);
      });
    }

    if(!roundMatches.length) break;
    newRounds.push(roundMatches);
    newByes.push(roundByes);
    newRoundTeams.push(roundPairs.map(([a, b]) => [state.players[a], state.players[b]]));
  }

  state.schedule   = kept.concat(newRounds);
  state.byeRounds  = keptByes.concat(newByes);
  state.roundTeams = (state.roundTeams || []).slice(0, keep).concat(newRoundTeams);
  applyPartnerLocks();
  // roundTeams must reflect any swaps applyPartnerLocks just made — rebuild
  // the upcoming portion straight from the corrected schedule rather than the
  // pre-fixup roundPairs collected during the build loop above.
  for(let r = keep; r < state.schedule.length; r++) {
    state.roundTeams[r] = state.schedule[r].map(m => [state.players[m.teamA[0]], state.players[m.teamA[1]]])
      .concat(state.schedule[r].map(m => [state.players[m.teamB[0]], state.players[m.teamB[1]]]));
  }
  state.teams = [];
  state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));
  state.notifiedRounds = new Set([...state.notifiedRounds].filter(r => r < keep));
  state.startedRounds  = new Set([...(state.startedRounds||[])].filter(r => r < keep));
  return newRounds.length || futureCount;
}

function clearPlayers() {
  if(!confirm('Remove all players?')) return;
  state.players = [];
  renderPlayers();
  autoSave();
}

// Sortable Players table. Sorting only affects DISPLAY ORDER — state.players itself
// stays untouched, since match/team data references players by their array index.
var PLAYER_SORT_KEY = 'pb_player_sort';

function getPlayerSort() {
  if(state._playerSort) return state._playerSort;
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(PLAYER_SORT_KEY) || 'null'); } catch(e) {}
  state._playerSort = saved || { col: null, dir: 1 };
  return state._playerSort;
}

function setPlayerSort(col) {
  const sort = getPlayerSort();
  if(sort.col === col) {
    sort.dir = -sort.dir; // toggle asc/desc
  } else {
    sort.col = col;
    sort.dir = 1;
  }
  try { localStorage.setItem(PLAYER_SORT_KEY, JSON.stringify(sort)); } catch(e) {}
  renderPlayers();
}

function playerSortIndicators() {
  const sort = getPlayerSort();
  ['num','name','gender','dupr','clubRating','club'].forEach(col => {
    const el = document.getElementById('sort-ind-' + col);
    if(!el) return;
    const th = el.closest('th');
    if(sort.col === col) {
      el.textContent = sort.dir === 1 ? '▲' : '▼';
      if(th) th.classList.add('sort-active');
    } else {
      el.textContent = '⇅';
      if(th) th.classList.remove('sort-active');
    }
  });
}

// Returns player indices (into state.players) in display order per current sort.
function sortedPlayerIndices() {
  const idxs = state.players.map((_, i) => i);
  const sort = getPlayerSort();
  if(!sort.col) return idxs; // unsorted = roster order

  const val = (p, i) => {
    switch(sort.col) {
      case 'num':        return i; // original roster position
      case 'name':       return (p.name || '').toLowerCase();
      case 'gender':     return (p.gender || '').toLowerCase();
      case 'dupr':       return (p.dupr != null && !isNaN(p.dupr)) ? p.dupr : null;
      case 'clubRating': return (p.clubRating != null && p.clubRating !== '' && !isNaN(parseFloat(p.clubRating))) ? parseFloat(p.clubRating) : null;
      case 'club':       return (p.club || '').toLowerCase();
      default:           return null;
    }
  };

  return idxs.sort((ia, ib) => {
    const a = val(state.players[ia], ia), b = val(state.players[ib], ib);
    // Nulls (missing values) always sort to the end, regardless of direction
    if(a == null && b == null) return ia - ib;
    if(a == null) return 1;
    if(b == null) return -1;
    let cmp;
    if(typeof a === 'string') cmp = a.localeCompare(b);
    else cmp = a - b;
    if(cmp === 0) return ia - ib; // stable tiebreak by original position
    return cmp * sort.dir;
  });
}

function renderPlayers() {
  renderWaitlist();
  const tbody = document.getElementById('players-body');
  // Roster stats exclude waitlisted players — they have their own count on the Waitlist card
  const rosterPlayers = state.players.filter(p => p.waitlist !== true);
  const male   = rosterPlayers.filter(p=>p.gender==='Male').length;
  const female = rosterPlayers.filter(p=>p.gender==='Female').length;
  const duprPlayers = rosterPlayers.filter(p=>p.dupr!=null&&!isNaN(p.dupr));
  const avgDupr = duprPlayers.length ? (duprPlayers.reduce((a,p)=>a+p.dupr,0)/duprPlayers.length).toFixed(2) : '—';
  const crPlayers = rosterPlayers.filter(p=>p.clubRating && !isNaN(parseFloat(p.clubRating)));
  const avgCR = crPlayers.length ? (crPlayers.reduce((a,p)=>a+parseFloat(p.clubRating),0)/crPlayers.length).toFixed(2) : '—';
  const active   = rosterPlayers.filter(p => p.active !== false).length;
  const inactive = rosterPlayers.length - active;
  document.getElementById('stat-total').textContent    = rosterPlayers.length;
  document.getElementById('stat-active').textContent   = active;
  document.getElementById('stat-inactive').textContent = inactive;
  document.getElementById('stat-male').textContent     = male;
  document.getElementById('stat-female').textContent   = female;
  document.getElementById('stat-avg-dupr').textContent = avgDupr;
  document.getElementById('stat-avg-cr').textContent   = avgCR;
  document.getElementById('stat-teams-ready').textContent = Math.floor(active / 2);
  renderDashboard();

  if(!rosterPlayers.length) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="empty-state"><div class="big">👥</div>No players yet — add some above or <a href="#" style="color:var(--lime)" onclick="loadSamples()">load sample data</a></div></td></tr>`;
    return;
  }

  playerSortIndicators();

  // Apply search filter (exclude waitlisted players — they're shown in the Waitlist card instead)
  const playerSearchQ = (document.getElementById('players-search')?.value || '').toLowerCase().trim();
  const allSortedIdxs = sortedPlayerIndices().filter(i => state.players[i].waitlist !== true);
  const filteredIdxs  = playerSearchQ
    ? allSortedIdxs.filter(i => {
        const p = state.players[i];
        return p.name.toLowerCase().includes(playerSearchQ)
          || (p.club || '').toLowerCase().includes(playerSearchQ)
          || (p.gender || '').toLowerCase().includes(playerSearchQ)
          || (String(p.clubRating || '')).includes(playerSearchQ)
          || (String(p.dupr || '')).includes(playerSearchQ);
      })
    : allSortedIdxs;

  // Show filter summary
  const filterSummaryEl = document.getElementById('players-filter-summary');
  if(filterSummaryEl) {
    if(playerSearchQ && filteredIdxs.length !== allSortedIdxs.length) {
      filterSummaryEl.textContent = `Showing ${filteredIdxs.length} of ${allSortedIdxs.length} players`;
      filterSummaryEl.style.display = '';
    } else {
      filterSummaryEl.style.display = 'none';
    }
  }

  tbody.innerHTML = filteredIdxs.map(i => {
    const p = state.players[i];
    if(p._editing) {
      return `<tr class="edit-row" id="edit-row-${p.id}">
        <td style="color:var(--txt3);font-size:0.78rem">${i+1}</td>
        <td></td>
        <td><input type="text"   id="edit-name-${p.id}"        value="${p.name}"            placeholder="Name"       style="width:140px"></td>
        <td><select id="edit-gender-${p.id}">
          <option value="Male"   ${p.gender==='Male'  ?'selected':''}>Male</option>
          <option value="Female" ${p.gender==='Female'?'selected':''}>Female</option>
        </select></td>
        <td><input type="number" id="edit-dupr-${p.id}"        value="${p.dupr??''}"        min="1" max="8" step="0.01" placeholder="—" style="width:72px"></td>
        <td><input type="text"   id="edit-clubrating-${p.id}"  value="${p.clubRating||''}"  placeholder="—"          style="width:72px"></td>
        <td><input type="text"   id="edit-club-${p.id}"        value="${p.club||''}"        placeholder="Club/City"  style="width:110px"></td>
        <td><input type="tel"    id="edit-phone-${p.id}"       value="${p.phone||''}"       placeholder="+1 555…"    style="width:125px"></td>
        <td><input type="email"  id="edit-email-${p.id}"       value="${p.email||''}"       placeholder="email"      style="width:150px"></td>
        <td colspan="2" style="white-space:nowrap">
          <button class="btn btn-primary btn-sm" onclick="savePlayerEdit(${p.id})">✓ Save</button>
          <button class="btn btn-secondary btn-sm" onclick="cancelPlayerEdit(${p.id})" style="margin-left:4px">✕</button>
        </td>
      </tr>`;
    }

    const duprTag = p.dupr!=null
      ? `<span style="font-family:'JetBrains Mono',monospace;font-size:0.8rem;color:#80CBC4">${p.dupr.toFixed(2)}</span>`
      : `<span style="color:var(--txt3)">—</span>`;
    const clubRatingTag = p.clubRating
      ? `<span style="font-family:'JetBrains Mono',monospace;font-size:0.8rem;color:#FFD54F">${p.clubRating}</span>`
      : `<span style="color:var(--txt3)">—</span>`;
    const phoneTag = p.phone
      ? `<span style="font-family:'JetBrains Mono',monospace;font-size:0.78rem;color:var(--lime)">${p.phone}</span>`
      : `<span style="color:var(--border);font-size:0.72rem">—</span>`;
    const emailTag = p.email
      ? `<span style="font-size:0.75rem;color:var(--txt2)">${escHtml(p.email)}</span>`
      : `<span style="color:var(--border);font-size:0.72rem">—</span>`;

    const left = p.active === false;
    return `<tr id="row-${p.id}" onclick="editPlayer(${p.id})" title="Click to edit" style="cursor:pointer;${left ? 'opacity:0.45' : ''}">
      <td style="color:var(--txt3);font-size:0.78rem">${i+1}</td>
      <td onclick="event.stopPropagation()" style="text-align:center">
        <input type="checkbox" ${p.checkedIn !== false ? 'checked' : ''} onchange="togglePlayerCheckedIn(${p.id})" title="Checked in tonight — uncheck if they haven't arrived yet" style="cursor:pointer;width:16px;height:16px">
      </td>
      <td style="font-weight:600">${p.name}${left ? ' <span style="background:rgba(239,83,80,0.2);color:var(--red);border-radius:4px;padding:1px 6px;font-size:0.65rem;font-weight:700;letter-spacing:0.5px">LEFT</span>' : ''}${p.checkedIn === false ? ' <span style="background:rgba(255,213,79,0.18);color:#FFD54F;border-radius:4px;padding:1px 6px;font-size:0.65rem;font-weight:700;letter-spacing:0.5px">NOT HERE YET</span>' : ''}</td>
      <td><span class="badge badge-${p.gender.toLowerCase()}">${p.gender}</span></td>
      <td>${duprTag}</td>
      <td>${clubRatingTag}</td>
      <td style="color:var(--txt3)">${p.club||'—'}</td>
      <td>${phoneTag}</td>
      <td>${emailTag}</td>
      <td style="white-space:nowrap" onclick="event.stopPropagation()">
        <button class="btn btn-secondary btn-sm" onclick="editPlayer(${p.id})" title="Edit">✏</button>
        <button class="btn btn-secondary btn-sm" onclick="movePlayerToWaitlist(${p.id})" title="Move to Waitlist" style="margin-left:2px">⏳</button>
        <button class="btn btn-secondary btn-sm" onclick="togglePlayerActive(${p.id})" title="${left ? 'Mark as returned' : 'Mark as left (kept in history, excluded from new rounds)'}" style="margin-left:2px">${left ? '▶' : '⏸'}</button>
        ${(() => {
          const lockId = getLockPartnerId(p.id);
          if(lockId) {
            const partnerName = state.players.find(x => x.id === lockId)?.name?.split(' ')[0] || '?';
            return `<button class="btn btn-sm" onclick="openLockPartnerModal(${p.id})" title="Locked with ${escHtml(partnerName)} — click to change or unlock" style="margin-left:2px;background:rgba(198,255,0,0.18);border:1px solid rgba(198,255,0,0.4);color:var(--lime)">🔗 ${escHtml(partnerName)}</button>`;
          }
          return `<button class="btn btn-secondary btn-sm" onclick="openLockPartnerModal(${p.id})" title="Lock partner for all upcoming rounds" style="margin-left:2px">🔗</button>`;
        })()}
      </td>
      <td onclick="event.stopPropagation()"><button class="btn btn-danger btn-sm" onclick="removePlayer(${p.id})" title="Remove">✕</button></td>
    </tr>`;
  }).join('');
}

function editPlayer(id) {
  // Cancel any other open edits first
  state.players.forEach(p => { if(p._editing) p._editing = false; });
  const p = state.players.find(p => p.id === id);
  if(!p) return;
  p._editing = true;
  state._editSkipBlurSave = false;
  renderPlayers();
  // Focus the name field
  const nameField = document.getElementById(`edit-name-${id}`);
  if(nameField) {
    nameField.focus(); nameField.select();
    // Allow Enter to save, Escape to cancel
    const handler = e => {
      if(e.key === 'Enter')  { savePlayerEdit(id); nameField.removeEventListener('keydown', handler); }
      if(e.key === 'Escape') { cancelPlayerEdit(id); nameField.removeEventListener('keydown', handler); }
    };
    nameField.addEventListener('keydown', handler);
  }
  // Autosave when focus leaves the row entirely (e.g. clicking elsewhere on the
  // page). relatedTarget is the element gaining focus — if it's still inside
  // this edit row (tabbing between fields), don't save yet.
  const editRow = document.getElementById(`edit-row-${id}`);
  if(editRow) {
    editRow.addEventListener('focusout', e => {
      if(state._editSkipBlurSave) return; // Escape/Cancel already handled this edit
      if(editRow.contains(e.relatedTarget)) return; // moved to another field in the same row
      // Defer slightly so a Cancel-button click (which also blurs the field)
      // has a chance to run cancelPlayerEdit first if that's what triggered this.
      setTimeout(() => {
        const stillEditing = state.players.find(pp => pp.id === id)?._editing;
        if(stillEditing) savePlayerEdit(id);
      }, 0);
    });
  }
}

function savePlayerEdit(id) {
  const p = state.players.find(p => p.id === id);
  if(!p) return;
  const name       = document.getElementById(`edit-name-${id}`)?.value.trim();
  const gender     = document.getElementById(`edit-gender-${id}`)?.value;
  const duprRaw    = document.getElementById(`edit-dupr-${id}`)?.value.trim();
  const clubRating = document.getElementById(`edit-clubrating-${id}`)?.value.trim();
  const club       = document.getElementById(`edit-club-${id}`)?.value.trim();
  const phone      = document.getElementById(`edit-phone-${id}`)?.value.trim() || '';
  const email      = document.getElementById(`edit-email-${id}`)?.value.trim() || '';

  if(!name)                               { toast("Name can't be empty","err"); return; }
  const duprNum = duprRaw ? parseFloat(duprRaw) : null;
  if(duprRaw && (isNaN(duprNum)||duprNum<1||duprNum>8)) { toast("DUPR must be 1.0–8.0","err"); return; }

  // Duplicate name check — exclude this player's own id
  if(state.players.some(q => q.id !== p.id && q.name.toLowerCase() === name.toLowerCase())) {
    toast(`"${name}" already exists on the roster`,"err"); return;
  }

  p.name       = name;
  p.gender     = gender;
  p.dupr       = duprNum;
  p.clubRating = clubRating;
  p.club       = club;
  p.phone      = phone;
  p.email      = email;
  delete p._editing;

  renderPlayers();
  autoSave();
  toast(`${name} updated!`);
}

function cancelPlayerEdit(id) {
  state._editSkipBlurSave = true; // don't let the row's focusout autosave fire after this
  const p = state.players.find(p => p.id === id);
  if(p) delete p._editing;
  renderPlayers();
}

// ── File import router — dispatches CSV vs Excel ─────────────────────────────
function importFile(event) {
  const file = event.target.files[0];
  if(!file) return;
  const ext = file.name.split('.').pop().toLowerCase();
  if(ext === 'xlsx' || ext === 'xls') {
    importXLSX(event);
  } else {
    importCSV(event);
  }
}

// ── Excel import (.xlsx / .xls) via SheetJS ──────────────────────────────────
function importXLSX(event) {
  const file = event.target.files[0];
  if(!file) return;

  if(typeof XLSX === 'undefined') {
    toast('Excel library not loaded yet — try again in a moment', 'err');
    return;
  }

  const reader = new FileReader();
  reader.onload = e => {
    let workbook;
    try {
      workbook = XLSX.read(e.target.result, { type: 'array' });
    } catch(err) {
      toast('Could not read Excel file — is it a valid .xlsx/.xls?', 'err');
      return;
    }

    // Use the first sheet
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];

    // Convert to array-of-arrays (raw values, no type coercion)
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
    if(!rows.length) { toast('Excel sheet appears empty', 'err'); return; }

    // ── Normalise gender (shared with CSV path) ───────────────────────────
    function normaliseGender(raw) {
      const s = (raw || '').toString().trim().toLowerCase();
      if(['male','m','man','boy'].includes(s)) return 'Male';
      if(['female','f','woman','girl','lady'].includes(s)) return 'Female';
      return null;
    }

    let added = 0, skipped = 0, dupes = 0, updated = 0;
    const updateExisting = document.getElementById('import-update-existing')?.checked;

    rows.forEach((cols, rowIdx) => {
      // Auto-detect and skip header row
      if(rowIdx === 0) {
        const first = (cols[0] || '').toString().toLowerCase().trim();
        if(['name','player','full name','#','no'].includes(first)) return;
      }

      const name = (cols[0] || '').toString().trim();
      if(!name) { skipped++; return; }

      // Column order: Name, Gender, DUPR, ClubRating, Club, Phone, Email
      const genderRaw  = (cols[1] || '').toString();
      const duprRaw    = (cols[2] || '').toString().trim();
      const clubRating = (cols[3] || '').toString().trim();
      const club       = (cols[4] || '').toString().trim();
      // Phone: Excel may store as number — convert back to string
      const phone      = (cols[5] !== undefined && cols[5] !== '') ? String(cols[5]).trim() : '';
      const email      = (cols[6] || '').toString().trim();

      const duprNum = duprRaw ? parseFloat(duprRaw) : null;
      const duprVal = (duprNum !== null && !isNaN(duprNum) && duprNum > 0) ? duprNum : null;

      const existing = state.players.find(p => p.name.toLowerCase() === name.toLowerCase());
      if(existing) {
        if(updateExisting) {
          // Only touch DUPR if this row actually has a value — never blank out
          // an existing rating just because a refreshed sheet left it empty.
          if(duprVal !== null) existing.dupr = duprVal;
          updated++;
        } else {
          dupes++;
        }
        return;
      }

      const gender  = normaliseGender(genderRaw) || genderRaw.trim() || '';

      state.players.push({
        id: Date.now() + Math.random(),
        name, gender, rating: null,
        dupr: duprVal,
        clubRating,
        club,
        phone,
        email,
      });
      added++;
    });

    let rebuilt = 0;
    if(added && state.schedule.length) {
      rebuilt = rebuildUpcomingRounds();
      renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
      if(typeof smsPopRounds === 'function') smsPopRounds();
    }
    renderPlayers();
    autoSave();

    let msg = added + ' player' + (added !== 1 ? 's' : '') + ' imported from ' + sheetName;
    if(updated > 0) msg += ' · ' + updated + ' player' + (updated > 1 ? 's' : '') + ' updated';
    if(dupes > 0)   msg += ' · ' + dupes + ' duplicate' + (dupes > 1 ? 's' : '') + ' skipped';
    if(skipped > 0) msg += ' · ' + skipped + ' empty row' + (skipped > 1 ? 's' : '') + ' skipped';
    if(rebuilt > 0) msg += ' · added to ' + rebuilt + ' upcoming round' + (rebuilt > 1 ? 's' : '');
    if(added === 0 && updated === 0 && dupes === 0) msg = '⚠️ No players found — check column order: Name, Gender, DUPR, ClubRating, Club, Phone, Email';

    toast(msg, (added > 0 || updated > 0) ? '' : 'err');
  };
  reader.readAsArrayBuffer(file);
  event.target.value = '';
}

function importCSV(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const raw = e.target.result;

    // ── Proper CSV parser: handles quoted fields containing commas/newlines ──
    function parseCSVRow(line) {
      const cols = [];
      let cur = '', inQ = false;
      for(let i = 0; i < line.length; i++) {
        const ch = line[i];
        if(ch === '"') {
          if(inQ && line[i+1] === '"') { cur += '"'; i++; } // escaped quote
          else inQ = !inQ;
        } else if(ch === ',' && !inQ) {
          cols.push(cur.trim()); cur = '';
        } else {
          cur += ch;
        }
      }
      cols.push(cur.trim());
      return cols;
    }

    // Split into lines, respecting quoted newlines
    const allLines = [];
    let curLine = '', inQ2 = false;
    for(const ch of raw) {
      if(ch === '"') inQ2 = !inQ2;
      if((ch === '\n' || ch === '\r') && !inQ2) {
        if(curLine.trim()) allLines.push(curLine);
        curLine = '';
      } else {
        curLine += ch;
      }
    }
    if(curLine.trim()) allLines.push(curLine);

    // ── Normalise gender ──────────────────────────────────────────────────
    function normaliseGender(raw) {
      const s = (raw || '').trim().toLowerCase();
      if(['male','m','man','boy'].includes(s)) return 'Male';
      if(['female','f','woman','girl','lady'].includes(s)) return 'Female';
      return null; // unrecognised — still import, leave blank
    }

    let added = 0, skipped = 0, dupes = 0, updated = 0;
    const skippedNames = [];
    const updateExisting = document.getElementById('import-update-existing')?.checked;

    allLines.forEach((line, lineIdx) => {
      const cols = parseCSVRow(line);
      if(cols.length < 1) return;

      // Auto-detect and skip header row
      if(lineIdx === 0) {
        const first = (cols[0] || '').toLowerCase().trim();
        if(['name','player','full name','#','no'].includes(first)) return;
      }

      const name = (cols[0] || '').trim();
      if(!name) return;

      // Column order: Name, Gender, DUPR, ClubRating, Club, Phone, Email
      const genderRaw  = cols[1] || '';
      const duprRaw    = (cols[2] || '').trim();
      const clubRating = (cols[3] || '').trim();
      const club       = (cols[4] || '').trim();
      const phone      = (cols[5] || '').trim();
      const email      = (cols[6] || '').trim();

      const duprNum = duprRaw ? parseFloat(duprRaw) : null;
      const duprVal = (duprNum !== null && !isNaN(duprNum) && duprNum > 0) ? duprNum : null;

      const existing = state.players.find(p => p.name.toLowerCase() === name.toLowerCase());
      if(existing) {
        if(updateExisting) {
          // Only touch DUPR if this row actually has a value — never blank out
          // an existing rating just because a refreshed sheet left it empty.
          if(duprVal !== null) existing.dupr = duprVal;
          updated++;
        } else {
          dupes++;
        }
        return;
      }

      const gender = normaliseGender(genderRaw) || genderRaw.trim() || '';

      // Only require name — gender/DUPR optional
      if(!name) { skipped++; return; }

      state.players.push({
        id: Date.now() + Math.random(),
        name, gender, rating: null,
        dupr: duprVal,
        clubRating,
        club,
        phone,
        email,
      });
      added++;
    });

    let rebuilt = 0;
    if(added && state.schedule.length) {
      rebuilt = rebuildUpcomingRounds();
      renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
      if(typeof smsPopRounds === 'function') smsPopRounds();
    }
    renderPlayers();
    autoSave();

    let msg = added + ' player' + (added !== 1 ? 's' : '') + ' imported';
    if(updated > 0)  msg += ' · ' + updated + ' player' + (updated > 1 ? 's' : '') + ' updated';
    if(dupes > 0)    msg += ' · ' + dupes + ' duplicate' + (dupes > 1 ? 's' : '') + ' skipped';
    if(skipped > 0)  msg += ' · ' + skipped + ' row' + (skipped > 1 ? 's' : '') + ' skipped (no name)';
    if(rebuilt > 0)  msg += ' · added to ' + rebuilt + ' upcoming round' + (rebuilt > 1 ? 's' : '');
    if(added === 0 && updated === 0 && dupes === 0) msg = '⚠️ No players found — check CSV format (Name, Gender, DUPR, ClubRating, Club, Phone, Email)';

    toast(msg, (added > 0 || updated > 0) ? '' : 'err');
  };
  reader.readAsText(file);
  event.target.value = '';
}

// ═══════════════════════════════════════════════

// ── Player management ─────────────────────────────────────
//  TEAMS (rotating — re-paired every round)
// ═══════════════════════════════════════════════

// state.teams is now per-round: state.roundTeams[roundIndex] = [{p1, p2}, ...]
// state.teams kept as alias to roundTeams[0] for backward compat with player stats


// ── Partner Mode Assistant ───────────────────────────────────────────────
function getActivePlayerSummaryForPartnerMode() {
  const active = (state.players || []).filter(p => p.active !== false && p.waitlist !== true && p.checkedIn !== false);
  const male = active.filter(p => p.gender === 'Male').length;
  const female = active.filter(p => p.gender === 'Female').length;
  const rated = active.filter(p => p.dupr != null || p.clubRating).length;
  const courts = Math.max(0, (state.selectedCourts && state.selectedCourts.size) ? state.selectedCourts.size : (parseInt(document.getElementById('courts-count')?.value) || 0));
  return { active, count: active.length, male, female, rated, courts };
}

function validateFixedTeams(showToast) {
  const messages = [];
  const pairs = state.fixedTeams || [];
  const seen = new Map();
  let complete = 0;
  pairs.forEach((pair, teamIdx) => {
    if(!pair || pair[0] == null || pair[1] == null) return;
    complete++;
    if(pair[0] === pair[1]) messages.push(`Team ${teamIdx+1} has the same player twice.`);
    pair.forEach(pi => {
      if(pi == null) return;
      if(seen.has(pi)) messages.push(`${state.players[pi]?.name || 'A player'} is assigned to more than one team.`);
      seen.set(pi, teamIdx);
    });
  });
  const activeIdxs = (state.players || []).map((p,i)=>i).filter(i => state.players[i].active !== false && state.players[i].waitlist !== true && state.players[i].checkedIn !== false);
  const unassigned = activeIdxs.filter(i => !seen.has(i));
  if(complete < 2) messages.push('Complete at least 2 teams before generating Fixed Teams.');
  if(unassigned.length) messages.push(`${unassigned.length} active player${unassigned.length===1?' is':'s are'} not assigned to a fixed team.`);
  if(messages.length && showToast) toast(messages[0], 'err');
  return { ok: messages.length === 0, messages };
}

function partnerModeStatus() {
  const mode = document.getElementById('team-mode')?.value || 'random';
  const s = getActivePlayerSummaryForPartnerMode();
  const locks = state.partnerLocks || [];
  const msgs = [];
  let status = 'Good';
  let icon = '✅';
  let recommended = '';

  if(s.count < 4) {
    status = 'Needs players'; icon = '⚠️';
    msgs.push('Add at least 4 active/check-in players before generating a schedule.');
  }
  if(mode.includes('mixed')) {
    if(s.male === 0 || s.female === 0) {
      status = 'Mixed unavailable'; icon = '⚠️';
      msgs.push('Mixed mode needs both Male and Female players.');
    } else if(s.male !== s.female) {
      status = 'Best effort mixed'; icon = '⚠️';
      msgs.push(`Mixed mode will use the best available draw (${s.male} male, ${s.female} female). No players are forced to standby.`);
    } else {
      msgs.push('Gender balance is even, so mixed mode should reach 100% compliance if court capacity allows.');
    }
  }
  if(mode === 'roundrobin-partners' || mode === 'americano') {
    if(s.count % 2 !== 0) {
      status = 'Rotating with byes'; icon = '⚠️';
      msgs.push('An odd player count means one player must sit each round, so everyone-partners-everyone may take longer.');
    } else {
      msgs.push('This is the best mode when the goal is maximum partner variety.');
    }
  }
  if(mode === 'fixed-teams') {
    const v = validateFixedTeams(false);
    if(!v.ok) { status = 'Fix teams first'; icon = '⚠️'; msgs.push(...v.messages); }
    else msgs.push('Fixed teams are complete. Teams will stay together for the full round-robin.');
  }
  if(locks.length && !['fixed-teams','king','shootout'].includes(mode)) {
    status = 'Partner locks active'; icon = '⚠️';
    msgs.push(`${locks.length} locked partnership${locks.length===1?'':'s'} will override normal partner rotation. This can reduce fairness/variety.`);
  }

  if(!recommended) {
    if(s.count <= 8) recommended = 'For a small group, use Round Robin Partners or Americano for maximum variety.';
    else if(s.male && s.female && Math.abs(s.male - s.female) <= 2) recommended = 'For mixed events, use Competitive Mixed if ratings matter, or Mixed if the goal is social rotation.';
    else if(s.rated >= Math.max(4, Math.floor(s.count * 0.7))) recommended = 'For skill balance, use Balanced, Equalizer, or DUPR Session.';
    else recommended = 'For a casual club night, Random/Chapeau is simple; Round Robin Partners gives better variety.';
  }
  return { mode, status, icon, messages: msgs, recommended, summary: s };
}


function mbModeLabel(mode) {
  const sel = document.getElementById('team-mode');
  if(!sel) return mode || '';
  const opt = Array.from(sel.options).find(o => o.value === mode);
  return opt ? opt.textContent.replace(/^[^A-Za-z0-9]+\s*/, '') : (mode || '');
}

function mbSetMode(mode) {
  const sel = document.getElementById('team-mode');
  if(!sel) return;
  sel.value = mode;
  onModeChange();
  toast('Schedule mode set to ' + mbModeLabel(mode));
}

function mbModeCategory(mode) {
  if(['mixed','mixed-rated','competitive-mixed'].includes(mode)) return 'mixed';
  if(['balanced','equalizer','progressive','snake','dupr'].includes(mode)) return 'balanced';
  if(['roundrobin-partners','americano'].includes(mode)) return 'rotation';
  if(mode === 'fixed-teams') return 'fixed';
  if(['king','shootout'].includes(mode)) return 'movement';
  return 'social';
}

function mbPartnerHealth() {
  let a = null;
  try { if(typeof buildFairnessAnalysis === 'function') a = buildFairnessAnalysis(); } catch(e) { a = null; }
  const repeatsP = a ? a.repeatsP.length : 0;
  const highOpp = a ? a.repeatsO.filter(x => Number(x[1]) >= 3).length : 0;
  const acceptableOpp = a ? a.repeatsO.filter(x => Number(x[1]) === 2).length : 0;
  const sitGap = a ? a.sitGap : 0;
  let status = 'Excellent', icon = '🟢', message = 'Partner rotation looks healthy.';
  if(repeatsP > 0) { status = 'Review'; icon = '🟡'; message = `${repeatsP} repeated partner pairing${repeatsP===1?'':'s'} found.`; }
  if(highOpp > 0) { status = 'Review'; icon = '🟡'; message = `${highOpp} high-repeat opponent matchup${highOpp===1?'':'s'} should be avoided.`; }
  if(sitGap >= 3) { status = 'Action needed'; icon = '🔴'; message = `${(a && a.mostSat ? a.mostSat.length : 0)} players have waited much longer than the rest. Put them on court first next round.`; }
  return { status, icon, message, repeatsP, highOpp, acceptableOpp, sitGap, analysis:a };
}


function mbApplyPreset(preset) {
  const presets = {
    balanced: {
      mode: 'balanced',
      label: 'Balanced Play',
      note: 'Balanced Play selected: rotate partners, reduce repeats, balance ratings, and prioritize wait time.'
    },
    mixed: {
      mode: 'competitive-mixed',
      label: 'Mixed Doubles',
      note: 'Mixed Doubles selected: prefer mixed teams and warn if 100% mixed compliance is not possible. Players are not put on standby.'
    },
    competitive: {
      mode: 'dupr',
      label: 'Competitive Ladder',
      note: 'Competitive Ladder selected: use ratings/DUPR style balancing with stronger fairness checks.'
    }
  };
  const cfg = presets[preset] || presets.balanced;
  const sel = document.getElementById('team-mode');
  if (sel) {
    const hasMode = Array.from(sel.options).some(o => o.value === cfg.mode);
    sel.value = hasMode ? cfg.mode : 'balanced';
    try { onModeChange(); } catch(e) {}
  }
  try { localStorage.setItem('pb_match_builder_preset', preset); } catch(e) {}
  toast('Schedule preset: ' + cfg.label);
  renderScheduleBuilderPanel();
}

function mbPresetCards(activePreset) {
  const cards = [
    ['balanced','🟢 Balanced Play','Best default for club sessions','Rotates partners, reduces repeats, prioritizes wait time, and balances ratings.'],
    ['mixed','🌈 Mixed Doubles','Best for social mixed events','Prefers mixed teams and clearly warns when 100% mixed is not possible. No standby needed.'],
    ['competitive','🏆 Competitive Ladder','Best for rated / DUPR play','Uses rating-first scheduling with fairness checks for competitive sessions.']
  ];
  return `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.65rem;margin:.75rem 0">
    ${cards.map(([key,title,subtitle,desc])=>`<button class="mb-preset-card ${activePreset===key?'active':''}" onclick="mbApplyPreset('${key}')" style="text-align:left;background:${activePreset===key?'rgba(198,255,0,.13)':'rgba(255,255,255,.035)'};border:1px solid ${activePreset===key?'rgba(198,255,0,.55)':'var(--border)'};border-radius:13px;padding:.8rem;cursor:pointer;color:var(--txt)">
      <div style="font-weight:900;font-size:.95rem">${title}</div>
      <div style="font-size:.76rem;color:var(--txt2);margin:.2rem 0 .35rem">${subtitle}</div>
      <div style="font-size:.76rem;color:var(--txt3);line-height:1.35">${desc}</div>
    </button>`).join('')}
  </div>`;
}

function renderScheduleBuilderPanel() {
  const boxes = ['match-builder-panel','match-builder-tab-panel'].map(id => document.getElementById(id)).filter(Boolean);
  if(!boxes.length) return;
  const box = boxes[0];
  const r = partnerModeStatus();
  const s = r.summary;
  const mode = r.mode || 'random';
  const category = mbModeCategory(mode);
  const health = mbPartnerHealth();
  let activePreset = 'balanced';
  try { activePreset = localStorage.getItem('pb_match_builder_preset') || 'balanced'; } catch(e) {}
  if(category === 'mixed') activePreset = 'mixed';
  else if(['balanced','dupr'].includes(mode)) activePreset = (mode === 'dupr') ? 'competitive' : activePreset;
  const warnings = [];
  const actions = [];
  if(r.messages && r.messages.length) warnings.push(...r.messages);
  if(s.count % 4 !== 0) warnings.push(`${s.count} active players means byes/sit-outs may be required depending on court capacity.`);
  if(category === 'mixed' && s.male !== s.female) warnings.push(`Mixed mode is best-effort with ${s.male} male / ${s.female} female. Players are not put on standby.`);
  if((state.partnerLocks || []).length) warnings.push(`${state.partnerLocks.length} partner lock${state.partnerLocks.length===1?'':'s'} active. Locks can reduce partner variety.`);
  if(health.sitGap >= 3) {
    const names = (health.analysis && health.analysis.mostSat ? health.analysis.mostSat.slice(0,6).map(x=>x.name).join(', ') : 'priority players');
    actions.push('Schedule the longest-waiting players first next round: ' + names + '.');
  }
  if(health.repeatsP > 0) actions.push('Avoid repeated partners in the next round if possible.');
  if(health.highOpp > 0) actions.push('Avoid high-repeat opponent matchups.');
  if(!actions.length) actions.push('Current setup looks usable. Generate the next best round, then review the fairness result.');

  const strategies = [
    ['random','🎲 Social / random draw'],
    ['roundrobin-partners','🔄 Rotate partners every round'],
    ['mixed','♀♂ Mixed teams'],
    ['competitive-mixed','♀♂⚖️ Competitive mixed'],
    ['balanced','⚖️ Skill-balanced partners'],
    ['equalizer','🧩 Equalizer: strong + developing'],
    ['fixed-teams','🔒 Fixed partners / couples / league teams'],
    ['shootout','🎯 Shootout / King-Queen rotation']
  ];

  const checks = [
    [s.count >= 4, 'Enough active players', `${s.count} active`],
    [category !== 'mixed' || (s.male > 0 && s.female > 0), 'Mixed eligibility', `${s.male}M / ${s.female}F`],
    [health.repeatsP === 0, 'Partner repeats', health.repeatsP ? `${health.repeatsP} repeat${health.repeatsP===1?'':'s'}` : 'none'],
    [health.highOpp === 0, 'High opponent repeats', health.highOpp ? `${health.highOpp} high repeat${health.highOpp===1?'':'s'}` : 'none'],
    [health.sitGap <= 2, 'Wait-time balance', health.sitGap <= 2 ? 'balanced' : `${(health.analysis && health.analysis.mostSat ? health.analysis.mostSat.length : 0)} waiting longest`]
  ];

  box.innerHTML = `
    <div style="background:linear-gradient(135deg,rgba(198,255,0,0.08),rgba(255,255,255,0.025));border:1px solid rgba(198,255,0,0.24);border-radius:14px;padding:0.95rem 1rem">
      <div style="display:flex;justify-content:space-between;gap:0.75rem;align-items:flex-start;flex-wrap:wrap;margin-bottom:0.8rem">
        <div>
          <div style="font-family:'Bebas Neue',sans-serif;font-size:1.25rem;color:var(--lime);letter-spacing:.3px">📅 Schedule Builder</div>
          <div style="color:var(--txt2);font-size:.84rem;margin-top:.1rem">Choose a preset, review warnings, then generate the next best round.</div>
        </div>
        <div style="text-align:right">
          <div style="font-weight:900;color:var(--txt)">${health.icon} ${escHtml(health.status)}</div>
          <div style="font-size:.76rem;color:var(--txt3)">${escHtml(health.message)}</div>
        </div>
      </div>

      <div style="margin-bottom:.35rem">
        <div style="font-size:.72rem;color:var(--txt3);font-weight:800;text-transform:uppercase;letter-spacing:.6px;margin-bottom:.25rem">1. Choose a preset</div>
        ${mbPresetCards(activePreset)}
      </div>

      <details style="margin-bottom:.75rem;background:rgba(0,0,0,.13);border:1px solid var(--border);border-radius:12px;padding:.65rem .75rem">
        <summary style="cursor:pointer;font-weight:900;color:var(--txt)">2. Optional advanced rules</summary>
        <div style="margin-top:.65rem">
          <select id="mb-strategy" onchange="mbSetMode(this.value)" style="width:100%;font-size:.85rem;padding:.45rem .55rem">
            ${strategies.map(([v,l])=>`<option value="${v}" ${mode===v?'selected':''}>${l}</option>`).join('')}
          </select>
          <div style="font-size:.76rem;color:var(--txt3);margin-top:.45rem">Current: ${escHtml(mbModeLabel(mode))}</div>
        </div>
      </details>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.65rem;margin-bottom:.75rem">
        <div style="background:rgba(0,0,0,.18);border:1px solid var(--border);border-radius:10px;padding:.75rem">
          <div style="font-size:.72rem;color:var(--txt3);font-weight:800;text-transform:uppercase;letter-spacing:.6px">Players / Courts</div>
          <div style="font-size:1.25rem;font-weight:900;margin-top:.25rem;color:var(--txt)">${s.count} players · ${s.courts} courts</div>
          <div style="font-size:.76rem;color:var(--txt3);margin-top:.25rem">${s.male} male · ${s.female} female · ${s.rated} rated</div>
        </div>
        <div style="background:rgba(0,0,0,.18);border:1px solid var(--border);border-radius:10px;padding:.75rem">
          <div style="font-size:.72rem;color:var(--txt3);font-weight:800;text-transform:uppercase;letter-spacing:.6px">Suggested action</div>
          <div style="font-size:.84rem;color:var(--txt);margin-top:.35rem;line-height:1.45">${actions.map(a=>`💡 ${escHtml(a)}`).join('<br>')}</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:.45rem;margin-bottom:.75rem">
        ${checks.map(([ok,label,detail])=>`<div style="border:1px solid ${ok?'rgba(102,187,106,.35)':'rgba(249,168,37,.45)'};background:${ok?'rgba(102,187,106,.08)':'rgba(249,168,37,.08)'};border-radius:9px;padding:.55rem .65rem;font-size:.8rem"><strong>${ok?'✅':'⚠️'} ${escHtml(label)}</strong><br><span style="color:var(--txt3)">${escHtml(detail)}</span></div>`).join('')}
      </div>

      ${warnings.length ? `<div style="background:rgba(249,168,37,.08);border:1px solid rgba(249,168,37,.35);border-radius:10px;padding:.65rem .75rem;color:var(--txt);font-size:.82rem;line-height:1.5;margin-bottom:.75rem"><strong style="color:var(--ball)">Warnings / notes</strong><br>${warnings.slice(0,5).map(w=>`• ${escHtml(w)}`).join('<br>')}</div>` : ''}

      <div style="display:flex;gap:.5rem;flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" onclick="promptGenerateSchedule()">⚡ 🚀 Generate Next Best Round</button>
        <button class="btn btn-secondary btn-sm" onclick="renderScheduleBuilderPanel();toast('Schedule checks refreshed')">🔍 Refresh Checks</button>
        <button class="btn btn-secondary btn-sm" onclick="showPartnerModeHelp()">Which mode?</button>
        <button class="btn btn-secondary btn-sm" onclick="renderSchedule();document.getElementById('schedule-output')?.scrollIntoView({behavior:'smooth'});">Review Current Schedule</button>
      </div>
    </div>`;
  boxes.slice(1).forEach(b => { b.innerHTML = box.innerHTML; });
}

function renderPartnerModeAssistant() {
  try { if(typeof renderMatchBuilderPanel === 'function') renderScheduleBuilderPanel(); } catch(e) { console.warn('Schedule Builder render failed', e); }
  const box = document.getElementById('partner-mode-assistant');
  if(!box) return;
  const r = partnerModeStatus();
  const s = r.summary;
  box.innerHTML = `
    <div style="background:rgba(255,255,255,0.035);border:1px solid var(--border);border-radius:12px;padding:0.75rem 0.9rem">
      <div style="display:flex;justify-content:space-between;gap:0.75rem;align-items:flex-start;flex-wrap:wrap">
        <div>
          <div style="font-weight:900;color:var(--lime);font-size:0.95rem">🤝 Partner Mode Assistant</div>
          <div style="color:var(--txt2);font-size:0.82rem;margin-top:0.15rem">${r.icon} ${escHtml(r.status)} · ${s.count} active players · ${s.male}M / ${s.female}F · ${s.courts} courts</div>
        </div>
        <button class="btn btn-secondary btn-sm" onclick="showPartnerModeHelp()">Which mode?</button>
      </div>
      <div style="margin-top:0.55rem;color:var(--txt);font-size:0.84rem;line-height:1.45">
        ${(r.messages.length?r.messages:['Current partner mode looks usable.']).map(m=>`<div>• ${escHtml(m)}</div>`).join('')}
        <div style="margin-top:0.35rem;color:var(--txt3)">Suggestion: ${escHtml(r.recommended)}</div>
      </div>
    </div>`;
}

function showPartnerModeHelp() {
  alert('Partner mode guide:\n\n• Random / Chapeau: casual draw, simple and social.\n• Round Robin Partners: best partner variety; everyone partners everyone when possible.\n• Mixed / Competitive Mixed: maximizes mixed pairings; warns if 100% mixed is not possible.\n• Balanced / Equalizer / DUPR: best for skill-balanced games.\n• Fixed Teams: permanent partners for leagues/couples/corporate events.\n• Shootout / King-Queen: court movement with partners rotating every round.');
}

function renderTeams() {
  renderPartnerModeAssistant();
  const searchTerm = (document.getElementById('teams-search')?.value || '').trim().toLowerCase();
  const container = document.getElementById('teams-container');

  if(!state.roundTeams || !state.roundTeams.length) {
    document.getElementById('teams-count').textContent = 0;
    container.innerHTML = '<div class="empty-state"><div class="big">🤝</div>Generate the schedule to see rotating partnerships per round</div>';
    return;
  }

  let totalShown = 0;
  const roundsHtml = state.roundTeams.map((roundPairs, ri) => {
    const byePlayersAll = (state.byeRounds || [])[ri] || [];

    // Filter pairs and byes to the search term (matches if EITHER player's name contains it)
    const matchedPairs = searchTerm
      ? roundPairs.filter(([p1, p2]) => p1.name.toLowerCase().includes(searchTerm) || p2.name.toLowerCase().includes(searchTerm))
      : roundPairs;
    const matchedByes = searchTerm
      ? byePlayersAll.filter(pi => (state.players[pi]?.name || '').toLowerCase().includes(searchTerm))
      : byePlayersAll;

    // Skip this round entirely if searching and nothing in it matches
    if(searchTerm && !matchedPairs.length && !matchedByes.length) return '';

    totalShown += matchedPairs.length;
    const byePlayers = matchedByes;
    const byeHtml = byePlayers.length ? `
      <div style="display:flex;align-items:center;gap:0.5rem;padding:0.5rem 0.75rem;background:rgba(249,168,37,0.06);border-radius:8px;margin-bottom:0.5rem;flex-wrap:wrap">
        <span style="background:rgba(249,168,37,0.2);color:var(--ball);border-radius:4px;padding:2px 8px;font-size:0.75rem;font-weight:700;white-space:nowrap">🪑 BYE</span>
        ${byePlayers.map(pi => {
          const p = state.players[pi];
          return `<span style="background:rgba(249,168,37,0.1);border:1px solid rgba(249,168,37,0.3);border-radius:20px;padding:2px 10px;font-size:0.78rem;font-weight:600;color:var(--ball)">${p?.name||'?'} <span style="color:var(--txt3)">${pRatingLabel(p)||''}</span></span>`;
        }).join('')}
      </div>` : '';

    const rows = matchedPairs.map((pair, pi) => {
      const p1 = pair[0], p2 = pair[1];
      const nr = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
      const duprOf = p => (p?.dupr != null && !isNaN(p.dupr)) ? p.dupr : null;
      const d1 = duprOf(p1), d2 = duprOf(p2);
      const hasNR = d1 == null || d2 == null; // at least one player using NR fallback
      const avgDupr = (d1 != null || d2 != null)
        ? (((d1 ?? nr) + (d2 ?? nr)) / 2).toFixed(2)
        : null;
      const crVals = [parseFloat(p1?.clubRating), parseFloat(p2?.clubRating)].filter(v => !isNaN(v));
      const avgCR = crVals.length ? (crVals.reduce((a,v)=>a+v,0)/crVals.length).toFixed(2) : null;
      const avg = avgDupr && avgCR
        ? `<span style="color:#80CBC4">D ${avgDupr}${hasNR?' <span title="includes NR provisional" style="font-size:0.65rem;opacity:0.7">~</span>':''}</span><br><span style="color:#FFD54F;font-size:0.85rem">CR ${avgCR}</span>`
        : avgDupr
          ? `<span style="color:#80CBC4">D ${avgDupr}${hasNR?' <span title="includes NR provisional" style="font-size:0.65rem;opacity:0.7">~</span>':''}</span>`
          : avgCR
            ? `<span style="color:#FFD54F">CR ${avgCR}</span>`
            : '—';
      const type = p1.gender !== p2.gender ? 'Mixed' : p1.gender;

      const highlightName = (name) => {
        if(!searchTerm) return escHtml(name);
        const idx = name.toLowerCase().indexOf(searchTerm);
        if(idx === -1) return escHtml(name);
        return escHtml(name.slice(0, idx)) + '<mark style="background:rgba(198,255,0,0.35);color:inherit;border-radius:2px">' + escHtml(name.slice(idx, idx + searchTerm.length)) + '</mark>' + escHtml(name.slice(idx + searchTerm.length));
      };

      const ratingTag = (p) => {
        const d = duprOf(p);
        const cr = p?.clubRating;
        const duprStr = d != null
          ? `<span style="color:#80CBC4">DUPR ${d.toFixed(2)}</span>`
          : `<span style="color:var(--txt3);background:rgba(255,255,255,0.08);border-radius:3px;padding:1px 4px" title="No DUPR on file — using NR ${nr} as provisional">NR ${nr}</span>`;
        const crStr = cr ? ` <span style="color:#FFD54F">CR ${escHtml(cr)}</span>` : '';
        return `<span style="font-family:'JetBrains Mono',monospace;font-size:0.75rem;margin-left:6px">${duprStr}${crStr}</span>`;
      };


      return `<tr>
        <td style="font-family:'Bebas Neue',sans-serif;font-size:1.1rem;color:var(--lime)">${pi+1}</td>
        <td>
          <span style="font-weight:600">${highlightName(p1.name)}</span>
          <span class="badge badge-${p1.gender.toLowerCase()}" style="margin-left:6px">${p1.gender}</span>
          ${ratingTag(p1)}
        </td>
        <td>
          <span style="font-weight:600">${highlightName(p2.name)}</span>
          <span class="badge badge-${p2.gender.toLowerCase()}" style="margin-left:6px">${p2.gender}</span>
          ${ratingTag(p2)}
        </td>
        <td><span class="badge badge-${type==='Mixed'?'mixed':type.toLowerCase()}">${type}</span></td>
        <td style="font-family:'Bebas Neue',sans-serif;font-size:1rem;color:var(--ball);line-height:1.4">${avg}</td>
      </tr>`;
    }).join('');
    const tableHtml = matchedPairs.length ? `
      <div class="tbl-wrap" style="margin-bottom:0.5rem">
      <table>
        <thead><tr><th>#</th><th>Player 1</th><th>Player 2</th><th>Type</th><th>Team Avg</th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>` : '';
    return `
      <div class="round-header" style="margin-top:${ri?'1rem':'0'}">Round ${ri+1} Partnerships${byePlayersAll.length?` <span style="color:var(--ball);font-size:0.85rem;font-family:'DM Sans',sans-serif;font-weight:600">(${byePlayersAll.length} on bye)</span>`:''}</div>
      ${byeHtml}
      ${tableHtml}`;
  }).join('');

  document.getElementById('teams-count').textContent = searchTerm
    ? totalShown + ' of ' + state.roundTeams.reduce((a,r)=>a+r.length,0)
    : state.roundTeams.reduce((a,r)=>a+r.length,0);

  if(searchTerm && totalShown === 0 && !state.roundTeams.some((rp, ri) => ((state.byeRounds||[])[ri]||[]).some(pi => (state.players[pi]?.name||'').toLowerCase().includes(searchTerm)))) {
    container.innerHTML = `<div class="empty-state"><div class="big">🔍</div>No player matching "${escHtml(document.getElementById('teams-search').value)}" found in any round</div>`;
    return;
  }

  container.innerHTML = roundsHtml;
}

function exportTeamsCSV() {
  if(!state.roundTeams || !state.roundTeams.length) { toast("Generate schedule first","err"); return; }
  const rows = [[getTournamentName()],['Round','Pair#','Player1','Gender1','DUPR1','ClubRating1','Player2','Gender2','DUPR2','ClubRating2','TeamAvgDUPR','TeamAvgCR']];
  state.roundTeams.forEach((rnd, ri) => {
    rnd.forEach((pair, pi) => {
      const [p1, p2] = pair;
      const d1 = p1.dupr ?? '', d2 = p2.dupr ?? '';
      const c1 = p1.clubRating || '', c2 = p2.clubRating || '';
      const duprVals = [p1.dupr, p2.dupr].filter(v => v != null);
      const crVals   = [parseFloat(p1.clubRating), parseFloat(p2.clubRating)].filter(v => !isNaN(v));
      const avgDupr  = duprVals.length ? (duprVals.reduce((a,v)=>a+v,0)/duprVals.length).toFixed(2) : '';
      const avgCR    = crVals.length   ? (crVals.reduce((a,v)=>a+v,0)/crVals.length).toFixed(2)     : '';
      rows.push([ri+1, pi+1, p1.name, p1.gender, d1, c1, p2.name, p2.gender, d2, c2, avgDupr, avgCR]);
    });
  });
  downloadCSV(rows, `${getTournamentName().replace(/[^a-zA-Z0-9]/g,'_')}_teams.csv`);
}

// ── Mode change UI handler ──────────────────────
function onModeChange() {
  const mode = document.getElementById('team-mode')?.value;
  const kingConfig = document.getElementById('king-config');
  const modeDesc   = document.getElementById('mode-desc');
  const modeDescs  = {
    'mixed':               'Each round pairs one M + one F. Partners rotate every round, minimising repeats.',
    'mixed-rated':         'M+F pairs matched by closest club rating.',
    'competitive-mixed':   'M+F pairs chosen so both teams on each court have similar combined ratings. Closest competitive matchups.',
    'snake':               'Players ranked by rating. Pair 1st+last, 2nd+2nd-last, etc. Maximally balanced teams every round.',
    'balanced':            'Players with similar ratings paired together. High plays with high, low with low.',
    'equalizer':           'Top club-rated players get the lowest-rated available partner. Evens out the competition.',
    'progressive':         'Round 1: random. Each round partners rotate up one club-rating tier.',
    'random':              '🎩 Chapeau / Hat Draw — fully random every round. No history tracking. Pure luck, maximally social.',
    'crossover':           'Winners from last round are split up and re-paired with losers. Keeps games competitive and gives experienced players fresh challenges.',
    'roundrobin-partners': 'Mathematically guarantees every player partners every other player exactly once before any repeat. Best with 8, 12, or 16 players.',
    'dupr':                '🏆 Official DUPR Session format — partners paired so team aggregate DUPR stays within the cap. Unrated players get a provisional rating. Opponents matched by closest aggregate. Mirrors how DUPR runs their rated sessions worldwide.',
    'pods':                '🏟️ Players split into pods by DUPR or Club, each pod gets its own dedicated court(s) for the whole tournament. Pod members only play each other — great for skill divisions or club groups.',
    'king':                '👑 Up & Down the River — winners move up a court, losers move down. Court 1 is the King Court.',
    'shootout':            '🎯 Shootout / King-Queen — same court movement as King of the Court, but partners ALWAYS rotate every round. Winners and new arrivals cross-pair so no one keeps the same partner twice.',
    'fixed-teams':         '🔒 Fixed Teams — assign permanent partners once. Every team plays every other team in a round-robin. Great for leagues, couples tournaments, or corporate events.',
    'rr-playoff':          '🏆 Round Robin + Playoff — generates a full round-robin schedule. When all rounds are complete, a \"Generate Playoff\" prompt appears automatically, seeding the bracket from your standings.',
    'mexicano':            '🇲🇽 Mexicano — after each round players are ranked by cumulative points. Next round pairs rank 1 vs rank 2, rank 3 vs rank 4 as opponents. Partners randomly drawn from each side. Rebuild after each round.',
    'americano':           '🌎 Americano — round-robin partner rotation (everyone partners everyone) combined with performance-based opponent matching. Rebuild after each round for best results.',
  };
  kingConfig.style.display = (mode === 'king' || mode === 'shootout') ? 'block' : 'none';
  const shootoutConfig = document.getElementById('shootout-config');
  if(shootoutConfig) shootoutConfig.style.display = mode === 'shootout' ? 'block' : 'none';
  // For shootout mode, force partner mode to 'split' (always rotates)
  if(mode === 'shootout') {
    const kpm = document.getElementById('king-partner-mode');
    if(kpm) { kpm.value = 'split'; }
  }
  const duprConfig = document.getElementById('dupr-config');
  if(duprConfig) duprConfig.style.display = mode === 'dupr' ? 'block' : 'none';
  const podsConfig = document.getElementById('pods-config');
  if(podsConfig) {
    podsConfig.style.display = mode === 'pods' ? 'block' : 'none';
    if(mode === 'pods') renderPodsPreview();
  }
  modeDesc.textContent = modeDescs[mode] || '';
  // Show Rebuild Next Round button for results-dependent modes when a schedule exists
  const rebuildNextBtn = document.getElementById('btn-rebuild-next');
  if(rebuildNextBtn) {
    const resultsModes2 = ['crossover', 'equalizer', 'progressive', 'dupr', 'mexicano', 'americano'];
    rebuildNextBtn.style.display = (resultsModes2.includes(mode) && state.schedule.length > 0) ? '' : 'none';
  }
  const fixedTeamsConfig = document.getElementById('fixed-teams-config');
  if(fixedTeamsConfig) {
    fixedTeamsConfig.style.display = mode === 'fixed-teams' ? 'block' : 'none';
    if(mode === 'fixed-teams') renderFixedTeamsPairs();
  }
  renderPartnerModeAssistant();
}

// ═══════════════════════════════════════════════

// ── Schedule generation & team pairing ────────────────────
//  UP & DOWN THE RIVER STATE
// ═══════════════════════════════════════════════
// riverState.courts[c] = { teamA:[pidx,pidx], teamB:[pidx,pidx], scoreA, scoreB, complete }
// Court index 0 = Court 1 = King Court (top)
var riverState = {
  enabled:      false,
  numCourts:    0,
  partnerMode:  'split',
  winPts:       11,
  currentRound: 1,
  courts:       [],   // per-court current match info, index 0 = court 1
  // stats per player index
  stats: {},          // { wins, losses, courtHistory:[courtNum...], kingWins, streak }
};

// ═══════════════════════════════════════════════
//  FIXED TEAMS MODE
// ═══════════════════════════════════════════════
function renderFixedTeamsPairs() {
  const players = state.players;
  const n = players.length;
  const container = document.getElementById('fixed-teams-pairs');
  const warn      = document.getElementById('fixed-teams-warn');
  if(!container) return;
  if(n < 2) { container.innerHTML = '<span style="color:var(--txt3);font-size:0.82rem">Add players first.</span>'; return; }
  if(!state.fixedTeams) state.fixedTeams = [];
  const numPairs = Math.floor(n / 2);
  while(state.fixedTeams.length < numPairs) state.fixedTeams.push([null, null]);
  state.fixedTeams.length = numPairs;
  container.innerHTML = state.fixedTeams.map((pair, i) => {
    const opts = (slot) => players.map((p, pi) => {
      const usedElsewhere = state.fixedTeams.some((pr, j) => { if(j === i) return false; return pr[0] === pi || pr[1] === pi; });
      const selected = pair[slot] === pi;
      return `<option value="${pi}" ${selected ? 'selected' : ''} ${usedElsewhere && !selected ? 'disabled' : ''}>${p.name}</option>`;
    }).join('');
    const complete = pair[0] != null && pair[1] != null;
    return `<div style="background:var(--surface);border:1px solid ${complete ? 'rgba(198,255,0,0.3)' : 'rgba(249,168,37,0.3)'};border-radius:8px;padding:0.6rem 0.8rem;display:flex;flex-direction:column;gap:0.4rem">
      <div style="font-size:0.7rem;color:var(--txt3);font-weight:600;text-transform:uppercase;letter-spacing:0.5px">Team ${i+1}</div>
      <div style="display:flex;align-items:center;gap:0.4rem">
        <select style="flex:1;font-size:0.82rem;padding:0.25rem 0.4rem" onchange="fixedTeamsSetPlayer(${i},0,this.value)">
          <option value="">— Player 1 —</option>${opts(0)}
        </select>
        <span style="color:var(--txt3);font-size:0.75rem">&amp;</span>
        <select style="flex:1;font-size:0.82rem;padding:0.25rem 0.4rem" onchange="fixedTeamsSetPlayer(${i},1,this.value)">
          <option value="">— Player 2 —</option>${opts(1)}
        </select>
      </div>
    </div>`;
  }).join('');
  const msgs = [];
  if(n % 2 !== 0) msgs.push(`⚠️ Odd number of players (${n}) — 1 player will have no fixed partner.`);
  const assigned = state.fixedTeams.flat().filter(v => v != null);
  const unassigned = players.filter((_,i) => !assigned.includes(i));
  if(unassigned.length) msgs.push(`⚠️ ${unassigned.length} player(s) not yet assigned: ${unassigned.map(p=>p.name).join(', ')}`);
  const v = validateFixedTeams(false);
  if(!v.ok) v.messages.forEach(m => { if(!msgs.some(x => x.includes(m))) msgs.push('⚠️ ' + m); });
  if(warn) warn.textContent = msgs.join('  ');
  renderPartnerModeAssistant();
}

function fixedTeamsSetPlayer(pairIdx, slot, val) {
  if(!state.fixedTeams) state.fixedTeams = [];
  if(!state.fixedTeams[pairIdx]) state.fixedTeams[pairIdx] = [null, null];
  state.fixedTeams[pairIdx][slot] = val === '' ? null : parseInt(val);
  renderFixedTeamsPairs();
}

function fixedTeamsAutoAssign(mode) {
  const n = state.players.length;
  if(n < 2) { toast('Add players first', 'err'); return; }
  state.fixedTeams = [];
  const idxs = Array.from({length: n}, (_, i) => i);
  if(mode === 'mixed' || mode === 'mixed-balanced') {
    const males = idxs.filter(i => state.players[i].gender === 'Male');
    const females = idxs.filter(i => state.players[i].gender === 'Female');
    if(mode === 'mixed-balanced') {
      males.sort((a,b) => pRating(state.players[b]) - pRating(state.players[a]));
      females.sort((a,b) => pRating(state.players[a]) - pRating(state.players[b]));
    } else {
      males.sort((a,b) => pRating(state.players[a]) - pRating(state.players[b]));
      females.sort((a,b) => pRating(state.players[a]) - pRating(state.players[b]));
    }
    const used = new Set();
    const pairCount = Math.min(males.length, females.length);
    for(let i = 0; i < pairCount; i++) {
      state.fixedTeams.push([males[i], females[i]]);
      used.add(males[i]); used.add(females[i]);
    }
    const leftover = idxs.filter(i => !used.has(i) && !state.fixedTeams.flat().includes(i));
    for(let i = 0; i < leftover.length - 1; i += 2) state.fixedTeams.push([leftover[i], leftover[i+1]]);
  } else if(mode === 'balanced') {
    const sorted = [...idxs].sort((a,b) => pRating(state.players[b]) - pRating(state.players[a]));
    for(let i = 0; i < Math.floor(sorted.length / 2); i++) state.fixedTeams.push([sorted[i], sorted[sorted.length - 1 - i]]);
  } else {
    shuffle(idxs);
    for(let i = 0; i < idxs.length - 1; i += 2) state.fixedTeams.push([idxs[i], idxs[i+1]]);
  }
  renderFixedTeamsPairs();
  renderPartnerModeAssistant();
  toast('✅ Teams auto-assigned — adjust any pair manually');
}

function fixedTeamsClear() {
  const n = state.players.length;
  state.fixedTeams = Array.from({length: Math.floor(n/2)}, () => [null, null]);
  renderFixedTeamsPairs();
  renderPartnerModeAssistant();
}

function generateFixedTeamsSchedule(players, fixedPairs, courtList, maxRounds) {
  const numTeams = fixedPairs.length;
  if(numTeams < 2) { toast('Need at least 2 fixed teams (4 players) to generate a schedule', 'err'); return false; }
  const courtsPerRound = Math.min(Math.floor(numTeams / 2), courtList.length);
  function roundRobinMatchups(n) {
    const rounds = []; const teams = Array.from({length: n}, (_, i) => i);
    if(n % 2 === 1) teams.push(-1);
    const t = teams.length;
    for(let r = 0; r < t - 1; r++) {
      const round = [];
      for(let i = 0; i < t / 2; i++) { const a = teams[i], b = teams[t - 1 - i]; if(a !== -1 && b !== -1) round.push([a, b]); }
      rounds.push(round);
      teams.splice(1, 0, teams.pop());
    }
    return rounds;
  }
  const allRounds = roundRobinMatchups(numTeams);
  const realRounds = Math.min(allRounds.length, maxRounds);
  state.schedule = []; state.roundTeams = []; state.teams = []; state.roundHistory = []; state.byeRounds = []; state.notifiedRounds = new Set(); state.startedRounds = new Set();
  let matchIdx = 0;
  for(let r = 0; r < realRounds; r++) {
    const matchups = allRounds[r];
    const roundMatches = matchups.slice(0, courtsPerRound).map(([tA, tB], ci) => ({
      id: matchIdx++, round: r + 1, court: courtList[ci],
      teamA: [...fixedPairs[tA]], teamB: [...fixedPairs[tB]],
      scoreA: '', scoreB: '', complete: false,
    }));
    const playingTeams = new Set(matchups.slice(0, courtsPerRound).flat());
    const byePlayers = Array.from({length: numTeams}, (_, i) => i).filter(i => !playingTeams.has(i)).flatMap(ti => fixedPairs[ti]);
    state.byeRounds.push(byePlayers);
    state.roundTeams.push(matchups.slice(0, courtsPerRound).map(([tA]) => [players[fixedPairs[tA][0]], players[fixedPairs[tA][1]]]));
    state.schedule.push(roundMatches);
  }
  state.teams = fixedPairs.map(([a, b]) => [players[a], players[b]]);
  const totalMatches = state.schedule.reduce((a, r) => a + r.length, 0);
  const si = document.getElementById('schedule-info');
  if(si) si.textContent = `${realRounds} rounds · ${courtsPerRound} courts/round · ${totalMatches} matches · ${numTeams} fixed teams · round-robin format`;
  return true;
}

function initRiver(players, n, numCourts, winPts, partnerMode) {
  riverState.enabled     = true;
  riverState.numCourts   = numCourts;
  riverState.partnerMode = partnerMode;
  riverState.winPts      = winPts;
  riverState.currentRound = 1;
  riverState.courts      = [];
  riverState.stats       = {};

  for(let i = 0; i < n; i++) {
    riverState.stats[i] = { wins:0, losses:0, courtHistory:[], kingWins:0, streak:0 };
  }

  // Initial court assignment: distribute players evenly across courts
  // Sort by rating so higher-rated start higher
  const sorted = Array.from({length:n}, (_,i)=>i)
    .sort((a,b) => pRating(players[b]) - pRating(players[a]));

  // Assign 4 players per court: top 4 → court 1, next 4 → court 2, etc.
  for(let c = 0; c < numCourts; c++) {
    const group = sorted.slice(c*4, c*4+4);
    if(group.length < 4) break;
    const pairs = formCourtPairs(group, players, partnerMode, c);
    riverState.courts.push({
      court: c + 1,
      teamA: pairs[0],
      teamB: pairs[1],
      scoreA: '',
      scoreB: '',
      complete: false,
    });
  }
}

// Given 4 player indices on a court, form 2 pairs based on partner mode
function formCourtPairs(group, players, partnerMode, courtIdx) {
  // group = [p0, p1, p2, p3] — already shuffled or sorted
  if(partnerMode === 'mixed') {
    const males   = group.filter(i => players[i].gender === 'Male');
    const females = group.filter(i => players[i].gender === 'Female');
    // Best-effort M+F pairing; fall back to any split if genders uneven
    if(males.length >= 1 && females.length >= 1) {
      return [[males[0], females[0]], [
        males[1] !== undefined ? males[1] : females[1],
        males[1] !== undefined ? (females[1] !== undefined ? females[1] : males[2]||females[2]) : (females[2]||males[2])
      ]];
    }
  }
  if(partnerMode === 'stay') {
    // Keep same pairs — just re-use existing teams (caller handles this)
    return [[group[0], group[1]], [group[2], group[3]]];
  }
  // Default split: cross-pair (diagonal split so winners/losers get new partners)
  // After movement, court has 2 winners from one court + 2 losers from another
  // Split: winner1 + loser2 vs winner2 + loser1
  return [[group[0], group[2]], [group[1], group[3]]];
}

// Advance all courts after all scores entered
function advanceRiver() {
  const incomplete = riverState.courts.filter(c => !c.complete);
  if(incomplete.length > 0) {
    toast(`Enter scores for all ${incomplete.length} remaining court(s) first`, 'err');
    return;
  }

  const players  = state.players;
  const n        = players.length;
  const numC     = riverState.numCourts;
  const pm       = riverState.partnerMode;

  // Determine winners/losers per court, track stats
  const winners = []; // winners[c] = [pidx, pidx]
  const losers  = []; // losers[c]  = [pidx, pidx]

  riverState.courts.forEach((ct, c) => {
    const w = ct.scoreA > ct.scoreB ? ct.teamA : ct.teamB;
    const l = ct.scoreA > ct.scoreB ? ct.teamB : ct.teamA;
    winners.push([...w]);
    losers.push([...l]);
    w.forEach(pi => {
      riverState.stats[pi].wins++;
      riverState.stats[pi].streak++;
      riverState.stats[pi].courtHistory.push(c+1);
      if(c === 0) riverState.stats[pi].kingWins++;
    });
    l.forEach(pi => {
      riverState.stats[pi].losses++;
      riverState.stats[pi].streak = 0;
      riverState.stats[pi].courtHistory.push(c+1);
    });
  });

  // Movement rules:
  // Court c winners → move to court c-1 (up, min 0)
  // Court c losers  → move to court c+1 (down, max numC-1)
  // Build new groups per court: each court gets winners from court below + losers from court above
  // Court 0 (King):  winners stay (no court above), challengers = winners[1]
  // Court numC-1 (bottom): losers stay (no court below)

  const newGroups = []; // newGroups[c] = [p0,p1,p2,p3]

  for(let c = 0; c < numC; c++) {
    // Who arrives at court c?
    // From above (court c-1): losers move down to c
    // From below (court c+1): winners move up to c
    let arrivals = [];
    if(c > 0)      arrivals = arrivals.concat(losers[c-1]);   // losers from court above drop down
    if(c < numC-1) arrivals = arrivals.concat(winners[c+1]);  // winners from court below rise up

    // Who stays?
    let stays = [];
    if(c === 0)      stays = stays.concat(winners[0]);   // King court winners stay
    if(c === numC-1) stays = stays.concat(losers[numC-1]); // Bottom losers stay

    const group = [...new Set([...stays, ...arrivals])].slice(0, 4);

    // If group < 4 (edge case with few courts), fill from stays
    newGroups.push(group);
  }

  // Form new pairs on each court and reset scores
  riverState.currentRound++;
  riverState.courts = newGroups.map((group, c) => {
    const shuffled = [...group];
    if(pm !== 'stay') shuffle(shuffled);
    const pairs = formCourtPairs(shuffled, players, pm, c);
    return {
      court: c + 1,
      teamA: pairs[0],
      teamB: pairs[1],
      scoreA: '', scoreB: '',
      complete: false,
    };
  });

  // Push new round into schedule for score tracking & player stats
  const roundMatches = riverState.courts.map((ct, ci) => ({
    id: state.schedule.flat().length + ci,
    round: riverState.currentRound,
    court: ct.court,
    teamA: [...ct.teamA],
    teamB: [...ct.teamB],
    scoreA: '', scoreB: '',
    complete: false,
    isRiverMatch: true,
  }));
  state.schedule.push(roundMatches);
  state.roundTeams.push(riverState.courts.map(ct => [players[ct.teamA[0]], players[ct.teamA[1]]]));

  renderRiverBoard();
  renderSchedule();
  autoSave();
  toast(`⬆️ Round ${riverState.currentRound} set! Players have moved courts.`);
}

// Save a river court score inline
function saveRiverScore(courtIdx) {
  const saEl = document.getElementById(`river-score-a-${courtIdx}`);
  const sbEl = document.getElementById(`river-score-b-${courtIdx}`);
  const sa = parseInt(saEl?.value);
  const sb = parseInt(sbEl?.value);
  if(isNaN(sa) || isNaN(sb)) { toast('Enter both scores','err'); return; }

  const ct = riverState.courts[courtIdx];
  ct.scoreA = sa;
  ct.scoreB = sb;
  ct.complete = true;

  // Also mark in state.schedule
  const scheduledMatch = state.schedule.flat().find(
    m => m.isRiverMatch &&
         m.round === riverState.currentRound &&
         m.court === ct.court
  );
  if(scheduledMatch) {
    scheduledMatch.scoreA = sa;
    scheduledMatch.scoreB = sb;
    scheduledMatch.complete = true;
  }

  renderRiverBoard();
  updateProgress();
  renderStandings();
  checkRoundComplete();
  autoSave();
  // Sync to schedule tab if visible
  if(document.getElementById('sec-schedule').classList.contains('active')) renderSchedule();
  if(document.getElementById('sec-playerstats').classList.contains('active')) renderPlayerStats();
  toast(`Court ${ct.court} score saved!`);
}

function renderRiverBoard() {
  const grid    = document.getElementById('river-courts-grid');
  const players = state.players;

  if(!riverState.enabled || !riverState.courts.length) {
    grid.innerHTML = '';
    return;
  }

  const allDone = riverState.courts.every(c => c.complete);

  grid.innerHTML = riverState.courts.map((ct, ci) => {
    const isKing = ci === 0;
    const ta = ct.teamA.map(pi => players[pi]);
    const tb = ct.teamB.map(pi => players[pi]);

    const taNames = ta.map(p => `<span class="player-chip"><span class="chip-name">${p?.name.split(' ')[0]||'?'}</span><span style="color:var(--txt3);font-size:0.65rem">${pRatingLabel(p)||''}</span></span>`).join('');
    const tbNames = tb.map(p => `<span class="player-chip"><span class="chip-name">${p?.name.split(' ')[0]||'?'}</span><span style="color:var(--txt3);font-size:0.65rem">${pRatingLabel(p)||''}</span></span>`).join('');

    // Movement preview after scoring
    let moveHtml = '';
    if(ct.complete) {
      const wTeam = ct.scoreA > ct.scoreB ? 'A' : 'B';
      const winnerNames = (wTeam==='A' ? ta : tb).map(p=>p?.name.split(' ')[0]).join(' & ');
      const loserNames  = (wTeam==='A' ? tb : ta).map(p=>p?.name.split(' ')[0]).join(' & ');
      const winMove = ci === 0 ? '👑 Stay (Kings!)' : `⬆ Court ${ci}`;
      const loseMove = ci === riverState.numCourts-1 ? '↕ Stay (Bottom)' : `⬇ Court ${ci+2}`;
      moveHtml = `
        <div class="river-movement">
          <div class="move-up">▲ ${winnerNames}: ${winMove}</div>
          <div class="move-down">▼ ${loserNames}: ${loseMove}</div>
        </div>`;
    }

    const scoreDisp = ct.complete
      ? `<span style="font-family:'Bebas Neue',sans-serif;font-size:1.4rem;color:${ct.scoreA>ct.scoreB?'var(--lime)':'var(--txt)'}">${ct.scoreA}</span>
         <span class="river-score-sep">–</span>
         <span style="font-family:'Bebas Neue',sans-serif;font-size:1.4rem;color:${ct.scoreB>ct.scoreA?'var(--lime)':'var(--txt)'}">${ct.scoreB}</span>
         <button class="btn btn-secondary btn-sm" onclick="editRiverScore(${ci})" style="margin-left:4px">✎</button>`
      : `<input id="river-score-a-${ci}" type="number" class="river-score-input" min="0" max="99" placeholder="0" onkeydown="if(event.key==='Enter')saveRiverScore(${ci})">
         <span class="river-score-sep">–</span>
         <input id="river-score-b-${ci}" type="number" class="river-score-input" min="0" max="99" placeholder="0" onkeydown="if(event.key==='Enter')saveRiverScore(${ci})">
         <button class="btn btn-primary btn-sm" onclick="saveRiverScore(${ci})">✓</button>`;

    return `
      <div class="river-court-row ${isKing?'king-court-row':''}">
        <div class="river-court-label ${isKing?'king-label':''}">
          ${isKing ? '👑' : ci+1}
          <div class="court-sub">${isKing ? 'KING' : 'COURT'}</div>
        </div>
        <div class="river-teams">
          <div class="river-team">${taNames}</div>
          <div class="river-vs">VS</div>
          <div class="river-team">${tbNames}</div>
        </div>
        <div class="river-score-area">${scoreDisp}</div>
        ${moveHtml}
      </div>`;
  }).join('');

  // Show advance button state
  const btn = document.querySelector('#king-board .btn-orange');
  if(btn) {
    btn.style.opacity = allDone ? '1' : '0.4';
    btn.title = allDone ? 'All scores entered — advance to next round' : 'Enter all scores before advancing';
  }

  renderRiverLeaderboard();
}

function editRiverScore(courtIdx) {
  const ct = riverState.courts[courtIdx];
  ct.complete = false;
  ct.scoreA = ''; ct.scoreB = '';
  renderRiverBoard();
  autoSave();
}

function renderRiverLeaderboard() {
  const lb = document.getElementById('king-leaderboard');
  const players = state.players;
  const entries = Object.entries(riverState.stats)
    .map(([pi, s]) => ({ pi: parseInt(pi), ...s }))
    .filter(x => x.wins + x.losses > 0)
    .sort((a, b) => b.wins - a.wins || b.kingWins - a.kingWins);

  if(!entries.length) {
    lb.innerHTML = '<div style="padding:0.75rem;color:var(--txt3);font-size:0.82rem">Enter round scores to see standings here.</div>';
    return;
  }

  lb.innerHTML = `<table style="width:100%;font-size:0.82rem;border-collapse:collapse">
    <thead><tr style="background:var(--court)">
      <th style="padding:0.5rem 0.8rem;color:var(--lime);text-align:left">Player</th>
      <th style="padding:0.5rem 0.8rem;color:var(--lime)">Wins</th>
      <th style="padding:0.5rem 0.8rem;color:var(--lime)">Losses</th>
      <th style="padding:0.5rem 0.8rem;color:var(--ball)">👑 King Wins</th>
      <th style="padding:0.5rem 0.8rem;color:var(--lime)">Streak</th>
      <th style="padding:0.5rem 0.8rem;color:var(--txt3)">Court History</th>
    </tr></thead>
    <tbody>${entries.map((x, i) => {
      const p = players[x.pi];
      const history = x.courtHistory.slice(-10).map(c =>
        `<span style="display:inline-block;width:18px;height:18px;line-height:18px;text-align:center;border-radius:4px;font-size:0.65rem;margin:1px;background:${c===1?'rgba(249,168,37,0.3)':c<=3?'rgba(198,255,0,0.15)':'rgba(100,100,100,0.2)'};color:${c===1?'var(--ball)':c<=3?'var(--lime)':'var(--txt3)'}">${c}</span>`
      ).join('');
      return `<tr style="border-bottom:1px solid var(--border);${i===0?'background:rgba(249,168,37,0.06)':''}">
        <td style="padding:0.45rem 0.8rem;font-weight:600">${i===0?'👑 ':''}${p?.name||'?'}</td>
        <td style="padding:0.45rem 0.8rem;text-align:center;color:var(--lime);font-weight:700">${x.wins}</td>
        <td style="padding:0.45rem 0.8rem;text-align:center;color:var(--red)">${x.losses}</td>
        <td style="padding:0.45rem 0.8rem;text-align:center;font-family:'Bebas Neue',sans-serif;font-size:1.1rem;color:var(--ball)">${x.kingWins||0}</td>
        <td style="padding:0.45rem 0.8rem;text-align:center;color:${x.streak>1?'var(--lime)':'var(--txt3)'}">${x.streak>0?`🔥${x.streak}`:x.streak}</td>
        <td style="padding:0.45rem 0.8rem">${history}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

// Stub – no longer needed but called in saveScore
function resolveKingMatch() {}
function renderKingBoard() { if(riverState.enabled) renderRiverBoard(); }

//  Every round: new partners, new opponents.
//  No player partners the same person twice (best-effort).
// ═══════════════════════════════════════════════
// ═══════════════════════════════════════════════
//  GENERATE SCHEDULE — WARNING MODAL
// ═══════════════════════════════════════════════
function promptGenerateSchedule() {
  const hasSchedule    = state.schedule.length > 0;
  const allMatches     = state.schedule.flat();
  const playedMatches  = allMatches.filter(m => m.complete).length;
  const pendingMatches = allMatches.length - playedMatches;
  const hasScores      = playedMatches > 0;

  // Count how many complete rounds (all matches done) vs partial
  let completedRounds = 0;
  state.schedule.forEach(round => {
    if(round.length && round.every(m => m.complete)) completedRounds++;
  });
  const pendingRounds = state.schedule.length - completedRounds;

  // No existing schedule — run directly, nothing to warn about
  if(!hasSchedule) { generateBestOfN(); return; }

  const body      = document.getElementById('gen-schedule-modal-body');
  const keepBtn   = document.getElementById('gen-schedule-keep-btn');
  const fullBtn   = document.getElementById('gen-schedule-confirm-btn');
  const adjCount  = state._manualAdjustments || 0;

  if(hasScores) {
    // ── Scores exist: offer two paths ────────────────────────────────────
    let html = '';

    // Option A — Keep completed rounds
    html += `<div style="background:rgba(198,255,0,0.06);border:1px solid rgba(198,255,0,0.25);border-radius:8px;padding:0.75rem 1rem;margin-bottom:0.75rem">`;
    html += `<div style="font-size:0.82rem;font-weight:700;color:var(--lime);margin-bottom:0.35rem">🔁 Option A — Keep scores, regenerate remaining</div>`;
    html += `<div style="font-size:0.8rem;color:var(--txt2);line-height:1.6">`;
    html += `• <strong style="color:var(--lime)">${completedRounds} completed round${completedRounds !== 1 ? 's' : ''} and ${playedMatches} score${playedMatches !== 1 ? 's' : ''} are kept.</strong><br>`;
    html += `• ${pendingRounds} unfinished round${pendingRounds !== 1 ? 's' : ''} (${pendingMatches} match${pendingMatches !== 1 ? 'es' : ''}) will be replaced with a fresh schedule.<br>`;
    html += `• Standings and stats remain intact for completed rounds.`;
    html += `</div></div>`;

    // Option B — Full regenerate
    html += `<div style="background:rgba(239,83,80,0.06);border:1px solid rgba(239,83,80,0.3);border-radius:8px;padding:0.75rem 1rem">`;
    html += `<div style="font-size:0.82rem;font-weight:700;color:var(--red);margin-bottom:0.35rem">⚡ Option B — Full regenerate (erase everything)</div>`;
    html += `<div style="font-size:0.8rem;color:var(--txt2);line-height:1.6">`;
    html += `• <strong style="color:var(--red)">${playedMatches} completed match${playedMatches !== 1 ? 'es' : ''} and all scores will be permanently erased.</strong><br>`;
    html += `• All standings, stats, and playoff brackets reset to zero.<br>`;
    html += `• A completely fresh schedule will be generated.`;
    html += `</div></div>`;

    // Manual adjustment warning
    if(adjCount > 0) {
      html += `<div style="background:rgba(249,168,37,0.1);border:1px solid rgba(249,168,37,0.4);border-radius:8px;padding:0.6rem 0.85rem;margin-top:0.75rem">
        <span style="font-weight:700;color:var(--ball)">⚠️ ${adjCount} manual player adjustment${adjCount !== 1 ? 's' : ''} will be lost.</span>
        <span style="font-size:0.8rem;color:var(--txt2);margin-left:0.4rem">You moved players between teams — regenerating will reset all matches to the original algorithm-assigned teams.</span>
      </div>`;
    }

    body.innerHTML = html;
    keepBtn.style.display = '';
    fullBtn.style.background = 'var(--red)';
    fullBtn.textContent = '⚡ Erase all & regenerate';
  } else {
    // ── No scores yet: simple confirmation ───────────────────────────────
    let lines = [];
    if(pendingMatches > 0) lines.push(`📋 ${pendingMatches} pending match${pendingMatches !== 1 ? 'es' : ''} will be replaced.`);
    lines.push(`📊 Standings and stats will reset.`);
    lines.push(`🏅 Any playoff bracket will be cleared.`);
    lines.push(`<span style="color:var(--lime)">✓ No scores entered yet — safe to regenerate.</span>`);
    let bodyHtml = lines.map(l => `<div style="margin-bottom:0.3rem">• ${l}</div>`).join('');
    if(adjCount > 0) {
      bodyHtml += `<div style="background:rgba(249,168,37,0.1);border:1px solid rgba(249,168,37,0.4);border-radius:8px;padding:0.6rem 0.85rem;margin-top:0.6rem">
        <span style="font-weight:700;color:var(--ball)">⚠️ ${adjCount} manual player adjustment${adjCount !== 1 ? 's' : ''} will be lost.</span>
        <span style="font-size:0.8rem;color:var(--txt2);margin-left:0.4rem">You moved players between teams — regenerating will reset all matches to the original algorithm-assigned teams.</span>
      </div>`;
    }
    body.innerHTML = bodyHtml;
    keepBtn.style.display = 'none';
    fullBtn.style.background = '';
    fullBtn.textContent = adjCount > 0 ? '⚡ Yes, lose adjustments & regenerate' : '⚡ Yes, regenerate';
  }

  const modal = document.getElementById('gen-schedule-modal');
  modal.style.display = 'flex';
  modal.onclick = (e) => { if(e.target === modal) closeGenScheduleModal(); };
}

function closeGenScheduleModal() {
  document.getElementById('gen-schedule-modal').style.display = 'none';
}

function confirmGenerateSchedule() {
  closeGenScheduleModal();
  state._manualAdjustments = 0;
  generateBestOfN();
}

function confirmKeepAndRegenerate() {
  closeGenScheduleModal();
  state._manualAdjustments = 0; // pending rounds will be rebuilt fresh
  regenerateRemaining();
}

// ═══════════════════════════════════════════════
//  BEST-OF-N SCHEDULE GENERATION
// ═══════════════════════════════════════════════

// Score a schedule: lower is better
// Weights: partner repeats most costly, opponent repeats next, balance gap last
function scoreSchedule(schedule, players) {
  let partnerRepeats = 0, oppRepeats = 0, balanceGap = 0, matchCount = 0;
  const n = players.length;
  const pc = Array.from({length:n}, () => new Array(n).fill(0));
  const oc = Array.from({length:n}, () => new Array(n).fill(0));
  schedule.flat().forEach(m => {
    if(!m.teamA || !m.teamB) return;
    const [a,b] = m.teamA, [c,d] = m.teamB;
    if(pc[a][b] > 0) partnerRepeats++;
    if(pc[c][d] > 0) partnerRepeats++;
    pc[a][b]++; pc[b][a]++; pc[c][d]++; pc[d][c]++;
    const oppScore = oc[a][c] + oc[a][d] + oc[b][c] + oc[b][d];
    if(oppScore > 0) oppRepeats += oppScore;
    oc[a][c]++; oc[a][d]++; oc[b][c]++; oc[b][d]++;
    oc[c][a]++; oc[c][b]++; oc[d][a]++; oc[d][b]++;
    const rA = pRating(players[a]) + pRating(players[b]);
    const rB = pRating(players[c]) + pRating(players[d]);
    balanceGap += Math.abs(rA - rB);
    matchCount++;
  });
  // Weighted total: partner repeats weighted 100x, opponent repeats 10x, balance secondary
  return partnerRepeats * 100 + oppRepeats * 10 + (matchCount > 0 ? balanceGap / matchCount : 0);
}

// Snapshot and restore full schedule state
function snapshotScheduleState() {
  return {
    schedule:      JSON.parse(JSON.stringify(state.schedule)),
    roundTeams:    JSON.parse(JSON.stringify(state.roundTeams)),
    teams:         JSON.parse(JSON.stringify(state.teams)),
    roundHistory:  JSON.parse(JSON.stringify(state.roundHistory)),
    byeRounds:     JSON.parse(JSON.stringify(state.byeRounds)),
    scheduleInfo:  document.getElementById('schedule-info')?.textContent || '',
    podWarn:       document.getElementById('pod-court-warn')?.textContent || '',
    podWarnVisible: document.getElementById('pod-court-warn')?.style.display || 'none',
  };
}

function restoreScheduleState(snap) {
  state.schedule     = snap.schedule;
  state.roundTeams   = snap.roundTeams;
  state.teams        = snap.teams;
  state.roundHistory = snap.roundHistory;
  state.byeRounds    = snap.byeRounds;
  const si = document.getElementById('schedule-info');
  if(si) si.textContent = snap.scheduleInfo;
  const pw = document.getElementById('pod-court-warn');
  if(pw) { pw.textContent = snap.podWarn; pw.style.display = snap.podWarnVisible; }
}

// Shuffle helper for trying different orderings
function _shuffleIndices(arr, seed) {
  // Deterministic Fischer-Yates using a simple LCG seeded by seed
  const a = [...arr];
  let s = seed;
  for(let i = a.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    const j = Math.abs(s) % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Wrap generateSchedule with a player-ordering permutation.
// The original algorithm uses state.players[] directly by index.
// We permute by reordering the players array, generating, then mapping indices back.
function generateWithSeed(seed) {
  const n = state.players.length;
  const perm    = _shuffleIndices(Array.from({length:n},(_,i)=>i), seed);
  const invPerm = new Array(n);
  perm.forEach((orig, newIdx) => { invPerm[orig] = newIdx; });

  // Temporarily reorder players
  const origPlayers = state.players;
  state.players = perm.map(i => origPlayers[i]);

  generateSchedule();

  // Map indices back from permuted space to original space
  state.schedule.forEach(round => round.forEach(m => {
    if(m.teamA) m.teamA = m.teamA.map(i => perm[i]);
    if(m.teamB) m.teamB = m.teamB.map(i => perm[i]);
  }));
  state.roundTeams = state.roundTeams.map(round =>
    round.map(pair => pair.map(p => {
      const origIdx = perm[origPlayers.indexOf(p)] ?? perm.indexOf(state.players.indexOf(p));
      return origPlayers[perm[state.players.indexOf(p)]];
    }))
  );

  // Restore original player order
  state.players = origPlayers;
}

// Run one trial synchronously, return the snapshot and score
function _runOneTrial(seed) {
  const origPlayers = [...state.players];

  if(seed > 0) {
    // Only shuffle active players — inactive stay at their positions
    const activeIdxs = state.players.map((p,i) => i).filter(i => state.players[i].active !== false && state.players[i].waitlist !== true && state.players[i].checkedIn !== false);
    const perm = _shuffleIndices(Array.from({length:activeIdxs.length},(_,i)=>i), seed);
    // Build a new players array where active players are shuffled but inactive stay put.
    // shuffledToOrig[k] = the ORIGINAL array position of whichever player now sits at
    // shuffled position k — needed to translate the schedule's indices back after restore,
    // since generateSchedule() builds teamA/teamB as indices into whatever state.players
    // happens to be at the time (the shuffled array), not the original.
    const shuffled = [...state.players];
    const shuffledToOrig = shuffled.map((_, i) => i); // defaults: untouched positions map to themselves
    perm.forEach((newPos, oldPos) => {
      shuffled[activeIdxs[newPos]] = origPlayers[activeIdxs[oldPos]];
      shuffledToOrig[activeIdxs[newPos]] = activeIdxs[oldPos];
    });
    state.players = shuffled;
    generateSchedule();
    // Translate every match's indices from shuffled-array positions back to
    // original-array positions before restoring state.players, so the
    // schedule's teamA/teamB correctly reference the same players the
    // algorithm actually chose, not whoever ends up at that index afterward.
    state.schedule.forEach(round => round.forEach(m => {
      if(m.teamA) m.teamA = m.teamA.map(i => shuffledToOrig[i]);
      if(m.teamB) m.teamB = m.teamB.map(i => shuffledToOrig[i]);
    }));
    (state.byeRounds || []).forEach((byes, ri) => {
      state.byeRounds[ri] = byes.map(i => shuffledToOrig[i]);
    });
    state.players = origPlayers;
  } else {
    generateSchedule();
  }

  if(!state.schedule.length) return null;

  // Score: count actual repeats + avg balance gap (uses global indices from schedule)
  const n2 = state.players.length;
  let partnerRep = 0, oppRep = 0, balanceGap = 0, matchCount = 0;
  const pc = Array.from({length:n2}, () => new Array(n2).fill(0));
  const oc = Array.from({length:n2}, () => new Array(n2).fill(0));
  state.schedule.flat().forEach(m => {
    if(!m.teamA || !m.teamB) return;
    const [a,b] = m.teamA, [c,d] = m.teamB;
    if(pc[a][b] > 0) partnerRep++;
    if(pc[c][d] > 0) partnerRep++;
    pc[a][b]++; pc[b][a]++; pc[c][d]++; pc[d][c]++;
    const os = oc[a][c]+oc[a][d]+oc[b][c]+oc[b][d];
    if(os > 0) oppRep += os;
    oc[a][c]++; oc[a][d]++; oc[b][c]++; oc[b][d]++;
    oc[c][a]++; oc[c][b]++; oc[d][a]++; oc[d][b]++;
    const rA = pRating(state.players[a]) + pRating(state.players[b]);
    const rB = pRating(state.players[c]) + pRating(state.players[d]);
    balanceGap += Math.abs(rA - rB);
    const spreadA = Math.abs(pRating(state.players[a]) - pRating(state.players[b]));
    const spreadB = Math.abs(pRating(state.players[c]) - pRating(state.players[d]));
    balanceGap += (spreadA + spreadB) * 0.5;
    matchCount++;
  });
  const avgGap = matchCount > 0 ? balanceGap / matchCount : 0;

  // Lock violations are disqualifying — weighted far above even partner repeats
  // (100/match) so the best-of-N optimizer can never prefer an unlocked trial
  // over one that honors a partner lock, no matter how much better its variety
  // score looks otherwise. applyPartnerLocksAndSync() inside generateSchedule()
  // already fixes most trials before we get here; this just makes sure a trial
  // that still couldn't fully satisfy a lock (e.g. a bye-rotation edge case)
  // never wins the comparison.
  let lockViolations = 0;
  if(state.partnerLocks && state.partnerLocks.length) {
    state.schedule.forEach(round => {
      round.forEach(m => {
        if(!m.teamA || !m.teamB) return;
        state.partnerLocks.forEach(([idA, idB]) => {
          const iA = state.players.findIndex(p => p.id === idA);
          const iB = state.players.findIndex(p => p.id === idB);
          if(iA === -1 || iB === -1) return;
          const aIn = m.teamA.includes(iA) || m.teamB.includes(iA);
          const bIn = m.teamA.includes(iB) || m.teamB.includes(iB);
          if(!aIn || !bIn) return; // one or both not in this match — not a violation
          const together = (m.teamA.includes(iA) && m.teamA.includes(iB)) || (m.teamB.includes(iA) && m.teamB.includes(iB));
          if(!together) lockViolations++;
        });
      });
    });
  }

  const totalScore = lockViolations * 100000 + partnerRep * 100 + oppRep * 10 + avgGap;

  return { snap: snapshotScheduleState(), totalScore, partnerRep, oppRep, lockViolations, avgGap: avgGap.toFixed(2) };
}

// ─── Time-budget generate: run trials for TIME_BUDGET_MS, keep the best ─────
const GENERATE_TIME_BUDGET_MS = 3000; // 3 seconds

function _showTrialProgress(t, elapsed, best) {
  const si = document.getElementById('schedule-info');
  if(!si) return;
  const budgetMs = parseInt(document.getElementById('gen-time-budget')?.value || '3000');
  const pct = Math.min(100, Math.round((elapsed / budgetMs) * 100));
  const filled = Math.round(pct / 10);
  const bar = '█'.repeat(filled) + '░'.repeat(10 - filled);
  const bestStr = best
    ? ` · ${best.partnerRep === 0 ? '✓ 0 partner repeats' : '⚠️ ' + best.partnerRep + ' repeat' + (best.partnerRep > 1 ? 's' : '')}`
      + `, ${best.oppRep === 0 ? '✓ 0 opp repeats' : '⚠️ ' + best.oppRep + ' opp'}`
      + `, gap ${best.avgGap}`
    : '';
  si.innerHTML = `<span style="color:var(--lime);font-family:'JetBrains Mono',monospace">🔍 Optimising ${bar} ${pct}% · trial ${t}${bestStr}</span>`;
}

function _commitBestResult(bestResult, trialsRun) {
  restoreScheduleState(bestResult.snap);

  const genBtn = document.getElementById('btn-generate-schedule');
  if(genBtn) { genBtn.disabled = false; genBtn.textContent = '⚡ Generate Schedule'; }

  const si = document.getElementById('schedule-info');
  if(si) {
    const pr = bestResult.partnerRep;
    const or = bestResult.oppRep;
    const lv = bestResult.lockViolations || 0;
    const ag = bestResult.avgGap;
    const rounds = state.schedule.length;
    const courts = state.schedule[0]?.length || 0;
    const total  = state.schedule.flat().length;
    si.innerHTML =
      `${rounds} rounds · ${courts} courts/round · ${total} matches &nbsp;·&nbsp; `
      + `<span style="color:${pr===0?'var(--lime)':'var(--ball)'}">${pr===0?'✓ 0 partner repeats':'⚠️ '+pr+' partner repeat'+(pr>1?'s':'')}</span> &nbsp;·&nbsp; `
      + `<span style="color:${or===0?'var(--lime)':'var(--ball)'}">${or===0?'✓ 0 opp repeats':'⚠️ '+or+' opp repeat'+(or>1?'s':'')}</span> &nbsp;·&nbsp; `
      + `<span style="color:var(--txt3)">⚖ avg gap ${ag}</span> &nbsp;·&nbsp; `
      + `<span style="color:var(--txt3)">🔍 ${trialsRun} trial${trialsRun>1?'s':''} tried</span>`
      + (lv > 0 ? ` &nbsp;·&nbsp; <span style="color:var(--red)">🔗 ⚠️ ${lv} lock${lv>1?'s':''} couldn't be satisfied this round</span>` : '');
  }

  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress(); autoSave();

  const pr = bestResult.partnerRep, or = bestResult.oppRep, lv = bestResult.lockViolations || 0;
  const quality = (pr === 0 && or === 0 && lv === 0) ? '✅' : '⚠️';
  let msg = `${quality} Schedule ready — ${pr} partner repeat${pr!==1?'s':''}, ${or} opp repeat${or!==1?'s':''}, avg gap ${bestResult.avgGap} (${trialsRun} trials)`;
  if(lv > 0) msg += ` · 🔗 ${lv} lock${lv>1?'s':''} unresolved`;
  toast(msg);
}

function generateBestOfN() {
  const genBtn = document.getElementById('btn-generate-schedule');
  if(genBtn) { genBtn.disabled = true; genBtn.textContent = '⏳ Optimising…'; }

  let bestResult = null;
  let t = 0;
  const budget = parseInt(document.getElementById('gen-time-budget')?.value || '3000');
  const deadline = Date.now() + budget;

  function runNextTrial() {
    const now = Date.now();

    // Stop when time is up OR we already have a perfect schedule
    const perfect = bestResult && bestResult.partnerRep === 0 && bestResult.oppRep === 0 && !bestResult.lockViolations;
    if(now >= deadline || perfect) {
      if(!bestResult) {
        // Shouldn't happen, but safety net
        if(genBtn) { genBtn.disabled = false; genBtn.textContent = '⚡ Generate Schedule'; }
        toast('⚠️ Could not generate a schedule — check player count', 'err');
        return;
      }
      _commitBestResult(bestResult, t);
      return;
    }

    // Update progress display first so the user sees it before we block
    _showTrialProgress(t + 1, now - (deadline - budget), bestResult);

    // Yield to let the browser paint the progress update, then run one trial.
    // After the trial completes, yield again proportional to how long it took
    // so larger player counts (slow trials) still stay responsive.
    setTimeout(() => {
      const trialStart = Date.now();
      const seed = t === 0 ? 0 : t * 7919 + 1;
      const result = _runOneTrial(seed);
      const trialMs = Date.now() - trialStart;

      if(result && (!bestResult || result.totalScore < bestResult.totalScore)) {
        bestResult = result;
      }
      t++;

      // Yield at least 80ms after heavy trials so the browser can repaint and
      // handle input — the longer the trial, the longer the yield.
      // For fast trials (<50ms) yield just 20ms; for slow ones yield 25% of trial time.
      const yieldMs = Math.max(20, Math.round(trialMs * 0.25));
      setTimeout(runNextTrial, yieldMs);
    }, 30); // initial yield before trial starts — gives browser time to paint progress
  }

  runNextTrial();
}



// ── Mixed Mode Compliance Warning ─────────────────────────────────────
// Mixed mode is intentionally best-effort: it should warn when 100% mixed
// pairings are not possible, but it should NOT put players on standby just
// to satisfy the mixed rule perfectly.
function isMixedModeValue(mode) {
  return mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed';
}
function teamIsMixed(team) {
  if(!team || team.length < 2) return false;
  const genders = team.map(i => (state.players[i]?.gender || '').toLowerCase());
  return genders.includes('male') && genders.includes('female');
}
function matchMixedCompliance(m) {
  if(!m || !m.teamA || !m.teamB) return { ok: true, reason: '' };
  const aMixed = teamIsMixed(m.teamA);
  const bMixed = teamIsMixed(m.teamB);
  if(aMixed && bMixed) return { ok: true, reason: '' };
  const reasons = [];
  if(!aMixed) reasons.push('Team A is not mixed');
  if(!bMixed) reasons.push('Team B is not mixed');
  return { ok: false, reason: reasons.join('; ') };
}
function buildMixedComplianceReport() {
  const mode = document.getElementById('team-mode')?.value || 'random';
  if(!isMixedModeValue(mode) || !state.schedule || !state.schedule.length) return null;
  const matches = state.schedule.flat().filter(m => m && m.teamA && m.teamB);
  const failed = matches.filter(m => !matchMixedCompliance(m).ok);
  const ok = matches.length - failed.length;
  const pct = matches.length ? Math.round((ok / matches.length) * 100) : 100;
  const active = state.players.filter(p => p.active !== false && p.waitlist !== true && p.checkedIn !== false);
  const male = active.filter(p => p.gender === 'Male').length;
  const female = active.filter(p => p.gender === 'Female').length;
  let reason = '';
  if(male !== female) reason = `Player mix is uneven (${male} male, ${female} female), so some same-gender teams or matches may be unavoidable.`;
  else if(failed.length) reason = 'The scheduler could not find a perfect mixed arrangement with the current players, rounds, courts, and repeat-avoidance rules.';
  return { mode, matches, failed, ok, pct, male, female, reason };
}
function renderMixedModeWarning() {
  const existing = document.getElementById('mixed-mode-warn');
  const anchor = document.getElementById('schedule-info');
  if(!anchor) return;
  const report = buildMixedComplianceReport();
  if(!report || report.pct === 100) {
    if(existing) existing.style.display = 'none';
    return;
  }
  let box = existing;
  if(!box) {
    box = document.createElement('div');
    box.id = 'mixed-mode-warn';
    anchor.insertAdjacentElement('afterend', box);
  }
  box.style.cssText = 'display:block;margin:0.45rem 0;background:rgba(249,168,37,0.13);border:1px solid rgba(249,168,37,0.55);border-radius:10px;padding:0.65rem 0.85rem;font-size:0.84rem;color:var(--ball);line-height:1.45';
  const affected = report.failed.slice(0,8).map(m => {
    const c = matchMixedCompliance(m);
    return `<div style="margin-top:3px;color:var(--txt)">Court ${escHtml(m.court)} · Round ${escHtml(m.round)}: ${escHtml(matchTeamName(m.teamA).replace(/<[^>]*>/g,''))} vs ${escHtml(matchTeamName(m.teamB).replace(/<[^>]*>/g,''))} <span style="color:var(--txt3)">(${escHtml(c.reason)})</span></div>`;
  }).join('');
  box.innerHTML = `
    <div style="font-weight:800;color:var(--ball);margin-bottom:4px">⚠️ Mixed Mode Warning</div>
    <div><strong>${report.ok} of ${report.matches.length}</strong> matches satisfy mixed rules (${report.pct}%).</div>
    <div style="color:var(--txt2);margin-top:3px">No players were put on standby just to force 100% mixed compliance. The app used the best available schedule and flagged the affected courts.</div>
    ${report.reason ? `<div style="color:var(--txt3);margin-top:3px">Reason: ${escHtml(report.reason)}</div>` : ''}
    ${affected ? `<details style="margin-top:7px"><summary style="cursor:pointer;color:var(--lime);font-weight:700">Review affected courts</summary>${affected}${report.failed.length>8?`<div style="margin-top:3px;color:var(--txt3)">+${report.failed.length-8} more affected match${report.failed.length-8===1?'':'es'}</div>`:''}</details>` : ''}
  `;
}
function mixedModeWarningToastIfNeeded() {
  const report = buildMixedComplianceReport();
  if(report && report.pct < 100) {
    toast(`⚠️ Mixed mode ${report.pct}% compliant — best available schedule used, no players put on standby`, 'err');
  }
}

function generateSchedule() {
  state._manualAdjustments = 0; // fresh generate always clears manual adjustment history

  const players = state.players;
  const n = players.length;

  if(n < 4)  { toast("Need at least 4 players","err"); return; }

  // ── Skill gap warning ──────────────────────────
  // Check DUPR spread of active players before generating
  const mode       = document.getElementById('team-mode')?.value || 'random';
  const activePlayers = players.filter(p => p.active !== false && p.waitlist !== true && p.checkedIn !== false);
  const duprVals = activePlayers.map(p => p.dupr).filter(v => v != null && !isNaN(v));
  if(duprVals.length >= 4 && mode !== 'pods' && mode !== 'dupr' && mode !== 'king') {
    const spread = Math.max(...duprVals) - Math.min(...duprVals);
    if(spread > 1.5) {
      const suggestionDismissed = sessionStorage.getItem('pb_skillgap_dismissed');
      if(!suggestionDismissed) {
        const proceed = confirm(
          `⚠️ Skill Gap Warning\n\n` +
          `DUPR spread: ${spread.toFixed(2)} (${Math.min(...duprVals).toFixed(2)} – ${Math.max(...duprVals).toFixed(2)})\n\n` +
          `A spread over 1.5 can lead to mismatched games. Consider:\n` +
          `• Pods mode (groups players by skill bracket)\n` +
          `• DUPR Balanced mode (pairs strong with weak)\n\n` +
          `Continue with ${mode.replace(/-/g, ' ')} mode anyway?`
        );
        if(!proceed) return;
        sessionStorage.setItem('pb_skillgap_dismissed', '1');
      }
    }
  }
  const maxRounds  = parseInt(document.getElementById('max-rounds')?.value) || 7;
  const maxCourts  = parseInt(document.getElementById('courts-count')?.value) || MAX_COURTS;
  // Use the explicitly selected court numbers (sorted)
  const courtList  = Array.from(state.selectedCourts).sort((a,b)=>a-b);

  // ── Up & Down the River mode ────────────────────
  if(mode === 'king' || mode === 'shootout') {
    const winPts      = parseInt(document.getElementById('king-win-pts')?.value) || 11;
    // Shootout always forces partner split — the key difference from King of the Court
    const partnerMode = mode === 'shootout' ? 'split' : (document.getElementById('king-partner-mode')?.value || 'split');
    const numCourts   = Math.min(courtList.length, Math.floor(n / 4));
    if(numCourts < 1) { toast('Need at least 4 players for 1 court','err'); return; }
    state.roundTeams = []; state.schedule = []; state.teams = [];
    riverState.enabled = false;
    riverState.mode = mode;
    initRiver(state.players, n, numCourts, winPts, partnerMode);
    const round1 = riverState.courts.map((ct, ci) => ({
      id: ci, round: 1, court: ct.court,
      teamA: [...ct.teamA], teamB: [...ct.teamB],
      scoreA: '', scoreB: '', complete: false, isRiverMatch: true,
    }));
    state.schedule.push(round1);
    state.roundTeams.push(riverState.courts.map(ct => [state.players[ct.teamA[0]], state.players[ct.teamA[1]]]));
    state.teams = [];
    state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));
    const modeLabel = mode === 'shootout' ? '🎯 Shootout / King-Queen' : '👑 Up & Down the River';
    if(document.getElementById('schedule-info')) document.getElementById('schedule-info').textContent =
      `${modeLabel} · ${numCourts} courts · Court 1 = ${mode === 'shootout' ? 'King Court' : 'King Court'} · Enter scores then click ▶ Advance Round`;
    document.getElementById('king-board').style.display = 'block';
    renderRiverBoard(); renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    autoSave();
    toast(`${modeLabel} started! ${numCourts} courts, ${n} players.`);
    return;
  }

  // ── Pods mode ─────────────────────────────────
  if(mode === 'pods') {
    return generatePodsSchedule();
  }

  // ── Fixed Teams mode ───────────────────────────
  if(mode === 'fixed-teams') {
    if(!state.fixedTeams || state.fixedTeams.length < 2) {
      toast('Assign at least 2 teams (4 players) in the Fixed Teams panel first', 'err');
      return;
    }
    const fixedValidation = validateFixedTeams(true);
    if(!fixedValidation.ok) return;
    const validPairs = state.fixedTeams.filter(p => p[0] != null && p[1] != null);
    if(validPairs.length < 2) {
      toast('Complete at least 2 team assignments before generating', 'err');
      return;
    }
    riverState.enabled = false;
    document.getElementById('king-board').style.display = 'none';
    const ok = generateFixedTeamsSchedule(state.players, validPairs, courtList, maxRounds);
    if(!ok) return;
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress(); autoSave();
    toast(`✅ Fixed Teams schedule ready: ${validPairs.length} teams, ${state.schedule.length} rounds!`);
    return;
  }

  // ── Normal rotating-partner modes ──────────────
  riverState.enabled = false;
  document.getElementById('king-board').style.display = 'none';

  // Only schedule active, checked-in players — those marked Left (active:false) or
  // not yet checked in are excluded entirely from tonight's matches.
  const activePlayers2 = state.players.filter(p => p.active !== false && p.waitlist !== true && p.checkedIn !== false);
  const activePlayerIdxMap = state.players.map((p,i) => i).filter(i => state.players[i].active !== false && state.players[i].waitlist !== true && state.players[i].checkedIn !== false);
  const schedulePlayers = activePlayers2;
  const na = schedulePlayers.length;

  if(na < 4) { toast('Need at least 4 active players', 'err'); return; }

  // ── BYE ROTATION ─────────────────────────────
  const courtsAvailable = Math.min(courtList.length, Math.floor(na / 4));
  const courtsPerRound  = courtsAvailable;
  const byeCount = na - courtsPerRound * 4;
  const byeHistory = new Array(na).fill(0);
  const surplusHistory = new Array(na).fill(0);
  state.byeRounds = [];
  const isMixedNormal = mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed';

  const partnerCount = Array.from({length:na}, () => new Array(na).fill(0));
  const oppCount     = Array.from({length:na}, () => new Array(na).fill(0));
  state.roundTeams   = [];
  state.schedule     = [];
  state.roundHistory = [];
  state.notifiedRounds = new Set();
  state.startedRounds  = new Set();
  let matchIdx = 0;

  for(let r = 0; r < maxRounds; r++) {

    let byePlayers = [];
    let surplusIdxs = []; // mixed-mode only: surplus-gender players playing each other this round
    let mixedCourtCount = courtsPerRound, surplusCourtCount = 0;

    if(isMixedNormal) {
      // Mixed modes pair as many 1-man-1-woman teams as the smaller gender
      // and the court count allow. Any leftover players from the LARGER
      // gender that's big enough to fill its own court (4 players) play each
      // other in a same-gender match instead of sitting out — surplus vs
      // surplus only, never a same-gender team against a mixed team. Only
      // the true remainder (fewer than 4 surplus players) goes to bye.
      const localIdxs = Array.from({length:na},(_,i)=>i);
      const males   = localIdxs.filter(i => schedulePlayers[i].gender === 'Male');
      const females = localIdxs.filter(i => schedulePlayers[i].gender === 'Female');
      const byFew = arr => [...arr].sort((a, b) => byeHistory[a] - byeHistory[b] || a - b);
      // Who's spent the FEWEST rounds in the surplus pool so far gets sent
      // there first — this is what actually rotates who plays mixed vs.
      // surplus each round. Without this, the same players (e.g. always the
      // highest-index women) would land in the surplus pool every round,
      // since byeHistory alone doesn't distinguish "played mixed" from
      // "played surplus" — both count as zero byes.
      const bySurplusFew = arr => [...arr].sort((a, b) => surplusHistory[a] - surplusHistory[b] || a - b);

      // How many mixed pairs (1M+1F) can we field, capped by court capacity?
      const pairsPossibleByGender = Math.min(males.length, females.length);
      const cap = courtsPerRound * 4;
      const maxMixedPairs = Math.min(pairsPossibleByGender - (pairsPossibleByGender % 2), Math.floor(cap / 2));
      mixedCourtCount = Math.floor(maxMixedPairs / 2);

      // Send whoever's had the MOST rounds in the surplus pool back to mixed
      // first (i.e. keep, for mixed, whoever has the FEWEST surplus rounds
      // so far is wrong — we want the opposite: prioritize moving frequent
      // surplus-sitters back into mixed). So "keep for mixed" = most surplus
      // rounds so far (descending), and "send to surplus" = fewest so far.
      const sortedMForMixed = [...males].sort((a,b) => surplusHistory[b] - surplusHistory[a] || a - b);
      const sortedFForMixed = [...females].sort((a,b) => surplusHistory[b] - surplusHistory[a] || a - b);
      const keepM = sortedMForMixed.slice(0, maxMixedPairs), keepF = sortedFForMixed.slice(0, maxMixedPairs);
      const surplusM = sortedMForMixed.slice(maxMixedPairs), surplusF = sortedFForMixed.slice(maxMixedPairs);
      let surplusPool = [...surplusM, ...surplusF];
      surplusPool.forEach(pi => surplusHistory[pi]++);

      // How many courts are left for surplus same-gender matches?
      const courtsLeftForSurplus = courtsPerRound - mixedCourtCount;
      const surplusByGender = g => surplusPool.filter(i => schedulePlayers[i].gender === g);
      let usableSurplus = [];
      if(courtsLeftForSurplus > 0) {
        ['Male', 'Female'].forEach(g => {
          if(surplusCourtCount >= courtsLeftForSurplus) return;
          const pool = surplusByGender(g);
          const courtsForThisGender = Math.min(Math.floor(pool.length / 4), courtsLeftForSurplus - surplusCourtCount);
          if(courtsForThisGender > 0) {
            usableSurplus.push(...byFew(pool).slice(0, courtsForThisGender * 4));
            surplusCourtCount += courtsForThisGender;
          }
        });
      }
      surplusIdxs = usableSurplus;
      const benchedSurplus = surplusPool.filter(i => !usableSurplus.includes(i));

      byePlayers = benchedSurplus;
      byePlayers.forEach(pi => byeHistory[pi]++);
    } else if(byeCount > 0) {
      // Pick bye players: those with fewest byes so far, random tiebreak
      const byeCandidates = Array.from({length:na},(_,i)=>i)
        .sort((a,b) => byeHistory[a] - byeHistory[b] || a - b);
      byePlayers = byeCandidates.slice(0, byeCount);
      byePlayers.forEach(pi => byeHistory[pi]++);
    }
    // Store bye players as global indices for display
    state.byeRounds.push(byePlayers.map(li => activePlayerIdxMap[li]));

    const activeIdxs = Array.from({length:na},(_,i)=>i).filter(i => !byePlayers.includes(i) && !surplusIdxs.includes(i));

    const roundPairs = pairPlayersFromPool(schedulePlayers, activeIdxs, mode, partnerCount, oppCount, r);
    if(roundPairs.length < 2 && !surplusIdxs.length) break;

    roundPairs.forEach(([a,b]) => { partnerCount[a][b]++; partnerCount[b][a]++; });

    const mixedCourts = courtList.slice(0, mixedCourtCount);
    const courtMatches = roundPairs.length >= 2
      ? matchPairs(roundPairs, oppCount, mixedCourtCount, mixedCourts, matchIdx, r, mode)
      : [];
    matchIdx += courtMatches.length;

    // Surplus same-gender pairing + court assignment, on whatever courts
    // weren't used for mixed play this round.
    let surplusCourtMatches = [];
    let surplusPairs = [];
    if(surplusIdxs.length >= 4) {
      surplusPairs = pairPlayersFromPool(schedulePlayers, surplusIdxs, 'balanced', partnerCount, oppCount, r);
      surplusPairs.forEach(([a,b]) => { partnerCount[a][b]++; partnerCount[b][a]++; });
      const surplusCourts = courtList.slice(mixedCourtCount, mixedCourtCount + surplusCourtCount);
      if(surplusPairs.length >= 2) {
        surplusCourtMatches = matchPairs(surplusPairs, oppCount, surplusCourtCount, surplusCourts, matchIdx, r, mode);
        matchIdx += surplusCourtMatches.length;
      } else {
        surplusPairs = []; // couldn't actually form a match — don't count these as "played"
      }
    }

    const allCourtMatches = [...courtMatches, ...surplusCourtMatches];
    allCourtMatches.forEach(([a,b,c,d]) => {
      oppCount[a][c]++; oppCount[a][d]++;
      oppCount[b][c]++; oppCount[b][d]++;
      oppCount[c][a]++; oppCount[c][b]++;
      oppCount[d][a]++; oppCount[d][b]++;
    });

    const roundMatches = allCourtMatches.map(([a,b,c,d,mid,court]) => ({
      id: mid, round: r+1, court,
      // Map local indices back to global state.players indices
      teamA: [activePlayerIdxMap[a], activePlayerIdxMap[b]],
      teamB: [activePlayerIdxMap[c], activePlayerIdxMap[d]],
      scoreA: '', scoreB: '', complete: false,
    }));

    if(!roundMatches.length) break;

    state.roundTeams.push(
      [...roundPairs, ...surplusPairs].map(([a,b]) => [schedulePlayers[a], schedulePlayers[b]])
    );
    state.schedule.push(roundMatches);
  }

  state.teams = [];
  state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));

  applyPartnerLocksAndSync();
  const totalMatches = state.schedule.reduce((a,r) => a + r.length, 0);
  const realRounds   = state.schedule.length;
  const dupPartners  = checkDuplicatePartners();
  const dupOpponents = checkDuplicateOpponents();
  const balanceStats = checkMatchBalance();
  const partnerWarn  = dupPartners  > 0 ? ` ⚠️ ${dupPartners} repeated partnership(s)` : ' ✓ partnerships unique';
  const oppWarn      = dupOpponents > 0 ? ` · ⚠️ ${dupOpponents} repeated opponent pair(s)` : ' · ✓ opponents unique';
  const balanceWarn  = ` · ⚖ avg gap: ${balanceStats.avgGap} (${balanceStats.even} even, ${balanceStats.close} close, ${balanceStats.uneven} uneven)`;
  const byeNote      = byeCount > 0 ? ` · 🪑 ${byeCount} bye(s)/round rotating` : '';
  const mixedReport  = isMixedNormal ? buildMixedComplianceReport() : null;
  const mixedNote    = mixedReport ? ` · ♀♂ mixed ${mixedReport.pct}%` : '';

  if(document.getElementById('schedule-info')) document.getElementById('schedule-info').textContent =
    `${realRounds} rounds · ${courtsPerRound} courts/round · ${totalMatches} matches ·${partnerWarn}${oppWarn}${balanceWarn}${byeNote}${mixedNote}`;

  renderSchedule();
  renderMixedModeWarning();
  mixedModeWarningToastIfNeeded();
  renderTeams();
  renderCourtsGrid();
  updateProgress();
  autoSave();
  // Clear any stale pod court warning from a previous run
  const _pw = document.getElementById('pod-court-warn');
  if(_pw) { _pw.textContent = ''; _pw.style.display = 'none'; }
  toast(`✅ Schedule ready: ${totalMatches} matches over ${realRounds} rounds!${byeCount>0?' ('+byeCount+' bye(s)/round)':''}`);
  if(typeof smsAutoSendIfEnabled === 'function') smsAutoSendIfEnabled(0);
  if(typeof msAutoPushIfEnabled === 'function') msAutoPushIfEnabled();
}

// ═══════════════════════════════════════════════
//  PAIR PLAYERS — all partner modes
// ═══════════════════════════════════════════════
// ── Bipartite matching on a restricted pool ───────────────────────────────
function bipartiteMatchPool(malePool, femalePool, partnerCount, mode, players) {
  const nM = malePool.length, nF = femalePool.length;
  const matchM = new Array(nM).fill(-1);
  const matchF = new Array(nF).fill(-1);

  function score(mi, fi) {
    if(mode === 'mixed-rated') return Math.abs(pRating(players[malePool[mi]]) - pRating(players[femalePool[fi]]));
    return 0;
  }
  function dfs(mi, visited) {
    const order = Array.from({length:nF},(_,fi)=>fi)
      .filter(fi => partnerCount[malePool[mi]][femalePool[fi]] === 0)
      .sort((a,b) => score(mi,a) - score(mi,b));
    for(const fi of order) {
      if(visited[fi]) continue;
      visited[fi] = true;
      if(matchF[fi] === -1 || dfs(matchF[fi], visited)) {
        matchM[mi] = fi; matchF[fi] = mi; return true;
      }
    }
    return false;
  }
  for(let mi = 0; mi < nM; mi++) dfs(mi, new Array(nF).fill(false));

  const pairs = [];
  const usedFIdx = new Set();
  malePool.forEach((m, mi) => {
    if(matchM[mi] === -1) return;
    pairs.push([m, femalePool[matchM[mi]]]);
    usedFIdx.add(matchM[mi]);
  });
  // Fallback unmatched
  const unmatchedM = malePool.filter((_,mi) => matchM[mi] === -1);
  const unmatchedF = femalePool.filter((_,fi) => !usedFIdx.has(fi));
  shuffle(unmatchedM); shuffle(unmatchedF);
  unmatchedM.forEach((m,i) => { if(unmatchedF[i] !== undefined) pairs.push([m, unmatchedF[i]]); });
  return pairs;
}

// ════════════════════════════════════════════
//  PODS MODE — group players by DUPR/Club, dedicated courts
// ════════════════════════════════════════════

// Split a single list of player indices into pods of at most podSize, applying
// the absorb rule: if the final leftover chunk would have fewer than 4 players,
// fold it into the previous chunk instead of stranding it (flagged hasAbsorb so
// the preview can show the "extra players rotate on bye" notice).
// idxs should already be sorted (e.g. by rating, strongest first) so labelFn
// can describe each resulting chunk (e.g. its DUPR range).
function chunkIntoPods(idxs, podSize, labelFn) {
  const pods = [];
  let i = 0;
  while(i < idxs.length) {
    let size = podSize;
    const remaining = idxs.length - i;
    // If remaining after this pod would be < 4, absorb into this pod
    if(remaining - size > 0 && remaining - size < 4) size = remaining;
    // If remaining is less than podSize, take all (handles last pod)
    if(remaining < size) size = remaining;
    const chunk = idxs.slice(i, i + size);
    const hasAbsorb = size > podSize; // this chunk swallowed a too-small remainder
    pods.push({ players: chunk, label: labelFn(chunk), ...(hasAbsorb ? { hasAbsorb: true } : {}) });
    i += size;
  }
  return pods;
}

// Kept for any external callers — applies podSize capping to a list of
// already-built pods (used when a single bucket, e.g. one Club Rating value
// or one bracket range, needs to be split into multiple same-label pods).
function applyAbsorb(pods) {
  const podSize = parseInt(document.getElementById('pods-size')?.value) || 8;
  const numerals = ['i','ii','iii','iv','v','vi','vii','viii'];
  return pods.flatMap(pod => {
    if(pod.players.length <= podSize) return [pod]; // fits in one pod, no split needed
    const split = chunkIntoPods(pod.players, podSize, () => pod.label);
    // Disambiguate same-label sub-pods (e.g. "Club Rating 4.0 (i)", "... (ii)")
    return split.length > 1
      ? split.map((sp, si) => ({ ...sp, label: sp.label + ' (' + (numerals[si] || (si+1)) + ')' }))
      : split;
  });
}

// Build pods: returns array of { players: [idx,...], label: string }
function buildPods() {
  const players  = state.players;
  const n        = players.length;
  const groupBy  = document.getElementById('pods-groupby')?.value || 'dupr';
  const podSize  = parseInt(document.getElementById('pods-size')?.value) || 8;

  let sortedIdxs;
  let labelFn;

  if(groupBy === 'club') {
    const clubWidth = document.getElementById('pods-club-width')?.value || 'exact';

    if(clubWidth === 'exact') {
      // Group by exact Club Rating value — everyone with the same rating forms a division.
      // Works for numeric levels (3.0, 3.5, 4.0…) and letter levels (A, B…) alike.
      const buckets = {};
      const none = [];
      players.forEach((p, i) => {
        if(p.active === false || p.waitlist === true || p.checkedIn === false) return;
        const key = String(p.clubRating ?? '').trim();
        if(!key) { none.push(i); return; }
        (buckets[key] = buckets[key] || []).push(i);
      });
      const pods = Object.entries(buckets)
        .sort((a, b) => {
          const na = parseFloat(a[0]), nb = parseFloat(b[0]);
          if(!isNaN(na) && !isNaN(nb)) return nb - na; // strongest rating = Pod A
          if(!isNaN(na)) return -1;
          if(!isNaN(nb)) return 1;
          return a[0].localeCompare(b[0]);
        })
        .map(([key, idxs]) => ({ players: idxs, label: 'Club Rating ' + key }));
      if(none.length) pods.push({ players: none, label: 'No Club Rating' });
      return applyAbsorb(pods);
    } else {
      // Group by Club Rating range (same logic as bracket mode but using clubRating)
      const width = parseFloat(clubWidth) || 0.5;
      const buckets = {};
      const unrated = [];
      players.forEach((p, i) => {
        if(p.active === false || p.waitlist === true || p.checkedIn === false) return;
        const r = parseFloat(p.clubRating);
        if(isNaN(r) || r <= 0) { unrated.push(i); return; }
        const lo = Math.floor(r / width + 1e-9) * width;
        const key = lo.toFixed(2);
        (buckets[key] = buckets[key] || []).push(i);
      });
      const fmt = v => (Math.round(v * 100) / 100).toFixed(2).replace(/\.?0+$/, '');
      const pods = Object.entries(buckets)
        .sort((a, b) => parseFloat(b[0]) - parseFloat(a[0])) // strongest division = Pod A
        .map(([key, idxs]) => {
          const lo = parseFloat(key);
          return { players: idxs, label: 'Club ' + fmt(lo) + '–' + fmt(lo + width - 0.01) };
        });
      if(unrated.length) pods.push({ players: unrated, label: 'No Club Rating' });
      return applyAbsorb(pods);
    }
  } else if(groupBy === 'gender') {
    // Men's division and women's division never cross-play — each gets its
    // own dedicated court(s), split further by podSize if either group is
    // larger than one pod's worth (same absorb-rule splitting as club/bracket).
    const buckets = {};
    const unspecified = [];
    players.forEach((p, i) => {
      if(p.active === false || p.waitlist === true || p.checkedIn === false) return;
      const g = (p.gender || '').trim();
      if(g !== 'Male' && g !== 'Female') { unspecified.push(i); return; }
      (buckets[g] = buckets[g] || []).push(i);
    });
    const pods = ['Male', 'Female']
      .filter(g => buckets[g] && buckets[g].length)
      .map(g => ({ players: buckets[g], label: g === 'Male' ? "Men's" : "Women's" }));
    if(unspecified.length) pods.push({ players: unspecified, label: 'Unspecified gender' });
    return applyAbsorb(pods);
  } else if(groupBy === 'bracket') {
    // Fixed rating ranges (e.g. 3.0–3.49) — division size varies with who signed up.
    // Uses DUPR, falls back to club rating; players with neither go in an Unrated division.
    const width = parseFloat(document.getElementById('pods-bracket-width')?.value) || 0.5;
    const buckets = {};
    const unrated = [];
    players.forEach((p, i) => {
      if(p.active === false || p.waitlist === true || p.checkedIn === false) return;
      const r = p.dupr ?? (pRating(p) || null);
      if(r == null || isNaN(r) || r <= 0) { unrated.push(i); return; }
      const lo = Math.floor(r / width + 1e-9) * width;
      const key = lo.toFixed(2);
      (buckets[key] = buckets[key] || []).push(i);
    });
    const fmt = v => (Math.round(v * 100) / 100).toFixed(2).replace(/\.?0+$/, '');
    const pods = Object.entries(buckets)
      .sort((a, b) => parseFloat(b[0]) - parseFloat(a[0])) // strongest division = Pod A
      .map(([key, idxs]) => {
        const lo = parseFloat(key);
        return { players: idxs, label: fmt(lo) + '–' + fmt(lo + width - 0.01) + ' DUPR' };
      });
    if(unrated.length) pods.push({ players: unrated, label: 'Unrated' });
    return applyAbsorb(pods);
  } else {
    // Group by DUPR — sort by rating descending (highest skill = Pod A)
    sortedIdxs = Array.from({length:n},(_,i)=>i)
      .filter(i => players[i].active !== false && players[i].waitlist !== true && players[i].checkedIn !== false)
      .sort((a,b) => {
        const ra = players[a].dupr ?? pRating(players[a]) ?? 0;
        const rb = players[b].dupr ?? pRating(players[b]) ?? 0;
        return rb - ra;
      });
    labelFn = (podIdxs) => {
      const ratings = podIdxs.map(i => players[i].dupr ?? pRating(players[i]) ?? 0).filter(r=>r>0);
      if(!ratings.length) return 'Unrated';
      const min = Math.min(...ratings).toFixed(1);
      const max = Math.max(...ratings).toFixed(1);
      return min === max ? min + ' DUPR' : min + '–' + max + ' DUPR';
    };
  }

  // Split into pods of podSize (last pod may be smaller/larger to keep multiples of 4)
  const pods = chunkIntoPods(sortedIdxs, podSize, labelFn);
  return pods;
}

function renderPodsPreview() {
  // Show/hide the right width/size selector based on groupBy mode
  const groupBy = document.getElementById('pods-groupby')?.value || 'dupr';
  const widthWrap     = document.getElementById('pods-bracket-width-wrap');
  const clubWidthWrap = document.getElementById('pods-club-width-wrap');
  const sizeWrap      = document.getElementById('pods-size-wrap');
  if(widthWrap)     widthWrap.style.display     = groupBy === 'bracket' ? '' : 'none';
  if(clubWidthWrap) clubWidthWrap.style.display  = groupBy === 'club'    ? '' : 'none';
  if(sizeWrap)      sizeWrap.style.display       = (groupBy === 'bracket' || groupBy === 'club') ? 'none' : '';

  const el = document.getElementById('pods-preview');
  if(!el) return;
  if(!state.players.length) { el.innerHTML = ''; return; }
  const pods = buildPods();
  const courtList = Array.from(state.selectedCourts).sort((a,b)=>a-b);
  const totalCourtsNeededPreview = pods.reduce((s, p) => s + (p.players.length >= 4 ? Math.floor(p.players.length / 4) : 0), 0);
  const courtsShortfall = Math.max(0, totalCourtsNeededPreview - courtList.length);
  let courtCursor = 0;

  el.innerHTML = '<div style="font-size:0.72rem;color:var(--txt3);text-transform:uppercase;letter-spacing:1px;margin-bottom:0.5rem">Pod Preview · ' + (groupBy === 'club' ? '<span style="color:#FFD54F">Club Rating</span>' : groupBy === 'gender' ? '<span style="color:#90CAF9">Gender</span>' : '<span style="color:#80CBC4">DUPR</span>') + '</div>'
    + (courtsShortfall > 0 ? '<div style="background:rgba(239,83,80,0.12);border:1px solid var(--red);border-radius:8px;padding:0.5rem 0.75rem;margin-bottom:0.5rem;font-size:0.82rem;color:var(--red)">⚠️ <strong>' + courtsShortfall + ' more court' + (courtsShortfall > 1 ? 's' : '') + ' needed</strong> — ' + totalCourtsNeededPreview + ' courts required for all pods, but only ' + courtList.length + ' selected. Enable more courts above before generating.</div>' : '')
    + '<div style="display:flex;flex-wrap:wrap;gap:0.6rem">'
    + pods.map((pod, pi) => {
        const tooSmall = pod.players.length < 4;
        const courtsNeeded = tooSmall ? 0 : Math.floor(pod.players.length / 4);
        let podCourts = [];
        if(!tooSmall) {
          if(courtCursor + courtsNeeded <= courtList.length) {
            podCourts = courtList.slice(courtCursor, courtCursor + courtsNeeded);
            courtCursor += courtsNeeded;
          }
          // else: no courts left — podCourts stays [] and card shows warning
        }
        // Show only the rating the grouping is based on: DUPR for dupr/bracket, CR for club rating
        const useCR = groupBy === 'club';
        const names = pod.players.map(idx => {
          const p = state.players[idx];
          if(!p) return '';
          const val   = useCR ? (p.clubRating || '—')
                              : ((p.dupr != null && !isNaN(p.dupr)) ? p.dupr.toFixed(2) : '—');
          const color = useCR ? '#FFD54F' : '#80CBC4';
          return '<span style="display:inline-block;margin:1px 8px 1px 0;white-space:nowrap">' + escHtml(p.name.split(' ')[0])
            + ' <span style="font-family:monospace;font-size:0.7rem;color:' + color + '">' + escHtml(val) + '</span></span>';
        }).join('');
        const podLetter = String.fromCharCode(65 + pi); // A, B, C...
        const courtNote = tooSmall
          ? '<span style="color:var(--red);font-weight:700">⚠ only ' + pod.players.length + ' player' + (pod.players.length===1?'':'s') + ' — sits out (needs 4)</span>'
          : podCourts.length < courtsNeeded
            ? '<span style="color:var(--ball);font-weight:700">⚠ No court available — enable ' + (courtsNeeded - podCourts.length) + ' more court' + (courtsNeeded - podCourts.length > 1 ? 's' : '') + '</span>'
          : pod.players.length + ' players · Court' + (podCourts.length>1?'s':'') + ' ' + podCourts.join(', ');
        const noCourt = !tooSmall && podCourts.length < courtsNeeded;
        return '<div style="background:var(--surface);border:1px solid ' + (tooSmall ? 'var(--red)' : noCourt ? 'var(--ball)' : 'var(--border)') + ';border-radius:8px;padding:0.6rem 0.85rem;min-width:200px;flex:1">'
          + '<div style="font-family:\'Bebas Neue\',sans-serif;color:var(--lime);font-size:1rem;letter-spacing:1px;margin-bottom:2px">'
          + 'Pod ' + podLetter + ' — ' + escHtml(pod.label)
          + '</div>'
          + '<div style="font-size:0.72rem;color:var(--txt3);margin-bottom:4px">' + courtNote + '</div>'
          + '<div style="font-size:0.78rem;color:var(--txt2)">' + names + '</div>'
          + '</div>';
      }).join('')
    + '</div>';
}

// Generate a full round-robin schedule with each pod confined to its own court(s)
function generatePodsSchedule() {
  const players   = state.players;
  const n         = players.length;
  const maxRounds = parseInt(document.getElementById('max-rounds')?.value) || 7;
  const pairing   = document.getElementById('pods-pairing')?.value || 'rotate';
  const courtList = Array.from(state.selectedCourts).sort((a,b)=>a-b);

  const pods = buildPods();
  if(!pods.length) { toast('No players to pod','err'); return; }

  // Assign courts sequentially to each pod.
  // Pods that can't get a court are skipped (players sit out) with a warning.
  // Never assign a court that isn't in the selected list.
  const totalCourtsNeeded = pods.reduce((sum, pod) => sum + (pod.players.length >= 4 ? Math.floor(pod.players.length / 4) : 0), 0);
  let courtCursor = 0;
  const skippedPods = [];
  pods.forEach((pod) => {
    if(pod.players.length < 4) {
      pod.courts = [];
      const names = pod.players.map(i => players[i]?.name.split(' ')[0]).join(', ');
      toast('⚠️ ' + pod.label + ' has only ' + pod.players.length + ' player' + (pod.players.length===1?'':'s') + ' (' + names + ') — sitting out, needs 4', 'err');
      return;
    }
    const courtsNeeded = Math.floor(pod.players.length / 4);
    if(courtCursor + courtsNeeded > courtList.length) {
      pod.courts = [];
      skippedPods.push({ label: pod.label, needed: courtsNeeded });
    } else {
      pod.courts = courtList.slice(courtCursor, courtCursor + courtsNeeded);
      courtCursor += courtsNeeded;
    }
  });
  const podWarnEl = document.getElementById('pod-court-warn');
  // Persist skipped pod info so renderSchedule can show inline red warnings
  state._skippedPods = skippedPods; // [{ label, needed }]
  if(skippedPods.length) {
    const missing = totalCourtsNeeded - courtList.length;
    const podNames = skippedPods.map(p => p.label).join(', ');
    const msg = '⚠️ ' + podNames + ' has no court assigned and will be skipped every round — '
      + missing + ' more court' + (missing > 1 ? 's' : '') + ' needed ('
      + totalCourtsNeeded + ' required, ' + courtList.length + ' selected). '
      + 'Go to the Courts tab and enable more courts, then regenerate.';
    toast(msg, 'err');
    if(podWarnEl) { podWarnEl.textContent = msg; podWarnEl.style.display = 'block'; }
  } else {
    state._skippedPods = [];
    if(podWarnEl) { podWarnEl.textContent = ''; podWarnEl.style.display = 'none'; }
  }

  state.roundTeams   = [];
  state.schedule     = [];
  state.roundHistory = [];
  state.byeRounds    = [];
  state.notifiedRounds = new Set();
  state.startedRounds  = new Set();
  state._podFixedPairs = []; // reset fixed pairing cache for fresh generation
  state._manualAdjustments = 0; // fresh generate clears manual adjustment history
  state._rrPlayoffPrompted = false;
  let matchIdx = 0;
  const podPartnerCount = pods.map(pod => {
    const m = pod.players.length;
    return Array.from({length:m}, () => new Array(m).fill(0));
  });
  const podOppCount = pods.map(pod => {
    const m = pod.players.length;
    return Array.from({length:m}, () => new Array(m).fill(0));
  });
  const podByeHistory = pods.map(pod => new Array(pod.players.length).fill(0));

  for(let r = 0; r < maxRounds; r++) {
    const roundMatches = [];
    const roundPairsGlobal = [];
    const byePlayersGlobal = [];

    pods.forEach((pod, podIdx) => {
      const m = pod.players.length;
      const byeCount = m % 4; // bench the remainder so active count is a multiple of 4

      let byeLocal = [];
      let localPairs;

      if(pairing === 'fixed') {
        // Pair the WHOLE pod once in round 0, then bench whole pairs on a rotation —
        // benching individuals would orphan their fixed partners.
        if(!state._podFixedPairs[podIdx]) {
          const everyone = Array.from({length:m},(_,i)=>i);
          state._podFixedPairs[podIdx] = buildLocalPairs(everyone, podPartnerCount[podIdx]);
          // Odd pod: buildLocalPairs leaves one player unpaired — they rotate in is not
          // possible with fixed pairs, so record them as a permanent bye and warn once.
          if(m % 2 === 1) {
            const paired = new Set(state._podFixedPairs[podIdx].flat());
            const odd = everyone.find(i => !paired.has(i));
            if(odd !== undefined) state._podFixedOdd = state._podFixedOdd || {}, state._podFixedOdd[podIdx] = odd;
            if(r === 0) toast('⚠️ Odd pod size with fixed partners — 1 player has no partner and will sit out', 'err');
          }
        }
        const allPairs   = state._podFixedPairs[podIdx];
        const pairsNeeded = Math.floor(m / 4) * 2; // 2 pairs per match
        const benchPairs  = Math.max(0, allPairs.length - pairsNeeded);
        // Bench the pairs that have sat out the least so far (rotates fairly)
        const ranked = allPairs.map((pr, i) => ({ pr, i,
          byes: podByeHistory[podIdx][pr[0]] + podByeHistory[podIdx][pr[1]] }))
          .sort((a,b) => a.byes - b.byes || a.idx - b.idx);
        const benched = ranked.slice(0, benchPairs).map(x => x.pr);
        const playing = ranked.slice(benchPairs).map(x => x.pr);
        benched.forEach(pr => pr.forEach(li => { byeLocal.push(li); podByeHistory[podIdx][li]++; }));
        const oddIdx = state._podFixedOdd?.[podIdx];
        if(oddIdx !== undefined) byeLocal.push(oddIdx);
        localPairs = playing;
      } else {
        // Rotating partners: bench individuals with the fewest byes so far
        if(byeCount > 0) {
          const candidates = Array.from({length:m},(_,i)=>i)
            .sort((a,b) => podByeHistory[podIdx][a] - podByeHistory[podIdx][b] || a - b);
          byeLocal = candidates.slice(0, byeCount);
          byeLocal.forEach(li => podByeHistory[podIdx][li]++);
        }
        const activeLocal = Array.from({length:m},(_,i)=>i).filter(i => !byeLocal.includes(i));
        if(activeLocal.length < 4) { byeLocal.forEach(li => byePlayersGlobal.push(pod.players[li])); return; }
        localPairs = buildLocalPairs(activeLocal, podPartnerCount[podIdx]);
      }

      byeLocal.forEach(li => byePlayersGlobal.push(pod.players[li]));
      if(localPairs.length < 2) return; // not enough pairs for a match this round

      localPairs.forEach(([a,b]) => { podPartnerCount[podIdx][a][b]++; podPartnerCount[podIdx][b][a]++; });

      // Match pairs into courts within this pod
      const podCourtMatches = matchLocalPairs(localPairs, podOppCount[podIdx], pod.courts.length, pod.courts, matchIdx, r);
      podCourtMatches.forEach(([a,b,c,d]) => {
        podOppCount[podIdx][a][c]++; podOppCount[podIdx][a][d]++;
        podOppCount[podIdx][b][c]++; podOppCount[podIdx][b][d]++;
        podOppCount[podIdx][c][a]++; podOppCount[podIdx][c][b]++;
        podOppCount[podIdx][d][a]++; podOppCount[podIdx][d][b]++;
      });

      podCourtMatches.forEach(([la,lb,lc,ld,mid,court]) => {
        const a = pod.players[la], b = pod.players[lb], c = pod.players[lc], d = pod.players[ld];
        roundMatches.push({
          id: mid, round: r+1, court,
          teamA: [a,b], teamB: [c,d],
          scoreA: '', scoreB: '', complete: false,
          podLabel: 'Pod ' + String.fromCharCode(65+podIdx) + ' · ' + pod.label,
        });
        matchIdx++;
        roundPairsGlobal.push([a,b], [c,d]);
      });
    });

    if(!roundMatches.length) {
      if(r === 0) toast('No division has enough players for a match — check the pod preview', 'err');
      break;
    }

    state.schedule.push(roundMatches);
    state.byeRounds.push(byePlayersGlobal);
    state.roundTeams.push(roundPairsGlobal.map(([a,b]) => [players[a], players[b]]));
  }

  state.teams = [];
  state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));

  applyPartnerLocksAndSync();

  if(document.getElementById('schedule-info')) document.getElementById('schedule-info').textContent =
    `🏟️ Pods mode · ${pods.length} pod${pods.length>1?'s':''} · ${state.schedule.length} rounds generated · ${players.length} players`;

  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
  autoSave();
  toast(`🏟️ ${pods.length} pod${pods.length>1?'s':''} created — ${state.schedule.length} rounds generated!`);
  if(typeof smsAutoSendIfEnabled === 'function') smsAutoSendIfEnabled(0);
  if(typeof msAutoPushIfEnabled === 'function') msAutoPushIfEnabled();
}

// ═══════════════════════════════════════════════
//  REGENERATE REMAINING ROUNDS (mid-tournament roster changes)
//  Keeps every round up to the last one with a recorded score, then rebuilds
//  the rest using only active players, seeding partner/opponent/bye history
//  from the kept rounds so repeats stay minimized.
// ═══════════════════════════════════════════════
function regenerateRemaining() {
  if(!state.schedule.length) { toast('No schedule yet — use ⚡ Generate Schedule first', 'err'); return; }

  const regenMode = document.getElementById('team-mode')?.value;
  if(regenMode === 'king') {
    toast('Regenerate isn\'t available for King of the Court — that mode advances round-by-round with its own ▶ Advance Round button', 'err');
    return;
  }

  // Cutoff: keep through the last round that's played OR already started
  const keep = protectedRoundCount();

  const n = state.players.length;
  const activeIdxs = state.players.map((p, i) => i).filter(i => state.players[i].active !== false && state.players[i].waitlist !== true && state.players[i].checkedIn !== false);
  const leftCount  = n - activeIdxs.length;
  if(activeIdxs.length < 4) { toast('Need at least 4 active players', 'err'); return; }

  const maxRounds  = parseInt(document.getElementById('max-rounds')?.value) || 7;
  const defaultNew = Math.max(1, maxRounds - keep);
  const promptMsg = (keep
      ? 'Keeping rounds 1–' + keep + ' (played or already started) exactly as they are.\n'
      : 'No rounds played or started yet — the whole schedule will be rebuilt.\n')
    + activeIdxs.length + ' active players' + (leftCount ? ' (' + leftCount + ' marked Left)' : '') + '.\n\n'
    + 'How many NEW rounds to generate?';
  const numNew = parseInt(prompt(promptMsg, defaultNew));
  if(!numNew || numNew < 1) return;

  // Seed history matrices from the kept rounds (global player indices)
  const partner = Array.from({length: n}, () => new Array(n).fill(0));
  const opp     = Array.from({length: n}, () => new Array(n).fill(0));
  const byeCnt  = new Array(n).fill(0);
  const surplusCnt = new Array(n).fill(0);
  const kept     = state.schedule.slice(0, keep);
  const keptByes = (state.byeRounds || []).slice(0, keep);
  let maxId = -1;
  state.schedule.flat().forEach(m => { if(m.id > maxId) maxId = m.id; });
  kept.forEach(round => round.forEach(m => {
    if(!m.teamA || !m.teamB) return;
    const [a, b] = m.teamA, [c, d] = m.teamB;
    if(a != null && b != null) { partner[a][b]++; partner[b][a]++; }
    if(c != null && d != null) { partner[c][d]++; partner[d][c]++; }
    [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => {
      if(x != null && y != null) { opp[x][y]++; opp[y][x]++; }
    });
  }));
  keptByes.forEach(byes => byes.forEach(i => { if(byeCnt[i] != null) byeCnt[i]++; }));

  // Groups: per pod in Pods mode (active roster), otherwise everyone together
  const mode = document.getElementById('team-mode')?.value;
  const isMixed = mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed';
  const courtList = Array.from(state.selectedCourts).sort((a, b) => a - b);
  let groups; // [{ idxs, courts, label }]
  if(mode === 'pods') {
    const pods = buildPods(); // already excludes players marked Left
    const totalNeeded3 = pods.reduce((s, p) => s + (p.players.length >= 4 ? Math.floor(p.players.length / 4) : 0), 0);
    const skipped3 = [];
    let cursor = 0;
    groups = pods.map((pod, pi) => {
      const playable = pod.players.length >= 4;
      const courtsNeeded = playable ? Math.floor(pod.players.length / 4) : 0;
      let courts = [];
      if(!playable) {
        toast('⚠️ ' + pod.label + ' has only ' + pod.players.length + ' active player' + (pod.players.length===1?'':'s') + ' — sitting out', 'err');
      } else if(cursor + courtsNeeded <= courtList.length) {
        courts = courtList.slice(cursor, cursor + courtsNeeded);
        cursor += courtsNeeded;
      } else {
        skipped3.push('Pod ' + String.fromCharCode(65 + pi));
      }
      return { idxs: pod.players, courts,
               label: 'Pod ' + String.fromCharCode(65 + pi) + ' · ' + pod.label };
    });
    if(skipped3.length) {
      const missing3 = totalNeeded3 - courtList.length;
      toast('⚠️ ' + skipped3.join(', ') + ' skipped — ' + missing3 + ' more court' + (missing3 > 1 ? 's' : '') + ' needed (' + totalNeeded3 + ' required, ' + courtList.length + ' selected). Enable more courts to run all pods.', 'err');
    }
  } else {
    groups = [{ idxs: activeIdxs, courts: courtList, label: null }];
  }

  // Generate the new rounds
  const newRounds = [], newByes = [], newRoundTeams = [];
  let matchIdx = maxId + 1;
  for(let r = 0; r < numNew; r++) {
    const roundMatches = [], roundByes = [], roundPairs = [];
    groups.forEach(g => {
      const m = g.idxs.length;
      if(m < 4 || !g.courts.length) { g.idxs.forEach(i => roundByes.push(i)); return; }
      // Bench enough players that the rest fill complete courts (capped by court count)
      const cap = g.courts.length * 4;
      let byes = [];
      let act;
      let surplusPool = [], surplusCourtsForGroup = 0, mixedCourtsForGroup = g.courts.length;
      if(isMixed) {
        // Keep equal M/F among active players so every team can be M+F. Any
        // leftover players from the larger gender, if there are at least 4 of
        // them, play each other in their own same-gender match instead of
        // sitting out — surplus vs surplus only, never against a mixed team.
        const males   = g.idxs.filter(i => state.players[i].gender === 'Male');
        const females = g.idxs.filter(i => state.players[i].gender === 'Female');
        const pairsPossible = Math.min(males.length, females.length);
        const maxMixedPairs = Math.min(pairsPossible - (pairsPossible % 2), (cap / 2));
        mixedCourtsForGroup = Math.floor(maxMixedPairs / 2);

        // Who's spent the MOST rounds as surplus gets priority back into mixed,
        // so being surplus rotates fairly instead of always landing on the
        // same players.
        const sortedM = [...males].sort((a,b) => surplusCnt[b] - surplusCnt[a] || a - b);
        const sortedF = [...females].sort((a,b) => surplusCnt[b] - surplusCnt[a] || a - b);
        const surplusM = sortedM.slice(maxMixedPairs), surplusF = sortedF.slice(maxMixedPairs);
        [...surplusM, ...surplusF].forEach(i => surplusCnt[i]++);

        const courtsLeftForSurplus = g.courts.length - mixedCourtsForGroup;
        const byFew = arr => [...arr].sort((a, b) => byeCnt[a] - byeCnt[b] || a - b);
        let usableSurplus = [], surplusCourtsUsed = 0;
        if(courtsLeftForSurplus > 0) {
          [surplusM, surplusF].forEach(genderPool => {
            if(surplusCourtsUsed >= courtsLeftForSurplus) return;
            const courtsForThisGender = Math.min(Math.floor(genderPool.length / 4), courtsLeftForSurplus - surplusCourtsUsed);
            if(courtsForThisGender > 0) {
              usableSurplus.push(...byFew(genderPool).slice(0, courtsForThisGender * 4));
              surplusCourtsUsed += courtsForThisGender;
            }
          });
        }
        surplusCourtsForGroup = surplusCourtsUsed;
        surplusPool = usableSurplus;

        const keepM = sortedM.slice(0, maxMixedPairs), keepF = sortedF.slice(0, maxMixedPairs);
        const keepSet = new Set([...keepM, ...keepF, ...surplusPool]);
        byes = g.idxs.filter(i => !keepSet.has(i));
        byes.forEach(i => byeCnt[i]++);
        act = [...keepM, ...keepF];
      } else {
        const playable = Math.min(m - (m % 4), cap);
        if(m - playable > 0) {
          byes = [...g.idxs].sort((a, b) => byeCnt[a] - byeCnt[b] || a - b).slice(0, m - playable);
          byes.forEach(i => byeCnt[i]++);
        }
        act = g.idxs.filter(i => !byes.includes(i));
      }
      byes.forEach(i => roundByes.push(i));
      if(act.length < 4 && surplusPool.length < 4) { act.forEach(i => roundByes.push(i)); return; }

      const mixedCourtsList = g.courts.slice(0, mixedCourtsForGroup);
      if(act.length >= 4) {
        const pairs = (isMixed && buildMixedLocalPairs(act, partner, state.players)) || buildLocalPairs(act, partner);
        pairs.forEach(([a, b]) => { partner[a][b]++; partner[b][a]++; });
        const courtMatches = matchLocalPairs(pairs, opp, mixedCourtsForGroup, mixedCourtsList, matchIdx, keep + r);
        courtMatches.forEach(([a, b, c, d, mid, court]) => {
          [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => { opp[x][y]++; opp[y][x]++; });
          const match = { id: mid, round: keep + r + 1, court,
                          teamA: [a, b], teamB: [c, d],
                          scoreA: '', scoreB: '', complete: false };
          if(g.label) match.podLabel = g.label;
          roundMatches.push(match);
          roundPairs.push([a, b], [c, d]);
          matchIdx++;
        });
      }

      // Surplus same-gender pairing on whatever courts are left for this group.
      if(surplusPool.length >= 4) {
        const surplusPairs = buildLocalPairs(surplusPool, partner);
        if(surplusPairs.length >= 2) {
          surplusPairs.forEach(([a, b]) => { partner[a][b]++; partner[b][a]++; });
          const surplusCourtsList = g.courts.slice(mixedCourtsForGroup, mixedCourtsForGroup + surplusCourtsForGroup);
          const surplusCourtMatches = matchLocalPairs(surplusPairs, opp, surplusCourtsForGroup, surplusCourtsList, matchIdx, keep + r);
          surplusCourtMatches.forEach(([a, b, c, d, mid, court]) => {
            [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => { opp[x][y]++; opp[y][x]++; });
            const match = { id: mid, round: keep + r + 1, court,
                            teamA: [a, b], teamB: [c, d],
                            scoreA: '', scoreB: '', complete: false };
            if(g.label) match.podLabel = g.label;
            roundMatches.push(match);
            roundPairs.push([a, b], [c, d]);
            matchIdx++;
          });
        }
      }
    });
    if(!roundMatches.length) break;
    newRounds.push(roundMatches);
    newByes.push(roundByes);
    newRoundTeams.push(roundPairs.map(([a, b]) => [state.players[a], state.players[b]]));
  }

  if(!newRounds.length) { toast('Could not build any new rounds — check active players and courts', 'err'); return; }

  // Splice the future onto the preserved past
  state.schedule   = kept.concat(newRounds);
  state.byeRounds  = keptByes.concat(newByes);
  state.roundTeams = (state.roundTeams || []).slice(0, keep).concat(newRoundTeams);
  applyPartnerLocks();
  // roundTeams must reflect any swaps applyPartnerLocks just made — rebuild
  // only the upcoming portion from the corrected schedule, leaving the kept
  // (played) rounds' roundTeams exactly as they were.
  for(let r = keep; r < state.schedule.length; r++) {
    state.roundTeams[r] = state.schedule[r].map(m => [state.players[m.teamA[0]], state.players[m.teamA[1]]])
      .concat(state.schedule[r].map(m => [state.players[m.teamB[0]], state.players[m.teamB[1]]]));
  }
  state.teams = [];
  state.roundTeams.forEach(rnd => rnd.forEach(pair => state.teams.push(pair)));
  // Forget completion notifications for rounds that no longer exist
  state.notifiedRounds = new Set([...state.notifiedRounds].filter(r => r < keep));
  state.startedRounds  = new Set([...(state.startedRounds||[])].filter(r => r < keep));

  if(document.getElementById('schedule-info')) document.getElementById('schedule-info').textContent =
    '🔁 Rounds 1–' + keep + ' preserved · ' + newRounds.length + ' new round' + (newRounds.length>1?'s':'') + ' for '
    + activeIdxs.length + ' active players' + (leftCount ? ' (' + leftCount + ' left)' : '');

  renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress(); renderPlayers();
  autoSave();
  toast('🔁 Kept ' + keep + ' played round' + (keep===1?'':'s') + ', generated ' + newRounds.length + ' new');
}

// Build local pairs for a pod: pairs players minimizing partner repeats
// Pair the whole pool minimizing partner repeats, preferring a perfect (zero-repeat)
// matching when one exists. Used for round-robin rebuild after a roster change.
function buildNonRepeatPairs(pool, partnerCount) {
  const idx = [...pool];
  const N = idx.length;
  // Try to find a perfect matching with no already-used partnerships via backtracking.
  const used = new Array(N).fill(false);
  const result = [];
  function backtrack(count) {
    if(count >= N - 1) return true; // 0 or 1 left over
    let a = -1;
    for(let i = 0; i < N; i++) if(!used[i]) { a = i; break; }
    if(a === -1) return true;
    used[a] = true;
    // Prefer partners never paired with, then fewest pairings; randomize ties
    const cands = [];
    for(let b = 0; b < N; b++) if(!used[b] && b !== a) cands.push(b);
    cands.sort((x, y) => partnerCount[idx[a]][idx[x]] - partnerCount[idx[a]][idx[y]] || idx[x] - idx[y]);
    for(const b of cands) {
      if(partnerCount[idx[a]][idx[b]] > 0) break; // no fresh partner available → bail to fallback
      used[b] = true;
      result.push([idx[a], idx[b]]);
      if(backtrack(count + 2)) return true;
      result.pop();
      used[b] = false;
    }
    used[a] = false;
    return false;
  }
  if(backtrack(0) && result.length === Math.floor(N / 2)) return result;
  // Fallback: greedy minimization (may include a few repeats if unavoidable)
  return buildLocalPairs(pool, partnerCount);
}

// Pair each male with a female (mixed modes), minimizing partner repeats.
// Returns null if it can't fully pair into M+F teams (caller falls back).
function buildMixedLocalPairs(activeLocal, partnerCount, players) {
  const males   = activeLocal.filter(i => players[i].gender === 'Male');
  const females = activeLocal.filter(i => players[i].gender === 'Female');
  // Need equal counts to form all-mixed pairs and an even number of pairs for matches
  if(males.length !== females.length) return null;
  // Global minimum-weight bipartite matching (males vs females)
  const NM = males.length;
  // Build all M×F edges
  const edges = [];
  for(let mi = 0; mi < NM; mi++)
    for(let fi = 0; fi < NM; fi++)
      edges.push({ mi, fi, w: partnerCount[males[mi]][females[fi]] });
  edges.sort((a, b) => a.w - b.w || a.mi - b.mi || a.fi - b.fi);

  const usedM = new Array(NM).fill(false);
  const usedF = new Array(NM).fill(false);
  const pairs = [];
  for(const e of edges) {
    if(usedM[e.mi] || usedF[e.fi]) continue;
    pairs.push([males[e.mi], females[e.fi]]);
    usedM[e.mi] = usedF[e.fi] = true;
    if(pairs.length >= NM) break;
  }
  return pairs;
}

function buildLocalPairs(activeLocal, partnerCount) {
  // Global minimum-weight matching to minimise total partner repeat count.
  // Uses greedy edge selection (sort all edges by weight) + 2-opt improvement.
  const pool = [...activeLocal];
  const N = pool.length;
  if(N < 2) return [];
  if(N === 2) return [[pool[0], pool[1]]];

  // Build all edges sorted by partnerCount (fewest repeats first), random tiebreak
  const edges = [];
  for(let i = 0; i < N; i++)
    for(let j = i + 1; j < N; j++)
      edges.push({ i, j, w: partnerCount[pool[i]][pool[j]] });
  edges.sort((a, b) => a.w - b.w || a.i - b.i || a.j - b.j);

  // Greedy matching: pick cheapest edge, mark both vertices used
  const used = new Array(N).fill(false);
  const matching = [];
  for(const e of edges) {
    if(used[e.i] || used[e.j]) continue;
    matching.push(e);
    used[e.i] = used[e.j] = true;
    if(matching.length >= Math.floor(N / 2)) break;
  }

  // 2-opt improvement: try all swaps of two matched pairs (capped to avoid UI freeze)
  let improved = true;
  let _passes1 = 0;
  while(improved && _passes1++ < 8) {
    improved = false;
    for(let x = 0; x < matching.length; x++) {
      for(let y = x + 1; y < matching.length; y++) {
        const { i: i1, j: j1 } = matching[x];
        const { i: i2, j: j2 } = matching[y];
        const cur = partnerCount[pool[i1]][pool[j1]] + partnerCount[pool[i2]][pool[j2]];
        if(i1 !== i2 && i1 !== j2 && j1 !== i2 && j1 !== j2) {
          const s1 = partnerCount[pool[i1]][pool[j2]] + partnerCount[pool[i2]][pool[j1]];
          if(s1 < cur) {
            matching[x] = { i: i1, j: j2, w: partnerCount[pool[i1]][pool[j2]] };
            matching[y] = { i: i2, j: j1, w: partnerCount[pool[i2]][pool[j1]] };
            improved = true; continue;
          }
          const s2 = partnerCount[pool[i1]][pool[i2]] + partnerCount[pool[j1]][pool[j2]];
          if(s2 < cur) {
            matching[x] = { i: i1, j: i2, w: partnerCount[pool[i1]][pool[i2]] };
            matching[y] = { i: j1, j: j2, w: partnerCount[pool[j1]][pool[j2]] };
            improved = true;
          }
        }
      }
    }
  }
  return matching.map(e => [pool[e.i], pool[e.j]]);
}

// Match local pairs into courts within a pod, minimizing opponent repeats (global matching)
function matchLocalPairs(pairs, oppCount, numCourts, courtNumbers, matchIdxStart, roundIdx) {
  const NP = pairs.length;
  if(NP < 2) return [];
  let mid = matchIdxStart;

  // Build all pair-vs-pair edges, score = total opponent repeat count
  const edges = [];
  for(let i = 0; i < NP; i++)
    for(let j = i + 1; j < NP; j++) {
      const [a,b] = pairs[i], [c,d] = pairs[j];
      const score = oppCount[a][c] + oppCount[a][d] + oppCount[b][c] + oppCount[b][d];
      edges.push({ i, j, score });
    }
  edges.sort((a, b) => a.score - b.score || a.i - b.i || a.j - b.j);

  const usedPairs = new Array(NP).fill(false);
  const matching = [];
  for(const e of edges) {
    if(usedPairs[e.i] || usedPairs[e.j]) continue;
    matching.push(e);
    usedPairs[e.i] = usedPairs[e.j] = true;
    if(matching.length >= Math.min(Math.floor(NP / 2), numCourts)) break;
  }

  // 2-opt improvement (capped)
  let improved = true;
  let _passes2 = 0;
  while(improved && _passes2++ < 8) {
    improved = false;
    for(let x = 0; x < matching.length; x++) {
      for(let y = x + 1; y < matching.length; y++) {
        const {i:i1,j:j1} = matching[x], {i:i2,j:j2} = matching[y];
        const [a1,b1]=pairs[i1],[c1,d1]=pairs[j1],[a2,b2]=pairs[i2],[c2,d2]=pairs[j2];
        const cur = (oppCount[a1][c1]+oppCount[a1][d1]+oppCount[b1][c1]+oppCount[b1][d1])
                  + (oppCount[a2][c2]+oppCount[a2][d2]+oppCount[b2][c2]+oppCount[b2][d2]);
        if(i1!==j2 && j1!==i2) {
          const [a3,b3]=pairs[i1],[c3,d3]=pairs[j2],[a4,b4]=pairs[i2],[c4,d4]=pairs[j1];
          const sw = (oppCount[a3][c3]+oppCount[a3][d3]+oppCount[b3][c3]+oppCount[b3][d3])
                   + (oppCount[a4][c4]+oppCount[a4][d4]+oppCount[b4][c4]+oppCount[b4][d4]);
          if(sw < cur) { matching[x]={i:i1,j:j2}; matching[y]={i:i2,j:j1}; improved=true; continue; }
        }
        if(i1!==i2 && j1!==j2) {
          const [a3,b3]=pairs[i1],[c3,d3]=pairs[i2],[a4,b4]=pairs[j1],[c4,d4]=pairs[j2];
          const sw = (oppCount[a3][c3]+oppCount[a3][d3]+oppCount[b3][c3]+oppCount[b3][d3])
                   + (oppCount[a4][c4]+oppCount[a4][d4]+oppCount[b4][c4]+oppCount[b4][d4]);
          if(sw < cur) { matching[x]={i:i1,j:i2}; matching[y]={i:j1,j:j2}; improved=true; }
        }
      }
    }
  }

  return matching.map(({i, j}) => {
    const [a,b] = pairs[i], [c,d] = pairs[j];
    return [a, b, c, d, mid++, courtNumbers[matching.indexOf({i,j})]];
  }).map((r, ci) => { r[5] = courtNumbers[ci]; return r; });
}

function pairPlayersFromPool(players, pool, mode, partnerCount, oppCount, roundIndex) {
  const pairs = [];
  const ratingDiff = (a,b) => Math.abs(pRating(players[a]) - pRating(players[b]));

  function greedyPairPool(scoreFn) {
    // Global minimum-weight matching: combined score of partner repeats + scoreFn
    // Enumerate all edges, sort by combined cost, greedily pick, then 2-opt improve
    const N = pool.length;
    const edges = [];
    for(let i = 0; i < N; i++)
      for(let j = i + 1; j < N; j++) {
        const a = pool[i], b = pool[j];
        const repeatCost = partnerCount[a][b] * 1000; // heavy penalty for repeat partners
        const rateCost   = scoreFn(a, b);
        edges.push({ i, j, w: repeatCost + rateCost });
      }
    edges.sort((a, b) => a.w - b.w || a.i - b.i || a.j - b.j);

    const used = new Array(N).fill(false);
    const matching = [];
    for(const e of edges) {
      if(used[e.i] || used[e.j]) continue;
      matching.push(e);
      used[e.i] = used[e.j] = true;
      if(matching.length >= Math.floor(N / 2)) break;
    }

    // 2-opt improvement (capped to avoid UI freeze)
    let improved = true;
    let _passes3 = 0;
    while(improved && _passes3++ < 8) {
      improved = false;
      for(let x = 0; x < matching.length; x++) {
        for(let y = x + 1; y < matching.length; y++) {
          const { i: i1, j: j1 } = matching[x];
          const { i: i2, j: j2 } = matching[y];
          const cur = matching[x].w + matching[y].w;
          if(i1 !== j2 && j1 !== i2) {
            const a1=pool[i1],b1=pool[j2],a2=pool[i2],b2=pool[j1];
            const sw1 = (partnerCount[a1][b1]*1000+scoreFn(a1,b1)) + (partnerCount[a2][b2]*1000+scoreFn(a2,b2));
            if(sw1 < cur - 1e-6) {
              matching[x].w = partnerCount[pool[i1]][pool[j2]]*1000+scoreFn(pool[i1],pool[j2]);
              matching[y].w = partnerCount[pool[i2]][pool[j1]]*1000+scoreFn(pool[i2],pool[j1]);
              matching[x] = {i:i1,j:j2,w:matching[x].w};
              matching[y] = {i:i2,j:j1,w:matching[y].w};
              improved = true; continue;
            }
          }
          if(i1 !== i2 && j1 !== j2) {
            const a1=pool[i1],b1=pool[i2],a2=pool[j1],b2=pool[j2];
            const sw2 = (partnerCount[a1][b1]*1000+scoreFn(a1,b1)) + (partnerCount[a2][b2]*1000+scoreFn(a2,b2));
            if(sw2 < cur - 1e-6) {
              matching[x] = {i:i1,j:i2,w:partnerCount[pool[i1]][pool[i2]]*1000+scoreFn(pool[i1],pool[i2])};
              matching[y] = {i:j1,j:j2,w:partnerCount[pool[j1]][pool[j2]]*1000+scoreFn(pool[j1],pool[j2])};
              improved = true;
            }
          }
        }
      }
    }

    matching.forEach(e => pairs.push([pool[e.i], pool[e.j]]));
  }

  if(mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed') {
    const males   = pool.filter(i => players[i].gender === 'Male');
    const females = pool.filter(i => players[i].gender === 'Female');
    const matched = bipartiteMatchPool(males, females, partnerCount, mode, players);
    matched.forEach(p => pairs.push(p));
    const used = new Set(pairs.flat());
    const leftoverM = males.filter(i => !used.has(i));
    const leftoverF = females.filter(i => !used.has(i));
    // Leftover players only happen when the no-repeat-partner bipartite match
    // couldn't find a full pairing (partner history blocked every option) —
    // NOT because the pool is gender-imbalanced (the bye-selection step keeps
    // it balanced). Pair any remaining males with remaining females directly,
    // accepting a repeat partnership this once rather than ever pairing two
    // of the same gender, which mixed mode must never do.
    shuffle(leftoverM); shuffle(leftoverF);
    const leftoverPairCount = Math.min(leftoverM.length, leftoverF.length);
    for(let i = 0; i < leftoverPairCount; i++) pairs.push([leftoverM[i], leftoverF[i]]);
    // In the rare case the genders still don't divide evenly here (shouldn't
    // happen given a balanced pool, but stay safe rather than silently drop
    // people), fall back to pairing whoever's left among themselves.
    const stillLeft = [...leftoverM.slice(leftoverPairCount), ...leftoverF.slice(leftoverPairCount)];
    for(let i=0;i+1<stillLeft.length;i+=2) pairs.push([stillLeft[i],stillLeft[i+1]]);

  } else if(mode === 'snake') {
    const sorted = [...pool].sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const used = new Set();
    let lo = sorted.length-1;
    for(let hi=0; hi<sorted.length&&hi<lo; hi++) {
      if(used.has(sorted[hi])) continue;
      while(lo>hi&&used.has(sorted[lo])) lo--;
      if(lo<=hi) break;
      let best=lo;
      for(let k=lo;k>hi;k--) {
        if(!used.has(sorted[k])&&partnerCount[sorted[hi]][sorted[k]]<partnerCount[sorted[hi]][sorted[best]]) best=k;
      }
      pairs.push([sorted[hi],sorted[best]]);
      used.add(sorted[hi]); used.add(sorted[best]);
      lo=sorted.length-1; while(used.has(sorted[lo])) lo--;
    }

  } else if(mode === 'balanced') {
  // scoreFn for partner pairing: prefer similar ratings (low diff) AND penalise
  // high within-pair spread so a 4.0+2.0 partnership is avoided even when average matches.
  // Spread penalty is proportional to the rating gap between the two partners.
  const SPREAD_WEIGHT = 1.5; // tune: how strongly to discourage mismatched partners
  const spreadPenalty = (a, b) => SPREAD_WEIGHT * Math.abs(pRating(players[a]) - pRating(players[b]));
  greedyPairPool((pi,c) => ratingDiff(pi,c) + spreadPenalty(pi,c));

  } else if(mode === 'equalizer') {
    const byRating=[...pool].sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const used=new Set(); let lo=byRating.length-1;
    for(let hi=0;hi<byRating.length&&hi<lo;hi++) {
      if(used.has(byRating[hi])) continue;
      while(lo>hi&&used.has(byRating[lo])) lo--;
      if(lo<=hi) break;
      let partner=byRating[lo];
      for(let k=lo;k>hi;k--) {
        if(!used.has(byRating[k])&&partnerCount[byRating[hi]][byRating[k]]===0){partner=byRating[k];break;}
      }
      pairs.push([byRating[hi],partner]);
      used.add(byRating[hi]); used.add(partner);
      lo=byRating.length-1; while(used.has(byRating[lo])) lo--;
    }

  } else if(mode === 'progressive') {
    const tierSize=Math.max(4,Math.floor(pool.length/4));
    const sorted=[...pool].sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const numTiers=Math.ceil(sorted.length/tierSize);
    const shift=(roundIndex||0)%Math.max(1,numTiers);
    const tiers=Array.from({length:numTiers},(_,t)=>sorted.slice(t*tierSize,(t+1)*tierSize));
    const used=new Set();
    for(let t=0;t<numTiers;t++){
      const dstIdx=(t+1+shift)%numTiers;
      const src=tiers[t], dst=dstIdx===t ? [] : tiers[dstIdx]; // guard: skip if src===dst
      for(const pi of src){
        if(used.has(pi)) continue;
        const avail=dst.filter(j=>!used.has(j)&&j!==pi);
        if(!avail.length) break;
        const fresh=avail.filter(j=>partnerCount[pi][j]===0);
        const c2=fresh.length?fresh:avail;
        c2.sort((a,b)=>partnerCount[pi][a]-partnerCount[pi][b]);
        pairs.push([pi,c2[0]]); used.add(pi); used.add(c2[0]);
      }
    }
    const leftover=pool.filter(i=>!used.has(i)); shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);

  } else if(mode === 'crossover') {
    const lastRound=state.roundHistory[state.roundHistory.length-1];
    if(!lastRound||!lastRound.winners.length){
      const p=[...pool]; shuffle(p);
      for(let i=0;i+1<p.length;i+=2) pairs.push([p[i],p[i+1]]);
    } else {
      const winners=lastRound.winners.filter(w=>pool.includes(w)); shuffle(winners);
      const losers=lastRound.losers.filter(l=>pool.includes(l));   shuffle(losers);
      const used=new Set();
      winners.forEach(w=>{
        if(used.has(w)) return;
        const avail=losers.filter(l=>!used.has(l));
        if(!avail.length) return;
        const fresh=avail.filter(l=>partnerCount[w][l]===0);
        const c2=fresh.length?fresh:avail;
        c2.sort((a,b)=>partnerCount[w][a]-partnerCount[w][b]);
        pairs.push([w,c2[0]]); used.add(w); used.add(c2[0]);
      });
      const leftover=pool.filter(i=>!used.has(i)); shuffle(leftover);
      for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);
    }

  } else if(mode === 'roundrobin-partners') {
    const round=roundIndex||0;
    const rotated=round===0?[...pool]:[pool[0],...pool.slice(pool.length-round),...pool.slice(1,pool.length-round)];
    const used=new Set();
    for(let i=0;i<rotated.length/2;i++){
      const pi=rotated[i], pj=rotated[rotated.length-1-i];
      if(pi===pj||used.has(pi)||used.has(pj)) continue;
      pairs.push([pi,pj]); used.add(pi); used.add(pj);
    }
    const leftover=pool.filter(i=>!used.has(i)); shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);

  } else if(mode === 'mexicano') {
    // ── Mexicano ─────────────────────────────────────────────────────
    // Rank all players by cumulative points scored (from state.schedule completed matches).
    // Then: rank1 + rank2 as a team vs rank3 + rank4; rank5 + rank6 vs rank7 + rank8, etc.
    // If no scores yet, fall back to random pairs.
    const mxScores = {};
    pool.forEach(i => { mxScores[i] = 0; });
    state.schedule.forEach(round => round.forEach(m => {
      if(!m.complete) return;
      (m.teamA||[]).forEach(i => { if(pool.includes(i)) mxScores[i] = (mxScores[i]||0) + (+m.scoreA||0); });
      (m.teamB||[]).forEach(i => { if(pool.includes(i)) mxScores[i] = (mxScores[i]||0) + (+m.scoreB||0); });
    }));
    const mxRanked = [...pool].sort((a, b) => (mxScores[b]||0) - (mxScores[a]||0) || a - b);
    // Pair consecutive ranks as partners: (1,2), (3,4), (5,6), (7,8)...
    for(let i = 0; i + 1 < mxRanked.length; i += 2) {
      pairs.push([mxRanked[i], mxRanked[i+1]]);
    }

  } else if(mode === 'americano') {
    // ── Americano ────────────────────────────────────────────────────
    // Partners rotate round-robin (everyone partners everyone, circle method).
    // Same as roundrobin-partners — partner rotation is handled there.
    // Opponents will be matched by ranking in matchPairs.
    const round = roundIndex || 0;
    const rotated = round === 0 ? [...pool] : [pool[0], ...pool.slice(pool.length - round), ...pool.slice(1, pool.length - round)];
    const used = new Set();
    for(let i = 0; i < rotated.length / 2; i++) {
      const pi = rotated[i], pj = rotated[rotated.length - 1 - i];
      if(pi === pj || used.has(pi) || used.has(pj)) continue;
      pairs.push([pi, pj]); used.add(pi); used.add(pj);
    }
    const leftover = pool.filter(i => !used.has(i));
    for(let i = 0; i + 1 < leftover.length; i += 2) pairs.push([leftover[i], leftover[i+1]]);

  } else if(mode === 'dupr') {
    // ── DUPR Session pairing ─────────────────────────────────────────
    // Official DUPR format: players matched within same rating bracket/range.
    // Brackets: 2.00-2.99 Beginner | 3.00-3.99 Intermediate | 4.00-4.99 Advanced
    //           5.00-5.99 Elite    | 6.00-8.00 Pro
    const aggCap    = parseFloat(document.getElementById('dupr-agg-cap')?.value)    || 16;
    const maxInd    = parseFloat(document.getElementById('dupr-max-ind')?.value)    || 8;
    const nrRating  = parseFloat(document.getElementById('dupr-nr-default')?.value) || 3.5;
    const rangeTol  = document.getElementById('dupr-range-tol')?.value              || '1.0';

    const DUPR_BRACKETS = [
      { min: 2.00, max: 2.999, label: 'Beginner',     color: '#42A5F5' },
      { min: 3.00, max: 3.999, label: 'Intermediate', color: '#66BB6A' },
      { min: 4.00, max: 4.999, label: 'Advanced',     color: '#F9A825' },
      { min: 5.00, max: 5.999, label: 'Elite',        color: '#AB47BC' },
      { min: 6.00, max: 8.000, label: 'Pro',          color: '#C6FF00' },
    ];

    const duprOf = (pi) => {
      const p = players[pi];
      return (p.dupr != null && !isNaN(p.dupr)) ? p.dupr : nrRating;
    };

    const bracketOf = (d) => DUPR_BRACKETS.findIndex(b => d >= b.min && d <= b.max);

    // Players exceeding max individual cap sit out
    const eligible = pool.filter(pi => duprOf(pi) <= maxInd);

    // Check if two players can be paired (range tolerance)
    const canPair = (a, b) => {
      const da = duprOf(a), db = duprOf(b);
      if(rangeTol === 'bracket') return bracketOf(da) === bracketOf(db);
      if(rangeTol === 'any')     return true;
      return Math.abs(da - db) <= parseFloat(rangeTol);
    };

    // Group players by bracket for bracket mode, or use full pool
    const sorted = [...eligible].sort((a, b) => duprOf(b) - duprOf(a));
    const used = new Set();

    sorted.forEach(hi => {
      if(used.has(hi)) return;
      const hiDupr = duprOf(hi);
      const maxPartnerDupr = aggCap - hiDupr;

      // Candidates: not used, within range tolerance, within aggregate cap
      const candidates = sorted.filter(j =>
        !used.has(j) && j !== hi &&
        canPair(hi, j) &&
        duprOf(j) <= maxPartnerDupr
      );

      if(!candidates.length) {
        // Relax range constraint: try anyone within aggregate cap
        const fallback = sorted.filter(j =>
          !used.has(j) && j !== hi && duprOf(j) <= maxPartnerDupr
        );
        if(!fallback.length) return;
        // Pick fresh partner closest to cap aggregate
        const fresh = fallback.filter(j => partnerCount[hi][j] === 0);
        const pool2 = fresh.length ? fresh : fallback;
        pool2.sort((a, b) => Math.abs((aggCap - hiDupr - duprOf(a))) - Math.abs((aggCap - hiDupr - duprOf(b))));
        pairs.push([hi, pool2[0]]);
        used.add(hi); used.add(pool2[0]);
        return;
      }

      // Pick fresh partner whose aggregate is closest to cap (most competitive)
      const fresh = candidates.filter(j => partnerCount[hi][j] === 0);
      const pool2 = fresh.length ? fresh : candidates;
      pool2.sort((a, b) =>
        Math.abs((aggCap - hiDupr - duprOf(a))) - Math.abs((aggCap - hiDupr - duprOf(b)))
      );
      pairs.push([hi, pool2[0]]);
      used.add(hi); used.add(pool2[0]);
    });

    // Leftover players — pair them regardless
    const leftover = eligible.filter(i => !used.has(i));
    shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i], leftover[i+1]]);

  } else {
    const p=[...pool]; shuffle(p);
    for(let i=0;i+1<p.length;i+=2) pairs.push([p[i],p[i+1]]);
  }

  return pairs;
}


function bipartiteMatchMixed(males, females, partnerCount, mode, players) {
  const nM = males.length, nF = females.length;
  const matchM = new Array(nM).fill(-1);
  const matchF = new Array(nF).fill(-1);

  function score(mi, fi) {
    if(mode === 'mixed-rated') return Math.abs(pRating(players[males[mi]]) - pRating(players[females[fi]]));
    return 0;
  }

  function dfs(mi, visited) {
    const order = Array.from({length: nF}, (_, fi) => fi)
      .filter(fi => partnerCount[males[mi]][females[fi]] === 0)
      .sort((a, b) => score(mi, a) - score(mi, b));
    for(const fi of order) {
      if(visited[fi]) continue;
      visited[fi] = true;
      if(matchF[fi] === -1 || dfs(matchF[fi], visited)) {
        matchM[mi] = fi; matchF[fi] = mi;
        return true;
      }
    }
    return false;
  }

  for(let mi = 0; mi < nM; mi++) {
    dfs(mi, new Array(nF).fill(false));
  }

  const pairs = [];
  const usedFIdx = new Set();
  males.forEach((m, mi) => {
    if(matchM[mi] === -1) return;
    pairs.push([m, females[matchM[mi]]]);
    usedFIdx.add(matchM[mi]);
  });

  // Fallback for unmatched (unequal gender counts only)
  const unmatchedM = males.filter((_, mi) => matchM[mi] === -1);
  const unmatchedF = females.filter((_, fi) => !usedFIdx.has(fi));
  shuffle(unmatchedM); shuffle(unmatchedF);
  unmatchedM.forEach((m, i) => { if(unmatchedF[i] !== undefined) pairs.push([m, unmatchedF[i]]); });

  return pairs;
}

// ═══════════════════════════════════════════════
//  PAIR PLAYERS — all partner modes
// ═══════════════════════════════════════════════
function pairPlayers(players, n, mode, partnerCount, oppCount, roundIndex) {
  const pairs = [];
  const ratingDiff = (a, b) => Math.abs(pRating(players[a]) - pRating(players[b]));

  function greedyPair(pool, scoreFn) {
    const used = new Set();
    const sorted = [...pool].sort((a, b) => {
      const an = pool.filter(j => j!==a && partnerCount[a][j]===0).length;
      const bn = pool.filter(j => j!==b && partnerCount[b][j]===0).length;
      return an - bn;
    });
    for(const pi of sorted) {
      if(used.has(pi)) continue;
      const candidates = pool.filter(j => j !== pi && !used.has(j));
      if(!candidates.length) break;
      const fresh = candidates.filter(j => partnerCount[pi][j] === 0);
      const pool2 = fresh.length ? fresh : candidates;
      pool2.sort((a, b) => scoreFn(pi, a) - scoreFn(pi, b));
      pairs.push([pi, pool2[0]]);
      used.add(pi); used.add(pool2[0]);
    }
  }

  if(mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed') {
    const males=[], females=[];
    for(let i=0;i<n;i++) (players[i].gender==='Male'?males:females).push(i);
    const matched = bipartiteMatchMixed(males, females, partnerCount, mode, players);
    matched.forEach(p => pairs.push(p));
    const used = new Set(pairs.flat());
    const leftover = Array.from({length:n},(_,i)=>i).filter(i=>!used.has(i));
    shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);

  } else if(mode === 'snake') {
    const sorted = Array.from({length:n},(_,i)=>i).sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const used = new Set();
    let lo = sorted.length-1;
    for(let hi=0; hi<sorted.length && hi<lo; hi++) {
      if(used.has(sorted[hi])) continue;
      while(lo>hi && used.has(sorted[lo])) lo--;
      if(lo<=hi) break;
      let best=lo;
      for(let k=lo;k>hi;k--) {
        if(!used.has(sorted[k]) && partnerCount[sorted[hi]][sorted[k]] < partnerCount[sorted[hi]][sorted[best]]) best=k;
      }
      pairs.push([sorted[hi],sorted[best]]);
      used.add(sorted[hi]); used.add(sorted[best]);
      lo=sorted.length-1; while(used.has(sorted[lo])) lo--;
    }

  } else if(mode === 'balanced') {
  const SPREAD_WEIGHT2 = 1.5;
  const spreadPenalty2 = (a, b) => SPREAD_WEIGHT2 * Math.abs(pRating(players[a]) - pRating(players[b]));
  greedyPair(Array.from({length:n},(_,i)=>i), (pi,c) => ratingDiff(pi,c) + spreadPenalty2(pi,c));

  } else if(mode === 'equalizer') {
    const byRating=Array.from({length:n},(_,i)=>i).sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const used=new Set();
    let lo=byRating.length-1;
    for(let hi=0;hi<byRating.length&&hi<lo;hi++) {
      if(used.has(byRating[hi])) continue;
      while(lo>hi&&used.has(byRating[lo])) lo--;
      if(lo<=hi) break;
      let partner=byRating[lo];
      for(let k=lo;k>hi;k--) {
        if(!used.has(byRating[k])&&partnerCount[byRating[hi]][byRating[k]]===0){partner=byRating[k];break;}
      }
      pairs.push([byRating[hi],partner]);
      used.add(byRating[hi]); used.add(partner);
      lo=byRating.length-1; while(used.has(byRating[lo])) lo--;
    }

  } else if(mode === 'progressive') {
    const tierSize=Math.max(4, Math.floor(n/4));
    const sorted=Array.from({length:n},(_,i)=>i).sort((a,b)=>pRating(players[b])-pRating(players[a]));
    const numTiers=Math.ceil(n/tierSize);
    const shift=(roundIndex||0)%Math.max(1,numTiers);
    const tiers=Array.from({length:numTiers},(_,t)=>sorted.slice(t*tierSize,(t+1)*tierSize));
    const used=new Set();
    for(let t=0;t<numTiers;t++){
      const dstIdx=(t+1+shift)%numTiers;
      const src=tiers[t], dst=dstIdx===t ? [] : tiers[dstIdx]; // guard: no self-pairing
      for(const pi of src){
        if(used.has(pi)) continue;
        const avail=dst.filter(j=>!used.has(j)&&j!==pi);
        if(!avail.length) break;
        const fresh=avail.filter(j=>partnerCount[pi][j]===0);
        const pool2=fresh.length?fresh:avail;
        pool2.sort((a,b)=>partnerCount[pi][a]-partnerCount[pi][b]);
        pairs.push([pi,pool2[0]]); used.add(pi); used.add(pool2[0]);
      }
    }
    const leftover=Array.from({length:n},(_,i)=>i).filter(i=>!used.has(i));
    shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);

  } else if(mode === 'random') {
    const pool=Array.from({length:n},(_,i)=>i); shuffle(pool);
    for(let i=0;i+1<pool.length;i+=2) pairs.push([pool[i],pool[i+1]]);

  } else if(mode === 'crossover') {
    const lastRound=state.roundHistory[state.roundHistory.length-1];
    if(!lastRound||!lastRound.winners.length){
      const pool=Array.from({length:n},(_,i)=>i); shuffle(pool);
      for(let i=0;i+1<pool.length;i+=2) pairs.push([pool[i],pool[i+1]]);
    } else {
      const winners=[...lastRound.winners]; shuffle(winners);
      const losers=[...lastRound.losers];   shuffle(losers);
      const used=new Set();
      winners.forEach(w=>{
        if(used.has(w)) return;
        const avail=losers.filter(l=>!used.has(l));
        if(!avail.length) return;
        const fresh=avail.filter(l=>partnerCount[w][l]===0);
        const pool2=fresh.length?fresh:avail;
        pool2.sort((a,b)=>partnerCount[w][a]-partnerCount[w][b]);
        pairs.push([w,pool2[0]]); used.add(w); used.add(pool2[0]);
      });
      const leftover=Array.from({length:n},(_,i)=>i).filter(i=>!used.has(i));
      shuffle(leftover);
      for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);
    }

  } else if(mode === 'roundrobin-partners' || mode === 'americano') {
    const round=roundIndex||0;
    const order=Array.from({length:n},(_,i)=>i);
    const rotated=round===0?[...order]:[order[0],...order.slice(n-round),...order.slice(1,n-round)];
    const used=new Set();
    for(let i=0;i<rotated.length/2;i++){
      const pi=rotated[i], pj=rotated[rotated.length-1-i];
      if(pi===pj||used.has(pi)||used.has(pj)) continue;
      pairs.push([pi,pj]); used.add(pi); used.add(pj);
    }
    const leftover=order.filter(i=>!used.has(i)); shuffle(leftover);
    for(let i=0;i+1<leftover.length;i+=2) pairs.push([leftover[i],leftover[i+1]]);

  } else if(mode === 'mexicano') {
    const allIdxs = Array.from({length:n},(_,i)=>i);
    const mxS3 = {};
    allIdxs.forEach(i => { mxS3[i] = 0; });
    state.schedule.forEach(r3 => r3.forEach(m => {
      if(!m.complete) return;
      (m.teamA||[]).forEach(i => { if(i<n) mxS3[i] = (mxS3[i]||0) + (+m.scoreA||0); });
      (m.teamB||[]).forEach(i => { if(i<n) mxS3[i] = (mxS3[i]||0) + (+m.scoreB||0); });
    }));
    const mxR3 = [...allIdxs].sort((a,b) => (mxS3[b]||0) - (mxS3[a]||0) || a - b);
    for(let i = 0; i + 1 < mxR3.length; i += 2) pairs.push([mxR3[i], mxR3[i+1]]);

  } else if(mode === 'dupr') {
    // Delegate to pool version with full player pool
    const pool = Array.from({length:n},(_,i)=>i);
    return pairPlayersFromPool(players, pool, mode, partnerCount, oppCount, roundIndex);
  }

  return pairs;
}


// ── Globally optimise court assignments to maximise opponent uniqueness ──
// Uses a full enumeration for small pair counts, greedy+swap for larger.
function matchPairs(roundPairs, oppCount, courtsPerRound, courtList, matchIdxStart, roundIdx, mode) {
  // courtList = array of actual court numbers to use (e.g. [1,3,5,7])
  const courts = Array.isArray(courtList) ? courtList : Array.from({length:courtList},(_,i)=>i+1);
  const np = roundPairs.length;
  const result = [];
  let courtSlot = 0;
  let mid = matchIdxStart;

  if(np <= 1) return result;

  const teamRating = pair => pair.reduce((s, pi) => s + pRating(state.players[pi]), 0);

  // DUPR range enforcement for opponent matching
  const isDuprMode = (mode === 'dupr');
  const duprRangeTol = isDuprMode ? (document.getElementById('dupr-range-tol')?.value || '1.0') : 'any';
  const nrRating    = isDuprMode ? (parseFloat(document.getElementById('dupr-nr-default')?.value) || 3.5) : 0;
  const DUPR_BRACKETS = [
    [2.00, 2.999], [3.00, 3.999], [4.00, 4.999], [5.00, 5.999], [6.00, 8.000]
  ];
  const teamDuprBracket = (pair) => {
    const avg = pair.reduce((s,pi) => s + ((state.players[pi]?.dupr ?? nrRating)), 0) / pair.length;
    return DUPR_BRACKETS.findIndex(([min,max]) => avg >= min && avg <= max);
  };
  const teamsCompatible = (pairI, pairJ) => {
    if(!isDuprMode || duprRangeTol === 'any') return true;
    const [a,b] = pairI, [c,d] = pairJ;
    const avgA = ((state.players[a]?.dupr ?? nrRating) + (state.players[b]?.dupr ?? nrRating)) / 2;
    const avgB = ((state.players[c]?.dupr ?? nrRating) + (state.players[d]?.dupr ?? nrRating)) / 2;
    if(duprRangeTol === 'bracket') return teamDuprBracket(pairI) === teamDuprBracket(pairJ);
    return Math.abs(avgA - avgB) <= parseFloat(duprRangeTol);
  };

  // ── Cost function ──────────────────────────────────────────────────────
  // Two competing goals, normalised to the same scale:
  //   1. BALANCE  — abs difference in combined team ratings (primary, weight 10)
  //   2. FRESHNESS — how many times these 4 players have already faced each other (weight 1)
  //
  // Weights chosen so that a 0.5-point imbalance costs
  // the same as 5 repeated matchups — so we nearly always prefer the even game,
  // but won't sacrifice freshness entirely when teams are equally balanced.
  const BALANCE_WEIGHT  = 10;
  const FRESH_WEIGHT    = 1;
  const MAX_RATING      = 5.5; // max possible combined diff = 2*(5.5-2.0) = 7.0
  const NORM            = 2 * MAX_RATING; // normalise rating diff to 0-1 range

  const cost = Array.from({length: np}, (_, i) =>
    Array.from({length: np}, (_, j) => {
      if(i === j) return Infinity;
      const [a, b] = roundPairs[i];
      const [c, d] = roundPairs[j];

      const ratingDiff   = Math.abs(teamRating([a,b]) - teamRating([c,d])) / NORM;
      const oppRepeats   = oppCount[a][c] + oppCount[a][d] + oppCount[b][c] + oppCount[b][d];
      // DUPR: heavily penalise out-of-range opponent pairings (but don't make Infinity — allow fallback)
      const rangePenalty = (!teamsCompatible([a,b],[c,d])) ? 50 : 0;

      return BALANCE_WEIGHT * ratingDiff + FRESH_WEIGHT * oppRepeats + rangePenalty;
    })
  );

  // ── Global minimum-weight matching (greedy + 2-opt) ───────────────────
  const used = new Set();
  const matching = [];

  // Sort all i<j edges by cost ascending — globally pick cheapest unmatched pairs
  const allEdges = [];
  for(let i = 0; i < np; i++)
    for(let j = i+1; j < np; j++)
      allEdges.push({i, j, c: cost[i][j]});
  allEdges.sort((a, b) => a.c - b.c);

  for(const edge of allEdges) {
    if(used.has(edge.i) || used.has(edge.j)) continue;
    matching.push(edge);
    used.add(edge.i); used.add(edge.j);
    if(matching.length >= courtsPerRound) break;
  }

  // 2-opt: try all pair-swaps, keep if it lowers total cost (capped)
  let improved = true;
  let _passes4 = 0;
  while(improved && _passes4++ < 8) {
    improved = false;
    for(let x = 0; x < matching.length; x++) {
      for(let y = x+1; y < matching.length; y++) {
        const {i: i1, j: j1} = matching[x];
        const {i: i2, j: j2} = matching[y];
        const cur   = cost[i1][j1] + cost[i2][j2];
        // swap1: i1 vs j2, i2 vs j1 — guard: neither side can be a self-match
        if(i1 !== j2 && i2 !== j1) {
          const swap1 = cost[i1][j2] + cost[i2][j1];
          if(swap1 < cur - 1e-9) {
            matching[x] = {i: i1, j: j2, c: cost[i1][j2]};
            matching[y] = {i: i2, j: j1, c: cost[i2][j1]};
            improved = true;
            continue;
          }
        }
        // swap2: i1 vs i2, j1 vs j2 — guard: neither side can be a self-match
        if(i1 !== i2 && j1 !== j2) {
          const swap2 = cost[i1][i2] + cost[j1][j2];
          if(swap2 < cur - 1e-9) {
            matching[x] = {i: i1, j: i2, c: cost[i1][i2]};
            matching[y] = {i: j1, j: j2, c: cost[j1][j2]};
            improved = true;
          }
        }
      }
    }
  }

  for(const {i, j} of matching) {
    if(i === j) continue;
    const [a, b] = roundPairs[i];
    const [c, d] = roundPairs[j];
    if(a === c || a === d || b === c || b === d) continue;
    if(courtSlot >= courts.length || courtSlot >= courtsPerRound) break;
    result.push([a, b, c, d, mid++, courts[courtSlot++]]);
  }

  return result;
}


function checkDuplicatePartners() {
  const seen = new Set();
  let dups = 0;
  state.schedule.flat().forEach(m => {
    if(!m.teamA || !m.teamB) return;
    [m.teamA, m.teamB].forEach(team => {
      const key = [...team].sort((a,b)=>a-b).join('|');
      if(seen.has(key)) dups++;
      else seen.add(key);
    });
  });
  return dups;
}

function checkDuplicateOpponents() {
  // Count how many times the same opponent PAIRINGS repeat across the schedule.
  // We track every individual player-vs-player cross (A1 vs B1, A1 vs B2, A2 vs B1, A2 vs B2).
  // A "duplicate" is when a specific player faces the same specific opponent again.
  // We count at the match level: a match is a dup if ANY cross-pairing has been seen before.
  const seenPairs = new Set();
  let dups = 0;
  state.schedule.flat().forEach(m => {
    if(!m.teamA || !m.teamB) return;
    let matchHasRepeat = false;
    m.teamA.forEach(a => {
      m.teamB.forEach(b => {
        const key = [Math.min(a,b), Math.max(a,b)].join('|');
        if(seenPairs.has(key)) matchHasRepeat = true;
        else seenPairs.add(key);
      });
    });
    if(matchHasRepeat) dups++;
  });
  return dups;
}

function checkMatchBalance() {
  const matches = state.schedule.flat().filter(m => m.teamA && m.teamB);
  if(!matches.length) return { avgGap: '—', even: 0, close: 0, uneven: 0, noRating: true };
  let totalGap = 0, even = 0, close = 0, uneven = 0, ratedCount = 0;
  matches.forEach(m => {
    const rA = m.teamA.reduce((s,i) => s + pRating(state.players[i]), 0) / m.teamA.length;
    const rB = m.teamB.reduce((s,i) => s + pRating(state.players[i]), 0) / m.teamB.length;
    if(rA === 0 && rB === 0) return; // skip unrated matches
    ratedCount++;
    const diff = Math.abs(rA - rB);
    totalGap += diff;
    if(diff < 0.10)       even++;
    else if(diff < 0.25)  close++;
    else if(diff < 0.5)   uneven++;
    else                  uneven++;  // mismatch/lopsided also counted as uneven in summary
  });
  if(!ratedCount) return { avgGap: '—', even: 0, close: 0, uneven: 0, noRating: true };
  return {
    avgGap: (totalGap / ratedCount).toFixed(2),
    even, close, uneven,
  };
}

function rowSum(arr) { return arr.reduce((a, v) => a + v, 0); }


function renderSchedule() {
  const container = document.getElementById('schedule-container');
  if(!state.schedule.length) { container.innerHTML = ''; return; }

  container.innerHTML = state.schedule.map((round, roundIdx) => {
    if(!round.length) return '';
    const rn = round[0].round;

    // Bye row for this round
    const byePlayers = (state.byeRounds || [])[roundIdx] || [];
    const byeRow = byePlayers.length ? `
      <tr style="background:rgba(249,168,37,0.06)">
        <td colspan="2" style="padding:0.5rem 0.9rem">
          <span style="background:rgba(249,168,37,0.2);color:var(--ball);border-radius:4px;padding:2px 8px;font-size:0.75rem;font-weight:700">🪑 BYE</span>
        </td>
        <td colspan="9" style="padding:0.5rem 0.9rem;font-size:0.82rem;color:var(--ball)">
          ${byePlayers.map(pi => {
            const p = state.players[pi];
            const tMode2 = document.getElementById('team-mode')?.value;
            const gb2    = document.getElementById('pods-groupby')?.value || 'dupr';
            const byeDupr = tMode2 === 'dupr' || (tMode2 === 'pods' && gb2 !== 'club');
            const rLbl = byeDupr ? ((p?.dupr != null && !isNaN(p.dupr)) ? p.dupr.toFixed(2) : '') : (pRatingLabel(p)||'');
            return `<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(249,168,37,0.12);border:1px solid rgba(249,168,37,0.3);border-radius:20px;padding:2px 10px;margin:2px;font-size:0.78rem">
              <span style="font-weight:600">${p?.name||'?'}</span>
              <span style="color:var(--txt3);font-size:0.68rem">${rLbl}</span>
            </span>`;
          }).join('')}
          <span style="color:var(--txt3);font-size:0.72rem;margin-left:8px">sitting out this round · rotates next round</span>
        </td>
      </tr>` : '';

    // Skipped-pod red warning rows (pods mode only, courts insufficient)
    const skippedPodRows = (() => {
      const skipped = state._skippedPods || [];
      if(!skipped.length) return '';
      return skipped.map(sp => `
        <tr style="background:rgba(239,83,80,0.08);border-left:3px solid var(--red)">
          <td colspan="11" style="padding:0.5rem 0.9rem">
            <span style="background:rgba(239,83,80,0.18);color:var(--red);border-radius:4px;padding:2px 10px;font-size:0.78rem;font-weight:700">⛔ NO COURT</span>
            <span style="color:var(--red);font-size:0.82rem;margin-left:0.5rem;font-weight:600">${escHtml(sp.label)}</span>
            <span style="color:var(--txt3);font-size:0.78rem;margin-left:0.5rem">— ${sp.needed} court${sp.needed > 1 ? 's' : ''} needed but not selected. Enable more courts and regenerate to run this pod.</span>
          </td>
        </tr>`).join('');
    })();

    const isStarted = (state.startedRounds && state.startedRounds.has(roundIdx));
    const hasScore  = round.some(m => m.complete);
    const lockControl = isStarted
      ? `<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(124,179,66,0.15);color:var(--lime);border:1px solid rgba(124,179,66,0.35);border-radius:20px;padding:3px 10px;font-size:0.72rem;font-weight:700;font-family:'DM Sans',sans-serif;letter-spacing:0;cursor:pointer" onclick="unlockRound(${roundIdx})" title="Matchups are locked — adding players won't reshuffle this round. Click to unlock.">🔒 Started</span>`
      : `<button class="btn btn-secondary btn-sm" style="font-family:'DM Sans',sans-serif;letter-spacing:0" onclick="lockRound(${roundIdx})" title="Lock this round's matchups so adding a new player won't reshuffle them">▶ Start Round</button>`;

    return `
      <div class="round-header" style="display:flex;align-items:center;justify-content:space-between;gap:0.75rem">
        <span>Round ${rn}${byePlayers.length ? ` <span style="color:var(--ball);font-size:0.85rem;font-family:'DM Sans',sans-serif;font-weight:600">(${byePlayers.length} on bye)</span>` : ''}</span>
        ${hasScore ? '' : lockControl}
      </div>
      <div class="tbl-wrap" style="margin-bottom:0.5rem">
      <table>
        <thead><tr>
          <th>Match</th><th>Court</th><th>Team A</th><th>Team B</th>
          <th>Score A</th><th>Score B</th><th>Winner</th><th>Balance</th><th>Repeats</th><th>Status</th><th></th>
        </tr></thead>
        <tbody>
          ${skippedPodRows}
          ${round.map(m => {
            const taName  = matchTeamName(m.teamA);
            const tbName  = matchTeamName(m.teamB);
            // Which rating system is this schedule based on?
            // DUPR session, or Pods grouped by DUPR/bracket → DUPR.
            // Pods grouped by Club Rating → CR. Other modes → CR fallback (legacy behavior).
            const tMode   = document.getElementById('team-mode')?.value;
            const groupBy = document.getElementById('pods-groupby')?.value || 'dupr';
            const isDupr  = tMode === 'dupr' || (tMode === 'pods' && groupBy !== 'club');

            const duprAvg = (team) => {
              if(!team) return '';
              const nr = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
              const vals = team.map(pi => { const p = state.players[pi]; return (p?.dupr != null && !isNaN(p.dupr)) ? p.dupr : nr; });
              return (vals.reduce((a,v)=>a+v,0) / vals.length).toFixed(2);
            };

            const clubAvg = (team) => {
              if(!team) return null;
              const nums = team.map(pi => parseFloat(state.players[pi]?.clubRating)).filter(v => !isNaN(v));
              return nums.length ? (nums.reduce((a,v)=>a+v,0) / nums.length).toFixed(2) : null;
            };

            const ratingBadge = (team) => {
              if(isDupr) {
                const nr = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
                const usesNR = team?.some(pi => { const p = state.players[pi]; return p?.dupr == null || isNaN(p.dupr); });
                const avg = duprAvg(team);
                return `<span style="font-family:'JetBrains Mono',monospace;font-size:0.72rem;color:#80CBC4">DUPR ${avg}${usesNR ? ` <span style="color:var(--ball)" title="includes NR ${nr} provisional">~</span>` : ''}</span>`;
              }
              const cr = clubAvg(team);
              if(cr !== null) {
                return `<span style="font-family:'JetBrains Mono',monospace;font-size:0.72rem;color:#FFD54F">CR ${cr}</span>`;
              }
              const avg = team ? (team.reduce((s,i)=>s+pRating(state.players[i]),0)/team.length).toFixed(2) : '';
              return avg ? `<span style="font-family:'JetBrains Mono',monospace;font-size:0.72rem;color:var(--ball)">${avg}</span>` : '';
            };

            const rA = isDupr
              ? `avg ${duprAvg(m.teamA)}`
              : (m.teamA ? (m.teamA.reduce((s,i)=>s+pRating(state.players[i]),0)/m.teamA.length).toFixed(2) : '');
            const rB = isDupr
              ? `avg ${duprAvg(m.teamB)}`
              : (m.teamB ? (m.teamB.reduce((s,i)=>s+pRating(state.players[i]),0)/m.teamB.length).toFixed(2) : '');
            const balanceTag = matchBalanceTag(m.teamA, m.teamB);
            const { partnerRepeats, opponentRepeats } = getRepeatInfo(m.teamA, m.teamB, m.id);
            const hasRepeats = partnerRepeats.length > 0 || opponentRepeats.length > 0;

            const repeatParts = [];
            partnerRepeats.forEach(r => repeatParts.push(
              `<span style="display:inline-block;background:rgba(171,71,188,0.2);color:#CE93D8;border-radius:4px;padding:2px 6px;font-size:0.68rem;font-weight:700;white-space:nowrap;margin:1px" title="Same partnership as Match #${r.matchId+1}">🤝 ${r.names} (= R${r.round} C${r.court})</span>`
            ));
            opponentRepeats.forEach(r => repeatParts.push(
              `<span style="display:inline-block;background:rgba(239,83,80,0.15);color:var(--red);border-radius:4px;padding:2px 6px;font-size:0.68rem;font-weight:700;white-space:nowrap;margin:1px" title="Same opponents as Match #${r.matchId+1}">⚔ ${r.label} (= R${r.round} C${r.court})</span>`
            ));
            const repeatCell = repeatParts.length
              ? `<div style="display:flex;flex-wrap:wrap;gap:2px">${repeatParts.join('')}</div>`
              : `<span style="color:var(--txt3);font-size:0.68rem">✓ Fresh</span>`;

            const taStyle = partnerRepeats.some(r => r.names === taName)
              ? 'font-weight:600;font-size:0.82rem;color:#CE93D8'
              : 'font-weight:600;font-size:0.82rem';
            const tbStyle = partnerRepeats.some(r => r.names === tbName)
              ? 'font-weight:600;font-size:0.82rem;color:#CE93D8'
              : 'font-weight:600;font-size:0.82rem';

            const winner = m.complete ? (m.scoreA > m.scoreB ? taName : m.scoreB > m.scoreA ? tbName : 'Tie') : '—';
            const status = m.complete ? 'done' : 'sched';
            const statusTxt = m.complete ? 'Complete' : 'Scheduled';
            const mixedModeActive = isMixedModeValue(document.getElementById('team-mode')?.value || '');
            const mixedCompliance = mixedModeActive ? matchMixedCompliance(m) : { ok: true, reason: '' };
            const mixedStatus = mixedModeActive && !mixedCompliance.ok
              ? `<div style="margin-top:3px;background:rgba(249,168,37,0.16);color:var(--ball);border:1px solid rgba(249,168,37,0.4);border-radius:4px;padding:2px 6px;font-size:0.66rem;font-weight:800;white-space:nowrap" title="${escHtml(mixedCompliance.reason)}">⚠️ Mixed rule</div>`
              : '';
            return `<tr id="match-${m.id}" style="${hasRepeats || (mixedModeActive && !mixedCompliance.ok)?'background:rgba(249,168,37,0.035)':''}">
              <td style="font-family:'JetBrains Mono',monospace;font-size:0.8rem;color:var(--txt3)">#${m.id+1}</td>
              <td><span style="background:var(--court2);color:var(--lime);padding:2px 8px;border-radius:4px;font-size:0.78rem;font-weight:700">🏟 ${m.court}</span>${m.podLabel ? `<div style="font-size:0.64rem;color:var(--txt3);margin-top:2px;white-space:nowrap">${escHtml(m.podLabel)}</div>` : ''}</td>
              <td style="${taStyle}">${taName} <span style="margin-left:4px">${ratingBadge(m.teamA)}</span></td>
              <td style="${tbStyle}">${tbName} <span style="margin-left:4px">${ratingBadge(m.teamB)}</span></td>
              <td onclick="event.stopPropagation()" style="white-space:nowrap">
                <input class="inline-score-a" type="number" min="0" max="99"
                  value="${m.scoreA !== '' ? m.scoreA : ''}"
                  placeholder="-"
                  style="width:40px;font-family:'JetBrains Mono',monospace;font-weight:700;font-size:0.9rem;background:transparent;border:none;border-bottom:2px solid var(--border);color:var(--txt);text-align:center;padding:2px 0"
                  onchange="saveScoreInline(${m.id})"
                  onkeydown="if(event.key==='Enter')this.closest('tr').querySelector('.inline-score-b').focus()">
              </td>
              <td onclick="event.stopPropagation()" style="white-space:nowrap">
                <input class="inline-score-b" type="number" min="0" max="99"
                  value="${m.scoreB !== '' ? m.scoreB : ''}"
                  placeholder="-"
                  style="width:40px;font-family:'JetBrains Mono',monospace;font-weight:700;font-size:0.9rem;background:transparent;border:none;border-bottom:2px solid var(--border);color:var(--txt);text-align:center;padding:2px 0"
                  onchange="saveScoreInline(${m.id})"
                  onkeydown="if(event.key==='Enter')saveScoreInline(${m.id})">
              </td>
              <td style="font-size:0.82rem;color:var(--ball)">${winner}</td>
              <td>${balanceTag}</td>
              <td>${repeatCell}</td>
              <td><span class="badge badge-${status}">${statusTxt}</span>${mixedStatus}</td>
              <td style="white-space:nowrap">
        <button class="btn btn-secondary btn-sm" onclick="openScoreModal(${m.id})" style="margin-right:2px" title="Enter score (or press court number key)">📝</button>
                ${!m.complete ? `<button class="btn btn-secondary btn-sm" onclick="openPlayerSwapModal(${m.id})" title="Adjust players for this match" style="color:var(--lime)">⇄</button>` : ''}
              </td>
            </tr>`;
          }).join('')}
          ${byeRow}
        </tbody>
      </table></div>`;
  }).join('');
  renderMixedModeWarning();
}

function matchTeamName(playerIdxArr) {
  if(!playerIdxArr) return '—';
  return playerIdxArr.map(i => {
    const p = state.players[i];
    const name = p?.name.split(' ')[0] || '?';
    if(p?.active === false) return `${name}<span style="font-size:0.6rem;color:var(--red);font-weight:700;margin-left:2px" title="This player has left">✕</span>`;
    return name;
  }).join(' & ');
}

// For a given match, returns what it repeats vs earlier matches in the schedule.
// Only the SECOND occurrence gets flagged — the first is "original", the repeat is the duplicate.
function getRepeatInfo(teamA, teamB, currentMatchId) {
  if(!teamA || !teamB) return { partnerRepeats: [], opponentRepeats: [] };

  const partnerRepeats  = [];
  const opponentRepeats = [];

  // Only look at matches that come BEFORE this one (lower id = earlier in schedule)
  const earlierMatches = state.schedule.flat().filter(m =>
    m.id < currentMatchId && m.teamA && m.teamB
  );

  // ── Partner repeat: same two players teamed up in an earlier match ──
  [teamA, teamB].forEach(pair => {
    const [p1, p2] = pair;
    const prev = earlierMatches.find(m =>
      (m.teamA.includes(p1) && m.teamA.includes(p2)) ||
      (m.teamB.includes(p1) && m.teamB.includes(p2))
    );
    if(prev) {
      const names = pair.map(i => state.players[i]?.name.split(' ')[0]).join(' & ');
      partnerRepeats.push({ names, matchId: prev.id, round: prev.round, court: prev.court });
    }
  });

  // ── Opponent repeat: any player from teamA faced any player from teamB before ──
  const seen = new Set();
  earlierMatches.forEach(m => {
    [[m.teamA, m.teamB], [m.teamB, m.teamA]].forEach(([sA, sB]) => {
      sA.forEach(pa => {
        if(!teamA.includes(pa)) return;
        sB.forEach(pb => {
          if(!teamB.includes(pb)) return;
          const key = [pa, pb].sort().join('-');
          if(!seen.has(key)) {
            seen.set ? seen.add(key) : seen.add(key);
            // find which earlier match this was
            const prev = earlierMatches.find(pm =>
              (pm.teamA.includes(pa) && pm.teamB.includes(pb)) ||
              (pm.teamB.includes(pa) && pm.teamA.includes(pb))
            );
            if(prev) {
              const label = [state.players[pa]?.name.split(' ')[0], state.players[pb]?.name.split(' ')[0]].sort().join(' vs ');
              if(!opponentRepeats.find(r => r.label === label)) {
                opponentRepeats.push({ label, matchId: prev.id, round: prev.round, court: prev.court });
              }
            }
          }
        });
      });
    });
  });

  return { partnerRepeats, opponentRepeats };
}

function matchBalanceTag(teamA, teamB) {
  if(!teamA || !teamB) return '';

  // Use the SAME rating source as the schedule display:
  // DUPR mode → p.dupr with NR-default fallback
  // Otherwise → pRating() (clubRating → dupr → p.rating)
  const mode  = document.getElementById('team-mode')?.value || '';
  const isDupr = mode === 'dupr' || mode === 'pods'; // pods can be dupr-grouped
  const nr    = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');

  const ratingOf = (i) => {
    const p = state.players[i];
    if(!p) return 0;
    if(isDupr) {
      // Mirror duprAvg(): use actual dupr if set, else NR default
      return (p.dupr != null && !isNaN(p.dupr)) ? p.dupr : nr;
    }
    return pRating(p); // clubRating → dupr → p.rating → 0
  };

  const ratingsA = teamA.map(i => ratingOf(i));
  const ratingsB = teamB.map(i => ratingOf(i));

  // If no player has any rating (non-DUPR mode, no ratings set), show dash
  if(!isDupr && [...ratingsA, ...ratingsB].every(r => r === 0)) {
    return '<span style="font-size:0.68rem;color:var(--txt3)" title="No ratings set for these players">—</span>';
  }

  const avgA = ratingsA.reduce((s,r) => s + r, 0) / ratingsA.length;
  const avgB = ratingsB.reduce((s,r) => s + r, 0) / ratingsB.length;
  const diff = Math.abs(avgA - avgB);

  // Tooltip mirrors the display badge: show each player's rating and team avg
  const fmt = (idxArr, ratings) => idxArr.map((i, pos) => {
    const p = state.players[i];
    const r = ratings[pos];
    const usedNR = isDupr && (p?.dupr == null || isNaN(p?.dupr));
    return (p?.name.split(' ')[0] || '?') + ' ' + r.toFixed(2) + (usedNR ? '~' : '');
  }).join(' + ');
  const teamAStr = `${fmt(teamA, ratingsA)} = avg ${avgA.toFixed(2)}`;
  const teamBStr = `${fmt(teamB, ratingsB)} = avg ${avgB.toFixed(2)}`;
  const tooltip  = `Team A: ${teamAStr}\nTeam B: ${teamBStr}\nGap: ${diff.toFixed(2)}`;

  let color, label;
  if(diff < 0.10)       { color = 'var(--lime)';  label = '⚖ Even'; }
  else if(diff < 0.25)  { color = '#A5D6A7';      label = '~ Close'; }
  else if(diff < 0.5)   { color = 'var(--ball)';  label = '△ Uneven'; }
  else if(diff < 1.0)   { color = '#FF8F00';      label = '✗ Mismatch'; }
  else                   { color = 'var(--red)';   label = '✗✗ Lopsided'; }

  // Stacked pair warning: one team has a high internal spread (strong+weak partnership)
  // even though team averages may look balanced. Threshold: >0.75 rating gap within a team.
  const STACK_THRESHOLD = 0.75;
  const spreadA = ratingsA.length >= 2 ? Math.abs(ratingsA[0] - ratingsA[1]) : 0;
  const spreadB = ratingsB.length >= 2 ? Math.abs(ratingsB[0] - ratingsB[1]) : 0;
  const stackedTeam = spreadA >= STACK_THRESHOLD ? 'A' : spreadB >= STACK_THRESHOLD ? 'B' : null;

  const gapStr = diff.toFixed(2);
  let tag = `<span style="font-size:0.68rem;font-weight:700;color:${color};white-space:nowrap;cursor:help" title="${tooltip}">${label} <span style="font-weight:400;opacity:0.8">(${gapStr})</span></span>`;

  if(stackedTeam) {
    const spread = stackedTeam === 'A' ? spreadA : spreadB;
    const stackedIdxs = stackedTeam === 'A' ? teamA : teamB;
    const [s1, s2] = stackedIdxs.map(i => state.players[i]?.name.split(' ')[0] || '?');
    const [r1, r2] = stackedIdxs.map(i => ratingOf(i));
    const weakPlayer = r1 < r2 ? s1 : s2;
    tag += ` <span style="font-size:0.68rem;font-weight:700;color:#FF6B6B;white-space:nowrap;cursor:help"
      title="Team ${stackedTeam}: ${s1} (${r1.toFixed(2)}) + ${s2} (${r2.toFixed(2)}) — ${spread.toFixed(2)} gap. ${weakPlayer} may get targeted.">⚡ Stacked</span>`;
  }

  return tag;
}

// ═══════════════════════════════════════════════
//  PLAYER SWAP MODAL
// ═══════════════════════════════════════════════
let _psmMatchId = null;
let _psmTeamA   = [];  // working copy of player indices
let _psmTeamB   = [];

function openPlayerSwapModal(matchId) {
  const m = state.schedule.flat().find(m => m.id == matchId);
  if(!m || m.complete) { toast('Cannot adjust a completed match', 'err'); return; }

  _psmMatchId = matchId;
  _psmTeamA   = [...m.teamA];
  _psmTeamB   = [...m.teamB];

  document.getElementById('psm-match-info').textContent =
    `Round ${m.round} · Court ${m.court}${m.podLabel ? ' · ' + m.podLabel : ''}`;

  renderPsmTeams();

  const modal = document.getElementById('player-swap-modal');
  modal.style.display = 'flex';
  modal.onclick = (e) => { if(e.target === modal) closePlayerSwapModal(); };
}

function closePlayerSwapModal() {
  document.getElementById('player-swap-modal').style.display = 'none';
  _psmMatchId = null;
}

function renderPsmTeams() {
  const mode   = document.getElementById('team-mode')?.value || '';
  const isDupr = mode === 'dupr' || mode === 'pods';
  const nr     = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');

  const ratingOf = (i) => {
    const p = state.players[i];
    if(!p) return 0;
    if(isDupr) return (p.dupr != null && !isNaN(p.dupr)) ? p.dupr : nr;
    return pRating(p);
  };

  // All active player indices not already in either team — for the dropdowns
  const allIdxs = state.players.map((p,i) => i).filter(i => state.players[i].active !== false && state.players[i].checkedIn !== false);

  const playerCard = (idx, team, slotPos) => {
    const p = state.players[idx];
    const r = ratingOf(idx);
    const rLabel = r > 0 ? r.toFixed(2) : '—';
    const otherTeam = team === 'A' ? _psmTeamB : _psmTeamA;

    // Swap buttons — one per player on the other team
    const swapBtns = otherTeam.map((oi, oPos) => {
      const op = state.players[oi];
      return `<button class="btn btn-secondary btn-sm" style="font-size:0.68rem;padding:1px 6px;margin:1px"
        onclick="psmSwapPlayers('${team}',${slotPos},'${team==='A'?'B':'A'}',${oPos})"
        title="Swap with ${op?.name}">
        ⇄ ${op?.name.split(' ')[0]}
      </button>`;
    }).join('');

    // Dropdown for direct reassignment
    const opts = allIdxs.map(ai => {
      const ap = state.players[ai];
      const ar = ratingOf(ai);
      const inUse = [..._psmTeamA, ..._psmTeamB].includes(ai) && ai !== idx;
      return `<option value="${ai}" ${ai === idx ? 'selected' : ''} ${inUse ? 'disabled' : ''}>
        ${ap.name} (${ar > 0 ? ar.toFixed(2) : '—'})
      </option>`;
    }).join('');

    return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:0.5rem 0.7rem">
      <div style="display:flex;align-items:center;gap:0.4rem;margin-bottom:0.35rem">
        <span style="font-weight:600;font-size:0.85rem">${escHtml(p?.name || '?')}</span>
        <span style="font-family:'JetBrains Mono',monospace;font-size:0.72rem;color:#80CBC4">${rLabel}</span>
      </div>
      <select style="font-size:0.75rem;width:100%;margin-bottom:0.3rem"
        onchange="psmReassignSlot('${team}',${slotPos},parseInt(this.value))">
        ${opts}
      </select>
      <div style="display:flex;flex-wrap:wrap;gap:2px">${swapBtns}</div>
    </div>`;
  };

  document.getElementById('psm-team-a').innerHTML = _psmTeamA.map((idx,i) => playerCard(idx,'A',i)).join('');
  document.getElementById('psm-team-b').innerHTML = _psmTeamB.map((idx,i) => playerCard(idx,'B',i)).join('');

  // Balance preview
  const avgA = _psmTeamA.reduce((s,i) => s + ratingOf(i), 0) / _psmTeamA.length;
  const avgB = _psmTeamB.reduce((s,i) => s + ratingOf(i), 0) / _psmTeamB.length;
  const diff = Math.abs(avgA - avgB);
  let balColor = diff < 0.10 ? 'var(--lime)' : diff < 0.25 ? '#A5D6A7' : diff < 0.5 ? 'var(--ball)' : diff < 1.0 ? '#FF8F00' : 'var(--red)';
  let balLabel = diff < 0.10 ? '⚖ Even' : diff < 0.25 ? '~ Close' : diff < 0.5 ? '△ Uneven' : diff < 1.0 ? '✗ Mismatch' : '✗✗ Lopsided';

  // Stacked pair warning
  const spreadA = _psmTeamA.length >= 2 ? Math.abs(ratingOf(_psmTeamA[0]) - ratingOf(_psmTeamA[1])) : 0;
  const spreadB = _psmTeamB.length >= 2 ? Math.abs(ratingOf(_psmTeamB[0]) - ratingOf(_psmTeamB[1])) : 0;
  const STACK_THRESHOLD = 0.75;
  let stackWarn = '';
  if(spreadA >= STACK_THRESHOLD) {
    const [p1, p2] = _psmTeamA.map(i => state.players[i]?.name.split(' ')[0] || '?');
    const [r1, r2] = _psmTeamA.map(i => ratingOf(i));
    const weak = r1 < r2 ? p1 : p2;
    stackWarn += `<div style="color:#FF6B6B;font-size:0.78rem;margin-top:0.35rem">⚡ Team A stacked: ${p1} (${r1.toFixed(2)}) + ${p2} (${r2.toFixed(2)}) — ${spreadA.toFixed(2)} gap. ${weak} may get targeted.</div>`;
  }
  if(spreadB >= STACK_THRESHOLD) {
    const [p1, p2] = _psmTeamB.map(i => state.players[i]?.name.split(' ')[0] || '?');
    const [r1, r2] = _psmTeamB.map(i => ratingOf(i));
    const weak = r1 < r2 ? p1 : p2;
    stackWarn += `<div style="color:#FF6B6B;font-size:0.78rem;margin-top:0.35rem">⚡ Team B stacked: ${p1} (${r1.toFixed(2)}) + ${p2} (${r2.toFixed(2)}) — ${spreadB.toFixed(2)} gap. ${weak} may get targeted.</div>`;
  }

  document.getElementById('psm-balance').innerHTML =
    `Team A avg <strong style="color:#80CBC4">${avgA.toFixed(2)}</strong> &nbsp;vs&nbsp; Team B avg <strong style="color:#80CBC4">${avgB.toFixed(2)}</strong>
     &nbsp;·&nbsp; Gap <strong style="color:${balColor}">${diff.toFixed(2)} — ${balLabel}</strong>${stackWarn}`;
}

function psmSwapPlayers(teamA, slotA, teamB, slotB) {
  const arrA = teamA === 'A' ? _psmTeamA : _psmTeamB;
  const arrB = teamB === 'A' ? _psmTeamA : _psmTeamB;
  const tmp = arrA[slotA];
  arrA[slotA] = arrB[slotB];
  arrB[slotB] = tmp;
  renderPsmTeams();
}

function psmReassignSlot(team, slot, newIdx) {
  const arr = team === 'A' ? _psmTeamA : _psmTeamB;
  const other = team === 'A' ? _psmTeamB : _psmTeamA;
  // If newIdx is already in the other team, swap them
  const otherSlot = other.indexOf(newIdx);
  if(otherSlot !== -1) {
    other[otherSlot] = arr[slot];
  }
  arr[slot] = newIdx;
  renderPsmTeams();
}

function applyPlayerSwap() {
  const m = state.schedule.flat().find(m => m.id == _psmMatchId);
  if(!m) return;

  const roundIdx = state.schedule.findIndex(r => r.some(match => match.id == _psmMatchId));

  // ── 1. Collect who was in the match before, and who's coming in ────────
  const oldPlayers = [...m.teamA, ...m.teamB];
  const newPlayers = [..._psmTeamA, ..._psmTeamB];
  const removedIdxs = oldPlayers.filter(i => !newPlayers.includes(i)); // going out
  const addedIdxs   = newPlayers.filter(i => !oldPlayers.includes(i)); // coming in

  // ── 2. Apply the swap to the match ────────────────────────────────────
  m.teamA = [..._psmTeamA];
  m.teamB = [..._psmTeamB];
  state._manualAdjustments = (state._manualAdjustments || 0) + 1;

  // ── 3. Fix bye tracking for this round ────────────────────────────────
  // Players going OUT of the match are now effectively on a bye.
  // Players coming IN are no longer on a bye (even if byeRounds said so).
  if(!state.byeRounds) state.byeRounds = [];
  if(!state.byeRounds[roundIdx]) state.byeRounds[roundIdx] = [];

  // Remove incoming players from bye list (they're now playing)
  state.byeRounds[roundIdx] = state.byeRounds[roundIdx].filter(i => !addedIdxs.includes(i));

  // Add outgoing players to bye list (they're now sitting out), avoiding duplicates
  removedIdxs.forEach(i => {
    if(!state.byeRounds[roundIdx].includes(i)) state.byeRounds[roundIdx].push(i);
  });

  closePlayerSwapModal();
  autoSave();
  renderSchedule();
  renderCourtsGrid();
  if(typeof msAutoPushIfEnabled === 'function') msAutoPushIfEnabled();
  toast('✅ Players updated for this match — bye tracking corrected');

  // ── 4. Offer to regenerate future unplayed rounds ─────────────────────
  // Only offer if there are future rounds beyond this one that haven't been
  // played or started — those are the ones that still have stale partner
  // history based on the original (pre-swap) pairings.
  const totalRounds = state.schedule.length;
  const protectedUpTo = protectedRoundCount(); // rounds that are played/started
  const futureUnplayed = totalRounds - Math.max(protectedUpTo, roundIdx + 1);

  if(futureUnplayed <= 0) return; // nothing to regenerate

  const changedNames = [
    ...removedIdxs.map(i => state.players[i]?.name).filter(Boolean),
    ...addedIdxs.map(i => state.players[i]?.name).filter(Boolean),
  ];

  const msg = `${futureUnplayed} future round${futureUnplayed > 1 ? 's' : ''} still exist beyond this point.\n\n`
    + `Because ${changedNames.join(', ')} ${changedNames.length > 1 ? 'were' : 'was'} swapped, `
    + `those rounds have stale partner pairings based on the old line-up.\n\n`
    + `Regenerate future rounds now to fix partner history?\n\n`
    + `(Played and started rounds are always preserved.)`;

  if(!confirm(msg)) return;

  // ── 5. Regenerate future rounds, seeding history from all kept rounds ──
  // "Kept" = everything up to and including the swapped round (since that
  // round is now final — the swap was applied and confirmed above).
  const keepCount = roundIdx + 1;
  const n = state.players.length;
  const kept = state.schedule.slice(0, keepCount);
  const keptByes = (state.byeRounds || []).slice(0, keepCount);

  // Seed partner/opponent/bye history from every kept round, including the
  // just-swapped one (which now has the corrected pairings).
  const partner = Array.from({length: n}, () => new Array(n).fill(0));
  const opp     = Array.from({length: n}, () => new Array(n).fill(0));
  const byeCnt  = new Array(n).fill(0);
  kept.forEach(round => round.forEach(match => {
    if(!match.teamA || !match.teamB) return;
    const [a, b] = match.teamA, [c, d] = match.teamB;
    if(a != null && b != null) { partner[a][b]++; partner[b][a]++; }
    if(c != null && d != null) { partner[c][d]++; partner[d][c]++; }
    [[a,c],[a,d],[b,c],[b,d]].forEach(([x, y]) => {
      if(x != null && y != null) { opp[x][y]++; opp[y][x]++; }
    });
  }));
  keptByes.forEach(byes => byes.forEach(i => { if(i != null && byeCnt[i] != null) byeCnt[i]++; }));

  // How many new rounds to generate — same count as what's being replaced
  const newRoundCount = futureUnplayed;
  const mode = document.getElementById('team-mode')?.value;
  const courtList = Array.from(state.selectedCourts).sort((a, b) => a - b);

  // Reuse the exact same generation pipeline as the main scheduler.
  // generateScheduleFromState is a thin wrapper we create here that
  // calls through to the existing generation logic with pre-seeded history.
  let maxId = -1;
  state.schedule.flat().forEach(match => { if(match.id > maxId) maxId = match.id; });

  // Call the existing regenSchedule function with our keepCount, which already
  // handles all mode-specific logic (pods, mixed, balanced, etc.)
  // We set up state so regen picks up from the right point.
  const savedSchedule = state.schedule.slice(0, keepCount);
  const savedByes = (state.byeRounds || []).slice(0, keepCount);

  // Trigger regen using the existing function, which reads keepCount via
  // protectedRoundCount() — but that checks played/started rounds, not our
  // keepCount. So we temporarily mark this round as started, run regen,
  // then let the regen result stand.
  if(!state.startedRounds) state.startedRounds = new Set();
  // Mark all rounds up to and including the swapped round as protected
  for(let ri = 0; ri < keepCount; ri++) state.startedRounds.add(ri);

  // Now call the standard regen (user already confirmed above, skip the prompt)
  regenScheduleSilent(keepCount, newRoundCount, partner, opp, byeCnt);
}

// Silent regen — same logic as the interactive regenSchedule() but skips
// the confirm/prompt since the user already answered above in applyPlayerSwap.
function regenScheduleSilent(keepCount, numNew, partner, opp, byeCnt) {
  const mode = document.getElementById('team-mode')?.value;
  if(mode === 'king') {
    toast('Cannot regenerate future rounds in King of the Court mode', 'err');
    return;
  }

  const n = state.players.length;
  const activeIdxs = state.players.map((p, i) => i).filter(i =>
    state.players[i].active !== false &&
    state.players[i].waitlist !== true &&
    state.players[i].checkedIn !== false
  );
  if(activeIdxs.length < 4) { toast('Need at least 4 active players', 'err'); return; }

  const courtList = Array.from(state.selectedCourts).sort((a, b) => a - b);
  let maxId = -1;
  state.schedule.flat().forEach(m => { if(m.id > maxId) maxId = m.id; });

  // Trim schedule and byeRounds to the kept portion
  state.schedule   = state.schedule.slice(0, keepCount);
  state.byeRounds  = (state.byeRounds || []).slice(0, keepCount);

  // Generate new rounds by calling the same underlying pair/match functions
  // the main scheduler uses, with our pre-seeded history matrices.
  const isMixed = mode === 'mixed' || mode === 'mixed-rated' || mode === 'competitive-mixed';
  const na = activeIdxs.length;
  const courtsAvailable = Math.min(courtList.length, Math.floor(na / 4));
  const courtsPerRound  = courtsAvailable;
  const byeCount = na - courtsPerRound * 4;

  // Local-index → global-index map for this active player set
  const activePlayerIdxMap = activeIdxs;

  // Re-map the seeded history matrices to local indices
  const localPartner = Array.from({length: na}, () => new Array(na).fill(0));
  const localOpp     = Array.from({length: na}, () => new Array(na).fill(0));
  const localBye     = new Array(na).fill(0);
  activeIdxs.forEach((gi, li) => {
    activeIdxs.forEach((gj, lj) => {
      localPartner[li][lj] = partner[gi][gj];
      localOpp[li][lj]     = opp[gi][gj];
    });
    localBye[li] = byeCnt[gi];
  });

  let matchIdx = maxId + 1;
  let newRounds = 0;

  for(let r = 0; r < numNew; r++) {
    // Bye selection
    const byePlayers = [];
    if(byeCount > 0) {
      const byeCandidates = Array.from({length: na}, (_, i) => i)
        .sort((a, b) => localBye[a] - localBye[b] || a - b);
      byePlayers.push(...byeCandidates.slice(0, byeCount));
      byePlayers.forEach(pi => localBye[pi]++);
    }
    state.byeRounds.push(byePlayers.map(li => activePlayerIdxMap[li]));

    const activeLocalIdxs = Array.from({length: na}, (_, i) => i).filter(i => !byePlayers.includes(i));
    const schedulePlayers = activeIdxs.map(gi => state.players[gi]);

    const roundPairs = pairPlayersFromPool(schedulePlayers, activeLocalIdxs, mode, localPartner, localOpp, r);
    if(roundPairs.length < 2) break;

    roundPairs.forEach(([a, b]) => { localPartner[a][b]++; localPartner[b][a]++; });

    const courts = courtList.slice(0, courtsPerRound);
    const courtMatches = matchPairs(roundPairs, localOpp, courtsPerRound, courts, matchIdx, r + keepCount, mode);
    matchIdx += courtMatches.length;

    // Rewrite match team indices from local → global
    courtMatches.forEach(m => {
      m.teamA = m.teamA.map(li => activePlayerIdxMap[li]);
      m.teamB = m.teamB.map(li => activePlayerIdxMap[li]);
      m.round = keepCount + r;
    });

    state.schedule.push(courtMatches);
    newRounds++;
  }

  autoSave();
  renderSchedule();
  renderCourtsGrid();
  if(typeof msAutoPushIfEnabled === 'function') msAutoPushIfEnabled();
  toast(`✅ Swap applied · ${newRounds} future round${newRounds !== 1 ? 's' : ''} regenerated with corrected partner history`);
}

// ── Score Modal ──────────────────────────────────
var _currentMatchFlat = [];
function flattenSchedule() {
  _currentMatchFlat = state.schedule.flat();
}

function openScoreModal(matchId) {
  flattenSchedule();
  const m = _currentMatchFlat.find(m=>m.id===matchId);
  if(!m) return;
  state.activeMatchIdx = matchId;
  const taName = matchTeamName(m.teamA);
  const tbName = matchTeamName(m.teamB);
  document.getElementById('modal-match-info').innerHTML =
    `Round ${m.round} — Court ${m.court}<br><strong>${taName}</strong> vs <strong>${tbName}</strong>`;

  // DUPR impact preview
  const nrDefRaw = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
  const nrDef = isNaN(nrDefRaw) ? 3.5 : nrDefRaw;
  const hasDupr = (team) => team?.some(pi => state.players[pi]?.dupr != null);
  const avgDuprTeam = (team) => {
    if(!team) return null;
    const vals = team.map(pi => { const p = state.players[pi]; return p?.dupr ?? nrDef; });
    return vals.reduce((a,v)=>a+v,0)/vals.length;
  };
  const avgA = avgDuprTeam(m.teamA), avgB = avgDuprTeam(m.teamB);
  let duprPreview = '';
  if(hasDupr(m.teamA) || hasDupr(m.teamB)) {
    const teamUsesNR = (team) => team?.some(pi => state.players[pi]?.dupr == null);
    const nrInPlay = teamUsesNR(m.teamA) || teamUsesNR(m.teamB);
    const expA = duprExpectedScore(avgA, avgB);
    const expB = 1 - expA;
    const nrNote = nrInPlay
      ? ` <span title="One or more players have no DUPR — using NR ${nrDef} as provisional" style="color:var(--ball);font-size:0.72rem">⚠ NR ${nrDef} used</span>`
      : '';
    duprPreview = `<div style="margin-top:6px;font-size:0.78rem;color:var(--txt3)">
      DUPR impact if <strong style="color:var(--txt)">${taName} wins</strong>: ${duprImpactStr(avgA,avgB,true)} · if <strong style="color:var(--txt)">${tbName} wins</strong>: ${duprImpactStr(avgB,avgA,true)}
      <span style="margin-left:6px;color:var(--txt3)">(win probability: ${Math.round(expA*100)}% / ${Math.round(expB*100)}%)</span>${nrNote}
    </div>`;
  }
  document.getElementById('modal-dupr-preview').innerHTML = duprPreview;
  document.getElementById('score-label-a').textContent = taName;
  document.getElementById('score-label-b').textContent = tbName;

  // Pre-populate from existing score (schedule OR river board)
  let existingA = m.scoreA !== '' ? m.scoreA : '';
  let existingB = m.scoreB !== '' ? m.scoreB : '';
  if(m.isRiverMatch && riverState.enabled) {
    const ct = riverState.courts.find(c =>
      c.court === m.court && riverState.currentRound === m.round
    );
    if(ct && ct.scoreA !== '') { existingA = ct.scoreA; existingB = ct.scoreB; }
  }
  document.getElementById('score-a').value = existingA;
  document.getElementById('score-b').value = existingB;
  document.getElementById('score-modal').classList.add('open');
  // Enter key saves score, Escape closes
  setTimeout(() => {
    const sa = document.getElementById('score-a');
    if(sa) sa.focus();
  }, 50);
}

function _scoreModalKeyHandler(e) {
  if(!document.getElementById('score-modal').classList.contains('open')) return;
  if(e.key === 'Enter')  saveScore();
  if(e.key === 'Escape') closeModal();
}
document.addEventListener('keydown', _scoreModalKeyHandler);

// Global keyboard shortcut: press a digit (1-9) while schedule tab is active
// and no modal/input is focused → jump to score entry for that court number
document.addEventListener('keydown', function(e) {
  // Ignore if a modal is open, or focus is inside an input/textarea/select
  if(document.getElementById('score-modal')?.classList.contains('open')) return;
  if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) return;
  const n = parseInt(e.key);
  if(isNaN(n) || n < 1) return;
  // Only act when schedule section is active
  if(!document.getElementById('sec-schedule')?.classList.contains('active')) return;
  // Find the current active round's match on that court number
  let activeRound = null;
  for(const round of state.schedule) {
    if(round.some(m => m.teamA && m.teamB && !m.complete)) { activeRound = round; break; }
  }
  if(!activeRound) return;
  const match = activeRound.find(m => m.court === n && m.teamA && m.teamB);
  if(!match) return;
  e.preventDefault();
  openScoreModal(match.id);
});

function saveScore() {
  flattenSchedule();
  const m = _currentMatchFlat.find(m=>m.id===state.activeMatchIdx);
  if(!m) return;
  const sa = parseInt(document.getElementById('score-a').value);
  const sb = parseInt(document.getElementById('score-b').value);
  if(isNaN(sa)||isNaN(sb)) { toast("Enter both scores","err"); return; }

  // Capture previous state for undo BEFORE overwriting
  const prevSa = m.scoreA, prevSb = m.scoreB, prevComplete = m.complete;

  m.scoreA = sa; m.scoreB = sb; m.complete = true;

  // Record for undo
  pushUndo(m.id, prevSa, prevSb, prevComplete);
  autoSave();

  // Sync back to river board if this is a river match
  if(m.isRiverMatch && riverState.enabled) {
    const ct = riverState.courts.find(c =>
      c.court === m.court && riverState.currentRound === m.round
    );
    if(ct) {
      ct.scoreA = sa;
      ct.scoreB = sb;
      ct.complete = true;
    }
    renderRiverBoard();
  }

  // Update roundHistory for crossover mode
  const winners = sa > sb ? [...m.teamA] : [...m.teamB];
  const losers  = sa > sb ? [...m.teamB] : [...m.teamA];
  const rh = state.roundHistory;
  const roundEntry = rh.find(e => e.round === m.round);
  if(roundEntry) {
    roundEntry.winners.push(...winners);
    roundEntry.losers.push(...losers);
  } else {
    rh.push({ round: m.round, winners, losers });
  }

  closeModal();
  renderSchedule();
  updateProgress();
  updateStandings();
  checkRoundComplete();
  if(document.getElementById('sec-playerstats').classList.contains('active')) {
    renderPlayerStats(); renderH2H();
  }
  updateReportIfActive();
  if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  _liveBroadcast();
  msAutoPushIfEnabled();
  toast("Score saved!");
}

// Inline score entry — same logic as saveScore() but reads from row inputs
// rather than the modal. Called from the schedule table's inline score fields.
function saveScoreInline(matchId) {
  flattenSchedule();
  const m = _currentMatchFlat.find(m => m.id === matchId);
  if(!m) return;
  const row = document.getElementById('match-' + matchId);
  if(!row) return;
  const inputA = row.querySelector('.inline-score-a');
  const inputB = row.querySelector('.inline-score-b');
  if(!inputA || !inputB) return;
  const sa = parseInt(inputA.value);
  const sb = parseInt(inputB.value);
  if(isNaN(sa) || isNaN(sb) || sa < 0 || sb < 0) return; // silently ignore incomplete/invalid

  const prevSa = m.scoreA, prevSb = m.scoreB, prevComplete = m.complete;
  m.scoreA = sa; m.scoreB = sb; m.complete = true;
  pushUndo(m.id, prevSa, prevSb, prevComplete);
  autoSave();

  if(m.isRiverMatch && riverState.enabled) {
    const ct = riverState.courts.find(c => c.court === m.court && riverState.currentRound === m.round);
    if(ct) { ct.scoreA = sa; ct.scoreB = sb; ct.complete = true; }
    renderRiverBoard();
  }

  const winners = sa > sb ? [...m.teamA] : [...m.teamB];
  const losers  = sa > sb ? [...m.teamB] : [...m.teamA];
  const rh = state.roundHistory;
  const roundEntry = rh.find(e => e.round === m.round);
  if(roundEntry) { roundEntry.winners.push(...winners); roundEntry.losers.push(...losers); }
  else rh.push({ round: m.round, winners, losers });

  renderSchedule();
  updateProgress();
  updateStandings();
  checkRoundComplete();
  if(document.getElementById('sec-playerstats').classList.contains('active')) renderPlayerStats();
  updateReportIfActive();
  if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  _liveBroadcast();
  msAutoPushIfEnabled();
}

// Re-record player history and refresh the Report tab if it's currently open.
// Called after every score save so trends stay live without needing a tab switch.
function updateReportIfActive() {
  if(document.getElementById('sec-report').classList.contains('active')) {
    renderReport();
  } else {
    // Still re-record history in the background so it's fresh when tab is opened
    const data = buildPlayerStats().map(emDeriveRow);
    if(data.length) recordPlayerHistory(data);
  }
}

function closeModal() {
  document.getElementById('score-modal').classList.remove('open');
  state.activeMatchIdx = null;
}

function updateProgress() {
  const all = state.schedule.flat();
  const done = all.filter(m=>m.complete).length;
  const pct = all.length ? Math.round(done/all.length*100) : 0;
  document.getElementById('tourney-progress').style.width = pct+'%';
  document.getElementById('progress-label').textContent = `${done} / ${all.length} matches complete (${pct}%)`;
}

function exportScheduleCSV() {
  if(!state.schedule.length) { toast("Generate schedule first","err"); return; }
  const rows = [[getTournamentName()],['Match','Round','Court','TeamA','TeamA_AvgDUPR','TeamA_AvgCR','TeamB','TeamB_AvgDUPR','TeamB_AvgCR','ScoreA','ScoreB','Winner','Complete']];
  const nrDef = parseFloat(document.getElementById('dupr-nr-default')?.value||'3.5');
  const teamDuprAvg = t => t ? (t.map(pi=>{const p=state.players[pi];return p?.dupr??nrDef;}).reduce((a,v)=>a+v,0)/t.length).toFixed(2) : '';
  const teamCRAvg   = t => t ? (()=>{const nums=t.map(pi=>parseFloat(state.players[pi]?.clubRating||'')).filter(v=>!isNaN(v));return nums.length?(nums.reduce((a,v)=>a+v,0)/nums.length).toFixed(2):'';})() : '';
  state.schedule.flat().forEach(m => {
    const taName = matchTeamName(m.teamA);
    const tbName = matchTeamName(m.teamB);
    const winner = m.complete ? (m.scoreA>m.scoreB?taName:m.scoreB>m.scoreA?tbName:'Tie') : '';
    rows.push([m.id+1, m.round, m.court, taName, teamDuprAvg(m.teamA), teamCRAvg(m.teamA), tbName, teamDuprAvg(m.teamB), teamCRAvg(m.teamB), m.scoreA, m.scoreB, winner, m.complete]);
  });
  downloadCSV(rows, `${getTournamentName().replace(/[^a-zA-Z0-9]/g,'_')}_schedule.csv`);
}

// ═══════════════════════════════════════════════

// ── Court, standings, playoffs rendering ───────────────────
//  COURTS
// ═══════════════════════════════════════════════
function toggleCourt(n) {
  if(state.selectedCourts.has(n)) {
    if(state.selectedCourts.size <= 1) { toast("Need at least 1 court","err"); return; }
    state.selectedCourts.delete(n);
  } else {
    state.selectedCourts.add(n);
  }
  updateCourtSelectorUI();
  renderCourtsGrid();
}

function selectAllCourts() {
  for(let i=1;i<=MAX_COURTS;i++) state.selectedCourts.add(i);
  updateCourtSelectorUI();
  renderCourtsGrid();
}

function selectNoCourts() {
  // Keep at least court 1
  state.selectedCourts.clear();
  state.selectedCourts.add(1);
  updateCourtSelectorUI();
  renderCourtsGrid();
}

function updateCourtSelectorUI() {
  for(let i=1;i<=MAX_COURTS;i++) {
    const el = document.getElementById(`court-sel-${i}`);
    if(!el) continue;
    const selected = state.selectedCourts.has(i);
    el.style.background    = selected ? 'rgba(198,255,0,0.2)'  : 'rgba(30,30,30,0.4)';
    el.style.borderColor   = selected ? 'var(--lime)'          : 'var(--border)';
    el.style.color         = selected ? 'var(--lime)'          : 'var(--txt3)';
    el.style.opacity       = selected ? '1'                    : '0.5';
  }
  const countEl = document.getElementById('courts-selected-count');
  if(countEl) countEl.textContent = state.selectedCourts.size;
  // Keep hidden input in sync for any legacy reads
  const inp = document.getElementById('courts-count');
  if(inp) inp.value = state.selectedCourts.size;
  // Refresh pod preview so court assignments stay in sync
  const mode = document.getElementById('mode-select')?.value;
  if(mode === 'pods' && typeof renderPodsPreview === 'function') renderPodsPreview();
}

function renderCourts() { renderCourtsGrid(); }

// ═══════════════════════════════════════════════
//  COURT MOVE / SWAP — explicit click-based UI
// ═══════════════════════════════════════════════
// _courtAction tracks current mode:
//   { mode: null }                          — normal
//   { mode: 'move', step: 1 }              — select players from pills (multi-select)
//   { mode: 'move', step: 2 }              — click destination court
//   { mode: 'swap', step: 1 }              — click first court
//   { mode: 'swap', step: 2, courtA }      — click second court
//
// _moveSelections = [{ matchId, playerIdx, fromCourt, fromTeam ('A'|'B') }, ...]
let _courtAction   = { mode: null };
let _moveSelections = []; // selected players waiting to be moved

function setCourtActionMode(mode) {
  _courtAction    = { mode, step: 1 };
  _moveSelections = [];
  document.getElementById('btn-cancel-court-action').style.display = '';
  document.getElementById('btn-move-mode').style.background = mode === 'move' ? 'rgba(198,255,0,0.15)' : '';
  document.getElementById('btn-swap-mode').style.background = mode === 'swap' ? 'rgba(198,255,0,0.15)' : '';
  const banner = document.getElementById('court-action-banner');
  banner.style.display = 'flex';
  updateMoveActionBanner();
  renderCourtsGrid();
}

function cancelCourtAction() {
  _courtAction    = { mode: null };
  _moveSelections = [];
  document.getElementById('btn-cancel-court-action').style.display = 'none';
  document.getElementById('btn-move-mode').style.background = '';
  document.getElementById('btn-swap-mode').style.background = '';
  const banner = document.getElementById('court-action-banner');
  if(banner) banner.style.display = 'none';
  renderCourtsGrid();
}

function updateMoveActionBanner() {
  const textEl = document.getElementById('court-action-text');
  if(!textEl) return;
  if(_courtAction.mode === 'swap') {
    textEl.textContent = _courtAction.step === 1
      ? '⇄ SWAP: Click the first court to swap.'
      : '⇄ SWAP: Court ' + _courtAction.courtA + ' selected — now click the second court.';
    return;
  }
  if(_courtAction.mode === 'move') {
    if(_moveSelections.length === 0) {
      textEl.innerHTML = '↗ MOVE: Click <strong>player name buttons</strong> on match pills to select them (select as many as you want), then click a destination court.';
    } else if(_courtAction.step === 1) {
      const names = _moveSelections.map(s => state.players[s.playerIdx]?.name.split(' ')[0]).join(', ');
      textEl.innerHTML = `↗ MOVE: <strong style="color:var(--lime)">${_moveSelections.length} player${_moveSelections.length > 1 ? 's' : ''} selected: ${escHtml(names)}</strong> — click more players or click a destination court.`;
    } else {
      textEl.innerHTML = '↗ MOVE: Click a destination court.';
    }
  }
}

function renderCourtsGrid() {
  const grid = document.getElementById('courts-grid');

  // Build map: court -> list of pending matches [{id, round, label, teamA, teamB}]
  const courtMatches = {};
  state.schedule.flat().filter(m => !m.complete).forEach(m => {
    if(!courtMatches[m.court]) courtMatches[m.court] = [];
    const taName = matchTeamName(m.teamA);
    const tbName = matchTeamName(m.teamB);
    courtMatches[m.court].push({
      id: m.id, round: m.round,
      label: `R${m.round}: ${taName} vs ${tbName}`,
      teamA: m.teamA, teamB: m.teamB   // needed for player-level move buttons
    });
  });

  const act = _courtAction;

  grid.innerHTML = Array.from({length:MAX_COURTS}, (_, i) => {
    const cn = i + 1;
    const selected = state.selectedCourts.has(cn);
    const matches  = courtMatches[cn] || [];
    const inUse    = matches.length > 0;

    // Visual state
    let borderColor, bgColor, statusText, statusColor, numColor;
    if(!selected) {
      borderColor = 'var(--border)'; bgColor = 'rgba(20,20,20,0.5)';
      statusText = '✗ Disabled'; statusColor = 'var(--txt3)'; numColor = 'var(--txt3)';
    } else if(inUse) {
      borderColor = 'var(--ball)'; bgColor = 'rgba(249,168,37,0.08)';
      statusText = '⚡ In Use'; statusColor = 'var(--ball)'; numColor = 'var(--lime)';
    } else {
      borderColor = 'var(--court3)'; bgColor = 'transparent';
      statusText = '✓ Open'; statusColor = 'var(--txt3)'; numColor = 'var(--lime)';
    }

    // Highlight for swap step 2 (first court selected) or move step 2 (destination)
    let extraStyle = '';
    if(act.mode === 'swap' && act.step === 2 && act.courtA === cn) {
      borderColor = 'var(--lime)'; bgColor = 'rgba(198,255,0,0.1)';
      extraStyle = 'box-shadow:0 0 0 2px var(--lime);';
    }
    if(act.mode === 'move' && act.step === 2 && act.fromCourt === cn) {
      borderColor = '#90CAF9'; bgColor = 'rgba(66,165,245,0.1)';
      extraStyle = 'box-shadow:0 0 0 2px #90CAF9;';
    }

    // Match pills — in move mode show individual player buttons for multi-selection
    const pills = matches.map(m => {
      if(act.mode !== 'move') {
        // Normal display: just show match label
        return `<div class="court-match-pill">
          <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:0.67rem">${escHtml(m.label)}</span>
        </div>`;
      }
      // Move mode: show individual player name buttons
      const allPlayers = [
        ...(m.teamA || []).map(pi => ({ pi, team:'A' })),
        ...(m.teamB || []).map(pi => ({ pi, team:'B' }))
      ];
      const playerBtns = allPlayers.map(({ pi, team }) => {
        const p = state.players[pi];
        const isSelected = _moveSelections.some(s => s.matchId === m.id && s.playerIdx === pi);
        return `<button class="court-swap-btn"
          style="padding:2px 8px;border-radius:4px;font-size:0.72rem;font-weight:600;
                 background:${isSelected ? 'rgba(198,255,0,0.2)' : 'transparent'};
                 color:${isSelected ? 'var(--lime)' : '#90CAF9'};
                 border:1px solid ${isSelected ? 'var(--lime)' : 'transparent'};
                 white-space:nowrap;margin:1px"
          data-match-id="${m.id}"
          data-player-idx="${pi}"
          data-from-court="${cn}"
          data-team="${team}"
          onclick="courtTogglePlayerSelect(event)"
          title="${isSelected ? 'Click to deselect' : 'Click to select'} ${p?.name}">
          ${isSelected ? '✓ ' : ''}${escHtml(p?.name.split(' ')[0] || '?')}
        </button>`;
      }).join('');
      return `<div class="court-match-pill" style="flex-direction:column;align-items:flex-start;height:auto;padding:4px 6px">
        <span style="font-size:0.65rem;color:var(--txt3);margin-bottom:2px">${escHtml(m.label)}</span>
        <div style="display:flex;flex-wrap:wrap;gap:1px">${playerBtns}</div>
      </div>`;
    }).join('');

    // Court card click behaviour — onclick and cursor set separately to avoid attribute collision
    let onclickAttr = '';
    let cursorStyle = '';
    if(!act.mode) {
      onclickAttr = `onclick="toggleCourt(${cn})"`;
      cursorStyle = 'cursor:pointer;';
    } else if(act.mode === 'swap') {
      onclickAttr = `onclick="courtSwapClick(${cn})"`;
      cursorStyle = 'cursor:pointer;';
    } else if(act.mode === 'move') {
      // Court card is clickable as destination whenever players are selected
      if(_moveSelections.length > 0 && selected) {
        onclickAttr = `onclick="courtMoveDestination(${cn})"`;
        cursorStyle = 'cursor:pointer;';
        if(!inUse) borderColor = 'rgba(198,255,0,0.4)';
      }
    }

    // Destination hint when players are selected and this court is a valid target
    const destHint = (act.mode === 'move' && _moveSelections.length > 0 && selected)
      ? `<div style="font-size:0.65rem;color:var(--lime);margin-top:3px">▶ Move here</div>` : '';

    return `<div class="court-card" id="court-card-${cn}"
      style="border-color:${borderColor};background:${bgColor};opacity:${selected?1:0.45};${cursorStyle}${extraStyle}"
      ${onclickAttr}
      title="Court ${cn}">
      <div class="court-num" style="color:${numColor}">${cn}</div>
      <div class="court-status" style="color:${statusColor}">${statusText}</div>
      ${pills}
      ${destHint}
    </div>`;
  }).join('');
}

// ─── Move: toggle a player in/out of the multi-select ───────────────────
function courtTogglePlayerSelect(e) {
  e.stopPropagation();
  const btn       = e.currentTarget;
  const matchId   = parseInt(btn.dataset.matchId);
  const playerIdx = parseInt(btn.dataset.playerIdx);
  const fromCourt = parseInt(btn.dataset.fromCourt);
  const team      = btn.dataset.team;

  const existingIdx = _moveSelections.findIndex(s => s.matchId === matchId && s.playerIdx === playerIdx);
  if(existingIdx >= 0) {
    _moveSelections.splice(existingIdx, 1);
  } else {
    _moveSelections.push({ matchId, playerIdx, fromCourt, team });
  }
  updateMoveActionBanner();
  renderCourtsGrid();
}

// ─── Move: user clicked destination court — apply all selections ─────────
function courtMoveDestination(toCourt) {
  if(_moveSelections.length === 0) { cancelCourtAction(); return; }
  if(!state.selectedCourts.has(toCourt)) {
    toast('⚠️ Court ' + toCourt + ' is disabled — enable it first', 'err');
    return;
  }

  const allMatches = state.schedule.flat();
  const matchIds   = [...new Set(_moveSelections.map(s => s.matchId))];

  // Single match: move the whole match to toCourt
  if(matchIds.length === 1) {
    const m = allMatches.find(m => m.id == matchIds[0]);
    if(!m || m.complete) { toast('Match already complete', 'err'); cancelCourtAction(); return; }
    const fromCourt = m.court;
    if(toCourt === fromCourt) { cancelCourtAction(); return; }
    m.court = toCourt;
    cancelCourtAction();
    autoSave(); renderCourtsGrid(); renderSchedule();
    toast('✅ Match moved: Court ' + fromCourt + ' → Court ' + toCourt);
    const schedBtn = document.querySelector('.tab-btn[onclick*="schedule"]');
    if(schedBtn) showTab('schedule', { target: schedBtn });
    highlightScheduleMatch(matchIds[0]);
    return;
  }

  // Multi-match: pair up selections across different matches and swap players
  const sels = [..._moveSelections];
  let swapCount = 0;
  const affectedIds = new Set();

  while(sels.length >= 2) {
    const s1 = sels.shift();
    const partnerIdx = sels.findIndex(s => s.matchId !== s1.matchId);
    if(partnerIdx < 0) continue;
    const s2 = sels.splice(partnerIdx, 1)[0];

    const m1 = allMatches.find(m => m.id == s1.matchId);
    const m2 = allMatches.find(m => m.id == s2.matchId);
    if(!m1 || !m2 || m1.complete || m2.complete) continue;

    const team1 = s1.team === 'A' ? m1.teamA : m1.teamB;
    const team2 = s2.team === 'A' ? m2.teamA : m2.teamB;
    const slot1 = team1.indexOf(s1.playerIdx);
    const slot2 = team2.indexOf(s2.playerIdx);
    if(slot1 < 0 || slot2 < 0) continue;

    team1[slot1] = s2.playerIdx;
    team2[slot2] = s1.playerIdx;
    swapCount++;
    affectedIds.add(s1.matchId);
    affectedIds.add(s2.matchId);
  }

  cancelCourtAction();
  if(!swapCount) {
    toast('⚠️ Select players from at least two different matches to swap them', 'err');
    return;
  }
  autoSave(); renderCourtsGrid(); renderSchedule();
  toast('✅ Swapped ' + swapCount + ' player pair' + (swapCount > 1 ? 's' : '') + ' across courts');
  const schedBtn = document.querySelector('.tab-btn[onclick*="schedule"]');
  if(schedBtn) showTab('schedule', { target: schedBtn });
}


// ─── Swap: step 1 — user clicked first court ────────────────────────────
function courtSwapClick(cn) {
  if(_courtAction.step === 1) {
    _courtAction = { mode: 'swap', step: 2, courtA: cn };
    updateMoveActionBanner();
    renderCourtsGrid();
  } else if(_courtAction.step === 2) {
    const a = _courtAction.courtA, b = cn;
    if(a === b) { cancelCourtAction(); return; }
    // Capture IDs BEFORE swapping so we can highlight them after
    const swappedIds = state.schedule.flat().filter(m => !m.complete && (m.court === a || m.court === b)).map(m => m.id);
    let moved = 0;
    state.schedule.flat().filter(m => !m.complete).forEach(m => {
      if(m.court === a)      { m.court = b; moved++; }
      else if(m.court === b) { m.court = a; moved++; }
    });
    cancelCourtAction();
    autoSave(); renderCourtsGrid(); renderSchedule();
    toast('✅ Swapped Courts ' + a + ' ↔ ' + b + ' (' + moved + ' match' + (moved !== 1 ? 'es' : '') + ')');
    // Switch to schedule tab and highlight swapped matches
    showTab('schedule', {target: document.querySelector('.tab-btn[onclick*="schedule"]')});
    swappedIds.forEach(id => highlightScheduleMatch(id));
  }
}

// ─── Flash-highlight a match row in the schedule tab ────────────────────
function highlightScheduleMatch(matchId) {
  // Schedule rows have id="match-{id}" as rendered in renderSchedule
  // Give renderSchedule a tick to finish painting before we scroll/flash
  requestAnimationFrame(() => {
    const row = document.getElementById('match-' + matchId) || document.getElementById('match-' + parseInt(matchId));
    if(!row) return;
    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    row.style.transition = 'background 0.15s';
    row.style.background = 'rgba(198,255,0,0.18)';
    setTimeout(() => { row.style.background = ''; }, 1800);
  });
}

// ═══════════════════════════════════════════════
//  STANDINGS
// ═══════════════════════════════════════════════
// ─── Populate CR/Pod filter dropdowns (called on render) ─────────────────
function populateFilterDropdowns() {
  // Collect unique club ratings and pod labels from completed matches
  const crVals  = [...new Set(state.players.map(p => String(p.clubRating || '').trim()).filter(Boolean))].sort((a,b) => {
    const na = parseFloat(a), nb = parseFloat(b);
    return !isNaN(na) && !isNaN(nb) ? na - nb : a.localeCompare(b);
  });
  const podVals = [...new Set(state.schedule.flat().map(m => m.podLabel).filter(Boolean))].sort();

  ['st-cr','ps-cr'].forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    const cur = el.value;
    el.innerHTML = '<option value="">All club ratings</option>' + crVals.map(v => `<option value="${v}"${v===cur?' selected':''}>${v}</option>`).join('');
  });
  ['st-pod','ps-pod'].forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    const cur = el.value;
    el.innerHTML = '<option value="">All pods</option>' + podVals.map(v => `<option value="${v}"${v===cur?' selected':''}>${escHtml(v)}</option>`).join('');
  });
}

function resetStandingsFilters() {
  ['st-search','st-gender','st-cr','st-pod','st-sort','st-min-played'].forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    if(el.tagName === 'INPUT') el.value = '';
    else el.selectedIndex = 0;
  });
  renderStandings();
}

function resetPlayerStatsFilters() {
  ['ps-search','ps-gender','ps-cr','ps-pod','ps-min-games','ps-sort'].forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    if(el.tagName === 'INPUT') el.value = '';
    else el.selectedIndex = 0;
  });
  renderPlayerStats();
}

function updateStandings() {
  // renderStandings reads live from state.schedule — always call it so standings stay current
  renderStandings();
}

// Local fallback — identical math to the Worker's computeStandings(), kept
// here so standings still work if the relay is unreachable (offline, relay
// down, etc.) rather than the whole tab breaking. The Worker copy is the
// "real" source of truth when reachable; this is a safety net, not a
// silent duplicate kept in sync by hand — see standingsCalcFallback below.
function standingsCalcFallback(players, schedule) {
  const stats = {};
  players.forEach((p,i) => { stats[i] = { idx: i, played: 0, wins: 0, losses: 0, pts: 0, pct: 0 }; });
  schedule.flat().filter(m=>m.complete).forEach(m => {
    m.teamA.forEach(pi => {
      if(!stats[pi]) return;
      stats[pi].played++;
      if(m.scoreA > m.scoreB) { stats[pi].wins++; stats[pi].pts += 2; }
      else if(m.scoreA < m.scoreB) { stats[pi].losses++; }
      else { stats[pi].pts += 1; }
    });
    m.teamB.forEach(pi => {
      if(!stats[pi]) return;
      stats[pi].played++;
      if(m.scoreB > m.scoreA) { stats[pi].wins++; stats[pi].pts += 2; }
      else if(m.scoreB < m.scoreA) { stats[pi].losses++; }
      else { stats[pi].pts += 1; }
    });
  });
  Object.values(stats).forEach(s => { s.pct = s.played ? s.wins/s.played : 0; });
  return stats;
}

// Cache of the last-known stats so re-renders triggered by filter/sort
// changes (search box typing, dropdown changes) don't all re-hit the Worker —
// only a fresh schedule snapshot (tracked via _standingsCacheKey) does.
var _standingsStatsCache = null;
var _standingsCacheKey = null;

async function fetchStandingsStats(players, schedule) {
  const key = JSON.stringify(schedule.flat().filter(m=>m.complete).map(m => [m.id, m.scoreA, m.scoreB]));
  if(_standingsStatsCache && _standingsCacheKey === key) return _standingsStatsCache;
  try {
    const r = await fetch(RELAY_BASE + '/api/standings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ players, schedule }),
    });
    const data = await r.json();
    if(data.ok && data.stats) {
      _standingsStatsCache = data.stats;
      _standingsCacheKey = key;
      return data.stats;
    }
    throw new Error(data.error || 'Worker returned no stats');
  } catch(e) {
    // Relay unreachable or errored — fall back to local calc so the tab
    // still works, just without the server-side protection on this call.
    const stats = standingsCalcFallback(players, schedule);
    _standingsStatsCache = stats;
    _standingsCacheKey = key;
    return stats;
  }
}

function renderStandings() {
  populateFilterDropdowns();
  const tbody = document.getElementById('standings-body');
  if(!state.players.length) {
    tbody.innerHTML = '<tr><td colspan="10"><div class="empty-state"><div class="big">🏆</div>Generate schedule and play matches first</div></td></tr>';
    return;
  }

  // Render synchronously from cache/fallback immediately (so the table never
  // flashes empty or feels laggy), then kick off the real fetch — if it
  // returns different data (cache miss), re-render once it lands. This keeps
  // every existing renderStandings()/updateStandings() call site working
  // exactly as before with no changes needed at the 18 call sites elsewhere
  // in this file.
  const key = JSON.stringify(state.schedule.flat().filter(m=>m.complete).map(m => [m.id, m.scoreA, m.scoreB]));
  if(_standingsCacheKey === key && _standingsStatsCache) {
    renderStandingsTable(_standingsStatsCache);
  } else {
    // Render the previous cache (if any) immediately to avoid a visible gap,
    // then replace it once the fresh fetch resolves.
    if(_standingsStatsCache) renderStandingsTable(_standingsStatsCache);
    fetchStandingsStats(state.players, state.schedule).then(stats => {
      // Guard against a stale response landing after the user navigated away
      // and the standings tab/table no longer being what's on screen.
      if(document.getElementById('standings-body')) renderStandingsTable(stats);
    });
  }
}

function renderStandingsTable(stats) {
  const tbody = document.getElementById('standings-body');
  if(!tbody) return;


  // Read filter values
  const stSearch     = (document.getElementById('st-search')?.value     || '').toLowerCase().trim();
  const stGender     = document.getElementById('st-gender')?.value     || '';
  const stCR         = document.getElementById('st-cr')?.value         || '';
  const stPod        = document.getElementById('st-pod')?.value        || '';
  const stSort       = document.getElementById('st-sort')?.value       || 'pts';
  const stMinPlayed  = parseInt(document.getElementById('st-min-played')?.value || '0');

  // Determine which players are in the selected pod (if any)
  const podPlayerSet = stPod
    ? new Set(state.schedule.flat().filter(m => m.podLabel === stPod).flatMap(m => [...m.teamA, ...m.teamB]))
    : null;

  let list = Object.values(stats);
  list.forEach(s => { s.pct = s.played ? s.wins/s.played : 0; });

  // Apply filters
  list = list.filter(s => {
    const p = state.players[s.idx];
    if(stSearch && !p.name.toLowerCase().includes(stSearch)) return false;
    if(stGender && p.gender !== stGender) return false;
    if(stCR && String(p.clubRating || '').trim() !== stCR) return false;
    if(podPlayerSet && !podPlayerSet.has(s.idx)) return false;
    if(stMinPlayed > 0 && s.played < stMinPlayed) return false;
    return true;
  });

  // Apply sort
  const sortFns = {
    pts:    (a,b) => b.pts - a.pts || b.pct - a.pct,
    wins:   (a,b) => b.wins - a.wins || b.pts - a.pts,
    pct:    (a,b) => b.pct - a.pct || b.pts - a.pts,
    played: (a,b) => b.played - a.played,
    name:   (a,b) => state.players[a.idx].name.localeCompare(state.players[b.idx].name),
    dupr:   (a,b) => (state.players[b.idx].dupr ?? -1) - (state.players[a.idx].dupr ?? -1),
  };
  list.sort(sortFns[stSort] || sortFns.pts);

  // Filter summary
  const totalCount = Object.values(stats).length;
  const summaryEl = document.getElementById('st-filter-summary');
  if(summaryEl) {
    const filtersActive = stSearch || stGender || stCR || stPod || stMinPlayed > 0;
    summaryEl.textContent = filtersActive
      ? `Showing ${list.length} of ${totalCount} player${totalCount !== 1 ? 's' : ''}`
      : '';
  }

  const medals = ['🥇','🥈','🥉'];
  tbody.innerHTML = list.length ? list.map((s, rank) => {
    const p = state.players[s.idx];
    const rankClass = rank < 3 ? `rank-${rank+1}` : '';
    const pct = s.played ? Math.round(s.pct*100)+'%' : '—';
    const duprVal = p.dupr != null ? `<span style="color:#80CBC4;font-family:'JetBrains Mono',monospace">${p.dupr.toFixed(2)}</span>` : '<span style="color:var(--txt3)">—</span>';
    const crVal   = p.clubRating ? `<span style="color:#FFD54F;font-family:'JetBrains Mono',monospace">${p.clubRating}</span>` : '<span style="color:var(--txt3)">—</span>';
    return `<tr class="${rankClass}">
      <td class="rank-num">${medals[rank]||rank+1}</td>
      <td style="font-weight:700;color:var(--lime)">${p.name}</td>
      <td><span class="badge badge-${p.gender.toLowerCase()}">${p.gender}</span></td>
      <td>${duprVal}</td>
      <td>${crVal}</td>
      <td>${s.played}</td>
      <td style="color:var(--txt3);font-weight:700">${s.wins}</td>
      <td style="color:var(--red)">${s.losses}</td>
      <td style="font-family:'Bebas Neue';font-size:1.2rem;color:var(--ball)">${s.pts}</td>
      <td>${pct}</td>
    </tr>`;
  }).join('')
    : '<tr><td colspan="10"><div class="empty-state">No players match the current filters.</div></td></tr>';
}

// ═══════════════════════════════════════════════
//  TV DISPLAY + PUBLIC STANDINGS
// ═══════════════════════════════════════════════
function getPublicStandingsLink() {
  const base = window.location.origin + window.location.pathname;
  return base + '?view=public';
}

function getDisplayRows(limit) {
  const stats = standingsCalcFallback(state.players || [], state.schedule || []);
  const rows = Object.values(stats).map(s => {
    const p = state.players[s.idx];
    return Object.assign({}, s, { player: p, pct: s.played ? s.wins / s.played : 0 });
  }).filter(r => r.player);
  rows.sort((a,b) => b.pts - a.pts || b.wins - a.wins || b.pct - a.pct || a.player.name.localeCompare(b.player.name));
  return typeof limit === 'number' ? rows.slice(0, limit) : rows;
}

function getTvCurrentRound() {
  const progress = dashboardGetProgress();
  if(!progress.rounds.length || progress.currentIdx < 0) return { idx: -1, matches: [], started: false };
  const idx = progress.currentIdx;
  const matches = (progress.rounds[idx] || []).filter(m => m && m.teamA && m.teamB);
  const started = !!(state.startedRounds && state.startedRounds.has(idx));
  return { idx, matches, started };
}

function renderTvAssignments(targetId, opts) {
  const el = document.getElementById(targetId);
  if(!el) return;
  const current = getTvCurrentRound();
  const progress = dashboardGetProgress();
  const name = (document.getElementById('tournament-name')?.value || '').trim() || 'Pickleball Tournament';
  const activePlayers = (state.players || []).filter(p => p.waitlist !== true && p.active !== false && p.checkedIn !== false).length;
  const roundLabel = current.idx >= 0 ? `${current.idx + 1} / ${progress.rounds.length}` : '—';
  if(!current.matches.length) {
    el.innerHTML = `<div class="tv-header"><div><div class="tv-title">${escHtml(name)}</div><div class="tv-subtitle">No court assignments yet.</div></div></div><div class="empty-state"><div class="big">🏓</div>Generate the next round to show player court assignments.</div>`;
    return;
  }
  const byeIdxs = (state.byeRounds || [])[current.idx] || [];
  const byeNames = byeIdxs.map(i => state.players[i]?.name).filter(Boolean);
  el.innerHTML = `
    <div class="tv-header">
      <div><div class="tv-title">${escHtml(name)}</div><div class="tv-subtitle">Round ${current.idx + 1} court assignments · Start the round to switch this screen to standings</div></div>
      <div class="tv-kpis">
        <div class="tv-kpi"><strong>${activePlayers}</strong><span>Players</span></div>
        <div class="tv-kpi"><strong>${roundLabel}</strong><span>Round</span></div>
        <div class="tv-kpi"><strong>${current.matches.length}</strong><span>Courts</span></div>
      </div>
    </div>
    <div class="tv-court-grid">
      ${current.matches.map(m => {
        const a = (m.teamA || []).map(i => state.players[i]?.name || '?');
        const b = (m.teamB || []).map(i => state.players[i]?.name || '?');
        return `<div class="tv-court-card">
          <div class="court-head"><div class="tv-court-num">Court ${escHtml(String(m.court))}</div><div class="tv-court-status">Ready</div></div>
          <div class="tv-team-row"><div class="tv-team-name">${escHtml(a[0] || '?')}<br>${escHtml(a[1] || '?')}</div><div class="tv-vs">VS</div><div class="tv-team-name" style="text-align:right">${escHtml(b[0] || '?')}<br>${escHtml(b[1] || '?')}</div></div>
        </div>`;
      }).join('')}
    </div>
    ${byeNames.length ? `<div class="tv-bye-box"><strong style="color:var(--ball)">Sitting out this round:</strong> ${byeNames.map(escHtml).join(', ')}</div>` : ''}`;
}

function renderTvStandings(targetId, opts) {
  const el = document.getElementById(targetId);
  if(!el) return;
  const rows = getDisplayRows((opts && opts.limit) || 24);
  const progress = dashboardGetProgress();
  const name = (document.getElementById('tournament-name')?.value || '').trim() || 'Pickleball Tournament';
  const activePlayers = (state.players || []).filter(p => p.waitlist !== true && p.active !== false && p.checkedIn !== false).length;
  const roundLabel = progress.rounds.length ? `${Math.min(progress.currentIdx + 1, progress.rounds.length)} / ${progress.rounds.length}` : '—';
  if(!rows.length) {
    el.innerHTML = `<div class="tv-header"><div><div class="tv-title">${escHtml(name)}</div><div class="tv-subtitle">Round is live. Standings will appear after scores are entered.</div></div></div><div class="empty-state"><div class="big">📊</div>Enter scores to populate the leaderboard.</div>`;
    return;
  }
  const medals = ['🥇','🥈','🥉'];
  el.innerHTML = `
    <div class="tv-header">
      <div><div class="tv-title">${escHtml(name)}</div><div class="tv-subtitle">Live standings · ${new Date().toLocaleTimeString([], {hour:'numeric', minute:'2-digit'})}</div></div>
      <div class="tv-kpis">
        <div class="tv-kpi"><strong>${activePlayers}</strong><span>Players</span></div>
        <div class="tv-kpi"><strong>${roundLabel}</strong><span>Round</span></div>
        <div class="tv-kpi"><strong>${progress.completeGames}/${progress.totalGames || 0}</strong><span>Games</span></div>
      </div>
    </div>
    <div class="tv-leader-grid">
      ${rows.map((r,i) => {
        const pct = r.played ? Math.round(r.pct * 100) + '%' : '—';
        return `<div class="tv-player-card ${i<3?'top':''}">
          <div style="display:flex;align-items:center;gap:0.75rem;min-width:0">
            <div class="tv-rank">${medals[i] || (i+1)}</div>
            <div style="min-width:0"><div class="tv-player-name">${escHtml(r.player.name)}</div><div class="tv-player-meta">${r.wins}W · ${r.losses}L · ${pct} win rate</div></div>
          </div>
          <div class="tv-points">${r.pts}<span>pts</span></div>
        </div>`;
      }).join('')}
    </div>`;
}

const TV_VIEW_MODE_KEY = 'pb_tv_live_view_mode';

function getTvViewMode() {
  try {
    const mode = localStorage.getItem(TV_VIEW_MODE_KEY);
    return (mode === 'courts' || mode === 'standings') ? mode : 'courts';
  } catch(e) {
    return 'courts';
  }
}

function setTvViewMode(mode) {
  if(mode !== 'courts' && mode !== 'standings') mode = 'courts';
  try { localStorage.setItem(TV_VIEW_MODE_KEY, mode); } catch(e) {}
  renderDisplayTools();
  toast(mode === 'courts' ? 'TV Display: Court assignments' : 'TV Display: Player standings');
}

function updateTvViewButtons() {
  const mode = getTvViewMode();
  const courts = document.getElementById('tv-mode-courts');
  const standings = document.getElementById('tv-mode-standings');
  if(courts) courts.className = mode === 'courts' ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm';
  if(standings) standings.className = mode === 'standings' ? 'btn btn-primary btn-sm' : 'btn btn-secondary btn-sm';
}

function renderTvBoard(targetId, opts) {
  const mode = getTvViewMode();
  updateTvViewButtons();
  if(mode === 'courts') return renderTvAssignments(targetId, opts);
  if(mode === 'standings') return renderTvStandings(targetId, opts);

  const current = getTvCurrentRound();
  if(current.matches.length && !current.started) return renderTvAssignments(targetId, opts);
  if(current.matches.length && current.started && current.matches.every(m => m.complete)) {
    const next = getNextUnstartedRoundAfter(current.idx);
    if(next && next.matches.length) return renderTvNextUp(targetId, next, opts);
  }
  return renderTvStandings(targetId, opts);
}

function getNextUnstartedRoundAfter(idx) {
  const rounds = state.schedule || [];
  for(let i = idx + 1; i < rounds.length; i++) {
    const matches = (rounds[i] || []).filter(m => m && m.teamA && m.teamB);
    if(matches.length && !(state.startedRounds && state.startedRounds.has(i))) return { idx:i, matches };
  }
  return null;
}

function renderTvNextUp(targetId, next, opts) {
  const el = document.getElementById(targetId);
  if(!el) return;
  const name = (document.getElementById('tournament-name')?.value || '').trim() || 'Pickleball Tournament';
  const byeIdxs = (state.byeRounds || [])[next.idx] || [];
  const byeNames = byeIdxs.map(i => state.players[i]?.name).filter(Boolean);
  el.innerHTML = `
    <div class="tv-header">
      <div><div class="tv-title">${escHtml(name)}</div><div class="tv-subtitle">Next up: Round ${next.idx + 1} court assignments</div></div>
      <div class="tv-kpis"><div class="tv-kpi"><strong>${next.matches.length}</strong><span>Courts</span></div><div class="tv-kpi"><strong>${byeNames.length}</strong><span>Sitting Out</span></div></div>
    </div>
    <div class="tv-court-grid">
      ${next.matches.map(m => {
        const a = (m.teamA || []).map(i => state.players[i]?.name || '?');
        const b = (m.teamB || []).map(i => state.players[i]?.name || '?');
        return `<div class="tv-court-card"><div class="court-head"><div class="tv-court-num">Court ${escHtml(String(m.court))}</div><div class="tv-court-status">Next</div></div><div class="tv-team-row"><div class="tv-team-name">${escHtml(a[0] || '?')}<br>${escHtml(a[1] || '?')}</div><div class="tv-vs">VS</div><div class="tv-team-name" style="text-align:right">${escHtml(b[0] || '?')}<br>${escHtml(b[1] || '?')}</div></div></div>`;
      }).join('')}
    </div>
    ${byeNames.length ? `<div class="tv-bye-box"><strong style="color:var(--ball)">Sitting out next round:</strong> ${byeNames.map(escHtml).join(', ')}</div>` : ''}`;
}

function renderDisplayTools() {
  renderTvBoard('tv-board', { limit: 24 });
  const link = getPublicStandingsLink();
  const box = document.getElementById('public-link-box');
  if(box) box.textContent = link;
  const qr = document.getElementById('public-qr');
  if(qr) {
    qr.innerHTML = '';
    try {
      if(window.QRCode) new QRCode(qr, { text: link, width: 150, height: 150, colorDark:'#000000', colorLight:'#ffffff' });
      else qr.textContent = link;
    } catch(e) { qr.textContent = link; }
  }
}

function renderPublicStandings() {
  const name = (document.getElementById('tournament-name')?.value || '').trim() || 'Pickleball Tournament';
  const st = document.getElementById('public-status');
  if(st) st.textContent = name + ' · live leaderboard';
  renderTvBoard('public-standings-wrap', { limit: 50 });
}

function tvToggleFullscreen() {
  const board = document.getElementById('tv-board');
  if(!board) return;
  board.classList.toggle('tv-fullscreen');
  renderTvBoard('tv-board', { limit: board.classList.contains('tv-fullscreen') ? 60 : 24 });
}

function copyPublicLink() {
  const link = getPublicStandingsLink();
  if(navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(link).then(()=>toast('Public standings link copied'));
  } else {
    prompt('Copy this public standings link:', link);
  }
}

function openPublicStandings() {
  window.open(getPublicStandingsLink(), '_blank');
}

function maybeEnterPublicMode() {
  const params = new URLSearchParams(window.location.search);
  if(params.get('view') === 'public') {
    document.body.classList.add('public-mode');
    showTab('public');
    setInterval(renderPublicStandings, 30000);
  }
  if(params.get('view') === 'checkin') {
    document.body.classList.add('public-mode');
    showTab('selfcheckinpublic');
  }
}

// ═══════════════════════════════════════════════
//  PLAYOFFS ENGINE
// ═══════════════════════════════════════════════

// playoffState.rounds = [{name, matches:[{id,teamA,teamB,scoreA,scoreB,complete,winner}]}]
// teamA/teamB = {seeds:[pidx,pidx], label, seedNums:[n,n]}
var playoffState = {
  active: false,
  format: 8,
  partnerMode: 'keep',
  seedBy: 'wins',
  rounds: [],        // [{name, stageKey, matches:[...]}]
  activeRoundIdx: 0,
  seeds: [],         // sorted player indices (seed 1 = best)
  partnerPairs: {},  // pidx → partner pidx (from round-robin, if partnerMode='keep')
  champion: null,    // {players:[pidx,pidx], label}
};

var STAGE_NAMES = {
  r16: 'Round of 16', qf: 'Quarterfinals', sf: 'Semifinals', f: 'Final'
};
var STAGE_COLORS = {
  r16: 'var(--txt3)', qf: 'var(--blue)', sf: 'var(--purple)', f: 'var(--ball)'
};

function onPlayoffFormatChange() {
  const fmtVal = document.getElementById('po-format')?.value || '8';
  const fmt = fmtVal.startsWith('de') ? fmtVal : parseInt(fmtVal);
  const descs = {
    4:    '4 players form 2 teams → 1 Final match.',
    8:    '8 players form 4 teams → Semifinals (2 matches) + Final (1) = 3 matches total.',
    16:   '16 players form 8 teams → Quarterfinals (4 matches) + SF (2) + Final (1) = 7 matches total.',
    32:   '32 players form 16 teams → R16 (8 matches) + QF (4) + SF (2) + Final (1) = 15 matches total.',
    de8:  '🔁 Double Elimination · 8 players (4 teams) — must lose TWICE to be eliminated. Winners bracket + Losers bracket + Grand Final.',
    de16: '🔁 Double Elimination · 16 players (8 teams) — must lose TWICE to be eliminated. Winners bracket + Losers bracket + Grand Final.',
  };
  const el = document.getElementById('po-format-desc');
  if(el) el.textContent = descs[fmt] || '';
}

// ═══════════════════════════════════════════════
//  DOUBLE ELIMINATION BRACKET
// ═══════════════════════════════════════════════
// Uses direct object references for routing — no string matching.
// Each match stores {onWin: fn(winTeam), onLose: fn(loseTeam)} callbacks set at build time.

function makeDeMatch(bracket, label, tA, tB) {
  return { id: null, bracket, label, teamA: tA||null, teamB: tB||null,
           scoreA:'', scoreB:'', complete:false, onWin:null, onLose:null };
}

function generateDoubleElimination(seedTeams, pMode, fmt) {
  const numTeams = fmt === 'de8' ? 4 : 8;
  const teams    = seedTeams.slice(0, numTeams);
  if(teams.length < 2) { toast('Not enough teams for Double Elimination', 'err'); return false; }

  playoffState.active      = true;
  playoffState.format      = fmt;
  playoffState.de          = true;
  playoffState.champion    = null;
  playoffState.activeRoundIdx = 0;
  playoffState.seeds       = seedTeams;

  let mid = 0;
  const mm = (bracket, label, tA, tB) => {
    const match = makeDeMatch(bracket, label, tA, tB);
    match.id = mid++;
    return match;
  };

  let allMatches, rounds;

  if(fmt === 'de8') {
    // 4 teams → 5 matches
    // W bracket: W-SF1, W-SF2 → W-Final
    // L bracket: losers of W-SFs → L-Final
    // Grand Final: W-Final winner vs L-Final winner
    const wSF1 = mm('W', 'W Semi 1',  teams[0], teams[3]);
    const wSF2 = mm('W', 'W Semi 2',  teams[1], teams[2]);
    const wF   = mm('W', 'W Final',   null, null);
    const lF   = mm('L', 'L Final',   null, null);
    const gF   = mm('GF','Grand Final',null, null);

    wSF1.onWin  = (t) => { wF.teamA = t; };
    wSF1.onLose = (t) => { lF.teamA = t; };
    wSF2.onWin  = (t) => { wF.teamB = t; };
    wSF2.onLose = (t) => { lF.teamB = t; };
    wF.onWin    = (t) => { gF.teamA = t; };
    wF.onLose   = (t) => { /* L Final already has both from SFs — W Final loser could replace or add */ };
    lF.onWin    = (t) => { gF.teamB = t; };

    allMatches = [wSF1, wSF2, wF, lF, gF];
    rounds = [
      { name:'Winners Semis',   stageKey:'wsf',  de:true, matches:[wSF1, wSF2] },
      { name:'W Final · L Final', stageKey:'wflf', de:true, matches:[wF, lF] },
      { name:'Grand Final',     stageKey:'gf',   de:true, matches:[gF] },
    ];
  } else {
    // 8 teams → 13 matches
    const wQF  = [mm('W','W QF 1',teams[0],teams[7]), mm('W','W QF 2',teams[1],teams[6]),
                  mm('W','W QF 3',teams[2],teams[5]), mm('W','W QF 4',teams[3],teams[4])];
    const lR1  = [mm('L','L R1-A',null,null), mm('L','L R1-B',null,null)];
    const wSF  = [mm('W','W SF 1',null,null), mm('W','W SF 2',null,null)];
    const lR2  = [mm('L','L R2-A',null,null), mm('L','L R2-B',null,null)];
    const wF   = mm('W','W Final',null,null);
    const lSF  = mm('L','L Semi', null,null);
    const lF   = mm('L','L Final',null,null);
    const gF   = mm('GF','Grand Final',null,null);

    wQF[0].onWin=(t)=>{wSF[0].teamA=t;}; wQF[0].onLose=(t)=>{lR1[0].teamA=t;};
    wQF[1].onWin=(t)=>{wSF[0].teamB=t;}; wQF[1].onLose=(t)=>{lR1[0].teamB=t;};
    wQF[2].onWin=(t)=>{wSF[1].teamA=t;}; wQF[2].onLose=(t)=>{lR1[1].teamA=t;};
    wQF[3].onWin=(t)=>{wSF[1].teamB=t;}; wQF[3].onLose=(t)=>{lR1[1].teamB=t;};
    lR1[0].onWin=(t)=>{lR2[0].teamA=t;};
    lR1[1].onWin=(t)=>{lR2[1].teamA=t;};
    wSF[0].onWin=(t)=>{wF.teamA=t;};   wSF[0].onLose=(t)=>{lR2[0].teamB=t;};
    wSF[1].onWin=(t)=>{wF.teamB=t;};   wSF[1].onLose=(t)=>{lR2[1].teamB=t;};
    lR2[0].onWin=(t)=>{lSF.teamA=t;};
    lR2[1].onWin=(t)=>{lSF.teamB=t;};
    wF.onWin =(t)=>{gF.teamA=t;};      wF.onLose=(t)=>{lF.teamA=t;};
    lSF.onWin=(t)=>{lF.teamB=t;};
    lF.onWin =(t)=>{gF.teamB=t;};

    allMatches = [...wQF,...lR1,...wSF,...lR2,wF,lSF,lF,gF];
    rounds = [
      { name:'W Quarterfinals',    stageKey:'wqf',  de:true, matches:wQF },
      { name:'L Round 1 + W Semis',stageKey:'lr1wsf',de:true,matches:[...lR1,...wSF] },
      { name:'L Round 2',          stageKey:'lr2',  de:true, matches:lR2 },
      { name:'W Final + L Semi',   stageKey:'wflsf',de:true, matches:[wF,lSF] },
      { name:'L Final',            stageKey:'lf',   de:true, matches:[lF] },
      { name:'Grand Final',        stageKey:'gf',   de:true, matches:[gF] },
    ];
  }

  playoffState.deMatches = allMatches;
  playoffState.rounds    = rounds;
  renderPlayoffs();
  return true;
}

function advanceDE(matchId, scoreA, scoreB) {
  const m = playoffState.deMatches.find(x => x.id == matchId); // == handles string/number mismatch
  if(!m || m.complete) return;
  const sa = parseInt(scoreA), sb = parseInt(scoreB);
  if(sa === sb) { toast('No ties allowed in Double Elimination', 'err'); return; }
  m.scoreA = sa; m.scoreB = sb; m.complete = true;
  if(!m.teamA || !m.teamB) { toast('Both teams must be set before scoring', 'err'); return; }
  const winTeam  = sa > sb ? m.teamA : m.teamB;
  const loseTeam = sa > sb ? m.teamB : m.teamA;
  if(m.onWin)  m.onWin(winTeam);
  if(m.onLose) m.onLose(loseTeam);

  // Check for champion
  const gf = playoffState.deMatches.find(x => x.label === 'Grand Final');
  if(gf?.complete) {
    const gfWin = parseInt(gf.scoreA) > parseInt(gf.scoreB) ? gf.teamA : gf.teamB;
    playoffState.champion = gfWin;
  }

  // Mark rounds complete and auto-advance to next playable round
  playoffState.rounds.forEach(r => {
    r.complete = r.matches.every(mx => mx.complete);
  });
  const nextPlayable = playoffState.rounds.findIndex(r =>
    r.matches.some(mx => mx.teamA && mx.teamB && !mx.complete)
  );
  if(nextPlayable !== -1) {
    playoffState.activeRoundIdx = nextPlayable;
  } else if(gf?.complete) {
    playoffState.activeRoundIdx = playoffState.rounds.length - 1;
  }

  autoSave();
  renderPlayoffs();
}


// ═══════════════════════════════════════════════
//  ROUND ROBIN + PLAYOFF — auto-prompt
// ═══════════════════════════════════════════════
function checkRRPlayoffComplete() {
  const mode = document.getElementById('team-mode')?.value || '';
  if(mode !== 'rr-playoff') return;
  if(!state.schedule.length) return;
  const allComplete = state.schedule.flat().every(m => m.complete || m.isRiverMatch);
  if(!allComplete) return;
  // Already prompted?
  if(state._rrPlayoffPrompted) return;
  state._rrPlayoffPrompted = true;

  // Show prompt in the round-complete banner area
  const banner = document.getElementById('round-complete-msg');
  const titleEl = document.getElementById('round-complete-title');
  const nextEl  = document.getElementById('round-complete-next');
  const viewBtn = document.getElementById('round-complete-view-btn');
  const rebuildBtn = document.getElementById('round-complete-rebuild-btn');
  const smsBtn = document.getElementById('round-complete-sms-btn');
  if(!banner) return;

  if(titleEl) titleEl.innerHTML = '🏆 Round Robin complete — ready for playoff!';
  if(nextEl) nextEl.innerHTML = 'All matches are scored. Generate the seeded playoff bracket now.';
  if(viewBtn) { viewBtn.style.display=''; viewBtn.textContent='🏆 Generate Playoff'; viewBtn.onclick=()=>{ dismissRoundComplete(); showTab('playoffs',{target:document.querySelector('.tab-btn[onclick*="playoffs"]')}); }; }
  if(rebuildBtn) rebuildBtn.style.display='none';
  if(smsBtn) smsBtn.style.display='none';
  banner.style.display='flex';
  banner.style.animation='none'; banner.offsetHeight; banner.style.animation='';
}

function resetPlayoffOnly() {
  if(!confirm('Reset the playoff bracket? Your round-robin schedule and scores will be kept.')) return;
  playoffState.active      = false;
  playoffState.rounds      = [];
  playoffState.seeds       = [];
  playoffState.partnerPairs= {};
  playoffState.champion    = null;
  playoffState.activeRoundIdx = 0;
  playoffState.de          = false;
  playoffState.deMatches   = [];
  state._rrPlayoffPrompted = false;
  document.getElementById('po-bracket-wrap').style.display = 'none';
  document.getElementById('po-setup-card').style.display   = 'block';
  document.getElementById('po-setup-card').style.display   = 'block';
  autoSave();
  toast('Playoff bracket cleared — schedule and scores kept');
}

function generatePlayoffs() {
  const fmtRaw    = document.getElementById('po-format')?.value || '8';
  const isDe      = fmtRaw.startsWith('de');
  const fmt       = isDe ? fmtRaw : parseInt(fmtRaw);
  const pMode     = document.getElementById('po-partner-mode')?.value || 'keep';
  const seedBy    = document.getElementById('po-seed-by')?.value || 'wins';
  const n         = state.players.length;

  const numTeamsNeeded = isDe ? (fmt === 'de8' ? 4 : 8) * 2 : fmt;
  if(n < numTeamsNeeded) { toast(`Need at least ${numTeamsNeeded} players for this format. Have ${n}.`, 'err'); return; }

  // ── 1. Seed players ───────────────────────────
  const seedCount = isDe ? (fmt === 'de8' ? 8 : 16) : fmt;
  const seeds = seedPlayers(seedBy, seedCount);

  // Build partner pairs from round-robin history (needed for DE team labels)
  const partnerPairsDE = {};
  if(pMode === 'keep') {
    const pf = playoffState.partnerPairs || {};
    state.players.forEach((_, i) => { if(pf[i] != null) partnerPairsDE[i] = pf[i]; });
    // Also build from last round's teams
    if(state.roundTeams.length) {
      state.roundTeams[state.roundTeams.length-1].forEach(pair => {
        if(pair.length === 2) {
          const ia = state.players.indexOf(pair[0]), ib = state.players.indexOf(pair[1]);
          if(ia >= 0 && ib >= 0) { partnerPairsDE[ia] = ib; partnerPairsDE[ib] = ia; }
        }
      });
    }
  }

  // Route Double Elimination to its own generator
  if(isDe) {
    const deSeeds = seeds.map((pidx, i) => {
      const p = state.players[pidx];
      const partner = partnerPairsDE[pidx];
      const teamPlayers = partner != null ? [pidx, partner] : [pidx];
      return { players: teamPlayers, label: p.name.split(' ')[0] + (partner!=null?' & '+state.players[partner]?.name.split(' ')[0]:''), seedNum: i+1 };
    });
    // Pair seeds into teams: seed1+seed2, seed3+seed4...
    const deTeams = [];
    for(let i = 0; i + 1 < deSeeds.length; i += 2) {
      const a = deSeeds[i], b = deSeeds[i+1];
      deTeams.push({
        players: [...a.players.slice(0,1), ...b.players.slice(0,1)],
        label: a.label + ' / ' + b.label,
        seedNum: Math.floor(i/2)+1
      });
    }
    generateDoubleElimination(deTeams, pMode, fmt);
    document.getElementById('po-setup-card').style.display = 'none';
    document.getElementById('po-bracket-wrap').style.display = 'block';
    toast('🔁 Double Elimination bracket generated!');
    return;
  }

  playoffState.seeds       = seeds;
  playoffState.format      = fmt;
  playoffState.partnerMode = pMode;
  playoffState.seedBy      = seedBy;
  playoffState.active      = true;
  playoffState.rounds      = [];
  playoffState.activeRoundIdx = 0;
  playoffState.champion    = null;

  // ── 2. Build partner pairs → teams ───────────
  const rawPairs = buildPlayoffPairs(seeds, pMode, fmt);
  // rawPairs[i] = [pidxA, pidxB]
  // Reorder pairs so they stay in seed order (pair containing seed[0] is team 1, etc.)
  const teams = [];
  const usedInPair = new Set();
  seeds.forEach((pi, si) => {
    if(usedInPair.has(pi)) return;
    const pair = rawPairs.find(p => p.includes(pi) && !usedInPair.has(p[0]) && !usedInPair.has(p[1]));
    if(pair) {
      teams.push({ players: [...pair], seeds: [si + 1, seeds.indexOf(pair.find(p=>p!==pi)) + 1] });
      usedInPair.add(pair[0]); usedInPair.add(pair[1]);
    }
  });

  // Fallback: if pairing produced fewer teams than expected, fill with adjacent seed pairs
  if(teams.length < fmt / 2) {
    teams.length = 0;
    usedInPair.clear();
    for(let i = 0; i < fmt; i += 2) {
      teams.push({ players: [seeds[i], seeds[i+1]], seeds: [i+1, i+2] });
    }
  }

  // ── 3. Build bracket rounds ───────────────────
  const stageKeys = getStageKeys(fmt);
  const firstRoundMatches = buildBracketMatches(teams, stageKeys[0]);
  playoffState.rounds = [{
    name: STAGE_NAMES[stageKeys[0]],
    stageKey: stageKeys[0],
    matches: firstRoundMatches,
    complete: false,
  }];

  // Pre-build empty later rounds as placeholders
  // teams.length = fmt/2. Each round halves the teams. Final always = 1 match.
  for(let r = 1; r < stageKeys.length; r++) {
    const matchCount = Math.max(1, Math.floor(teams.length / Math.pow(2, r + 1)));
    const emptyMatches = Array.from({length: matchCount}, (_, i) => ({
      id: `po-${stageKeys[r]}-${i}`,
      teamA: null, teamB: null,
      scoreA: '', scoreB: '',
      complete: false, winner: null,
    }));
    playoffState.rounds.push({
      name: STAGE_NAMES[stageKeys[r]],
      stageKey: stageKeys[r],
      matches: emptyMatches,
      complete: false,
    });
  }

  document.getElementById('po-bracket-wrap').style.display = 'block';
  document.getElementById('po-setup-card').style.display = 'block';
  renderPlayoffs();
  autoSave();
  toast(`🏆 Playoff bracket generated! ${fmt} players seeded.`);
}

function seedPlayers(seedBy, count) {
  // Build score from round-robin stats
  const scoreMap = {};
  state.players.forEach((_, i) => { scoreMap[i] = { wins:0, pts:0, games:0, avg:0 }; });
  state.schedule.flat().filter(m=>m.complete).forEach(m => {
    m.teamA.forEach(pi => {
      scoreMap[pi].games++;
      scoreMap[pi].pts += m.scoreA;
      if(m.scoreA > m.scoreB) scoreMap[pi].wins++;
    });
    m.teamB.forEach(pi => {
      scoreMap[pi].games++;
      scoreMap[pi].pts += m.scoreB;
      if(m.scoreB > m.scoreA) scoreMap[pi].wins++;
    });
  });
  Object.keys(scoreMap).forEach(pi => {
    const s = scoreMap[pi];
    s.avg = s.games ? s.pts / s.games : 0;
  });

  const all = Array.from({length: state.players.length}, (_,i) => i);
  const sorters = {
    wins:   (a,b) => scoreMap[b].wins  - scoreMap[a].wins   || scoreMap[b].pts - scoreMap[a].pts,
    pts:    (a,b) => scoreMap[b].pts   - scoreMap[a].pts    || scoreMap[b].wins - scoreMap[a].wins,
    avg:    (a,b) => scoreMap[b].avg   - scoreMap[a].avg    || scoreMap[b].wins - scoreMap[a].wins,
    rating: (a,b) => pRating(state.players[b]) - pRating(state.players[a]),
  };
  return all.sort(sorters[seedBy] || sorters.wins).slice(0, count);
}

function buildPlayoffPairs(seeds, pMode, fmt) {
  // Returns array of [pidx, pidx] pairs for fmt players
  // Standard seeding: 1+fmt, 2+(fmt-1), ...  grouped into adjacent bracket halves
  if(pMode === 'keep') {
    // Use partners from last played round
    const partnerOf = {};
    (state.roundTeams || []).forEach(rnd => rnd.forEach(([p1,p2]) => {
      if(seeds.includes(state.players.indexOf(p1)) && seeds.includes(state.players.indexOf(p2))) {
        const i1 = state.players.indexOf(p1);
        const i2 = state.players.indexOf(p2);
        partnerOf[i1] = i2; partnerOf[i2] = i1;
      }
    }));
    playoffState.partnerPairs = partnerOf;
    // Group seeds into pairs; if no partner found, pair adjacent seeds
    const used = new Set();
    const pairs = [];
    seeds.forEach(pi => {
      if(used.has(pi)) return;
      const partner = partnerOf[pi];
      if(partner !== undefined && seeds.includes(partner) && !used.has(partner)) {
        pairs.push([pi, partner]); used.add(pi); used.add(partner);
      } else {
        const free = seeds.find(s => !used.has(s) && s !== pi);
        if(free !== undefined) { pairs.push([pi, free]); used.add(pi); used.add(free); }
      }
    });
    return pairs;
  }

  if(pMode === 'seeded') {
    // Pair seed 1+last, 2+second-last, etc.
    const pairs = [];
    for(let i = 0; i < fmt/2; i++) pairs.push([seeds[i], seeds[fmt-1-i]]);
    return pairs;
  }

  if(pMode === 'mixed' || pMode === 'mixed-rated') {
    const males   = seeds.filter(pi => state.players[pi].gender === 'Male');
    const females = seeds.filter(pi => state.players[pi].gender === 'Female');
    shuffle(males); shuffle(females);
    const pairs = [];
    const used = new Set();
    males.forEach(m => {
      if(used.has(m)) return;
      const available = females.filter(f => !used.has(f));
      available.sort((a, b) => {
        if(pMode === 'mixed-rated') {
          return Math.abs(pRating(state.players[m]) - pRating(state.players[a]))
               - Math.abs(pRating(state.players[m]) - pRating(state.players[b]));
        }
        return 0;
      });
      const f = available[0];
      if(f !== undefined) { pairs.push([m, f]); used.add(m); used.add(f); }
    });
    seeds.filter(s => !used.has(s)).forEach((s, i, arr) => {
      if(i % 2 === 0 && arr[i+1] !== undefined) { pairs.push([s, arr[i+1]]); used.add(s); used.add(arr[i+1]); }
    });
    return pairs;
  }

  // random
  const pool = [...seeds]; shuffle(pool);
  const pairs = [];
  for(let i=0;i<pool.length;i+=2) if(pool[i+1]!==undefined) pairs.push([pool[i],pool[i+1]]);
  return pairs;
}

function buildBracketMatches(teams, stageKey) {
  // teams[i] = {players, seeds, label} already seeded in order (index 0 = seed 1)
  const n = teams.length; // number of teams this round
  const matches = [];

  if(n === 1) {
    // Final with one team already known — shouldn't happen but guard it
    return matches;
  }

  // Standard bracket pairing: use bracketOrder on n teams
  // bracketOrder(n) returns e.g. [1,4,2,3] for n=4
  const order = buildBracketOrder(n); // indices are 1-based team seeds
  for(let i = 0; i < order.length; i += 2) {
    const tA = teams[order[i] - 1];
    const tB = teams[order[i + 1] - 1];
    if(!tA || !tB) continue;
    matches.push({
      id: `po-${stageKey}-${i / 2}`,
      teamA: tA,
      teamB: tB,
      scoreA: '', scoreB: '',
      complete: false, winner: null,
    });
  }
  return matches;
}

// Returns bracket seed order array of length n (1-based)
// e.g. n=8: [1,8,4,5,2,7,3,6] — seed 1 and 2 land in opposite halves
function buildBracketOrder(n) {
  if (n === 2) return [1, 2];
  const half = buildBracketOrder(n / 2);
  const result = [];
  half.forEach(s => { result.push(s); result.push(n + 1 - s); });
  return result;
}

function getStageKeys(fmt) {
  const map = { 4:['f'], 8:['sf','f'], 16:['qf','sf','f'], 32:['r16','qf','sf','f'] };
  return map[fmt] || ['f'];
}

function advancePlayoffRound() {
  const r = playoffState.rounds[playoffState.activeRoundIdx];
  if(!r) return;
  if(r.matches.some(m => !m.complete)) {
    toast('Enter all scores for this round first','err'); return;
  }
  r.complete = true;

  const nextRoundIdx = playoffState.activeRoundIdx + 1;
  if(nextRoundIdx >= playoffState.rounds.length) {
    // Tournament complete — find champion
    const finalMatch = r.matches[0];
    playoffState.champion = finalMatch?.winner || null;
    renderPlayoffs();
    autoSave();
  toast('🏆 Tournament complete! Champion crowned!');
    return;
  }

  // Populate next round with winners
  const winners = r.matches.map(m => m.winner).filter(Boolean);
  const nextRound = playoffState.rounds[nextRoundIdx];
  const pMode = playoffState.partnerMode;

  // Re-pair winners based on partner mode
  const winnerIndices = winners.map(t => t.players);
  const newTeams = repairForNextRound(winners, pMode, nextRoundIdx);

  for(let i = 0; i < nextRound.matches.length; i++) {
    nextRound.matches[i].teamA = newTeams[i*2]   || null;
    nextRound.matches[i].teamB = newTeams[i*2+1] || null;
  }

  playoffState.activeRoundIdx = nextRoundIdx;
  renderPlayoffs();
  autoSave();
  toast(`⏩ Advanced to ${nextRound.name}!`);
}

function repairForNextRound(winners, pMode, roundIdx) {
  // winners = [{players:[pi,pi], seeds, label}, ...]
  // Returns array of teams for next round in bracket order (winners[0] faces winners[1], etc. keeping bracket integrity)
  if(pMode === 'keep' || pMode === 'seeded') {
    // Keep same pairings within each team, just pass through in bracket order
    return winners;
  }
  // For random/mixed: pool all players, re-pair
  const allPlayers = winners.flatMap(t => t.players);
  let newPairs;
  if(pMode === 'mixed' || pMode === 'mixed-rated') {
    const males   = allPlayers.filter(pi => state.players[pi].gender === 'Male');
    const females = allPlayers.filter(pi => state.players[pi].gender === 'Female');
    shuffle(males); shuffle(females);
    const used = new Set(); newPairs = [];
    males.forEach(m => {
      if(used.has(m)) return;
      const available = females.filter(f => !used.has(f));
      if(pMode === 'mixed-rated') {
        available.sort((a, b) =>
          Math.abs(pRating(state.players[m])) - Math.abs(pRating(state.players[a])) -
          Math.abs(pRating(state.players[m])) + Math.abs(pRating(state.players[a]))
        );
      }
      const f = available[0];
      if(f !== undefined) { newPairs.push([m, f]); used.add(m); used.add(f); }
    });
    allPlayers.filter(p => !used.has(p)).forEach((p, i, arr) => {
      if(i % 2 === 0 && arr[i+1] !== undefined) { newPairs.push([p, arr[i+1]]); }
    });
  } else {
    shuffle(allPlayers);
    newPairs = [];
    for(let i=0;i<allPlayers.length;i+=2) if(allPlayers[i+1]!==undefined) newPairs.push([allPlayers[i],allPlayers[i+1]]);
  }
  return newPairs.map((pair,i) => ({
    players: pair,
    seeds: [i*2+1, i*2+2],
    label: pair.map(pi => state.players[pi]?.name.split(' ')[0]).join(' & '),
  }));
}

function savePlayoffScore(matchId) {
  // Route Double Elimination scores through advanceDE
  if(playoffState.de) {
    const saEl = document.getElementById(`po-sa-${matchId}`);
    const sbEl = document.getElementById(`po-sb-${matchId}`);
    const sa = parseInt(saEl?.value), sb = parseInt(sbEl?.value);
    if(isNaN(sa)||isNaN(sb)) { toast('Enter both scores','err'); return; }
    if(sa === sb) { toast('No ties in playoff','err'); return; }
    advanceDE(matchId, sa, sb);
    return;
  }
  const m = findPlayoffMatch(matchId);
  if(!m) return;
  const saEl = document.getElementById(`po-sa-${matchId}`);
  const sbEl = document.getElementById(`po-sb-${matchId}`);
  const sa = parseInt(saEl?.value);
  const sb = parseInt(sbEl?.value);
  if(isNaN(sa)||isNaN(sb)) { toast('Enter both scores','err'); return; }
  if(sa === sb) { toast('Playoff matches must have a winner — no ties allowed','err'); return; }

  const ppo_prevSa = m.scoreA, ppo_prevSb = m.scoreB, ppo_prevComplete = m.complete;
  m.scoreA = sa; m.scoreB = sb; m.complete = true;
  m.winner = sa > sb ? m.teamA : m.teamB;
  pushUndo(matchId, ppo_prevSa, ppo_prevSb, ppo_prevComplete);
  autoSave();
  if(m.winner) {
    m.winner.label = m.winner.players.map(pi => state.players[pi]?.name.split(' ')[0]).join(' & ');
  }

  // Track in schedule for player stats
  const schedMatch = {
    id: `po_${matchId}`,
    round: `PO-${playoffState.rounds[playoffState.activeRoundIdx]?.name||''}`,
    court: 1,
    teamA: m.teamA?.players || [],
    teamB: m.teamB?.players || [],
    scoreA: sa, scoreB: sb,
    complete: true,
    isPlayoff: true,
    stage: playoffState.rounds[playoffState.activeRoundIdx]?.name,
  };
  if(!state.schedule.find(r => r.find(x => x.id === schedMatch.id))) {
    const lastRound = state.schedule[state.schedule.length-1] || [];
    if(lastRound[0]?.isPlayoff) lastRound.push(schedMatch);
    else state.schedule.push([schedMatch]);
  }

  renderPlayoffs();
  if(document.getElementById('sec-playerstats').classList.contains('active')) renderPlayerStats();
  toast('Score saved!');
}

function editPlayoffScore(matchId) {
  const m = findPlayoffMatch(matchId);
  if(!m) return;
  m.complete = false; m.scoreA=''; m.scoreB=''; m.winner=null;
  renderPlayoffs();
  autoSave();
}

function findPlayoffMatch(matchId) {
  for(const r of playoffState.rounds) {
    const m = r.matches.find(m => m.id === matchId);
    if(m) return m;
  }
  return null;
}

function renderPlayoffs() {
  const wrap = document.getElementById('po-bracket-wrap');
  if(!playoffState.active) { wrap.style.display='none'; return; }
  wrap.style.display = 'block';

  // Champion banner
  let championHtml = '';
  if(playoffState.champion) {
    const names = playoffState.champion.players.map(pi => state.players[pi]?.name || '?').join(' & ');
    championHtml = `<div class="po-champion-banner">
      <div class="trophy">🏆</div>
      <div class="champ-name">${names}</div>
      <div class="champ-sub">Tournament Champions</div>
    </div>`;
  }

  // Stats bar
  const totalPO = playoffState.rounds.reduce((a,r)=>a+r.matches.length,0);
  const donePO  = playoffState.rounds.reduce((a,r)=>a+r.matches.filter(m=>m.complete).length,0);
  const deLabel = playoffState.de ? ' <span style="font-size:0.7rem;background:rgba(198,255,0,0.15);color:var(--lime);border-radius:4px;padding:1px 6px">Double Elim</span>' : '';
  document.getElementById('po-stats-row').innerHTML = `
    <div class="stat"><div class="stat-val">${typeof playoffState.format === 'string' && playoffState.format.startsWith('de') ? playoffState.format.replace('de','') : playoffState.format}${deLabel}</div><div class="stat-lbl">Players</div></div>
    <div class="stat"><div class="stat-val">${playoffState.rounds.length}</div><div class="stat-lbl">Rounds</div></div>
    <div class="stat"><div class="stat-val">${totalPO}</div><div class="stat-lbl">Total Matches</div></div>
    <div class="stat"><div class="stat-val">${donePO}/${totalPO}</div><div class="stat-lbl">Completed</div></div>
  `;

  // Round tabs
  const tabs = playoffState.rounds.map((r,i) => {
    const cls = i===playoffState.activeRoundIdx ? 'active' : r.complete ? 'complete' : '';
    return `<button class="po-round-tab ${cls}" onclick="setPlayoffRound(${i})">${r.name}${r.complete?' ✓':''}</button>`;
  }).join('');
  document.getElementById('po-round-tabs').innerHTML = tabs;

  // Active round matches
  const ar = playoffState.rounds[playoffState.activeRoundIdx];
  const allDone = ar?.matches.every(m=>m.complete);
  const isLast  = playoffState.activeRoundIdx === playoffState.rounds.length-1;

  let activeHtml = '';
  if(championHtml) activeHtml += championHtml;

  if(ar) {
    activeHtml += `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:1.4rem;color:${STAGE_COLORS[ar.stageKey]||'var(--lime)'}">
        ${ar.name}
      </div>
      ${allDone && !playoffState.champion ? `<button class="btn btn-primary" onclick="advancePlayoffRound()">⏩ Advance to ${playoffState.rounds[playoffState.activeRoundIdx+1]?.name||'Final'}</button>` : ''}
    </div>
    <div class="po-matches-grid">${ar.matches.map(m => renderPlayoffMatchCard(m, ar.stageKey)).join('')}</div>`;
  }

  document.getElementById('po-active-round').innerHTML = activeHtml;

  // Bracket tree
  renderBracketTree();
}

function setPlayoffRound(idx) {
  playoffState.activeRoundIdx = idx;
  renderPlayoffs();
}

function renderPlayoffMatchCard(m, stageKey) {
  const stageColor = STAGE_COLORS[stageKey] || 'var(--lime)';
  const tA = m.teamA;
  const tB = m.teamB;

  const teamRow = (team, score, isWinner, isLoser, side) => {
    if(!team) return `<div class="po-team-row"><span style="color:var(--txt3);font-style:italic;font-size:0.82rem">TBD — awaiting previous round</span></div>`;
    // Support both single-elim format {players, seeds, label} and DE format {players, label}
    const playerIdxs = Array.isArray(team.players) ? team.players : (Array.isArray(team) ? team : []);
    const names = playerIdxs.length > 0
      ? playerIdxs.map(pi => {
          const p = state.players[pi];
          return `<span class="po-player-name">${p?.name||'?'}</span><span class="po-player-rating">${pRatingLabel(p)||''}</span>`;
        }).join('<span style="color:var(--txt3);margin:0 4px">&</span>')
      : `<span class="po-player-name">${team.label||'TBD'}</span>`;
    const seedLabel = team.seeds ? `<span style="color:var(--txt3);font-size:0.7rem;margin-right:6px">${team.seeds.map(s=>`#${s}`).join('/')}</span>`
                    : team.seedNum ? `<span style="color:var(--txt3);font-size:0.7rem;margin-right:6px">#${team.seedNum}</span>` : '';
    const scoreHtml = m.complete
      ? `<span class="po-score-cell ${isWinner?'win':isLoser?'lose':''}">${score}</span>`
      : `<input id="po-s${side}-${m.id}" type="number" min="0" max="99" placeholder="0"
           style="width:52px;text-align:center;font-family:'Bebas Neue',sans-serif;font-size:1.2rem;padding:0.25rem">`;
    return `<div class="po-team-row ${isWinner?'winner':isLoser?'loser':''}">
      <span class="po-seed">${seedLabel}</span>
      <span class="po-players">${names}</span>
      ${scoreHtml}
    </div>`;
  };

  const winA = m.complete && m.scoreA > m.scoreB;
  const winB = m.complete && m.scoreB > m.scoreA;

  const footer = m.complete
    ? `<div class="po-match-footer">
        <button class="btn btn-secondary btn-sm" onclick="editPlayoffScore('${m.id}')">✎ Edit</button>
       </div>`
    : `<div class="po-match-footer">
        <button class="btn btn-primary btn-sm" onclick="savePlayoffScore('${m.id}')">✓ Save Score</button>
       </div>`;

  const statusClass = m.complete ? 'done' : (tA && tB ? 'live' : '');

  return `<div class="po-match-card ${statusClass}">
    <div class="po-match-header">
      <span class="po-stage" style="color:${stageColor}">${STAGE_NAMES[stageKey] || (playoffState.de ? {W:'Winners Bracket',L:'Losers Bracket',GF:'Grand Final'}[m.bracket]||'' : '')}</span>
      <span>${m.complete ? `✓ ${m.winner?.label||(m.bracket==='GF'?'Champion':'')}`  : (tA&&tB?'In Progress':'Waiting')}</span>
    </div>
    ${teamRow(tA, m.scoreA, winA, !winA&&m.complete, 'a')}
    ${teamRow(tB, m.scoreB, winB, !winB&&m.complete, 'b')}
    ${footer}
  </div>`;
}

function renderBracketTree() {
  const wrap = document.getElementById('po-bracket-tree');
  const rounds = playoffState.rounds;
  if(!rounds.length) { wrap.innerHTML=''; return; }

  const cols = rounds.map(r => {
    const slots = r.matches.map(m => {
      const teamLabel = (t) => !t ? 'TBD' : t.label ? t.label : (Array.isArray(t.players) ? t.players.map(pi=>state.players[pi]?.name.split(' ')[0]).join(' & ') : 'TBD');
      const ta = teamLabel(m.teamA);
      const tb = teamLabel(m.teamB);
      const isFinal = r.stageKey === 'f';
      const winnerA = m.complete && m.scoreA > m.scoreB;
      const winnerB = m.complete && m.scoreB > m.scoreA;
      return `<div class="bracket-slot ${isFinal?'final-slot':''}">
        <div class="bracket-team ${!m.teamA?'tbd':''} ${winnerA?'winner':''}">
          <span>${ta}</span>
          ${m.complete?`<span class="bracket-score">${m.scoreA}</span>`:''}
        </div>
        <div class="bracket-team ${!m.teamB?'tbd':''} ${winnerB?'winner':''}">
          <span>${tb}</span>
          ${m.complete?`<span class="bracket-score">${m.scoreB}</span>`:''}
        </div>
      </div>`;
    }).join('');
    return `<div class="bracket-round-col">
      <div class="bracket-round-title">${r.name}</div>
      ${slots}
    </div>`;
  }).join('');

  // Champion slot
  const champSlot = playoffState.champion
    ? `<div class="bracket-round-col">
        <div class="bracket-round-title" style="color:var(--ball)">🏆 Champion</div>
        <div class="bracket-slot final-slot">
          <div class="bracket-team winner">
            <span>${playoffState.champion.players.map(pi=>state.players[pi]?.name.split(' ')[0]).join(' & ')}</span>
          </div>
        </div>
      </div>`
    : '';

  wrap.innerHTML = `<div class="bracket-wrap">${cols}${champSlot}</div>`;
}



// Build per-player game log from schedule
function buildPlayerStats() {
  if(!state.players.length) return [];

  // Per-player accumulator keyed by player index
  const statsMap = {};
  state.players.forEach((p, pi) => {
    statsMap[pi] = {
      player: p,
      playerIdx: pi,
      games: [],
    };
  });

  const completedMatches = state.schedule.flat().filter(m => m.complete);

  completedMatches.forEach(m => {
    // teamA players
    m.teamA.forEach(pi => {
      if(statsMap[pi] === undefined) return;
      const partnerIdx = m.teamA.find(x => x !== pi);
      statsMap[pi].games.push({
        matchId: m.id,
        round: m.round,
        court: m.court,
        pts: m.scoreA,
        opponentPts: m.scoreB,
        won: m.scoreA > m.scoreB,
        tied: m.scoreA === m.scoreB,
        partnerIdx,
        opponentIdxs: m.teamB,
      });
    });
    // teamB players
    m.teamB.forEach(pi => {
      if(statsMap[pi] === undefined) return;
      const partnerIdx = m.teamB.find(x => x !== pi);
      statsMap[pi].games.push({
        matchId: m.id,
        round: m.round,
        court: m.court,
        pts: m.scoreB,
        opponentPts: m.scoreA,
        won: m.scoreB > m.scoreA,
        tied: m.scoreA === m.scoreB,
        partnerIdx,
        opponentIdxs: m.teamA,
      });
    });
  });

  return Object.values(statsMap).map(s => {
    const g = s.games;
    const totalPts    = g.reduce((a, x) => a + x.pts, 0);
    const totalConced = g.reduce((a, x) => a + x.opponentPts, 0);
    const diff        = totalPts - totalConced;
    const gamesPlayed = g.length;
    const wins   = g.filter(x => x.won).length;
    const losses = g.filter(x => !x.won && !x.tied).length;
    const best   = g.length ? Math.max(...g.map(x => x.pts)) : 0;
    const worst  = g.length ? Math.min(...g.map(x => x.pts)) : 0;
    const avg    = gamesPlayed ? totalPts / gamesPlayed : 0;

    // Momentum: compare last-3 avg vs overall avg → arrow
    let momentum = '→';
    if(g.length >= 4) {
      const last3avg = g.slice(-3).reduce((a,x) => a + x.pts, 0) / 3;
      const rest     = g.slice(0, -3);
      const restAvg  = rest.reduce((a,x) => a + x.pts, 0) / rest.length;
      if(last3avg > restAvg + 0.8)       momentum = '↑';
      else if(last3avg < restAvg - 0.8)  momentum = '↓';
    }

    // Nemesis: opponent faced 2+ times with worst win rate
    const oppRecord = {};
    g.forEach(game => {
      game.opponentIdxs.forEach(oi => {
        if(!oppRecord[oi]) oppRecord[oi] = { wins: 0, games: 0 };
        oppRecord[oi].games++;
        if(game.won) oppRecord[oi].wins++;
      });
    });
    let nemesisIdx = null, nemesisWinRate = 1;
    Object.entries(oppRecord).forEach(([oi, rec]) => {
      if(rec.games >= 2) {
        const wr = rec.wins / rec.games;
        if(wr < nemesisWinRate) { nemesisWinRate = wr; nemesisIdx = parseInt(oi); }
      }
    });

    // Favourite partner: partner played with 2+ times with best win rate
    const partnerRecord = {};
    g.forEach(game => {
      const pi = game.partnerIdx;
      if(pi === undefined || pi === null) return;
      if(!partnerRecord[pi]) partnerRecord[pi] = { wins: 0, games: 0 };
      partnerRecord[pi].games++;
      if(game.won) partnerRecord[pi].wins++;
    });
    let favPartnerIdx = null, favPartnerWinRate = -1;
    Object.entries(partnerRecord).forEach(([pi, rec]) => {
      if(rec.games >= 2) {
        const wr = rec.wins / rec.games;
        if(wr > favPartnerWinRate) { favPartnerWinRate = wr; favPartnerIdx = parseInt(pi); }
      }
    });

    return { ...s, totalPts, totalConced, diff, gamesPlayed, wins, losses, best, worst, avg,
             momentum, nemesisIdx, nemesisWinRate, favPartnerIdx, favPartnerWinRate };
  });
}

var _selectedPlayerId = null;

function renderPlayerStats() {
  const data = buildPlayerStats();
  const search = (document.getElementById('ps-search')?.value || '').toLowerCase();
  const sortBy = document.getElementById('ps-sort')?.value || 'pts';

  // Update header stats
  const active = data.filter(d => d.gamesPlayed > 0);
  const totalGames = state.schedule.flat().filter(m=>m.complete).length;
  document.getElementById('ps-stat-players').textContent = active.length;
  document.getElementById('ps-stat-games').textContent = totalGames;

  if(active.length) {
    const leader = active.reduce((a,b) => b.totalPts > a.totalPts ? b : a);
    const avgLeader = active.reduce((a,b) => b.avg > a.avg ? b : a);
    document.getElementById('ps-stat-top-pts').textContent = leader.totalPts;
    document.getElementById('ps-stat-top-avg').textContent = avgLeader.avg.toFixed(1);
    document.getElementById('ps-stat-top-name').textContent = leader.player.name.split(' ')[0];
  } else {
    document.getElementById('ps-stat-top-pts').textContent = '—';
    document.getElementById('ps-stat-top-avg').textContent = '—';
    document.getElementById('ps-stat-top-name').textContent = '—';
  }

  const psGender   = document.getElementById('ps-gender')?.value    || '';
  const psCR       = document.getElementById('ps-cr')?.value        || '';
  const psPod      = document.getElementById('ps-pod')?.value       || '';
  const psMinGames = parseInt(document.getElementById('ps-min-games')?.value || '0');

  // Pod filter: determine which player indices are in the selected pod
  const psPodSet = psPod
    ? new Set(state.schedule.flat().filter(m => m.podLabel === psPod).flatMap(m => [...m.teamA, ...m.teamB]))
    : null;

  // Filter
  let filtered = data.filter(d => {
    if(!d.player.name.toLowerCase().includes(search)) return false;
    if(psGender && d.player.gender !== psGender) return false;
    if(psCR && String(d.player.clubRating || '').trim() !== psCR) return false;
    if(psPodSet && !psPodSet.has(d.playerIdx)) return false;
    if(psMinGames > 0 && d.gamesPlayed < psMinGames) return false;
    return true;
  });

  // Sort
  filtered.sort((a, b) => {
    if(sortBy === 'pts')   return b.totalPts - a.totalPts;
    if(sortBy === 'avg')   return b.avg - a.avg;
    if(sortBy === 'diff')  return b.diff - a.diff;
    if(sortBy === 'games') return b.gamesPlayed - a.gamesPlayed;
    if(sortBy === 'wins')  return b.wins - a.wins;
    if(sortBy === 'name')  return a.player.name.localeCompare(b.player.name);
    if(sortBy === 'dupr')  return (b.player.dupr ?? -1) - (a.player.dupr ?? -1);
    return 0;
  });

  // Filter summary
  const summaryEl = document.getElementById('ps-filter-summary');
  if(summaryEl) {
    const filtersActive = search || psGender || psCR || psPod || psMinGames > 0;
    summaryEl.textContent = filtersActive
      ? `Showing ${filtered.length} of ${data.length} player${data.length !== 1 ? 's' : ''}`
      : '';
  }

  const maxPts = Math.max(...filtered.map(d => d.totalPts), 1);
  const tbody = document.getElementById('ps-body');

  if(!filtered.length) {
    const msg = data.length > 0 ? 'No players match the current filters.' : 'No stats yet — enter match scores first';
    tbody.innerHTML = `<tr><td colspan="15"><div class="empty-state"><div class="big">📊</div>${msg}</div></td></tr>`;
    document.getElementById('ps-detail-card').style.display = 'none';
    return;
  }

  tbody.innerHTML = filtered.map((d, rank) => {
    const rankStr = rank === 0 ? '🥇' : rank === 1 ? '🥈' : rank === 2 ? '🥉' : rank + 1;

    // Find this round's partner from the last game played
    const lastGame = d.games[d.games.length - 1];
    const lastPartner = lastGame !== undefined && lastGame.partnerIdx !== undefined
      ? state.players[lastGame.partnerIdx]?.name.split(' ')[0] || '—'
      : '—';

    // Sparkbar — one bar per game (height proportional to points scored)
    const allGamePts = d.games.map(g => g.pts);
    const maxG = Math.max(...allGamePts, 1);
    const spark = d.games.map((g, gi) => {
      const h = Math.max(4, Math.round((g.pts / maxG) * 22));
      const col = g.won ? '#C6FF00' : g.tied ? '#F9A825' : '#EF5350';
      return `<div class="sparkbar-bar" style="height:${h}px;background:${col}" title="Game ${gi+1}: ${g.pts} pts ${g.won?'✓':'✗'}"></div>`;
    }).join('');

    // W/L streak display (last 10)
    const last10 = d.games.slice(-10);
    const wlStr = last10.map(g =>
      `<span class="win-char ${g.won?'w':g.tied?'':'l'}">${g.won?'W':g.tied?'T':'L'}</span>`
    ).join('');

    // Momentum arrow styling
    const momColor = d.momentum === '↑' ? 'var(--lime)' : d.momentum === '↓' ? 'var(--red)' : d.games.length < 4 ? 'var(--txt3)' : 'var(--txt3)';
    const momDisplay = d.games.length < 4 ? '—' : d.momentum;
    const momTitle = d.momentum === '↑' ? 'Trending up (last 3 games above average)'
                   : d.momentum === '↓' ? 'Trending down (last 3 games below average)'
                   : d.games.length < 4 ? 'Need 4+ games for trend' : 'Steady (last 3 games near average)';

    // +/- diff styling
    const diffStr  = d.diff > 0 ? '+' + d.diff : String(d.diff);
    const diffColor = d.diff > 0 ? 'var(--lime)' : d.diff < 0 ? 'var(--red)' : 'var(--txt3)';

    // Nemesis
    const nemesisName = d.nemesisIdx !== null
      ? (state.players[d.nemesisIdx]?.name.split(' ')[0] || '?') +
        ` <span style="font-size:0.68rem;color:var(--txt3)">(${Math.round(d.nemesisWinRate*100)}%)</span>`
      : '<span style="color:var(--txt3)">—</span>';

    // Favourite partner
    const favName = d.favPartnerIdx !== null
      ? (state.players[d.favPartnerIdx]?.name.split(' ')[0] || '?') +
        ` <span style="font-size:0.68rem;color:var(--lime)">(${Math.round(d.favPartnerWinRate*100)}%)</span>`
      : '<span style="color:var(--txt3)">—</span>';

    const selected = d.player.id === _selectedPlayerId ? 'selected' : '';

    return `<tr class="ps-row ${selected}" onclick="selectPlayer(${d.player.id})">
      <td style="font-family:'Bebas Neue',sans-serif;font-size:1.2rem">${rankStr}</td>
      <td style="font-weight:700">${d.player.name}</td>
      <td><span class="badge badge-${d.player.gender.toLowerCase()}">${d.player.gender}</span></td>
      <td style="color:var(--txt3);font-size:0.78rem">last w/ <span style="color:var(--lime)">${lastPartner}</span></td>
      <td style="font-family:'JetBrains Mono',monospace">${d.gamesPlayed}</td>
      <td style="font-family:'Bebas Neue',sans-serif;font-size:1.4rem;color:var(--ball)">${d.totalPts}</td>
      <td style="font-family:'JetBrains Mono',monospace;font-weight:700;color:${diffColor}">${diffStr}</td>
      <td style="font-family:'JetBrains Mono',monospace;color:${d.avg>=10?'var(--lime)':'var(--txt)'}">${d.avg.toFixed(1)}</td>
      <td style="color:var(--txt3);font-family:'JetBrains Mono',monospace">${d.best}</td>
      <td style="color:var(--red);font-family:'JetBrains Mono',monospace">${d.worst !== Infinity ? d.worst : '—'}</td>
      <td style="font-size:1.1rem;color:${momColor};font-weight:700" title="${momTitle}">${momDisplay}</td>
      <td style="font-size:0.82rem;color:var(--red)">😈 ${nemesisName}</td>
      <td style="font-size:0.82rem;color:var(--lime)">🤝 ${favName}</td>
      <td class="win-loss">${wlStr || '<span style="color:var(--txt3)">—</span>'}</td>
      <td><div class="sparkbar">${spark || '<span style="color:var(--txt3);font-size:0.75rem">no games</span>'}</div></td>
    </tr>`;
  }).join('');

  // If someone was selected, re-show their detail
  if(_selectedPlayerId) {
    const d = data.find(d => d.player.id === _selectedPlayerId);
    if(d) showPlayerDetail(d);
  }
}

function selectPlayer(playerId) {
  _selectedPlayerId = (_selectedPlayerId === playerId) ? null : playerId;
  if(_selectedPlayerId) {
    const data = buildPlayerStats();
    const d = data.find(d => d.player.id === playerId);
    if(d) showPlayerDetail(d);
  } else {
    document.getElementById('ps-detail-card').style.display = 'none';
  }
  renderPlayerStats();
}

function showPlayerDetail(d) {
  const card = document.getElementById('ps-detail-card');
  card.style.display = 'block';
  document.getElementById('ps-detail-title').textContent =
    `📋 ${d.player.name} — Game-by-Game Log (${d.gamesPlayed} games, ${d.totalPts} total pts)`;

  const tbody = document.getElementById('ps-detail-body');
  if(!d.games.length) {
    tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No completed games yet</td></tr>';
    renderSparkChart([], d.player.name);
    return;
  }

  let cumPts = 0;
  tbody.innerHTML = d.games.map((g, gi) => {
    cumPts += g.pts;
    const partner = g.partnerIdx !== undefined ? state.players[g.partnerIdx] : null;
    const partnerName = partner ? partner.name : '—';
    const oppNames = g.opponentIdxs
      ? g.opponentIdxs.map(i => state.players[i]?.name.split(' ')[0] || '?').join(' & ')
      : '—';
    const resultColor = g.won ? 'var(--lime)' : g.tied ? 'var(--ball)' : 'var(--red)';
    const resultTxt = g.won ? '✓ WIN' : g.tied ? '≈ TIE' : '✗ LOSS';
    return `<tr>
      <td style="font-family:'JetBrains Mono';color:var(--txt3)">G${gi+1}</td>
      <td>R${g.round}</td>
      <td><span style="background:var(--court2);color:var(--lime);padding:1px 6px;border-radius:4px;font-size:0.75rem">🏟 ${g.court}</span></td>
      <td style="font-size:0.82rem;color:var(--txt2)">${partnerName}</td>
      <td style="font-size:0.78rem;color:var(--txt3)">${oppNames}</td>
      <td style="font-family:'Bebas Neue';font-size:1.2rem;color:var(--ball)">${g.pts}</td>
      <td style="font-family:'JetBrains Mono';color:var(--txt3)">${g.opponentPts}</td>
      <td style="font-weight:700;color:${resultColor}">${resultTxt}</td>
      <td>
        <span style="font-family:'Bebas Neue';font-size:1.1rem;color:var(--lime)">${g.pts}</span>
        <span style="font-size:0.72rem;color:var(--txt3);margin-left:4px">(cum: ${cumPts})</span>
      </td>
    </tr>`;
  }).join('');

  renderSparkChart(d.games, d.player.name);
  card.scrollIntoView({behavior:'smooth', block:'start'});
}

function populateH2HDropdowns() {
  const players = state.players.filter(p => p.name);
  ['h2h-player-a','h2h-player-b'].forEach(id => {
    const sel = document.getElementById(id);
    if(!sel) return;
    const cur = sel.value;
    sel.innerHTML = `<option value="">Player…</option>` +
      players.map((p,i) => `<option value="${i}" ${String(i)===cur?'selected':''}>${escHtml(p.name)}</option>`).join('');
  });
}

function renderH2H() {
  const el = document.getElementById('h2h-body');
  if(!el) return;
  const aIdx = parseInt(document.getElementById('h2h-player-a')?.value);
  const bIdx = parseInt(document.getElementById('h2h-player-b')?.value);
  if(isNaN(aIdx) || isNaN(bIdx) || aIdx === bIdx) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.85rem;padding:1rem 0">Select two different players to see their rivalry record.</div>';
    return;
  }
  const pA = state.players[aIdx], pB = state.players[bIdx];
  if(!pA || !pB) return;

  const completed = state.schedule.flat().filter(m => m.complete);
  // Matches where A and B were opponents
  const asOpponents = completed.filter(m => {
    const inA = m.teamA.includes(aIdx), inB = m.teamB.includes(aIdx);
    const inOA = m.teamA.includes(bIdx), inOB = m.teamB.includes(bIdx);
    return (inA && inOB) || (inB && inOA);
  });
  // Matches where A and B were partners
  const asPartners = completed.filter(m =>
    (m.teamA.includes(aIdx) && m.teamA.includes(bIdx)) ||
    (m.teamB.includes(aIdx) && m.teamB.includes(bIdx))
  );

  if(!asOpponents.length && !asPartners.length) {
    el.innerHTML = `<div style="color:var(--txt3);font-size:0.85rem;padding:1rem 0">${escHtml(pA.name)} and ${escHtml(pB.name)} haven't met yet.</div>`;
    return;
  }

  // H2H as opponents
  let aWins = 0, bWins = 0, ties = 0, aPts = 0, bPts = 0;
  const matchRows = asOpponents.map(m => {
    const aOnTeamA = m.teamA.includes(aIdx);
    const aScore = aOnTeamA ? m.scoreA : m.scoreB;
    const bScore = aOnTeamA ? m.scoreB : m.scoreA;
    const aWon = aScore > bScore, bWon = bScore > aScore;
    if(aWon) aWins++; else if(bWon) bWins++; else ties++;
    aPts += Number(aScore); bPts += Number(bScore);
    const aPartner = (aOnTeamA ? m.teamA : m.teamB).find(i => i !== aIdx);
    const bPartner = (aOnTeamA ? m.teamB : m.teamA).find(i => i !== bIdx);
    const result = aWon ? `<span style="color:var(--lime);font-weight:700">${pA.name.split(' ')[0]} wins</span>` :
                   bWon ? `<span style="color:var(--red);font-weight:700">${pB.name.split(' ')[0]} wins</span>` :
                   `<span style="color:var(--ball)">Tie</span>`;
    return `<tr>
      <td>R${m.round}</td>
      <td><span style="background:var(--court2);color:var(--lime);padding:1px 6px;border-radius:4px;font-size:0.75rem">🏟 ${m.court}</span></td>
      <td style="font-size:0.8rem;color:var(--txt2)">${escHtml(state.players[aPartner]?.name.split(' ')[0] || '—')}</td>
      <td style="font-family:'Bebas Neue';font-size:1.25rem;color:${aWon?'var(--lime)':aScore===bScore?'var(--ball)':'var(--red)'}">${aScore}</td>
      <td style="font-family:'Bebas Neue';font-size:1.25rem;color:${bWon?'var(--lime)':aScore===bScore?'var(--ball)':'var(--red)'}">${bScore}</td>
      <td style="font-size:0.8rem;color:var(--txt2)">${escHtml(state.players[bPartner]?.name.split(' ')[0] || '—')}</td>
      <td>${result}</td>
    </tr>`;
  }).join('');

  const leader = aWins > bWins ? pA.name : bWins > aWins ? pB.name : null;
  const trophyA = aWins > bWins ? '🏆 ' : '';
  const trophyB = bWins > aWins ? '🏆 ' : '';

  const partnerSection = asPartners.length ? (() => {
    let pwWins = 0, pwTotal = asPartners.length;
    asPartners.forEach(m => {
      const onA = m.teamA.includes(aIdx);
      const won = onA ? m.scoreA > m.scoreB : m.scoreB > m.scoreA;
      if(won) pwWins++;
    });
    return `<div style="margin-top:1rem;padding:0.75rem;background:rgba(198,255,0,0.05);border:1px solid rgba(198,255,0,0.15);border-radius:8px;font-size:0.85rem">
      🤝 <strong>As partners:</strong> ${pwWins}W–${pwTotal-pwWins}L in ${pwTotal} match${pwTotal!==1?'es':''}
      (${Math.round(pwWins/pwTotal*100)}% win rate)
    </div>`;
  })() : '';

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:1rem;align-items:center;margin-bottom:1.25rem">
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-family:'Bebas Neue';color:${aWins>bWins?'var(--lime)':'var(--txt)'}">${trophyA}${aWins}</div>
        <div style="font-size:0.85rem;color:var(--txt2)">${escHtml(pA.name)}</div>
        <div style="font-size:0.75rem;color:var(--txt3)">${aPts} pts</div>
      </div>
      <div style="text-align:center">
        <div style="font-family:'Bebas Neue';font-size:1rem;color:var(--txt3)">${ties>0?`${ties} TIE${ties>1?'S':''}`:'HEAD TO HEAD'}</div>
        <div style="font-size:0.75rem;color:var(--txt3)">${asOpponents.length} match${asOpponents.length!==1?'es':''}</div>
        ${leader ? `<div style="font-size:0.72rem;margin-top:4px;color:var(--lime)">👑 ${leader.split(' ')[0]} leads</div>` : '<div style="font-size:0.72rem;color:var(--ball)">All square</div>'}
      </div>
      <div style="text-align:center">
        <div style="font-size:1.8rem;font-family:'Bebas Neue';color:${bWins>aWins?'var(--lime)':'var(--txt)'}">${trophyB}${bWins}</div>
        <div style="font-size:0.85rem;color:var(--txt2)">${escHtml(pB.name)}</div>
        <div style="font-size:0.75rem;color:var(--txt3)">${bPts} pts</div>
      </div>
    </div>
    ${asOpponents.length ? `<div class="tbl-wrap"><table>
      <thead><tr>
        <th>Round</th><th>Court</th>
        <th style="font-size:0.78rem">${escHtml(pA.name.split(' ')[0])} partner</th>
        <th style="color:var(--lime)">${escHtml(pA.name.split(' ')[0])}</th>
        <th style="color:var(--lime)">${escHtml(pB.name.split(' ')[0])}</th>
        <th style="font-size:0.78rem">${escHtml(pB.name.split(' ')[0])} partner</th>
        <th>Result</th>
      </tr></thead>
      <tbody>${matchRows}</tbody>
    </table></div>` : ''}
    ${partnerSection}
  `;
}

function renderSparkChart(games, playerName) {
  const canvas = document.getElementById('ps-chart');
  const ctx = canvas.getContext('2d');
  const W = canvas.offsetWidth || 800;
  const H = canvas.offsetHeight || 120;
  canvas.width = W;
  canvas.height = H;
  ctx.clearRect(0, 0, W, H);

  if(!games.length) return;

  const pts = games.map(g => g.pts);
  const cumulativePts = [];
  let cum = 0;
  games.forEach(g => { cum += g.pts; cumulativePts.push(cum); });

  const maxPts = Math.max(...pts, 1);
  const maxCum = Math.max(...cumulativePts, 1);
  const n = games.length;
  const pad = { t: 16, b: 24, l: 36, r: 16 };
  const chartW = W - pad.l - pad.r;
  const chartH = H - pad.t - pad.b;

  // Grid lines
  ctx.strokeStyle = '#2E3D2E';
  ctx.lineWidth = 1;
  [0, 0.25, 0.5, 0.75, 1].forEach(f => {
    const y = pad.t + chartH * (1 - f);
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W-pad.r, y);
    ctx.stroke();
  });

  // Bar chart (pts per game)
  const barW = Math.max(4, (chartW / n) * 0.6);
  games.forEach((g, i) => {
    const x = pad.l + (i / (n-1||1)) * chartW;
    const bH = (g.pts / maxPts) * chartH;
    const y = pad.t + chartH - bH;
    ctx.fillStyle = g.won ? 'rgba(198,255,0,0.35)' : g.tied ? 'rgba(249,168,37,0.35)' : 'rgba(239,83,80,0.25)';
    ctx.fillRect(x - barW/2, y, barW, bH);
  });

  // Cumulative line
  ctx.beginPath();
  ctx.strokeStyle = '#C6FF00';
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  cumulativePts.forEach((cp, i) => {
    const x = pad.l + (i / (n-1||1)) * chartW;
    const y = pad.t + chartH * (1 - cp/maxCum);
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Dots on line
  cumulativePts.forEach((cp, i) => {
    const x = pad.l + (i / (n-1||1)) * chartW;
    const y = pad.t + chartH * (1 - cp/maxCum);
    ctx.beginPath();
    ctx.arc(x, y, 3.5, 0, Math.PI*2);
    ctx.fillStyle = '#C6FF00';
    ctx.fill();
  });

  // Axis labels
  ctx.fillStyle = '#66BB6A';
  ctx.font = '11px JetBrains Mono, monospace';
  ctx.textAlign = 'center';
  games.forEach((_, i) => {
    if(n <= 20 || i % Math.ceil(n/20) === 0) {
      const x = pad.l + (i / (n-1||1)) * chartW;
      ctx.fillText(`G${i+1}`, x, H - 4);
    }
  });
  ctx.textAlign = 'right';
  ctx.fillText(maxPts, pad.l - 4, pad.t + 4);
  ctx.fillText(0, pad.l - 4, pad.t + chartH);

  // Legend
  ctx.textAlign = 'left';
  ctx.fillStyle = '#C6FF00';
  ctx.fillText('── Cumulative pts', pad.l, 12);
  ctx.fillStyle = '#66BB6A';
  ctx.fillText('  ▌ Per-game', pad.l + 140, 12);
}

function exportPlayerStatsCSV() {
  const data = buildPlayerStats();
  if(!data.length) { toast("No stats to export","err"); return; }
  const rows = [[getTournamentName()],['Player','Gender','ClubRating','GamesPlayed','TotalPoints','AvgPtsPerGame','BestGame','WorstGame','Wins','Losses']];
  data.sort((a,b)=>b.totalPts-a.totalPts).forEach(d => {
    rows.push([d.player.name, d.player.gender, d.player.clubRating||'',
      d.gamesPlayed, d.totalPts, d.avg.toFixed(2), d.best, d.worst, d.wins, d.losses]);
  });
  // Also add per-game rows
  rows.push([]);
  rows.push(['--- PER GAME BREAKDOWN ---']);
  rows.push(['Player','Game#','Round','Court','Points','OppPoints','Result','CumulativePts']);
  data.forEach(d => {
    let cum = 0;
    d.games.forEach((g,gi) => {
      cum += g.pts;
      rows.push([d.player.name, gi+1, g.round, g.court, g.pts, g.opponentPts,
        g.won?'WIN':g.tied?'TIE':'LOSS', cum]);
    });
  });
  downloadCSV(rows, `${getTournamentName().replace(/[^a-zA-Z0-9]/g,'_')}_player_stats.csv`);
  toast("Player stats exported!");
}


function shuffle(arr) {
  for(let i=arr.length-1;i>0;i--) {
    const j = Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]] = [arr[j],arr[i]];
  }
}

function toast(msg, type='ok') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.style.background = type==='err' ? 'var(--red)' : 'var(--lime)';
  el.style.color = type==='err' ? '#fff' : '#000';
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2800);
}

function downloadCSV(rows, filename) {
  const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = filename;
  a.click();
}

// ═══════════════════════════════════════════════

// ── Storage, save/load, history, backup, undo, report ──────
//  SAVE / LOAD / RESET
// ═══════════════════════════════════════════════
function saveTournament() {
  const data = buildSaveData();
  const name = `${getTournamentName().replace(/[^a-zA-Z0-9]/g,'_')}_${new Date().toISOString().slice(0,10)}.json`;
  const a = document.createElement('a');
  a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
  a.download = name;
  a.click();
  toast(`💾 Saved as ${name}`);
}

function loadTournament(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if(!data.state) throw new Error('Invalid file');

      restoreSaveData(data);

      // Re-render everything
      renderPlayers();
      renderTeams();
      renderSchedule();
      renderCourtsGrid();
      updateCourtSelectorUI();
      updateProgress();
      renderStandings();
      renderPlayoffs();
      onModeChange();
      showUndoButton();
      if(riverState.enabled) renderRiverBoard();

      toast(`📂 Tournament loaded: ${state.players.length} players, ${state.schedule.flat().length} matches`);
    } catch(err) {
      toast('❌ Could not load file: ' + err.message, 'err');
    }
  };
  reader.readAsText(file);
  event.target.value = '';
}

// Shows the Reset Tournament modal, offering "keep completed games" when
// there's anything worth keeping, or a single confirm path when there isn't.
// ── Logout ────────────────────────────────────────────────────────────
// Sends the browser through Cloudflare Access's own logout endpoint,
// which clears the Access session cookie (the thing that's actually
// keeping this person logged in — there's no separate "this app's own"
// session to clear). returnTo brings them back to this app's root after,
// where the next request has no valid session and Access naturally shows
// the login challenge (email + one-time PIN) again. No tournament data is
// at risk here — the schedule/players/scores already autosave to this
// browser's localStorage independently of the Access login, so logging
// out and back in picks up right where things were left.
function logoutFromApp() {
  if (!confirm("Log out? You'll need to sign back in with your email to use the app again. Your tournament data is saved on this device and will still be here.")) return;
  const returnTo = window.location.origin + '/';
  window.location.href = '/cdn-cgi/access/logout?returnTo=' + encodeURIComponent(returnTo);
}

function promptResetTournament() {
  const allMatches    = state.schedule.flat();
  const playedMatches = allMatches.filter(m => m.complete).length;
  const hasSchedule   = state.schedule.length > 0;

  const body    = document.getElementById('reset-tournament-modal-body');
  const keepBtn = document.getElementById('reset-tournament-keep-btn');
  const fullBtn = document.getElementById('reset-tournament-full-btn');

  if(playedMatches > 0) {
    // ── Completed games exist: offer both paths ──────────────────────
    let completedRounds = 0;
    state.schedule.forEach(round => { if(round.length && round.every(m => m.complete)) completedRounds++; });
    const pendingMatches = allMatches.length - playedMatches;

    let html = '';
    html += `<div style="background:rgba(198,255,0,0.06);border:1px solid rgba(198,255,0,0.25);border-radius:8px;padding:0.75rem 1rem;margin-bottom:0.75rem">`;
    html += `<div style="font-size:0.82rem;font-weight:700;color:var(--lime);margin-bottom:0.35rem">🔁 Option A — Keep completed games, reset the rest</div>`;
    html += `<div style="font-size:0.8rem;color:var(--txt2);line-height:1.6">`;
    html += `• <strong style="color:var(--lime)">${completedRounds} completed round${completedRounds !== 1 ? 's' : ''} and ${playedMatches} score${playedMatches !== 1 ? 's' : ''} are kept.</strong><br>`;
    html += `• ${pendingMatches} unfinished match${pendingMatches !== 1 ? 'es' : ''} will be replaced with a fresh schedule for the remaining rounds.<br>`;
    html += `• Player roster, standings, and stats for completed rounds stay intact.`;
    html += `</div></div>`;

    html += `<div style="background:rgba(239,83,80,0.06);border:1px solid rgba(239,83,80,0.3);border-radius:8px;padding:0.75rem 1rem">`;
    html += `<div style="font-size:0.82rem;font-weight:700;color:var(--red);margin-bottom:0.35rem">⚡ Option B — Reset everything</div>`;
    html += `<div style="font-size:0.8rem;color:var(--txt2);line-height:1.6">`;
    html += `• <strong style="color:var(--red)">${playedMatches} completed match${playedMatches !== 1 ? 'es' : ''} and all scores will be permanently erased.</strong><br>`;
    html += `• Schedule, teams, and standings reset to zero.<br>`;
    html += `• Your player roster stays — this starts a brand new tournament with the same players.`;
    html += `</div></div>`;

    body.innerHTML = html;
    keepBtn.style.display = '';
    fullBtn.textContent = '⚡ Erase all & reset';
  } else {
    // ── Nothing completed yet: single straightforward confirmation ───
    let lines = [];
    if(hasSchedule) lines.push(`📋 The current schedule will be cleared.`);
    lines.push(`👥 Your player roster stays.`);
    lines.push(`<span style="color:var(--lime)">✓ No scores entered yet — safe to reset.</span>`);
    body.innerHTML = lines.map(l => `<div style="margin-bottom:0.3rem">• ${l}</div>`).join('');
    keepBtn.style.display = 'none';
    fullBtn.textContent = '⚡ Yes, reset';
  }

  const modal = document.getElementById('reset-tournament-modal');
  modal.style.display = 'flex';
  modal.onclick = (e) => { if(e.target === modal) closeResetTournamentModal(); };
}

function closeResetTournamentModal() {
  document.getElementById('reset-tournament-modal').style.display = 'none';
}

// Option A: preserve completed/started rounds, regenerate only what's left.
// Reuses the same proven path as the Schedule tab's "Keep scores" option,
// without touching roster, waitlist, or any of the full-reset's setup-level
// changes (Left-player status, court selection, etc).
function confirmResetKeepCompleted() {
  closeResetTournamentModal();
  if(!state.schedule.length) { toast('No schedule to keep — nothing to regenerate', 'err'); return; }
  regenerateRemaining();
  toast('🔁 Completed games kept — remaining rounds regenerated');
}

// Option B: the original full wipe.
function confirmResetFull() {
  closeResetTournamentModal();
  resetTournamentFull();
}

function resetTournamentFull() {
  // Clear tournament-specific state, but keep state.players (roster, ratings, phone, email).
  state.teams        = [];
  state.roundTeams   = [];
  state.schedule     = [];
  state.roundHistory = [];
  state.byeRounds      = [];
  state.notifiedRounds = new Set();
  state.startedRounds  = new Set();
  state.selectedCourts = new Set(Array.from({length:MAX_COURTS},(_,i)=>i+1));
  state._skippedPods = [];
  // Anyone marked Left rejoins the active roster for the new tournament
  state.players.forEach(p => { delete p.active; });
  state.waitlist = [];
  riverState.enabled = false;
  playoffState.active = false;
  clearAutoSave(); // clear persisted session so it's not offered again after reset
  _undoStack.length = 0; // clear undo history
  try { localStorage.removeItem(UNDO_STORE_KEY); } catch(e) {}
  const tnEl = document.getElementById('tournament-name'); if(tnEl) tnEl.value = '';
  const tdEl = document.getElementById('tournament-datetime'); if(tdEl) tdEl.value = '';
  updateTournamentName();
  try { sessionStorage.removeItem('pb_skillgap_dismissed'); } catch(e) {}
  document.title = '🏓 Pickleball Tournament Manager';
  renderPlayers();
  renderTeams();
  renderSchedule();
  renderCourtsGrid();
  updateCourtSelectorUI();
  updateProgress();
  renderStandings();
  document.getElementById('king-board').style.display = 'none';
  document.getElementById('po-bracket-wrap').style.display = 'none';
  onModeChange();
  pauseTimer();
  resetTimer();
  toast('↺ Tournament reset — players kept, ready for a new schedule');
}

// ═══════════════════════════════════════════════
//  PRINT
// ═══════════════════════════════════════════════
function printSchedule() {
  // Inject tournament name as print-only header
  const name = getTournamentName();
  const printHeader = document.createElement('div');
  printHeader.id = '_print_header';
  printHeader.style.cssText = 'display:none;font-family:sans-serif;padding:1rem 0 0.5rem;border-bottom:2px solid #1B5E20;margin-bottom:1rem';
  printHeader.innerHTML = `<h1 style="font-size:1.6rem;margin:0">${name}</h1><div style="font-size:0.85rem;color:#555">Printed ${new Date().toLocaleDateString()}</div>`;
  document.body.insertBefore(printHeader, document.body.firstChild);
  // Record which tab is currently active
  const activeSection = document.querySelector('.section.active');
  const activeBtnText = document.querySelector('.tab-btn.active')?.textContent;
  // Temporarily show all sections for print
  document.querySelectorAll('.section').forEach(s => s.classList.add('active'));
  // Use afterprint event to cleanly restore state
  const restore = () => {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    if(activeSection) activeSection.classList.add('active');
    const ph = document.getElementById('_print_header'); if(ph) ph.remove();
    window.removeEventListener('afterprint', restore);
  };
  window.addEventListener('afterprint', restore);
  window.print();
  // Fallback for browsers that skip afterprint (fire only if not already restored)
  setTimeout(() => { if(document.querySelector('.section.active') === null) restore(); }, 800);
}

// ═══════════════════════════════════════════════
//  MATCH TIMER
// ═══════════════════════════════════════════════
var _timerInterval = null;
var _timerSeconds  = 11 * 60;
var _timerRunning  = false;
var _timerStartedAt      = null;
var _timerSecondsAtStart = 0;
var _timerRafId          = null;
var _timerAlerted2min    = false;
var _timerAlertedEnd     = false;

function getTimerMinutes() {
  return parseInt(document.getElementById('timer-minutes')?.value || '11');
}

// ── Rounds-from-time calculator ─────────────────────────────────────────
function toggleRoundsCalc() {
  const panel = document.getElementById('rounds-calc-panel');
  if(!panel) return;
  const opening = panel.style.display === 'none';
  panel.style.display = opening ? 'block' : 'none';
  if(opening) {
    // Pre-fill round length from the existing round timer, so the two stay
    // in sync by default rather than asking the person to re-enter it.
    const timerMins = document.getElementById('timer-minutes')?.value;
    if(timerMins) document.getElementById('rc-round-mins').value = timerMins;
    updateRoundsCalc();
  }
}

function _roundsCalcCompute() {
  const hours   = parseFloat(document.getElementById('rc-hours')?.value) || 0;
  const mins    = parseFloat(document.getElementById('rc-mins')?.value) || 0;
  const roundMin  = parseFloat(document.getElementById('rc-round-mins')?.value) || 0;
  const bufferMin = parseFloat(document.getElementById('rc-buffer-mins')?.value) || 0;
  const totalMin = hours * 60 + mins;
  if(roundMin <= 0 || totalMin <= 0) return { rounds: 0, totalMin, roundMin, bufferMin, usedMin: 0 };
  // N rounds of play plus (N-1) buffers between them must fit in totalMin:
  // N*roundMin + (N-1)*bufferMin <= totalMin  =>  N <= (totalMin+bufferMin)/(roundMin+bufferMin)
  const rounds = Math.max(0, Math.floor((totalMin + bufferMin) / (roundMin + bufferMin)));
  const usedMin = rounds > 0 ? rounds * roundMin + (rounds - 1) * bufferMin : 0;
  return { rounds, totalMin, roundMin, bufferMin, usedMin };
}

function updateRoundsCalc() {
  const { rounds, totalMin, usedMin } = _roundsCalcCompute();
  const leftoverMin = Math.max(0, totalMin - usedMin);
  const result = document.getElementById('rc-result');
  if(!result) return;
  if(rounds <= 0) {
    result.innerHTML = '<span style="color:var(--ball)">Not enough time for even one round at this length.</span>';
    return;
  }
  const hrs = Math.floor(usedMin / 60), mns = Math.round(usedMin % 60);
  const usedStr = hrs > 0 ? `${hrs}h ${mns}m` : `${mns}m`;
  const leftHrs = Math.floor(leftoverMin / 60), leftMns = Math.round(leftoverMin % 60);
  const leftStr = leftHrs > 0 ? `${leftHrs}h ${leftMns}m` : `${Math.round(leftoverMin)}m`;
  result.innerHTML =
    `<span style="font-size:1.4rem;font-weight:700;color:var(--lime)">${rounds}</span> rounds fit, `
    + `using <strong>${usedStr}</strong> &nbsp;·&nbsp; ~<strong>${leftStr}</strong> left over for warmup, awards, etc.`
    + (rounds < 3 ? '<div style="color:var(--ball);margin-top:4px;font-size:0.78rem">⚠️ That\'s a short night — consider shorter rounds or a smaller buffer.</div>' : '');
}

function applyRoundsCalc() {
  const { rounds } = _roundsCalcCompute();
  if(rounds <= 0) { toast('Adjust the numbers — no rounds fit in that time', 'err'); return; }
  const maxRoundsInput = document.getElementById('max-rounds');
  if(maxRoundsInput) maxRoundsInput.value = rounds;
  const roundMinsInput = document.getElementById('rc-round-mins');
  const timerInput = document.getElementById('timer-minutes');
  if(roundMinsInput && timerInput) { timerInput.value = roundMinsInput.value; resetTimer(); }
  toggleRoundsCalc();
  toast(`Max Rounds set to ${rounds}`);
}

function _timerGetRemaining() {
  if(!_timerRunning) return _timerSeconds;
  const elapsed = (Date.now() - _timerStartedAt) / 1000;
  return _timerSecondsAtStart - elapsed;
}

function updateTimerDisplay() {
  const el = document.getElementById('timer-display');
  const st = document.getElementById('timer-status');
  if(!el) return;
  const secs = _timerGetRemaining();
  const abs = Math.abs(secs);
  const m = Math.floor(abs / 60);
  const s = Math.floor(abs % 60);
  const sign = secs < 0 ? '+' : '';
  el.textContent = `${sign}${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.className = 'timer-display' + (secs <= 0 ? ' expired' : secs <= 60 ? ' warning' : '');
  if(st) st.textContent = _timerRunning
    ? (secs > 0 ? 'Running' : 'Overtime')
    : (Math.round(secs) === getTimerMinutes()*60 ? 'Ready' : 'Paused');
}

function _timerTick() {
  if(!_timerRunning) return;
  const secs = _timerGetRemaining();
  updateTimerDisplay();
  // Alerts (fire once each)
  if(!_timerAlerted2min && secs <= 120 && secs > 0) {
    _timerAlerted2min = true;
    _timerBeep(880, 0.15); setTimeout(() => _timerBeep(880, 0.15), 200);
    toast('⚠️ 2 minutes remaining!', 'err');
  }
  if(!_timerAlertedEnd && secs <= 0) {
    _timerAlertedEnd = true;
    _timerBeep(880, 0.25); setTimeout(() => _timerBeep(660, 0.25), 280); setTimeout(() => _timerBeep(440, 0.5), 560);
    toast('⏰ Time\'s up! Enter scores and advance the round.', 'err');
  }
  _timerRafId = requestAnimationFrame(_timerTick);
}

function _timerBeep(freq, duration, vol) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = 'sine'; osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol || 0.4, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + duration);
  } catch(e) {}
}

// Short ascending "ta-da" arpeggio for the Round Complete celebration —
// reuses the same oscillator approach as _timerBeep, just three brighter
// notes in quick succession instead of one flat warning tone.
function _ldCelebrationChime() {
  if(_ldMuted) return;
  _timerBeep(523.25, 0.16, 0.28); // C5
  setTimeout(() => _timerBeep(659.25, 0.16, 0.28), 90);  // E5
  setTimeout(() => _timerBeep(783.99, 0.30, 0.30), 180); // G5
}

// Lightweight CSS-only confetti burst for the Round Complete moment — no
// external libraries. Pieces spawn at center, fly outward on randomized
// trajectories via CSS custom properties, and remove themselves after the
// animation finishes so the DOM doesn't accumulate stale nodes.
function _ldFireConfetti() {
  const host = document.getElementById('ld-confetti');
  if(!host) return;
  host.innerHTML = ''; // clear any leftovers from a previous round
  const colors = [ldGetAccent(), '#FFD54F', '#FF7043', '#60A5FA', '#FFFFFF'];
  const pieceCount = 36;
  const frag = document.createDocumentFragment();
  for(let i = 0; i < pieceCount; i++) {
    const piece = document.createElement('div');
    const angle = Math.random() * Math.PI * 2;
    const dist = 25 + Math.random() * 35; // vw units traveled outward
    const cx = (Math.cos(angle) * dist).toFixed(1) + 'vw';
    const cy = (Math.sin(angle) * dist + 20).toFixed(1) + 'vh'; // slight downward drift (gravity feel)
    const rot = Math.round(360 + Math.random() * 720) + 'deg';
    const size = 6 + Math.random() * 8;
    const color = colors[i % colors.length];
    const duration = (1.1 + Math.random() * 0.9).toFixed(2);
    const delay = (Math.random() * 0.15).toFixed(2);
    piece.style.cssText =
      `position:absolute;left:50%;top:38%;width:${size}px;height:${size * 0.5}px;` +
      `background:${color};border-radius:2px;` +
      `--cx:${cx};--cy:${cy};--cr:${rot};` +
      `animation:ldConfettiFall ${duration}s ease-out ${delay}s forwards;`;
    frag.appendChild(piece);
  }
  host.appendChild(frag);
  // Clean up after the longest possible piece animation finishes
  setTimeout(() => { host.innerHTML = ''; }, 2200);
}

function startTimer() {
  if(_timerRunning) return;
  _timerSecondsAtStart = _timerSeconds;
  _timerStartedAt = Date.now();
  _timerRunning = true;
  _timerAlerted2min = _timerSeconds <= 120;
  _timerAlertedEnd  = _timerSeconds <= 0;
  cancelAnimationFrame(_timerRafId);
  _timerRafId = requestAnimationFrame(_timerTick);
  updateTimerDisplay();
}

function pauseTimer() {
  _timerSeconds = _timerGetRemaining();
  _timerRunning = false;
  cancelAnimationFrame(_timerRafId);
  updateTimerDisplay();
}

function resetTimer() {
  pauseTimer();
  _timerSeconds = getTimerMinutes() * 60;
  _timerAlerted2min = false;
  _timerAlertedEnd  = false;
  updateTimerDisplay();
}

function toggleTimer() {
  if(_timerRunning) pauseTimer(); else startTimer();
}

// Snap display up-to-date the moment the browser tab becomes visible again
document.addEventListener('visibilitychange', () => {
  if(!document.hidden && _timerRunning) {
    cancelAnimationFrame(_timerRafId);
    _timerRafId = requestAnimationFrame(_timerTick);
  }
});

// ═══════════════════════════════════════════════
//  DUPR IMPACT PREVIEW
// ═══════════════════════════════════════════════
// Expected score formula (Elo-like): E = 1/(1+10^((oppAvg-teamAvg)/4))
// Rating change = K * (actual - expected), where K ≈ 0.1 for DUPR
function duprExpectedScore(teamAvg, oppAvg) {
  return 1 / (1 + Math.pow(10, (oppAvg - teamAvg) / 4));
}

function duprImpactStr(teamAvg, oppAvg, won) {
  const exp = duprExpectedScore(teamAvg, oppAvg);
  const actual = won ? 1 : 0;
  const K = 0.1;
  const delta = +(K * (actual - exp)).toFixed(3);
  const sign = delta >= 0 ? '+' : '';
  const cls = delta > 0 ? 'dupr-impact-pos' : delta < 0 ? 'dupr-impact-neg' : 'dupr-impact-neu';
  return `<span class="${cls}">${sign}${delta}</span>`;
}

// ═══════════════════════════════════════════════
//  ROUND COMPLETE NOTIFICATION
// ═══════════════════════════════════════════════
function checkRoundComplete() {
  if(!state.schedule.length) return;
  state.schedule.forEach((round, r) => {
    if(!round.length) return;
    const scoreableMatches = round.filter(m => !m.isRiverMatch);
    if(!scoreableMatches.length) return;
    const allDone = scoreableMatches.every(m => m.complete);
    if(!allDone || state.notifiedRounds.has(r)) return;

    state.notifiedRounds.add(r);

    const msg      = document.getElementById('round-complete-msg');
    const titleEl  = document.getElementById('round-complete-title');
    const nextEl   = document.getElementById('round-complete-next');
    const smsBtn   = document.getElementById('round-complete-sms-btn');
    const viewBtn  = document.getElementById('round-complete-view-btn');
    if(!msg) return;

    // Check if there's a next round to show
    const nextRound = state.schedule[r + 1];
    const hasNext   = nextRound && nextRound.some(m => m.teamA && m.teamB);

    if(titleEl) titleEl.textContent = `✅ Round ${r+1} complete — all courts scored!`;

    if(hasNext && nextEl) {
      // Build a compact preview of next round's courts
      const courts = nextRound.filter(m => m.teamA && m.teamB).map(m =>
        `Court ${m.court}: ${matchTeamName(m.teamA)} vs ${matchTeamName(m.teamB)}`
      );
      nextEl.innerHTML = `<strong style="color:var(--lime)">Round ${r+2} →</strong> `
        + courts.slice(0,3).map(c => `<span style="margin-right:1rem">${escHtml(c)}</span>`).join('')
        + (courts.length > 3 ? `<span style="color:var(--txt3)">+${courts.length-3} more</span>` : '');
      if(viewBtn) { viewBtn.style.display=''; viewBtn.textContent = `▶ View Round ${r+2}`; }
    } else {
      if(nextEl) nextEl.textContent = r+1 === state.schedule.length ? '🏆 Tournament complete!' : '';
      if(viewBtn) viewBtn.style.display = r+1 < state.schedule.length ? '' : 'none';
    }

    // SMS notify button — always shown now; Twilio credentials live
    // server-side on the relay Worker, not in a client-side config object,
    // so there's nothing client-visible left to gate this on.
    if(smsBtn) {
      smsBtn.style.display = '';
    }

    // Show Rebuild Next Round button for modes where next round depends on results
    const rebuildBtn = document.getElementById('round-complete-rebuild-btn');
    if(rebuildBtn) {
      const mode = document.getElementById('team-mode')?.value || '';
      const resultsModes = ['crossover', 'equalizer', 'progressive', 'dupr', 'mexicano', 'americano'];
      const hasNextRound = r + 1 < state.schedule.length;
      const needsRebuild = resultsModes.includes(mode) && hasNextRound;
      rebuildBtn.style.display = needsRebuild ? '' : 'none';
      if(needsRebuild) {
        const modeName = { crossover:'Crossover', equalizer:'Equalizer', progressive:'Progressive', dupr:'DUPR Session', mexicano:'Mexicano', americano:'Americano' }[mode] || mode;
        rebuildBtn.title = modeName + ' mode: next round should be rebuilt using actual results from this round';
      }
    }

    msg.style.display = 'flex';
    // Re-trigger animation
    msg.style.animation = 'none';
    msg.offsetHeight; // reflow
    msg.style.animation = '';

    // Store which round just completed so actions know where to go
    msg.dataset.completedRound = r;

    // Update live display if it's open
    if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  });
  // RR+Playoff: check if all matches are done and prompt for playoff
  checkRRPlayoffComplete();
}

function dismissRoundComplete() {
  const msg = document.getElementById('round-complete-msg');
  if(msg) msg.style.display = 'none';
}

function rebuildNextRound() {
  // Find the last completed round index
  let lastCompleted = -1;
  state.schedule.forEach((round, r) => {
    const scoreable = round.filter(m => !m.isRiverMatch);
    if(scoreable.length && scoreable.every(m => m.complete)) lastCompleted = r;
  });

  if(lastCompleted < 0) {
    toast('Complete at least one round first', 'err');
    return;
  }
  if(lastCompleted + 1 >= state.schedule.length) {
    toast('No future rounds to rebuild', 'err');
    return;
  }

  const rebuilt = rebuildUpcomingRounds();
  if(rebuilt > 0) {
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
    autoSave();
    const mode = document.getElementById('team-mode')?.value || '';
    const modeName = { crossover:'Crossover', equalizer:'Equalizer', progressive:'Progressive', dupr:'DUPR Session', mexicano:'Mexicano', americano:'Americano' }[mode] || mode;
    toast(`✅ ${modeName}: ${rebuilt} round${rebuilt>1?'s':''} rebuilt using actual results`);
    msAutoPushIfEnabled();
    // Scroll to next round
    const schedBtn = document.querySelector('.tab-btn[onclick*="schedule"]');
    if(schedBtn) showTab('schedule', { target: schedBtn });
    setTimeout(() => {
      const headers = document.querySelectorAll('#schedule-container .round-header');
      if(headers[lastCompleted + 1]) headers[lastCompleted + 1].scrollIntoView({ behavior:'smooth', block:'start' });
    }, 150);
  } else {
    toast('No rounds were rebuilt', 'err');
  }
}

function roundCompleteRebuild() {
  const msg = document.getElementById('round-complete-msg');
  const completedRound = parseInt(msg?.dataset.completedRound ?? '0'); // 0-indexed
  dismissRoundComplete();

  // Rebuild all future rounds using actual results from completed rounds
  const rebuilt = rebuildUpcomingRounds();

  if(rebuilt > 0) {
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
    autoSave();
    const mode = document.getElementById('team-mode')?.value || '';
    const modeName = { crossover:'Crossover', equalizer:'Equalizer', progressive:'Progressive', dupr:'DUPR Session', mexicano:'Mexicano', americano:'Americano' }[mode] || mode;
    toast(`✅ ${modeName}: Round ${completedRound + 2} rebuilt using actual results`);
    // Switch to schedule tab and scroll to the rebuilt round
    const schedBtn = document.querySelector('.tab-btn[onclick*="schedule"]');
    if(schedBtn) showTab('schedule', { target: schedBtn });
    setTimeout(() => {
      const headers = document.querySelectorAll('#schedule-container .round-header');
      if(headers[completedRound + 1]) headers[completedRound + 1].scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 150);
  } else {
    toast('No future rounds to rebuild', 'err');
  }
}

function roundCompleteViewNext() {
  dismissRoundComplete();
  const msg = document.getElementById('round-complete-msg');
  const nextRound = parseInt(msg?.dataset.completedRound ?? '0') + 2; // 1-indexed
  showTab('schedule', {target: document.querySelector('.tab-btn[onclick*="schedule"]')});
  // Scroll to the next round section after a tick
  setTimeout(() => {
    const headers = document.querySelectorAll('#schedule-container .round-header, #schedule-container h3, #schedule-container .card-title');
    for(const h of headers) {
      if(h.textContent.includes('Round ' + nextRound)) {
        h.scrollIntoView({behavior:'smooth', block:'start'});
        break;
      }
    }
  }, 150);
}

function roundCompleteNotify() {
  dismissRoundComplete();
  showTab('sms', {target: document.querySelector('.tab-btn[onclick*="sms"]')});
  toast('📱 Head to SMS tab to send the next round notification');
}




// ═══════════════════════════════════════════════
//  TOURNAMENT NAME
// ═══════════════════════════════════════════════
function getTournamentName() {
  return document.getElementById('tournament-name')?.value.trim() || 'Pickleball Tournament';
}

// Returns the raw datetime-local value (e.g. "2026-06-20T09:00"), or '' if unset.
function getTournamentDateTime() {
  return document.getElementById('tournament-datetime')?.value || '';
}

// Formats the event date/time for display (e.g. "Jun 20, 2026, 9:00 AM"), or '' if unset.
function formatTournamentDateTime() {
  const raw = getTournamentDateTime();
  if(!raw) return '';
  const d = new Date(raw);
  if(isNaN(d.getTime())) return '';
  return d.toLocaleString(undefined, { month:'short', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit' });
}

function updateTournamentName() {
  // Update page title
  const name = getTournamentName();
  document.title = name ? `🏓 ${name}` : '🏓 Pickleball Tournament Manager';
  // If the email subject still looks like the auto-generated default (user hasn't
  // customized it), keep it in sync with the tournament name/date as they're edited.
  const subjEl = document.getElementById('em-subject');
  if(subjEl && (subjEl.value === '' || subjEl.value === subjEl.dataset.lastDefault)) {
    subjEl.value = emDefaultSubject();
    subjEl.dataset.lastDefault = subjEl.value;
  }
  // Include in autosave
  autoSave();
}


function exportStandingsCSV() {
  if(!state.players.length) { toast('No standings data yet','err'); return; }
  const stats = {};
  state.players.forEach((p,i) => { stats[i] = {idx:i, played:0, wins:0, losses:0, pts:0}; });
  state.schedule.flat().filter(m=>m.complete).forEach(m => {
    [[m.teamA, m.scoreA, m.scoreB],[m.teamB, m.scoreB, m.scoreA]].forEach(([team,s,opp]) => {
      team.forEach(pi => {
        if(!stats[pi]) return;
        stats[pi].played++;
        if(s > opp)      { stats[pi].wins++;   stats[pi].pts+=2; }
        else if(s < opp) { stats[pi].losses++; }
        else              { stats[pi].pts+=1; }
      });
    });
  });
  const list = Object.values(stats)
    .map(s => ({...s, pct: s.played ? s.wins/s.played : 0}))
    .sort((a,b) => b.pts-a.pts || b.pct-a.pct);
  const rows = [[getTournamentName()],['Rank','Player','Gender','DUPR','ClubRating','Club','Played','Wins','Losses','Points','WinPct']];
  list.forEach((s,rank) => {
    const p = state.players[s.idx];
    rows.push([rank+1, p.name, p.gender, p.dupr??'', p.clubRating||'', p.club||'',
               s.played, s.wins, s.losses, s.pts,
               s.played ? (s.wins/s.played*100).toFixed(1)+'%' : '0%']);
  });
  downloadCSV(rows, `${getTournamentName().replace(/[^a-zA-Z0-9]/g,'_')}_standings.csv`);
  toast('📥 Standings exported!');
}

// ═══════════════════════════════════════════════
//  DUPR MATCH IMPORT EXPORT
// ═══════════════════════════════════════════════
// Builds a CSV matching DUPR's official "Import Matches via CSV" club
// template (Matches tab → Import Matches via CSV on dupr.com), so an
// organizer can run their tournament here and then hand the results to
// DUPR with one upload instead of retyping every score by hand.
//
// DUPR's template needs each player's DUPR ID (the short alphanumeric
// code on their profile, e.g. "BK5V6D") — NOT the numeric rating this
// app already tracks in p.dupr. Those are two different fields. Since
// this app has never needed to collect DUPR IDs before, we ask for them
// here, once, and remember them in TWO places:
//
//  1. localStorage on this device — instant, no network wait, works even
//     if the relay is briefly unreachable.
//  2. The relay Worker's KV store (/api/dupr-ids) — durable, shared across
//     every device/organizer who logs in, survives a cleared browser.
//
// SCOPED PER TOURNAMENT NAME: both the localStorage key and the server
// entry are namespaced by getTournamentName(), not stored as one single
// global map. This matters for two directors running two DIFFERENT
// tournaments — without scoping, a player named "John Smith" in Director
// A's event and a different, unrelated "John Smith" in Director B's
// event would collide in one shared map, with whoever saved last winning.
// Scoping by tournament name avoids that, at one deliberate cost: a
// regular player's DUPR ID does NOT automatically carry over between two
// of YOUR OWN differently-named tournaments — e.g. "Spring Open 2026" and
// "Summer Open 2026" are different scopes, even for the same person. If
// you re-use the exact same tournament name across events on purpose,
// IDs carry over; if you don't, you'll re-enter repeat players' IDs once
// per uniquely-named tournament. This was a deliberate simplicity
// tradeoff over auto-generated per-tournament IDs (which would avoid
// collisions entirely but never carry over at all, even within the same
// named series) — see project notes for the decision.
//
// On load: read localStorage first (instant), then fetch this
// tournament's server copy in the background and merge anything the
// server knows that this device doesn't — so a second device converges
// to the same data instead of re-prompting for IDs another device
// already collected. On save: write to localStorage immediately, then
// push the same entries to the server (best-effort — a save still
// succeeds locally even if the network call fails, so a flaky connection
// never blocks the actual export).
var DUPR_ID_MAP_KEY_PREFIX = 'pickleball_dupr_id_map:';

// Tournament-scoped localStorage key. Falls back to a fixed "(untitled)"
// scope if the tournament has no name yet, so this never throws on an
// empty/just-started tournament — it just means an unnamed tournament's
// IDs land in their own small bucket until the director names the event.
function duprIdMapStorageKey() {
  const name = (getTournamentName() || '').trim() || '(untitled)';
  return DUPR_ID_MAP_KEY_PREFIX + name;
}

function duprIdMapLoad() {
  try { return JSON.parse(localStorage.getItem(duprIdMapStorageKey()) || '{}'); } catch(e) { return {}; }
}
function duprIdMapSaveLocal(map) {
  try { localStorage.setItem(duprIdMapStorageKey(), JSON.stringify(map)); } catch(e) {}
}

// Fetches the server's copy for THIS tournament and merges anything new
// into the local copy. Server entries never overwrite a value this
// device already has for the same player — if they ever disagree, that's
// a rare edge case (two organizers typed different IDs for a same-named
// player) not worth silently resolving one way; the device's own value
// wins locally, and the next save pushes it back up, naturally converging.
async function duprIdMapSync() {
  const local = duprIdMapLoad();
  try {
    const r = await fetch(RELAY_BASE + '/api/dupr-ids?tournament=' + encodeURIComponent(getTournamentName() || '(untitled)'));
    const data = await r.json();
    if (data.ok && data.map) {
      let changed = false;
      Object.keys(data.map).forEach(k => {
        if (!local[k]) { local[k] = data.map[k]; changed = true; }
      });
      if (changed) duprIdMapSaveLocal(local);
    }
  } catch(e) {
    // Relay unreachable — proceed with whatever this device already has
    // locally. The export itself still works; it just won't benefit from
    // IDs another device may have saved.
  }
  return local;
}

// Saves locally immediately, then best-effort pushes to the server so
// other devices working on the SAME-NAMED tournament can pick these up
// later. Never throws — a server push failure shouldn't block the export
// the person is actively trying to do. `removeKeys` (optional) is pushed
// alongside so deletions made in the Manage DUPR IDs screen propagate to
// other devices too, not just this one — see handleSaveDuprIds in the
// Worker for how merge+remove combine.
function duprIdMapSave(map, removeKeys) {
  duprIdMapSaveLocal(map);
  fetch(RELAY_BASE + '/api/dupr-ids', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ tournament: getTournamentName() || '(untitled)', map, remove: removeKeys || [] }),
  }).catch(e => {
    // Best-effort — see function comment above.
  });
}

// Normalizes a name the same way the rest of the app keys player history —
// lowercased + trimmed — so "Bob Smith" and "bob smith " hit the same entry.
function duprNameKey(name) {
  return String(name||'').trim().toLowerCase();
}

async function exportDuprCSV() {
  const completed = state.schedule.flat().filter(m => m.complete && m.teamA && m.teamB && m.teamA.length && m.teamB.length);
  if (!completed.length) { toast('No completed matches to export yet', 'err'); return; }

  // Collect every player who appears in a completed match — only these
  // actually need a DUPR ID, not the whole roster (e.g. a player who
  // withdrew before playing any matches shouldn't block the export).
  const playerIdxSet = new Set();
  completed.forEach(m => { m.teamA.forEach(i => playerIdxSet.add(i)); m.teamB.forEach(i => playerIdxSet.add(i)); });

  const idMap = await duprIdMapSync();
  const missing = [...playerIdxSet]
    .map(i => state.players[i])
    .filter(p => p && !idMap[duprNameKey(p.name)]);

  if (missing.length) {
    exportDuprCSV_promptForIds(missing, idMap, () => exportDuprCSV());
    return;
  }

  const event = getTournamentName();
  const rows = [['matchType','scoreType','event','date','playerA1','playerA1DuprId','playerA2','playerA2DuprId','playerB1','playerB1DuprId','playerB2','playerB2DuprId','teamAGame1','teamBGame1','teamAGame2','teamBGame2','teamAGame3','teamBGame3','teamAGame4','teamBGame4','teamAGame5','teamBGame5']];

  completed.forEach(m => {
    const matchType = m.teamA.length >= 2 ? 'D' : 'S';
    const a1 = state.players[m.teamA[0]], a2 = m.teamA.length > 1 ? state.players[m.teamA[1]] : null;
    const b1 = state.players[m.teamB[0]], b2 = m.teamB.length > 1 ? state.players[m.teamB[1]] : null;
    rows.push([
      matchType, 'RALLY', event, todayAsDuprDate(),
      a1?.name||'', idMap[duprNameKey(a1?.name)]||'',
      a2?.name||'', a2 ? (idMap[duprNameKey(a2.name)]||'') : '',
      b1?.name||'', idMap[duprNameKey(b1?.name)]||'',
      b2?.name||'', b2 ? (idMap[duprNameKey(b2.name)]||'') : '',
      m.scoreA, m.scoreB, '', '', '', '', '', '', '', '',
    ]);
  });

  downloadCSV(rows, `${event.replace(/[^a-zA-Z0-9]/g,'_')}_dupr_import.csv`);
  toast(`🏓 Exported ${completed.length} match${completed.length===1?'':'es'} for DUPR import`);
}

// DUPR's CSV wants YYYY-MM-DD or MM/DD/YYYY — using today's date (export
// time) since this app doesn't currently track a per-match played-on
// date, only a round number. Good enough for DUPR's import (it just needs
// *a* valid date for the match), but worth knowing if you ever need the
// exact day a multi-day tournament's earlier rounds were actually played.
function todayAsDuprDate() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

// One simple modal collecting DUPR IDs for every player missing one.
// Built with plain DOM rather than this app's normal modal markup so it
// has zero dependency on any specific section being open when called.
function exportDuprCSV_promptForIds(missingPlayers, idMap, onDone) {
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem';

  const box = document.createElement('div');
  box.style.cssText = 'background:var(--card,#1a1a1a);border-radius:12px;padding:1.5rem;max-width:480px;width:100%;max-height:80vh;overflow-y:auto';

  const title = document.createElement('div');
  title.style.cssText = 'font-weight:700;margin-bottom:0.25rem';
  title.textContent = '🏓 DUPR IDs needed';
  box.appendChild(title);

  const sub = document.createElement('div');
  sub.style.cssText = 'font-size:0.82rem;color:#999;margin-bottom:1rem';
  sub.textContent = `Enter each player's DUPR ID (from their DUPR profile) to include them in the export. Saved on this device for next time.`;
  box.appendChild(sub);

  const inputs = {};
  missingPlayers.forEach(p => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:0.5rem;margin-bottom:0.5rem';
    const label = document.createElement('span');
    label.style.cssText = 'flex:1;font-size:0.88rem';
    label.textContent = p.name;
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'e.g. BK5V6D';
    input.style.cssText = 'width:120px;padding:0.3rem 0.5rem;border-radius:6px;border:1px solid #444;background:#111;color:#eee';
    inputs[duprNameKey(p.name)] = input;
    row.appendChild(label); row.appendChild(input);
    box.appendChild(row);
  });

  const btnRow = document.createElement('div');
  btnRow.style.cssText = 'display:flex;gap:0.5rem;margin-top:1rem;justify-content:flex-end';

  const skipBtn = document.createElement('button');
  skipBtn.className = 'btn btn-secondary btn-sm';
  skipBtn.textContent = 'Cancel';
  skipBtn.onclick = () => document.body.removeChild(overlay);

  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-orange btn-sm';
  saveBtn.textContent = 'Save & Export';
  saveBtn.onclick = () => {
    let anyBlank = false;
    Object.keys(inputs).forEach(key => {
      const val = inputs[key].value.trim().toUpperCase();
      if (val) idMap[key] = val; else anyBlank = true;
    });
    duprIdMapSave(idMap);
    document.body.removeChild(overlay);
    if (anyBlank) {
      toast('Exported with some players left blank — fill in their DUPR ID later and re-export to include them.', 'err');
    }
    onDone();
  };

  btnRow.appendChild(skipBtn); btnRow.appendChild(saveBtn);
  box.appendChild(btnRow);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}

// ── Manage DUPR IDs: view/edit/delete every saved player → DUPR ID ──────
// Reuses duprIdMapSync()/duprIdMapSave() — the exact same dual-write path
// (localStorage + the relay's /api/dupr-ids) used by the export flow — so
// any change made here is just as durable and just as shared across
// devices as an ID entered during export. Lists by name as currently
// saved in the map, which may include players from past tournaments, not
// just this one — that's intentional, since the map is a standing record
// independent of any single tournament's roster.
// Standalone CSV-line splitter — same quoted-field-handling logic as the
// parser inside importCSV(), pulled out so the DUPR ID bulk importer can
// use it too without reaching into that function's closure. Handles
// commas inside quoted fields and escaped ("") quotes; does not handle
// quoted newlines within a single field (callers that need that, like
// importCSV's full-file parser, do their own line-splitting first).
function parseCSVLine(line) {
  const cols = [];
  let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQ && line[i+1] === '"') { cur += '"'; i++; }
      else inQ = !inQ;
    } else if (ch === ',' && !inQ) {
      cols.push(cur.trim()); cur = '';
    } else {
      cur += ch;
    }
  }
  cols.push(cur.trim());
  return cols;
}

async function openDuprIdManager() {
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem';

  const box = document.createElement('div');
  box.style.cssText = 'background:var(--card,#1a1a1a);border-radius:12px;padding:1.5rem;max-width:560px;width:100%;max-height:80vh;overflow-y:auto';

  const title = document.createElement('div');
  title.style.cssText = 'font-weight:700;margin-bottom:0.25rem';
  title.textContent = '⚙️ Manage DUPR IDs';
  box.appendChild(title);

  const scopeNote = document.createElement('div');
  scopeNote.style.cssText = 'font-size:0.78rem;color:#C6FF00;margin-bottom:0.5rem';
  scopeNote.textContent = `📋 Scoped to: "${getTournamentName() || '(untitled)'}" — a differently-named tournament keeps its own separate list.`;
  box.appendChild(scopeNote);

  const sub = document.createElement('div');
  sub.style.cssText = 'font-size:0.82rem;color:#999;margin-bottom:1rem';
  sub.textContent = 'Loading saved IDs…';
  box.appendChild(sub);

  const listEl = document.createElement('div');
  box.appendChild(listEl);

  // ── Bulk import: paste rows or upload a CSV ─────────────────────────
  // Accepts "Name,DuprID" per line (also tolerates "Name, DuprID" with a
  // space, and a quoted name containing a comma via parseCSVLine). If a
  // pasted/uploaded file has a header row ("name,duprid" or similar), it's
  // detected and skipped automatically rather than imported as a fake
  // player. This is intentionally forgiving about format — the realistic
  // source is "whatever the organizer was able to copy out of DUPR's
  // on-screen member list or assemble in a spreadsheet," not a
  // perfectly-formed export, since DUPR doesn't provide one.
  const bulkToggle = document.createElement('button');
  bulkToggle.className = 'btn btn-secondary btn-sm';
  bulkToggle.style.cssText = 'margin-top:0.75rem';
  bulkToggle.textContent = '📋 Bulk import (paste or CSV)';
  box.appendChild(bulkToggle);

  const bulkSection = document.createElement('div');
  bulkSection.style.cssText = 'display:none;margin-top:0.5rem;padding:0.75rem;border:1px solid #333;border-radius:8px';

  const bulkHint = document.createElement('div');
  bulkHint.style.cssText = 'font-size:0.78rem;color:#999;margin-bottom:0.5rem';
  bulkHint.textContent = 'One player per line: Name,DuprID — e.g. "Alice Turner,BK5V6D". Paste below or upload a CSV file.';
  bulkSection.appendChild(bulkHint);

  const bulkTextarea = document.createElement('textarea');
  bulkTextarea.placeholder = 'Alice Turner,BK5V6D\nBob Martin,7Q2X9P\n...';
  bulkTextarea.style.cssText = 'width:100%;min-height:100px;padding:0.5rem;border-radius:6px;border:1px solid #444;background:#111;color:#eee;font-family:monospace;font-size:0.82rem;box-sizing:border-box';
  bulkSection.appendChild(bulkTextarea);

  const bulkActionRow = document.createElement('div');
  bulkActionRow.style.cssText = 'display:flex;gap:0.5rem;margin-top:0.5rem;align-items:center;flex-wrap:wrap';

  const bulkFileInput = document.createElement('input');
  bulkFileInput.type = 'file';
  bulkFileInput.accept = '.csv,text/csv,text/plain';
  bulkFileInput.style.cssText = 'font-size:0.78rem;max-width:180px';
  bulkFileInput.onchange = () => {
    const file = bulkFileInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => { bulkTextarea.value = e.target.result; };
    reader.readAsText(file);
  };

  const bulkImportBtn = document.createElement('button');
  bulkImportBtn.className = 'btn btn-orange btn-sm';
  bulkImportBtn.textContent = 'Import';
  bulkImportBtn.onclick = () => {
    const lines = bulkTextarea.value.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if (!lines.length) { toast('Nothing to import — paste rows or choose a file first', 'err'); return; }

    let added = 0, skipped = 0;
    lines.forEach(line => {
      const cols = parseCSVLine(line);
      const name = (cols[0] || '').trim();
      const id = (cols[1] || '').trim().toUpperCase();
      if (!name || !id) { skipped++; return; }
      // Skip an obvious header row ("name,duprid" / "Player,DUPR ID" etc.)
      // rather than importing "name" as a literal player.
      const nameLower = name.toLowerCase();
      if ((nameLower === 'name' || nameLower === 'player' || nameLower === 'playername') &&
          /dupr/i.test(id)) { skipped++; return; }
      map[duprNameKey(name)] = id;
      added++;
    });

    if (!added) { toast('No valid "Name,DuprID" rows found', 'err'); return; }
    duprIdMapSave(map);
    bulkTextarea.value = '';
    bulkFileInput.value = '';
    renderDuprIdManagerList();
    toast(`Imported ${added} player${added===1?'':'s'}${skipped ? ` (${skipped} row${skipped===1?'':'s'} skipped)` : ''}`);
  };

  bulkActionRow.appendChild(bulkFileInput);
  bulkActionRow.appendChild(bulkImportBtn);
  bulkSection.appendChild(bulkActionRow);
  box.appendChild(bulkSection);

  bulkToggle.onclick = () => {
    const isHidden = bulkSection.style.display === 'none';
    bulkSection.style.display = isHidden ? 'block' : 'none';
    bulkToggle.textContent = isHidden ? '📋 Hide bulk import' : '📋 Bulk import (paste or CSV)';
  };

  const addRow = document.createElement('div');
  addRow.style.cssText = 'display:flex;gap:0.5rem;margin-top:1rem;padding-top:1rem;border-top:1px solid #333';
  const addName = document.createElement('input');
  addName.type = 'text'; addName.placeholder = 'Player name';
  addName.style.cssText = 'flex:1;padding:0.3rem 0.5rem;border-radius:6px;border:1px solid #444;background:#111;color:#eee';
  const addId = document.createElement('input');
  addId.type = 'text'; addId.placeholder = 'DUPR ID';
  addId.style.cssText = 'width:110px;padding:0.3rem 0.5rem;border-radius:6px;border:1px solid #444;background:#111;color:#eee';
  const addBtn = document.createElement('button');
  addBtn.className = 'btn btn-orange btn-sm';
  addBtn.textContent = '+ Add';
  addRow.appendChild(addName); addRow.appendChild(addId); addRow.appendChild(addBtn);
  box.appendChild(addRow);

  const closeRow = document.createElement('div');
  closeRow.style.cssText = 'display:flex;justify-content:flex-end;margin-top:1rem';
  const closeBtn = document.createElement('button');
  closeBtn.className = 'btn btn-secondary btn-sm';
  closeBtn.textContent = 'Close';
  closeBtn.onclick = () => document.body.removeChild(overlay);
  closeRow.appendChild(closeBtn);
  box.appendChild(closeRow);

  overlay.appendChild(box);
  document.body.appendChild(overlay);

  // Pull the latest from both layers (same sync used before export) so
  // the manager always reflects what another device may have saved too,
  // not just whatever this device happened to have cached.
  let map = await duprIdMapSync();
  renderDuprIdManagerList();

  function renderDuprIdManagerList() {
    const keys = Object.keys(map).sort();
    sub.textContent = keys.length
      ? `${keys.length} player${keys.length===1?'':'s'} saved. Changes here update this device and the shared server copy.`
      : 'No DUPR IDs saved yet — add one below, or enter them next time you export.';
    listEl.innerHTML = '';
    keys.forEach(key => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:0.5rem;margin-bottom:0.4rem';

      const nameLabel = document.createElement('span');
      nameLabel.style.cssText = 'flex:1;font-size:0.88rem;text-transform:capitalize';
      nameLabel.textContent = key;

      const idInput = document.createElement('input');
      idInput.type = 'text';
      idInput.value = map[key];
      idInput.style.cssText = 'width:110px;padding:0.3rem 0.5rem;border-radius:6px;border:1px solid #444;background:#111;color:#eee';
      idInput.onchange = () => {
        const val = idInput.value.trim().toUpperCase();
        if (!val) { idInput.value = map[key]; toast('DUPR ID cannot be blank — use Remove instead', 'err'); return; }
        map[key] = val;
        duprIdMapSave(map);
        toast(`Updated ${key}`);
      };

      const delBtn = document.createElement('button');
      delBtn.className = 'btn btn-secondary btn-sm';
      delBtn.textContent = '🗑️';
      delBtn.title = 'Remove';
      delBtn.onclick = () => {
        delete map[key];
        duprIdMapSaveLocal(map);
        fetch(RELAY_BASE + '/api/dupr-ids', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({ tournament: getTournamentName() || '(untitled)', map: {}, remove: [key] }),
        }).catch(e => {});
        renderDuprIdManagerList();
        toast(`Removed ${key}`);
      };

      row.appendChild(nameLabel); row.appendChild(idInput); row.appendChild(delBtn);
      listEl.appendChild(row);
    });
  }

  addBtn.onclick = () => {
    const name = addName.value.trim();
    const id = addId.value.trim().toUpperCase();
    if (!name || !id) { toast('Enter both a name and a DUPR ID', 'err'); return; }
    map[duprNameKey(name)] = id;
    duprIdMapSave(map);
    addName.value = ''; addId.value = '';
    renderDuprIdManagerList();
    toast(`Added ${name}`);
  };
}

// ═══════════════════════════════════════════════
//  AUTO-SAVE TO LOCALSTORAGE
// ═══════════════════════════════════════════════
var _autoSaveTimer = null;
var AUTO_SAVE_KEY = 'pickleball_autosave';

// ═══════════════════════════════════════════════
//  PLAYER HISTORY (cross-tournament improvement tracking)
// ═══════════════════════════════════════════════
// Keyed by lowercased player name (player IDs are per-session and don't persist).
// One entry per tournament per player: { date, name (tournament), dupr, delta, winPct, gp }.
// A tournament is identified by state._historyId (generated once, stable across re-renders
// of the same session) so re-rendering the report doesn't create duplicate entries.
var PLAYER_HISTORY_KEY = 'pickleball_player_history';

function phLoad() {
  try { return JSON.parse(localStorage.getItem(PLAYER_HISTORY_KEY) || '{}'); } catch(e) { return {}; }
}
function phSave(hist) {
  try { localStorage.setItem(PLAYER_HISTORY_KEY, JSON.stringify(hist)); } catch(e) {}
}

// Record this tournament's results into each player's history (upsert by tournament id).
// Records every active roster player, not just those with gp>0 — a player on a bye
// still has a Club Rating / roster presence worth tracking, even with no DUPR impact.
function recordPlayerHistory(data) {
  const roster = data.filter(d => d.player.active !== false);
  if(!roster.length) return;
  if(!state._historyId) state._historyId = 'T' + Date.now() + '_' + Math.random().toString(36).slice(2,7);

  const hist = phLoad();
  const tname = getTournamentName() || 'Tournament';
  const date = new Date().toISOString().slice(0,10);

  roster.forEach(s => {
    const key = s.player.name.trim().toLowerCase();
    if(!key) return;
    const startRating = s.player.dupr != null ? s.player.dupr : null;
    const delta = s.gp > 0 ? (s._duprDelta != null ? s._duprDelta : 0) : 0;
    // Store the rating AFTER this tournament's impact, so each event reflects what the
    // player earned that day. Trends then chain off this (event N's result is the
    // baseline for event N+1), instead of comparing identical input ratings every time.
    const resultingDupr = startRating != null ? +(startRating + delta).toFixed(3) : null;
    const clubRating = (s.player.clubRating != null && String(s.player.clubRating).trim() !== '')
      ? String(s.player.clubRating).trim() : null;
    const entry = {
      tid: state._historyId, date, tournament: tname,
      dupr: resultingDupr,
      clubRating,
      delta, winPct: s.winPct, gp: s.gp,
    };
    const arr = hist[key] || [];
    const existingIdx = arr.findIndex(e => e.tid === state._historyId);
    if(existingIdx >= 0) arr[existingIdx] = entry; else arr.push(entry);
    hist[key] = arr;
  });
  phSave(hist);
}

// ── Player History Manager (modal) ──────────────────────────
function openHistoryManager() {
  renderHistoryModal();
  document.getElementById('history-modal')?.classList.add('open');
}
function closeHistoryModal() {
  document.getElementById('history-modal')?.classList.remove('open');
}

let _histEditKey = null, _histEditTid = null; // currently-editing entry

function renderHistoryModal() {
  const body = document.getElementById('history-modal-body');
  if(!body) return;
  const hist = phLoad();
  const keys = Object.keys(hist).filter(k => (hist[k]||[]).length > 0)
    .sort((a,b) => a.localeCompare(b));

  if(!keys.length) {
    body.innerHTML = '<div style="color:var(--txt3);font-size:0.85rem;text-align:center;padding:1.5rem">No history recorded yet. Open the Report tab after entering scores to start tracking.</div>';
    return;
  }

  const displayName = (key) => {
    const p = state.players.find(p => p.name.trim().toLowerCase() === key);
    return p ? p.name : key.replace(/\b\w/g, c => c.toUpperCase());
  };

  body.innerHTML = keys.map(key => {
    const arr = (hist[key]||[]).slice().sort((a,b) => a.date.localeCompare(b.date) || a.tid.localeCompare(b.tid));
    const rows = arr.map(e => {
      const isEditing = _histEditKey === key && _histEditTid === e.tid;
      const deltaStr  = e.delta ? (e.delta > 0 ? '+' : '') + e.delta.toFixed(3) : '—';
      const deltaColor = e.delta > 0 ? 'var(--lime)' : e.delta < 0 ? 'var(--red)' : 'var(--txt3)';
      // Use data-attributes to avoid quote-collision in onclick handlers
      const dKey = escHtml(key), dTid = escHtml(e.tid);

      if(isEditing) {
        return '<tr style="background:rgba(198,255,0,0.05);outline:1px solid rgba(198,255,0,0.25)">'
          + '<td><input id="hedit-date" type="date" value="' + escHtml(e.date||'') + '" style="width:130px;font-size:0.78rem"></td>'
          + '<td><input id="hedit-tournament" value="' + escHtml(e.tournament||'') + '" style="width:160px;font-size:0.78rem"></td>'
          + '<td><input id="hedit-dupr" type="number" step="0.01" min="1" max="8" value="' + (e.dupr!=null?e.dupr:'') + '" placeholder="DUPR" style="width:60px;font-size:0.78rem"></td>'
          + '<td style="color:var(--txt3);font-size:0.75rem;text-align:center">auto</td>'
          + '<td><input id="hedit-cr" value="' + escHtml(e.clubRating!=null?String(e.clubRating):'') + '" placeholder="CR" style="width:50px;font-size:0.78rem"></td>'
          + '<td><input id="hedit-winpct" type="number" min="0" max="100" value="' + (e.winPct!=null?e.winPct:'') + '" placeholder="%" style="width:50px;font-size:0.78rem"></td>'
          + '<td><input id="hedit-gp" type="number" min="0" value="' + (e.gp!=null?e.gp:'') + '" placeholder="GP" style="width:45px;font-size:0.78rem"></td>'
          + '<td style="white-space:nowrap">'
          + '<button class="btn btn-primary btn-sm" data-hkey="' + dKey + '" data-htid="' + dTid + '" onclick="historySaveEdit(this)">✓</button> '
          + '<button class="btn btn-secondary btn-sm" onclick="historyCancelEdit()">✕</button>'
          + '</td></tr>';
      }

      return '<tr>'
        + '<td style="font-size:0.8rem;color:var(--txt3)">' + escHtml(e.date) + '</td>'
        + '<td style="font-size:0.85rem;font-weight:600">' + escHtml(e.tournament) + '</td>'
        + '<td style="font-family:monospace;font-size:0.8rem;text-align:center">' + (e.dupr!=null?e.dupr.toFixed(2):'—') + '</td>'
        + '<td style="font-family:monospace;font-size:0.8rem;text-align:center;color:' + deltaColor + '">' + deltaStr + '</td>'
        + '<td style="font-family:monospace;font-size:0.8rem;text-align:center;color:#FFD54F">' + (e.clubRating!=null?escHtml(String(e.clubRating)):'—') + '</td>'
        + '<td style="font-family:monospace;font-size:0.8rem;text-align:center">' + e.winPct + '%</td>'
        + '<td style="font-family:monospace;font-size:0.8rem;text-align:center">' + e.gp + '</td>'
        + '<td style="white-space:nowrap">'
        + '<button class="btn btn-secondary btn-sm" data-hkey="' + dKey + '" data-htid="' + dTid + '" onclick="historyStartEdit(this)" title="Edit">✏</button> '
        + '<button class="btn btn-danger btn-sm" data-hkey="' + dKey + '" data-htid="' + dTid + '" onclick="historyDeleteEntry(this)" title="Remove">✕</button>'
        + '</td></tr>';
    }).join('');

    return '<div style="margin-bottom:1rem">'
      + '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.3rem">'
      + '<div style="font-weight:700;font-size:0.95rem">' + escHtml(displayName(key)) + '</div>'
      + '<button class="btn btn-secondary btn-sm" data-hkey="' + escHtml(key) + '" onclick="historyDeletePlayer(this)" title="Remove all history for this player">🗑 Remove player</button>'
      + '</div>'
      + '<div class="tbl-wrap"><table><thead><tr>'
      + '<th>Date</th><th>Tournament</th><th>DUPR</th><th>Δ</th><th>CR</th><th>Win%</th><th>GP</th><th></th>'
      + '</tr></thead><tbody>' + rows + '</tbody></table></div>'
      + '</div>';
  }).join('');
}

function historyStartEdit(btn) {
  _histEditKey = btn.dataset.hkey;
  _histEditTid = btn.dataset.htid;
  renderHistoryModal();
  document.getElementById('hedit-tournament')?.focus();
}

function historyCancelEdit() {
  _histEditKey = null;
  _histEditTid = null;
  renderHistoryModal();
}

function historySaveEdit(btn) {
  const key = btn.dataset.hkey, tid = btn.dataset.htid;
  const hist = phLoad();
  const entry = (hist[key]||[]).find(e => e.tid === tid);
  if(!entry) return;

  const date    = document.getElementById('hedit-date')?.value.trim();
  const tourn   = document.getElementById('hedit-tournament')?.value.trim();
  const duprRaw = document.getElementById('hedit-dupr')?.value.trim();
  const cr      = document.getElementById('hedit-cr')?.value.trim();
  const wpRaw   = document.getElementById('hedit-winpct')?.value.trim();
  const gpRaw   = document.getElementById('hedit-gp')?.value.trim();

  if(!tourn) { toast('Tournament name is required', 'err'); return; }

  if(date)   entry.date       = date;
  if(tourn)  entry.tournament = tourn;
  entry.dupr      = duprRaw !== '' && !isNaN(parseFloat(duprRaw)) ? parseFloat(duprRaw) : entry.dupr;
  entry.clubRating = cr !== '' ? cr : entry.clubRating;
  entry.winPct    = wpRaw !== '' && !isNaN(parseInt(wpRaw)) ? parseInt(wpRaw) : entry.winPct;
  entry.gp        = gpRaw !== '' && !isNaN(parseInt(gpRaw)) ? parseInt(gpRaw) : entry.gp;

  // Recalculate delta vs previous entry
  const arr = (hist[key]||[]).slice().sort((a,b) => a.date.localeCompare(b.date));
  const idx = arr.findIndex(e => e.tid === tid);
  if(idx > 0 && arr[idx-1].dupr != null && entry.dupr != null) {
    entry.delta = parseFloat((entry.dupr - arr[idx-1].dupr).toFixed(3));
  }

  phSave(hist);
  _histEditKey = null;
  _histEditTid = null;
  renderHistoryModal();
  toast('✅ History entry updated');
}

function historyDeleteEntry(btn) {
  const key = btn.dataset.hkey, tid = btn.dataset.htid;
  const hist = phLoad();
  if(!hist[key]) return;
  hist[key] = hist[key].filter(e => e.tid !== tid);
  if(!hist[key].length) delete hist[key];
  phSave(hist);
  renderHistoryModal();
  if(document.getElementById('sec-season')?.classList.contains('active')) renderSeasonBoard();
  toast('Removed event from history');
}

function historyDeletePlayer(btn) {
  const key = btn.dataset.hkey;
  if(!confirm('Remove all tournament history for ' + (state.players.find(p=>p.name.trim().toLowerCase()===key)?.name || key) + '?')) return;
  const hist = phLoad();
  delete hist[key];
  phSave(hist);
  renderHistoryModal();
  if(document.getElementById('sec-season')?.classList.contains('active')) renderSeasonBoard();
  toast('Player history removed');
}

function historyClearAll() {
  if(!confirm('Clear ALL stored player history? This removes improvement-trend data for every player on this device. This cannot be undone.')) return;
  phSave({});
  renderHistoryModal();
  if(document.getElementById('sec-season')?.classList.contains('active')) renderSeasonBoard();
  toast('🗑 All player history cleared');
}

function historyExport() {
  const hist = phLoad();
  if(!Object.keys(hist).length) { toast('No history to export', 'err'); return; }
  const blob = new Blob([JSON.stringify(hist, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'pickleball_player_history.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('⬇ Exported player history');
}

// ═══════════════════════════════════════════════
//  CLUB ROSTER (persistent player list, separate from tonight's lineup)
// ═══════════════════════════════════════════════
var CLUB_ROSTER_KEY = 'pb_club_roster';

function crLoad() {
  try { return JSON.parse(localStorage.getItem(CLUB_ROSTER_KEY) || '[]'); } catch(e) { return []; }
}
function crSave(list) {
  try { localStorage.setItem(CLUB_ROSTER_KEY, JSON.stringify(list)); } catch(e) {}
}

function openClubRoster() {
  renderRosterModal();
  document.getElementById('roster-modal')?.classList.add('open');
}
function closeClubRoster() {
  document.getElementById('roster-modal')?.classList.remove('open');
  const s = document.getElementById('cr-search'); if(s) s.value = '';
}

function renderRosterModal() {
  const tableEl = document.getElementById('cr-roster-table');
  if(!tableEl) return;
  const roster = crLoad();
  if(!state._crSelected) state._crSelected = new Set();

  if(!roster.length) {
    tableEl.innerHTML = '<div style="color:var(--txt3);font-size:0.85rem;text-align:center;padding:1.5rem">'
      + 'No saved players yet. Click \'Save Tonight\'s Players to Club Roster\' to add everyone, '
      + 'or Import a previously exported Club Roster JSON.</div>';
    const cnt = document.getElementById('roster-add-count'); if(cnt) cnt.textContent = '';
    const panel = document.getElementById('cr-edit-panel');
    if(panel) panel.style.display = 'none';
    return;
  }

  const tonightStatus = new Map();
  state.players.forEach(p => tonightStatus.set(p.name.trim().toLowerCase(), p.active === false ? 'left' : 'active'));
  const editId = state._crEditId || null;

  // Populate CR and Club filter dropdowns dynamically
  const crVals   = [...new Set(roster.map(r => String(r.clubRating||'').trim()).filter(Boolean))].sort((a,b)=>{const na=parseFloat(a),nb=parseFloat(b);return !isNaN(na)&&!isNaN(nb)?na-nb:a.localeCompare(b);});
  const clubVals = [...new Set(roster.map(r => (r.club||'').trim()).filter(Boolean))].sort();
  const crSel = document.getElementById('cr-filter-cr');
  const clubSel = document.getElementById('cr-filter-club');
  if(crSel) {
    const curCR = crSel.value;
    crSel.innerHTML = '<option value="">All club ratings</option>' + crVals.map(v=>`<option value="${v}"${v===curCR?' selected':''}>${v}</option>`).join('');
  }
  if(clubSel) {
    const curClub = clubSel.value;
    clubSel.innerHTML = '<option value="">All clubs</option>' + clubVals.map(v=>`<option value="${escHtml(v)}"${v===curClub?' selected':''}>${escHtml(v)}</option>`).join('');
  }

  const q          = (document.getElementById('cr-search')?.value || '').trim().toLowerCase();
  const gFilter    = (document.getElementById('cr-filter-gender')?.value || '').toLowerCase();
  const crFilter   = (document.getElementById('cr-filter-cr')?.value || '');
  const clubFilter = (document.getElementById('cr-filter-club')?.value || '');
  const sortBy     = document.getElementById('cr-sort')?.value || 'name';

  let filtered = roster.filter(rp => {
    if(q && !rp.name.toLowerCase().includes(q) && !(rp.club||'').toLowerCase().includes(q)) return false;
    if(gFilter && (rp.gender||'').toLowerCase() !== gFilter) return false;
    if(crFilter && String(rp.clubRating||'').trim() !== crFilter) return false;
    if(clubFilter && (rp.club||'').trim() !== clubFilter) return false;
    return true;
  });

  // Sort
  filtered = [...filtered].sort((a, b) => {
    switch(sortBy) {
      case 'name-desc': return b.name.localeCompare(a.name);
      case 'dupr-desc': return (b.dupr ?? -1) - (a.dupr ?? -1);
      case 'dupr-asc':  return (a.dupr ?? 999) - (b.dupr ?? 999);
      case 'cr-desc': {
        const na = parseFloat(a.clubRating), nb = parseFloat(b.clubRating);
        return (!isNaN(nb)?nb:-1) - (!isNaN(na)?na:-1);
      }
      case 'gender': return (a.gender||'').localeCompare(b.gender||'') || a.name.localeCompare(b.name);
      default: return a.name.localeCompare(b.name);
    }
  });

  const filtersActive = q || gFilter || crFilter || clubFilter;
  const filterSummary = filtersActive ? `<div style="font-size:0.72rem;color:var(--txt3);margin-bottom:0.4rem">Showing ${filtered.length} of ${roster.length} players</div>` : '';

  tableEl.innerHTML = filterSummary + '<div class="tbl-wrap"><table><thead><tr>'
    + '<th></th><th>Name</th><th>Gender</th><th>DUPR</th><th>CR</th><th>Club</th><th>Actions</th>'
    + '</tr></thead><tbody>'
    + (filtered.length ? filtered.map(rp => {
        const sid = "'" + rp.id.replace(/'/g, "\'") + "'";
        const checked = state._crSelected.has(rp.id) ? 'checked' : '';
        const status = tonightStatus.get(rp.name.trim().toLowerCase());
        const alreadyActive = status === 'active';
        const tag = alreadyActive ? ' <span style="font-size:0.7rem;color:var(--txt3)">(tonight)</span>'
          : status === 'left' ? ' <span style="font-size:0.7rem;color:var(--ball)">(left)</span>' : '';
        const isEditing = editId === rp.id;
        return '<tr style="' + (isEditing ? 'background:rgba(198,255,0,0.08)' : alreadyActive ? 'opacity:0.5' : '') + '">'
          + '<td><input type="checkbox" ' + checked + (alreadyActive ? ' disabled' : '') + ' onchange="crToggleSelected(' + sid + ', this.checked)"></td>'
          + '<td style="font-weight:600">' + escHtml(rp.name) + tag + '</td>'
          + '<td><span class="badge badge-' + (rp.gender||'').toLowerCase() + '">' + escHtml(rp.gender||'—') + '</span></td>'
          + '<td style="font-family:monospace;color:#80CBC4">' + (rp.dupr != null ? Number(rp.dupr).toFixed(2) : '—') + '</td>'
          + '<td style="font-family:monospace;color:#FFD54F">' + (rp.clubRating || '—') + '</td>'
          + '<td style="color:var(--txt3)">' + escHtml(rp.club || '—') + '</td>'
          + '<td style="white-space:nowrap">'
          + '<button class="btn ' + (isEditing ? 'btn-primary' : 'btn-secondary') + ' btn-sm" onclick="crEdit(' + sid + ')" title="Edit">✏</button> '
          + '<button class="btn btn-danger btn-sm" onclick="crRemove(' + sid + ')" title="Remove">✕</button>'
          + '</td>'
          + '</tr>';
      }).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--txt3);padding:1rem">No players match "' + escHtml(q) + '"</td></tr>')
    + '</tbody></table></div>';

  crUpdateAddCount();
}
function crToggleSelected(id, checked) {
  if(!state._crSelected) state._crSelected = new Set();
  if(checked) state._crSelected.add(id); else state._crSelected.delete(id);
  crUpdateAddCount();
}

function crResetFilters() {
  ['cr-search','cr-filter-gender','cr-filter-cr','cr-filter-club'].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.value = '';
  });
  const srt = document.getElementById('cr-sort');
  if(srt) srt.value = 'name';
  renderRosterModal();
}

function crSelectAll(on) {
  const roster = crLoad();
  const activeNames = new Set(state.players.filter(p => p.active !== false).map(p => p.name.trim().toLowerCase()));
  // Select all respects current filter — only selects visible, non-active players
  const q          = (document.getElementById('cr-search')?.value || '').trim().toLowerCase();
  const gFilter    = (document.getElementById('cr-filter-gender')?.value || '').toLowerCase();
  const crFilter   = (document.getElementById('cr-filter-cr')?.value || '');
  const clubFilter = (document.getElementById('cr-filter-club')?.value || '');
  const visible = roster.filter(rp => {
    if(q && !rp.name.toLowerCase().includes(q) && !(rp.club||'').toLowerCase().includes(q)) return false;
    if(gFilter && (rp.gender||'').toLowerCase() !== gFilter) return false;
    if(crFilter && String(rp.clubRating||'').trim() !== crFilter) return false;
    if(clubFilter && (rp.club||'').trim() !== clubFilter) return false;
    return true;
  });
  state._crSelected = new Set(on
    ? visible.filter(rp => !activeNames.has(rp.name.trim().toLowerCase())).map(rp => rp.id)
    : []);
  renderRosterModal();
}

function crUpdateAddCount() {
  const el = document.getElementById('roster-add-count');
  if(!el) return;
  const n = (state._crSelected || new Set()).size;
  el.textContent = n ? n + ' player' + (n===1?'':'s') + ' selected' : '';
}

// Save everyone currently in tonight's roster into the persistent Club Roster
// (skips anyone already there by name; updates ratings/contact info if changed).
function rosterSaveCurrentPlayers() {
  if(!state.players.length) { toast('No players to save \u2014 add some first', 'err'); return; }
  const roster = crLoad();
  let added = 0, updated = 0;
  state.players.forEach(p => {
    const key = p.name.trim().toLowerCase();
    const existing = roster.find(rp => rp.name.trim().toLowerCase() === key);
    const entry = {
      name: p.name, gender: p.gender, dupr: p.dupr ?? null,
      clubRating: p.clubRating || '', club: p.club || '',
      phone: p.phone || '', email: p.email || '',
    };
    if(existing) {
      Object.assign(existing, entry);
      updated++;
    } else {
      roster.push({ id: 'cr_' + Date.now() + '_' + Math.random().toString(36).slice(2,7), ...entry });
      added++;
    }
  });
  crSave(roster);
  renderRosterModal();
  toast('\ud83d\udccb Club Roster: ' + added + ' added, ' + updated + ' updated');
}

// Add the checked Club Roster players into tonight's tournament as new players,
// or reactivate them if they're already on the roster but marked "Left".
// If a schedule already exists, folds them into upcoming rounds (same as addPlayer).
function rosterAddSelectedToTournament() {
  const roster = crLoad();
  const selected = state._crSelected || new Set();
  const toProcess = roster.filter(rp => selected.has(rp.id));
  if(!toProcess.length) { toast('No new players selected', 'err'); return; }

  let added = 0, reactivated = 0;
  toProcess.forEach(rp => {
    const key = rp.name.trim().toLowerCase();
    const existing = state.players.find(p => p.name.trim().toLowerCase() === key);
    if(existing) {
      if(existing.active === false) { delete existing.active; reactivated++; }
    } else {
      state.players.push({
        id: Date.now() + Math.random(), name: rp.name, gender: rp.gender, rating: null,
        dupr: rp.dupr ?? null, clubRating: rp.clubRating || '', club: rp.club || '',
        phone: rp.phone || '', email: rp.email || '',
      });
      added++;
    }
  });

  if(!added && !reactivated) { toast('No new players selected', 'err'); return; }

  let rebuilt = 0;
  if(state.schedule.length) {
    rebuilt = rebuildUpcomingRounds();
    renderSchedule(); renderTeams(); renderCourtsGrid(); updateProgress();
    if(typeof smsPopRounds === 'function') smsPopRounds();
  }

  state._crSelected = new Set();
  renderPlayers();
  renderRosterModal();
  autoSave();
  const parts = [];
  if(added) parts.push(added + ' added');
  if(reactivated) parts.push(reactivated + ' reactivated');
  toast('\u2795 ' + parts.join(', ')
    + (rebuilt > 0 ? ' \u2014 included in ' + rebuilt + ' upcoming round' + (rebuilt>1?'s':'') : ''));
}

function crEdit(id) {
  const roster = crLoad();
  const rp = roster.find(r => r.id === id);
  if(!rp) return;
  state._crEditId = id;

  // Populate panel fields
  const set = (elId, val) => { const el = document.getElementById(elId); if(el) el.value = val ?? ''; };
  set('cre-name',  rp.name);
  set('cre-gender', rp.gender || 'Male');
  set('cre-dupr',  rp.dupr ?? '');
  set('cre-cr',    rp.clubRating || '');
  set('cre-club',  rp.club || '');
  set('cre-phone', rp.phone || '');
  set('cre-email', rp.email || '');

  // Show panel, scroll it into view
  const panel = document.getElementById('cr-edit-panel');
  if(panel) {
    panel.style.display = 'block';
    try { panel.scrollIntoView({ behavior: "smooth", block: "nearest" }); } catch(e) {}
  }
  renderRosterModal(); // highlight the row being edited
  setTimeout(() => document.getElementById('cre-name')?.focus(), 50);
}

function crCancelEdit() {
  state._crEditId = null;
  const panel = document.getElementById('cr-edit-panel');
  if(panel) panel.style.display = 'none';
  renderRosterModal();
}

function crSaveEdit() {
  const id = state._crEditId;
  if(!id) return;
  const roster = crLoad();
  const rp = roster.find(r => r.id === id);
  if(!rp) return;
  const name = document.getElementById('cre-name')?.value.trim();
  if(!name) { toast('Name is required', 'err'); return; }
  const duprRaw = document.getElementById('cre-dupr')?.value.trim();
  const duprNum = duprRaw ? parseFloat(duprRaw) : null;
  if(duprRaw && (isNaN(duprNum) || duprNum < 1 || duprNum > 8)) { toast('DUPR must be 1.0–8.0', 'err'); return; }
  rp.name       = name;
  rp.gender     = document.getElementById('cre-gender')?.value || rp.gender;
  rp.dupr       = duprNum;
  rp.clubRating = document.getElementById('cre-cr')?.value.trim() || '';
  rp.club       = document.getElementById('cre-club')?.value.trim() || '';
  rp.phone      = document.getElementById('cre-phone')?.value.trim() || '';
  rp.email      = document.getElementById('cre-email')?.value.trim() || '';
  crSave(roster);
  state._crEditId = null;
  const panel = document.getElementById('cr-edit-panel');
  if(panel) panel.style.display = 'none';
  renderRosterModal();
  toast('✓ ' + name + ' saved');
}

function crClearAll() {
  const roster = crLoad();
  if(!roster.length) return;
  if(!confirm('Remove all ' + roster.length + ' players from the Club Roster? This cannot be undone.')) return;
  crSave([]);
  state._crSelected = new Set();
  state._crEditId   = null;
  renderRosterModal();
  toast('Club Roster cleared');
}

function crRemove(id) {
  let roster = crLoad();
  const rp = roster.find(r => r.id === id);
  if(!rp) return;
  if(!confirm('Remove ' + rp.name + ' from the Club Roster? (Does not affect tonight\\\'s players.)')) return;
  roster = roster.filter(r => r.id !== id);
  crSave(roster);
  if(state._crSelected) state._crSelected.delete(id);
  renderRosterModal();
}

function rosterExport() {
  const roster = crLoad();
  if(!roster.length) { toast('No Club Roster to export', 'err'); return; }
  const blob = new Blob([JSON.stringify(roster, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'pickleball_club_roster.json';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('\u2b07 Exported Club Roster');
}

function rosterImport(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    let imported;
    try { imported = JSON.parse(e.target.result); } catch(err) { toast('Invalid JSON file', 'err'); return; }
    if(!Array.isArray(imported)) { toast('Unrecognized Club Roster file format', 'err'); return; }
    const roster = crLoad();
    let added = 0, updated = 0;
    imported.forEach(rp => {
      if(!rp || !rp.name) return;
      const key = rp.name.trim().toLowerCase();
      const existing = roster.find(r => r.name.trim().toLowerCase() === key);
      const entry = {
        name: rp.name, gender: rp.gender || '', dupr: rp.dupr ?? null,
        clubRating: rp.clubRating || '', club: rp.club || '', phone: rp.phone || '', email: rp.email || '',
      };
      if(existing) { Object.assign(existing, entry); updated++; }
      else { roster.push({ id: rp.id || ('cr_' + Date.now() + '_' + Math.random().toString(36).slice(2,7)), ...entry }); added++; }
    });
    crSave(roster);
    renderRosterModal();
    toast('\u2b06 Imported: ' + added + ' new, ' + updated + ' updated');
  };
  reader.readAsText(file);
  event.target.value = '';
}

// ═══════════════════════════════════════════════
//  FULL BACKUP / RESTORE
//  Bundles: current tournament (same shape as Save), player history,
//  Club Roster, and Email/SMTP config into one file.
// ═══════════════════════════════════════════════
function openBackupModal() {
  const tournament = buildSaveData();
  const hist = phLoad();
  const roster = crLoad();
  let emailCfg = {};
  try { emailCfg = JSON.parse(localStorage.getItem(EM_STORE) || '{}'); } catch(e) {}
  let twCfg = {};
  try { twCfg = JSON.parse(localStorage.getItem('pb_tw') || '{}'); } catch(e) {}

  const histPlayers = Object.keys(hist).length;
  const histEvents = Object.values(hist).reduce((sum, arr) => sum + (Array.isArray(arr) ? arr.length : 0), 0);
  const emailConfigured = !!(emailCfg.host && emailCfg.user);

  const summary = document.getElementById('backup-summary');
  if(summary) {
    summary.innerHTML =
      '\ud83c\udfd3 <strong>Current tournament:</strong> ' + escHtml(getTournamentName()) + ' \u2014 ' + tournament.state.players.length + ' players, '
        + tournament.state.schedule.length + ' rounds<br>'
      + '\ud83d\udcca <strong>Player history:</strong> ' + histPlayers + ' player' + (histPlayers===1?'':'s') + ', '
        + histEvents + ' tournament record' + (histEvents===1?'':'s') + '<br>'
      + '\ud83d\udccb <strong>Club Roster:</strong> ' + roster.length + ' saved player' + (roster.length===1?'':'s') + '<br>'
      + '\u2699\ufe0f <strong>Email/SMS:</strong> handled by your hosted relay (not stored in this browser backup)';
  }
  document.getElementById('backup-modal')?.classList.add('open');
}
function closeBackupModal() {
  document.getElementById('backup-modal')?.classList.remove('open');
}

function backupExportAll() {
  let emailCfg = {};
  try { emailCfg = JSON.parse(localStorage.getItem(EM_STORE) || '{}'); } catch(e) {}
  let twCfgExport = {};
  try { twCfgExport = JSON.parse(localStorage.getItem('pb_tw') || '{}'); } catch(e) {}
  const bundle = {
    backupVersion: '1.0',
    savedAt: new Date().toISOString(),
    tournament: buildSaveData(),
    playerHistory: phLoad(),
    clubRoster: crLoad(),
    emailConfig: emailCfg,
    twilioConfig: twCfgExport,
    smsLabel: (() => { try { return localStorage.getItem('pb_sms_label') || ''; } catch(e) { return ''; } })(),
  };
  const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const name = `pickleball_backup_${new Date().toISOString().slice(0,10)}.json`;
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast('\ud83d\udce6 Backup saved as ' + name);
}

function backupImportAll(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    let bundle;
    try { bundle = JSON.parse(e.target.result); } catch(err) { toast('Invalid JSON file', 'err'); return; }
    if(!bundle || typeof bundle !== 'object') { toast('Unrecognized backup file format', 'err'); return; }

    const parts = [];

    if(bundle.tournament && bundle.tournament.state) {
      restoreSaveData(bundle.tournament);
      renderPlayers(); renderTeams(); renderSchedule(); renderCourtsGrid();
      updateCourtSelectorUI(); updateProgress(); renderStandings(); renderPlayoffs();
      onModeChange();
      if(typeof showUndoButton === 'function') showUndoButton();
      parts.push('tournament restored');
    }

    if(bundle.playerHistory && typeof bundle.playerHistory === 'object' && !Array.isArray(bundle.playerHistory)) {
      const hist = phLoad();
      let added = 0, merged = 0;
      Object.entries(bundle.playerHistory).forEach(([key, arr]) => {
        if(!Array.isArray(arr)) return;
        const existing = hist[key] || [];
        arr.forEach(ev => {
          if(!ev || !ev.tid) return;
          const i = existing.findIndex(x => x.tid === ev.tid);
          if(i >= 0) { existing[i] = ev; merged++; } else { existing.push(ev); added++; }
        });
        hist[key] = existing;
      });
      phSave(hist);
      parts.push('history: ' + added + ' new / ' + merged + ' updated');
    }

    if(Array.isArray(bundle.clubRoster)) {
      crSave(bundle.clubRoster);
      parts.push('club roster: ' + bundle.clubRoster.length + ' players');
    }

    if(bundle.emailConfig && typeof bundle.emailConfig === 'object') {
      try { localStorage.setItem(EM_STORE, JSON.stringify(bundle.emailConfig)); } catch(err) {}
      if(typeof emLoad === 'function') emLoad();
      parts.push('email settings restored');
    }

    if(bundle.twilioConfig && typeof bundle.twilioConfig === 'object' && bundle.twilioConfig.sid) {
      try { localStorage.setItem('pb_tw', JSON.stringify(bundle.twilioConfig)); } catch(err) {}
      if(typeof twLoad === 'function') twLoad();
      parts.push('SMS settings restored');
    }

    // Also restore SMS label and datetime preferences if present
    if(bundle.smsLabel != null) {
      try { localStorage.setItem('pb_sms_label', bundle.smsLabel); } catch(e) {}
      const lbl = document.getElementById('sms-sender-label');
      if(lbl) lbl.value = bundle.smsLabel;
    }

    closeBackupModal();
    toast('\ud83d\udce6 Restored: ' + parts.join(', '));
  };
  reader.readAsText(file);
  event.target.value = '';
}

function historyImport(event) {
  const file = event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    let imported;
    try { imported = JSON.parse(e.target.result); } catch(err) { toast('Invalid JSON file', 'err'); return; }
    if(typeof imported !== 'object' || Array.isArray(imported)) { toast('Unrecognized history file format', 'err'); return; }
    const hist = phLoad();
    let added = 0, merged = 0;
    Object.entries(imported).forEach(([key, arr]) => {
      if(!Array.isArray(arr)) return;
      const existing = hist[key] || [];
      arr.forEach(e => {
        if(!e || !e.tid) return;
        const i = existing.findIndex(x => x.tid === e.tid);
        if(i >= 0) { existing[i] = e; merged++; } else { existing.push(e); added++; }
      });
      hist[key] = existing;
    });
    phSave(hist);
    renderHistoryModal();
    toast('⬆ Imported: ' + added + ' new, ' + merged + ' updated');
  };
  reader.readAsText(file);
  event.target.value = '';
}


function autoSave() {
  clearTimeout(_autoSaveTimer);
  _autoSaveTimer = setTimeout(() => {
    try {
      const data = buildSaveData();
      localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(data));
      const el = document.getElementById('autosave-indicator');
      if(el) {
        const now = new Date();
        el.textContent = `✓ ${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
      }
    } catch(e) { /* localStorage full or unavailable */ }
  }, 2000);
}

function buildSaveData() {
  return {
    version: '2.0', savedAt: new Date().toISOString(),
    state: {
      players: state.players, waitlist: state.waitlist || [], teams: state.teams, roundTeams: state.roundTeams,
      schedule: state.schedule, roundHistory: state.roundHistory, byeRounds: state.byeRounds,
      notifiedRounds: Array.from(state.notifiedRounds),
      startedRounds: Array.from(state.startedRounds || []),
      selectedCourts: Array.from(state.selectedCourts),
      partnerLocks: state.partnerLocks || [],
      _ldAnnouncement: state._ldAnnouncement || '',
    },
    riverState: {
      enabled: riverState.enabled, numCourts: riverState.numCourts,
      partnerMode: riverState.partnerMode, winPts: riverState.winPts,
      currentRound: riverState.currentRound, courts: riverState.courts, stats: riverState.stats,
    },
    playoffState: {
      active: playoffState.active, format: playoffState.format,
      partnerMode: playoffState.partnerMode, seedBy: playoffState.seedBy,
      rounds: playoffState.rounds, activeRoundIdx: playoffState.activeRoundIdx,
      seeds: playoffState.seeds, champion: playoffState.champion,
    },
    tournamentName: getTournamentName(),
    tournamentDateTime: getTournamentDateTime(),
    timerMinutes: document.getElementById('timer-minutes')?.value || '11',
    settings: {
      teamMode: document.getElementById('team-mode')?.value,
      maxRounds: document.getElementById('max-rounds')?.value,
      duprAggCap: document.getElementById('dupr-agg-cap')?.value,
      duprMaxInd: document.getElementById('dupr-max-ind')?.value,
      duprNrDef: document.getElementById('dupr-nr-default')?.value,
      duprRangeTol: document.getElementById('dupr-range-tol')?.value,
    }
  };
}

function restoreSaveData(data) {
  const s = data.state;
  state.players        = s.players        || [];
  // Backfill checkedIn for saves from before this feature existed — default
  // everyone to checked-in so loading an older tournament doesn't suddenly
  // exclude the whole roster from scheduling.
  state.players.forEach(p => { if(p.checkedIn === undefined) p.checkedIn = true; });
  state.waitlist        = s.waitlist        || [];
  state.teams          = s.teams          || [];
  state.roundTeams     = s.roundTeams     || [];
  state.schedule       = s.schedule       || [];
  state.roundHistory   = s.roundHistory   || [];
  state.byeRounds      = s.byeRounds      || [];
  state.notifiedRounds = new Set(s.notifiedRounds || []);
  state.startedRounds  = new Set(s.startedRounds  || []);
  // One-time backfill, not an ongoing rule: mobile sync now treats "▶
  // Start Round" as the ONLY way a round becomes visible to scorekeepers'
  // phones — no other implicit path in, by design. But a tournament
  // already in progress before this rule existed may have real,
  // already-submitted scores in a round that was never explicitly marked
  // started (because the old, looser rule didn't require it). Without
  // this, loading that tournament under the new strict rule would yank
  // those in-progress courts out from under players mid-match. This scan
  // runs every time a save is restored, but is a no-op for any round
  // already in startedRounds — it only ever ADDS rounds that have real
  // scores and were missing the explicit flag, never removes anything.
  state.schedule.forEach((round, i) => {
    if(round.some(m => m.complete) && !state.startedRounds.has(i)) state.startedRounds.add(i);
  });
  state.selectedCourts = new Set(s.selectedCourts || Array.from({length:MAX_COURTS},(_,i)=>i+1));
  state.partnerLocks   = s.partnerLocks   || [];
  state._ldAnnouncement = s._ldAnnouncement || '';
  if(data.riverState)   Object.assign(riverState,   data.riverState);
  if(data.playoffState) Object.assign(playoffState, data.playoffState);
  if(data.settings) {
    const ids = ['team-mode','max-rounds','dupr-agg-cap','dupr-max-ind','dupr-nr-default','dupr-range-tol'];
    const vals = [data.settings.teamMode, data.settings.maxRounds, data.settings.duprAggCap,
                  data.settings.duprMaxInd, data.settings.duprNrDef, data.settings.duprRangeTol];
    ids.forEach((id,i) => { const el=document.getElementById(id); if(el&&vals[i]) el.value=vals[i]; });
  }
  if(data.timerMinutes)   { const el=document.getElementById('timer-minutes');   if(el) { el.value=data.timerMinutes; resetTimer(); } }
  if(data.tournamentName) { const el=document.getElementById('tournament-name'); if(el) { el.value=data.tournamentName; updateTournamentName(); } }
  if(data.tournamentDateTime) { const el=document.getElementById('tournament-datetime'); if(el) { el.value=data.tournamentDateTime; updateTournamentName(); } }
}

function loadAutoSave() {
  try {
    const raw = localStorage.getItem(AUTO_SAVE_KEY);
    if(!raw) return false;
    const data = JSON.parse(raw);
    if(!data.state?.players?.length) return false;
    const savedAt = data.savedAt ? new Date(data.savedAt).toLocaleString() : 'unknown';
    const n = data.state.players.length;
    const m = (data.state.schedule||[]).flat().length;
    if(!confirm(`Resume previous session?\n${n} players · ${m} matches\nLast saved: ${savedAt}`)) return false;
    restoreSaveData(data);
    return true;
  } catch(e) { return false; }
}

function clearAutoSave() {
  try { localStorage.removeItem(AUTO_SAVE_KEY); } catch(e) {}
}

// ═══════════════════════════════════════════════
//  CROSS-WINDOW LIVE SYNC
//  When scoring in one window, live display in
//  another window on the same server updates instantly.
// ═══════════════════════════════════════════════
const _liveChannel = typeof BroadcastChannel !== 'undefined'
  ? new BroadcastChannel('pb_live_sync') : null;

function _liveBroadcast() {
  // Send the full state so the receiving window can render without its own copy
  const payload = JSON.stringify({ type: 'score_update', state: {
    players:        state.players,
    schedule:       state.schedule,
    byeRounds:      state.byeRounds,
    roundHistory:   state.roundHistory,
    _ldAnnouncement: state._ldAnnouncement || '',
  }});
  if(_liveChannel) {
    try { _liveChannel.postMessage(payload); } catch(e) {}
  }
  // localStorage fallback for browsers without BroadcastChannel
  try { localStorage.setItem('pb_live_sync', payload); } catch(e) {}
}

// Receive updates — applies to the window running the live display
if(_liveChannel) {
  _liveChannel.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      if(msg.type !== 'score_update') return;
      // Merge incoming state
      state.players        = msg.state.players;
      state.schedule       = msg.state.schedule;
      state.byeRounds      = msg.state.byeRounds      || [];
      state.roundHistory   = msg.state.roundHistory   || [];
      state._ldAnnouncement = msg.state._ldAnnouncement || '';
      if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
    } catch(err) {}
  };
}

// localStorage fallback listener
window.addEventListener('storage', (e) => {
  if(e.key !== 'pb_live_sync' || !e.newValue) return;
  try {
    const msg = JSON.parse(e.newValue);
    if(msg.type !== 'score_update') return;
    state.players         = msg.state.players;
    state.schedule        = msg.state.schedule;
    state.byeRounds       = msg.state.byeRounds       || [];
    state.roundHistory    = msg.state.roundHistory    || [];
    state._ldAnnouncement = msg.state._ldAnnouncement || '';
    if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  } catch(err) {}
});
var _undoStack = [];
var MAX_UNDO = 10;
const UNDO_STORE_KEY = 'pb_undo_stack';

function _saveUndoStack() {
  try { localStorage.setItem(UNDO_STORE_KEY, JSON.stringify(_undoStack)); } catch(e) {}
}

function _loadUndoStack() {
  try {
    const raw = localStorage.getItem(UNDO_STORE_KEY);
    if(raw) _undoStack = JSON.parse(raw) || [];
  } catch(e) { _undoStack = []; }
}

function pushUndo(matchId, prevScoreA, prevScoreB, prevComplete) {
  _undoStack.push({ matchId, prevScoreA, prevScoreB, prevComplete });
  if(_undoStack.length > MAX_UNDO) _undoStack.shift();
  _saveUndoStack();
  showUndoButton();
}

function showUndoButton() {
  const btn = document.getElementById('undo-btn');
  if(!btn) return;
  if(_undoStack.length) {
    btn.style.display = 'inline-flex';
    const { matchId } = _undoStack[_undoStack.length-1];
    const m = state.schedule.flat().find(x => x.id === matchId);
    if(m) {
      const ta = matchTeamName(m.teamA);
      const tb = matchTeamName(m.teamB);
      btn.title = `Undo score: ${ta} ${m.scoreA}–${m.scoreB} ${tb}`;
      btn.textContent = `↩ Undo`;
    }
  } else {
    btn.style.display = 'none';
  }
}

function undoLastScore() {
  if(!_undoStack.length) { toast('Nothing to undo','err'); return; }
  const { matchId, prevScoreA, prevScoreB, prevComplete } = _undoStack.pop();
  _saveUndoStack();
  const m = state.schedule.flat().find(x => x.id === matchId);
  if(!m) { showUndoButton(); return; }

  // Restore previous state
  m.scoreA = prevScoreA;
  m.scoreB = prevScoreB;
  m.complete = prevComplete;
  if(!prevComplete) m.winner = null; // clear winner if match wasn't complete before

  // Also restore river board if applicable
  if(m.isRiverMatch && riverState.enabled) {
    const ct = riverState.courts.find(c => c.court === m.court && riverState.currentRound === m.round);
    if(ct) { ct.scoreA = prevScoreA; ct.scoreB = prevScoreB; ct.complete = prevComplete; }
    renderRiverBoard();
  }

  // Remove round-complete notification for this round if it was just triggered
  const roundIdx = state.schedule.findIndex(r => r.some(x => x.id === matchId));
  if(roundIdx !== -1 && !prevComplete) {
    state.notifiedRounds.delete(roundIdx);
    const msg = document.getElementById('round-complete-msg');
    if(msg) msg.style.display = 'none';
  }

  showUndoButton();
  renderSchedule();
  updateProgress();
  renderStandings();
  autoSave();
  toast(`↩ Score undone`);
}

// ── Init ──────────────────────────────────────
renderPlayers();
renderCourtsGrid();
onModeChange();
updateCourtSelectorUI();
updateTimerDisplay();
showUndoButton();

// Try to restore auto-saved session on load
if(loadAutoSave()) {
  renderPlayers();
  renderTeams();
  renderSchedule();
  renderCourtsGrid();
  updateCourtSelectorUI();
  updateProgress();
  renderStandings();
  renderPlayoffs();
  onModeChange();
  _loadUndoStack();
  showUndoButton();
  if(riverState.enabled) renderRiverBoard();
  toast('📂 Previous session restored');
}
_loadUndoStack(); // also load on fresh start in case of partial reload


// ════════════════════════════════════════════
//  REPORT TAB
// ════════════════════════════════════════════
function renderReport() {
  const tname = getTournamentName();
  const el    = document.getElementById('report-title');
  if(el) el.textContent = tname + ' — Report';

  const sub = document.getElementById('report-subtitle');
  if(sub) {
    const totalRounds  = state.schedule.length;
    const doneMatches  = state.schedule.flat().filter(m => m.complete).length;
    const totalMatches = state.schedule.flat().length;
    sub.textContent = totalRounds + ' rounds · ' + doneMatches + '/' + totalMatches + ' matches complete · ' + state.players.length + ' players';
  }

  const stats = buildPlayerStats();
  if(!stats.length) {
    document.getElementById('report-tbody').innerHTML = '<tr><td colspan="19" style="text-align:center;color:var(--txt3);padding:2rem">Generate a schedule and enter scores to see the report.</td></tr>';
    reportSummaryGrid([]);
    ['report-dupr-impact','report-trends','report-h2h'].forEach(id => {
      const el = document.getElementById(id); if(el) el.innerHTML = '';
    });
    return;
  }

  // ── Filters ──────────────────────────────
  const search  = (document.getElementById('report-search')?.value || '').toLowerCase();
  const sortBy  = document.getElementById('report-sort')?.value   || 'pts';
  const gender  = document.getElementById('report-gender')?.value || 'all';

  let data = stats.map(s => {
    const g     = s.games;
    const pf    = g.reduce((a, x) => a + Number(x.pts), 0);
    const pa    = g.reduce((a, x) => a + Number(x.opponentPts), 0);
    const wins  = g.filter(x => x.won).length;
    const losses= g.filter(x => !x.won && !x.tied).length;
    const ties  = g.filter(x => x.tied).length;
    const gp    = g.length;
    const winPct= gp ? Math.round((wins / gp) * 100) : 0;
    const diff  = pf - pa;
    const avg   = gp ? (pf / gp) : 0;
    const best  = gp ? Math.max(...g.map(x => Number(x.pts))) : 0;
    const worst = gp ? Math.min(...g.map(x => Number(x.pts))) : 0;
    // Current streak
    let streak = 0, streakType = '';
    for(let i = g.length - 1; i >= 0; i--) {
      const t = g[i].won ? 'W' : g[i].tied ? 'T' : 'L';
      if(i === g.length - 1) { streakType = t; streak = 1; }
      else if(t === streakType) streak++;
      else break;
    }
    return { ...s, pf, pa, wins, losses, ties, gp, winPct, diff, avg, best, worst,
             streak, streakType };
  });

  // Filter
  data = data.filter(d =>
    d.player.name.toLowerCase().includes(search) &&
    (gender === 'all' || d.player.gender === gender)
  );

  // Sort
  data.sort((a, b) => {
    if(sortBy === 'pts')    return b.totalPts - a.totalPts;
    if(sortBy === 'wins')   return b.wins - a.wins;
    if(sortBy === 'winpct') return b.winPct - a.winPct;
    if(sortBy === 'avg')    return b.avg - a.avg;
    if(sortBy === 'pf')     return b.pf - a.pf;
    if(sortBy === 'pa')     return a.pa - b.pa;
    if(sortBy === 'diff')   return b.diff - a.diff;
    if(sortBy === 'name')   return a.player.name.localeCompare(b.player.name);
    return 0;
  });

  reportSummaryGrid(data);
  reportAwards(data);
  reportDuprImpact(data);
  recordPlayerHistory(data);
  reportTrends(data);
  reportH2H(data);

  // ── Leaderboard table ──────────────────────
  const tbody = document.getElementById('report-tbody');
  if(!data.length) {
    tbody.innerHTML = '<tr><td colspan="19" style="text-align:center;color:var(--txt3);padding:2rem">No players match the filter.</td></tr>';
  } else {
    tbody.innerHTML = data.map((d, i) => {
      const rank     = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1;
      const dupr     = d.player.dupr != null ? d.player.dupr.toFixed(2) : '—';
      const diffCol  = d.diff > 0 ? 'var(--lime)' : d.diff < 0 ? 'var(--red)' : 'var(--txt3)';
      const diffStr  = d.diff > 0 ? '+' + d.diff : String(d.diff);
      const wPct     = d.gp ? d.winPct + '%' : '—';
      const streakCol = d.streakType === 'W' ? 'var(--lime)' : d.streakType === 'L' ? 'var(--red)' : 'var(--txt3)';
      const streakStr = d.gp ? d.streak + d.streakType : '—';
      return '<tr>'
        + '<td style="font-family:\'Bebas Neue\',sans-serif;font-size:1.1rem">' + rank + '</td>'
        + '<td style="font-weight:700">' + escHtml(d.player.name) + '</td>'
        + '<td><span class="badge badge-' + d.player.gender.toLowerCase() + '">' + d.player.gender + '</span></td>'
        + '<td style="color:var(--txt3);font-size:0.8rem">' + escHtml(d.player.club || '—') + '</td>'
        + '<td style="font-family:monospace;color:#80CBC4">' + dupr + '</td>'
        + '<td style="font-family:monospace;color:#FFD54F">' + escHtml(d.player.clubRating || '—') + '</td>'
        + '<td style="font-family:monospace">' + d.gp + '</td>'
        + '<td style="font-family:monospace;color:var(--lime);font-weight:700">' + d.wins + '</td>'
        + '<td style="font-family:monospace;color:var(--red)">' + d.losses + '</td>'
        + '<td style="font-family:monospace;color:var(--txt3)">' + d.ties + '</td>'
        + '<td style="font-family:monospace;font-weight:700">' + wPct + '</td>'
        + '<td style="font-family:monospace">' + d.pf + '</td>'
        + '<td style="font-family:monospace;color:var(--txt3)">' + d.pa + '</td>'
        + '<td style="font-family:monospace;color:' + diffCol + ';font-weight:700">' + diffStr + '</td>'
        + '<td style="font-family:monospace">' + d.avg.toFixed(1) + '</td>'
        + '<td style="font-family:monospace;color:var(--lime)">' + d.best + '</td>'
        + '<td style="font-family:monospace;color:var(--red)">' + d.worst + '</td>'
        + '<td style="font-family:monospace;color:' + streakCol + ';font-weight:700">' + streakStr + '</td>'
        + '<td>' + emailBtnFor(d.player) + '</td>'
        + '</tr>';
    }).join('');
  }

}

// Sum each player's actual per-match DUPR deltas (same Elo-like K=0.1 formula used
// in the live match preview), using real teammate/opponent ratings for each game.
function reportDuprImpact(data) {
  const el = document.getElementById('report-dupr-impact');
  if(!el) return;
  const active = data.filter(d => d.gp > 0);
  if(!active.length) { el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem">Enter match scores to see DUPR impact.</div>'; return; }

  const nr = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
  const ratingOf = i => { const p = state.players[i]; return (p?.dupr != null && !isNaN(p.dupr)) ? p.dupr : nr; };

  const rows = active.map(s => {
    const myRating = ratingOf(s.playerIdx);
    let delta = 0;
    s.games.forEach(g => {
      if(g.tied) return; // no rating change on a tie
      const teamAvg = g.partnerIdx !== undefined ? (myRating + ratingOf(g.partnerIdx)) / 2 : myRating;
      const oppAvg  = g.opponentIdxs && g.opponentIdxs.length
        ? g.opponentIdxs.reduce((sum,oi) => sum + ratingOf(oi), 0) / g.opponentIdxs.length
        : myRating;
      const exp = duprExpectedScore(teamAvg, oppAvg);
      delta += 0.1 * ((g.won ? 1 : 0) - exp);
    });
    return { player: s.player, startRating: myRating, delta: +delta.toFixed(3), gp: s.gp, _stat: s };
  }).sort((a,b) => b.delta - a.delta);

  // Make the computed delta available to recordPlayerHistory via the original stat row
  rows.forEach(r => { r._stat._duprDelta = r.delta; });

  const maxAbs = Math.max(...rows.map(r => Math.abs(r.delta)), 0.01);
  el.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:0.5rem">'
    + rows.map(r => {
        const sign = r.delta > 0 ? '+' : '';
        const color = r.delta > 0 ? 'var(--lime)' : r.delta < 0 ? 'var(--red)' : 'var(--txt3)';
        const newRating = (r.startRating + r.delta).toFixed(2);
        const barPct = Math.round((Math.abs(r.delta) / maxAbs) * 100);
        return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.45rem 0.6rem">'
          + '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:3px">'
          + '<span style="font-size:0.82rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + escHtml(r.player.name.split(' ')[0]) + '</span>'
          + '<span style="font-family:monospace;font-size:0.8rem;font-weight:700;color:' + color + '">' + sign + r.delta + '</span>'
          + '</div>'
          + '<div style="background:var(--bg);border-radius:3px;height:5px;overflow:hidden;margin-bottom:3px">'
          + '<div style="height:100%;background:' + color + ';width:' + barPct + '%;border-radius:3px;' + (r.delta < 0 ? 'margin-left:' + (100-barPct) + '%' : '') + '"></div>'
          + '</div>'
          + '<div style="font-size:0.7rem;color:var(--txt3)">' + r.startRating.toFixed(2) + ' \u2192 ' + newRating + '</div>'
          + '</div>';
      }).join('')
    + '</div>'
    + '<div style="font-size:0.72rem;color:var(--txt3);margin-top:0.6rem">Estimate only \u2014 based on an Elo-like formula (K=0.1), not your official DUPR.</div>';
}

// Cross-tournament improvement: compare this tournament's results to each player's
// prior tournaments (from PLAYER_HISTORY_KEY). Shows DUPR trend and win% trend.
function reportH2H(data) {
  const el = document.getElementById('report-h2h');
  if(!el) return;
  const active = data.filter(d => d.gp > 0);
  if(active.length < 2) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem;padding:1rem 0">Enter match scores to see head-to-head records.</div>';
    return;
  }

  // Build H2H map keyed by TEAM PAIR — one row per unique team matchup.
  // Key = sorted indices of both teams combined, so "Alex&Sam vs Jamie&Pat"
  // is always the same entry regardless of which was teamA or teamB.
  const h2h = {};
  state.schedule.forEach(round => round.forEach(m => {
    if(!m.complete || !m.teamA || !m.teamB) return;
    const sigA = [...m.teamA].sort((a,b)=>a-b).join(',');
    const sigB = [...m.teamB].sort((a,b)=>a-b).join(',');
    // Canonical order: lower sig first
    const [loSig, hiSig, loTeam, hiTeam] = sigA < sigB
      ? [sigA, sigB, m.teamA, m.teamB]
      : [sigB, sigA, m.teamB, m.teamA];
    const key = loSig + '|' + hiSig;
    const teamName = idxs => idxs.map(i => (state.players[i]?.name||'?').split(' ')[0]).join(' & ');
    if(!h2h[key]) h2h[key] = {
      nameA: teamName(loTeam),
      nameB: teamName(hiTeam),
      loTeam, hiTeam,
      winsLo: 0, winsHi: 0, games: 0, scores: []
    };
    const rec = h2h[key];
    rec.games++;
    const aWon = m.scoreA > m.scoreB;
    const loIsTeamA = sigA >= sigB; // loSig came from teamB when sigB < sigA
    const sLo = loIsTeamA ? +m.scoreA : +m.scoreB;
    const sHi = loIsTeamA ? +m.scoreB : +m.scoreA;
    const loWon = loIsTeamA ? aWon : !aWon;
    if(loWon) rec.winsLo++; else rec.winsHi++;
    rec.scores.push({ sLo, sHi });
  }));

  const pairs = Object.values(h2h).sort((a,b) => b.games - a.games);
  if(!pairs.length) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem;padding:1rem 0">No completed matches yet.</div>';
    return;
  }

  const row = (p) => {
    const loLeads = p.winsLo >= p.winsHi;
    const winner  = loLeads ? p.nameA : p.nameB;
    const loser   = loLeads ? p.nameB : p.nameA;
    const wW = loLeads ? p.winsLo : p.winsHi;
    const wL = loLeads ? p.winsHi : p.winsLo;
    const tied = wW === wL;
    const scoreStr = p.scores.map(s => {
      const s1 = loLeads ? s.sLo : s.sHi;
      const s2 = loLeads ? s.sHi : s.sLo;
      return s1 + '–' + s2;
    }).join('  ');

    return `<tr>
      <td style="font-weight:700;color:${tied?'var(--txt)':'var(--lime)'};padding:0.55rem 0.9rem;white-space:nowrap">${escHtml(winner)}</td>
      <td style="font-family:'JetBrains Mono',monospace;font-weight:800;font-size:1rem;color:${tied?'var(--ball)':'var(--lime)'};text-align:center;padding:0.55rem 0.75rem;white-space:nowrap">${wW}–${wL}</td>
      <td style="color:${tied?'var(--txt3)':'var(--txt)'};padding:0.55rem 0.9rem;white-space:nowrap">${escHtml(loser)}</td>
      <td style="font-family:'JetBrains Mono',monospace;font-size:0.75rem;color:var(--txt3);padding:0.55rem 0.9rem">${escHtml(scoreStr)}</td>
    </tr>`;
  };

  el.innerHTML = `
    <div class="tbl-wrap">
      <table>
        <thead><tr>
          <th>Winner</th>
          <th style="text-align:center">Record</th>
          <th>vs</th>
          <th>Scores</th>
        </tr></thead>
        <tbody>${pairs.map(row).join('')}</tbody>
      </table>
    </div>`;
}


function reportTrends(data) {
  const el = document.getElementById('report-trends');
  const sub = document.getElementById('report-trends-sub');
  if(!el) return;
  // Everyone on the active roster, regardless of whether they've played/been scored yet —
  // a player on a bye, or whose match isn't entered yet, still has tournament history to show.
  const roster = data.filter(d => d.player.active !== false);
  if(!roster.length) { el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem">Add players to see trends.</div>'; if(sub) sub.textContent = ''; return; }

  const hist = phLoad();
  const rows = roster.map(s => {
    const key = s.player.name.trim().toLowerCase();
    const arr = (hist[key] || []).slice().sort((a,b) => a.date.localeCompare(b.date) || a.tid.localeCompare(b.tid));
    const past = arr.filter(e => e.tid !== state._historyId);
    return { player: s.player, winPct: s.winPct, gp: s.gp, history: arr, past };
  });

  const withHistory = rows.filter(r => r.past.length > 0);
  if(sub) sub.textContent = withHistory.length
    ? withHistory.length + ' of ' + rows.length + ' player' + (rows.length===1?'':'s') + ' with prior tournament data'
    : 'First tournament tracked for this group \u2014 trends will appear next time';

  const sparkline = (vals, color) => {
    const clean = vals.filter(v => typeof v === 'number' && !isNaN(v));
    if(clean.length < 2) return '';
    const max = Math.max(...clean, 1), min = Math.min(...clean, 0);
    const range = (max - min) || 1;
    const w = 60, h = 18, step = w / (clean.length - 1);
    const pts = clean.map((v,i) => (i*step) + ',' + (h - ((v-min)/range)*h)).join(' ');
    return `<svg width="${w}" height="${h}" style="vertical-align:middle"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.5"/></svg>`;
  };

  // Players WITH prior history: full trend card (DUPR change, win% sparkline)
  const ranked = withHistory.map(r => {
    const firstDupr = r.past.find(e => e.dupr != null)?.dupr ?? null;
    const lastTournament = r.history[r.history.length - 1];
    const curDupr = lastTournament.dupr != null ? lastTournament.dupr
      : (state.players.find(p => p.id === r.player.id)?.dupr ?? null);
    const overallChange = (firstDupr != null && curDupr != null) ? curDupr - firstDupr : null;
    const lastPastWithDupr = [...r.past].reverse().find(e => e.dupr != null);
    const sinceLastChange = (lastPastWithDupr && curDupr != null) ? curDupr - lastPastWithDupr.dupr : null;
    const winPctTrend = r.history.map(e => e.winPct).filter(v => typeof v === 'number');

    // Club Rating: discrete level, not a computed score — track first-seen vs current,
    // flag a promotion/demotion if the level itself changed.
    const firstCR = r.past.find(e => e.clubRating != null)?.clubRating ?? null;
    const curCR = lastTournament.clubRating != null ? lastTournament.clubRating
      : (state.players.find(p => p.id === r.player.id)?.clubRating || null);
    const crChanged = firstCR != null && curCR != null && firstCR !== curCR;

    return { ...r, overallChange, sinceLastChange, winPctTrend, eventCount: r.history.length, isNew: false,
             firstCR, curCR, crChanged };
  }).sort((a,b) => (b.overallChange ?? -99) - (a.overallChange ?? -99));

  // Players with NO prior history yet: still show them, so nobody silently disappears
  const newcomers = rows.filter(r => r.past.length === 0).map(r => ({
    ...r, overallChange: null, sinceLastChange: null, winPctTrend: [], eventCount: 1, isNew: true,
    curCR: state.players.find(p => p.id === r.player.id)?.clubRating || null,
  }));

  const all = [...ranked, ...newcomers];

  el.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:0.6rem">'
    + all.map(r => {
        const noGameYet = !r.gp;
        if(r.isNew) {
          return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.5rem 0.65rem">'
            + '<div style="display:flex;justify-content:space-between;align-items:baseline">'
            + '<span style="font-weight:700;font-size:0.88rem">' + escHtml(r.player.name.split(' ')[0]) + '</span>'
            + '<span style="font-size:0.7rem;color:var(--txt3)">1st event</span>'
            + '</div>'
            + '<div style="font-size:0.78rem;color:var(--txt3);margin-top:6px">No prior tournaments yet \u2014 this one starts their history.</div>'
            + (noGameYet
              ? '<div style="font-size:0.7rem;color:var(--txt3);margin-top:5px">No result recorded yet this event.</div>'
              : '<div style="font-size:0.7rem;color:var(--txt3);margin-top:5px">Win rate: <span style="font-family:monospace">' + r.winPct + '%</span></div>')
            + (r.curCR ? '<div style="font-size:0.7rem;color:var(--txt3);margin-top:4px">Club Rating: <span style="font-family:monospace;color:#FFD54F">' + escHtml(r.curCR) + '</span></div>' : '')
            + '</div>';
        }
        const oc = r.overallChange;
        const slc = r.sinceLastChange;
        const ocStr = oc == null ? '\u2014' : (oc > 0 ? '+' : '') + oc.toFixed(2);
        const slcStr = slc == null ? '' : 'last event: ' + (slc > 0 ? '+' : '') + slc.toFixed(2);
        const ocColor = oc == null ? 'var(--txt3)' : oc > 0 ? 'var(--lime)' : oc < 0 ? 'var(--red)' : 'var(--txt3)';
        const arrow = oc == null ? '' : oc > 0.01 ? '\ud83d\udcc8' : oc < -0.01 ? '\ud83d\udcc9' : '\u27a1\ufe0f';
        const ocSuffix = oc == null ? ' <span style="font-size:0.68rem">(no DUPR recorded in earlier events)</span>' : '';
        const winSpark = sparkline(r.winPctTrend, '#80CBC4');
        const winNow = r.winPctTrend.length ? r.winPctTrend[r.winPctTrend.length-1] : r.winPct;
        return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.5rem 0.65rem">'
          + '<div style="display:flex;justify-content:space-between;align-items:baseline">'
          + '<span style="font-weight:700;font-size:0.88rem">' + escHtml(r.player.name.split(' ')[0]) + '</span>'
          + '<span style="font-size:0.7rem;color:var(--txt3)">' + r.eventCount + ' event' + (r.eventCount===1?'':'s') + '</span>'
          + '</div>'
          + '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px">'
          + '<div><span style="font-family:monospace;font-weight:700;color:' + ocColor + '">' + arrow + ' ' + ocStr + '</span> '
          + '<span style="font-size:0.7rem;color:var(--txt3)">DUPR since first tracked</span>' + ocSuffix + '</div>'
          + '</div>'
          + (slcStr ? '<div style="font-size:0.72rem;color:var(--txt3);margin-top:2px">' + slcStr + '</div>' : '')
          + (noGameYet
              ? '<div style="margin-top:5px;font-size:0.7rem;color:var(--txt3)">No result recorded yet this event.</div>'
              : '<div style="margin-top:5px;font-size:0.7rem;color:var(--txt3)">win% trend ' + (winSpark || '<span style="font-family:monospace">' + winNow + '%</span>') + (winSpark ? ' <span style="font-family:monospace">' + winNow + '%</span>' : '') + '</div>')
          + (r.curCR ? '<div style="margin-top:4px;font-size:0.7rem;color:var(--txt3)">Club Rating: '
              + (r.crChanged
                  ? '<span style="color:#FFD54F">' + escHtml(r.firstCR) + ' \u2192 ' + escHtml(r.curCR) + '</span> \ud83c\udf89'
                  : '<span style="font-family:monospace;color:#FFD54F">' + escHtml(r.curCR) + '</span>')
              + '</div>' : '')
          + '</div>';
      }).join('')
    + '</div>'
    + '<div style="font-size:0.72rem;color:var(--txt3);margin-top:0.6rem">Tracked locally by player name across tournaments opened in this browser. Renaming a player starts a new history.</div>';
}

function reportAwards(data) {
  const el = document.getElementById('report-awards');
  if(!el) return;
  const active = data.filter(d => d.gp > 0);
  if(!active.length) { el.innerHTML = '<div style="color:var(--txt3);font-size:0.85rem;grid-column:1/-1">Enter match scores to see highlights.</div>'; return; }

  const fn = d => d.player.name.split(' ')[0];
  const card = (icon, title, who, detail, color) =>
    `<div style="background:var(--surface);border:1px solid var(--border);border-left:3px solid ${color};border-radius:8px;padding:0.7rem 0.85rem">
      <div style="font-size:0.7rem;color:var(--txt3);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:3px">${icon} ${title}</div>
      <div style="font-weight:700;font-size:0.95rem">${escHtml(who)}</div>
      <div style="font-size:0.75rem;color:var(--txt2);margin-top:1px">${escHtml(detail)}</div>
    </div>`;

  const champion = [...active].sort((a,b) => b.wins - a.wins || b.diff - a.diff)[0];
  const topScorer = [...active].sort((a,b) => b.pf - a.pf)[0];
  const bestPct = [...active].sort((a,b) => b.winPct - a.winPct || b.gp - a.gp)[0];
  const bestDiff = [...active].sort((a,b) => b.diff - a.diff)[0];
  // longest current win streak
  const streaker = [...active].filter(d => d.streakType === 'W').sort((a,b) => b.streak - a.streak)[0];
  // biggest single-game blowout (margin) and highest single score
  let blowout = null, highGame = null;
  active.forEach(d => d.games.forEach(g => {
    const margin = Number(g.pts) - Number(g.opponentPts);
    if(g.won && (!blowout || margin > blowout.margin)) blowout = { who: fn(d), margin, score: g.pts + '–' + g.opponentPts };
    if(!highGame || Number(g.pts) > highGame.pts) highGame = { who: fn(d), pts: Number(g.pts) };
  }));
  // most games played (iron player)
  const iron = [...active].sort((a,b) => b.gp - a.gp)[0];
  // closest-game specialist: most wins by 1-2 points
  const clutch = [...active].map(d => ({ d, n: d.games.filter(g => g.won && (Number(g.pts) - Number(g.opponentPts)) <= 2).length }))
    .sort((a,b) => b.n - a.n)[0];

  const cards = [];
  if(champion) cards.push(card('🏆','Champion', fn(champion), champion.wins + 'W · ' + (champion.diff>0?'+':'') + champion.diff + ' diff', 'var(--gold)'));
  if(bestPct && bestPct.gp >= 2) cards.push(card('🎯','Best Win %', fn(bestPct), bestPct.winPct + '% over ' + bestPct.gp + ' games', 'var(--lime)'));
  if(topScorer) cards.push(card('🔥','Top Scorer', fn(topScorer), topScorer.pf + ' total points', 'var(--ball)'));
  if(bestDiff && bestDiff !== champion) cards.push(card('📈','Best Point Diff', fn(bestDiff), (bestDiff.diff>0?'+':'') + bestDiff.diff + ' net', 'var(--blue)'));
  if(streaker && streaker.streak >= 2) cards.push(card('⚡','Hot Streak', fn(streaker), streaker.streak + ' wins in a row', 'var(--red)'));
  if(blowout) cards.push(card('💥','Biggest Win', blowout.who, 'by ' + blowout.margin + ' (' + blowout.score + ')', 'var(--purple)'));
  if(highGame) cards.push(card('🎆','Highest Score', highGame.who, highGame.pts + ' in one game', 'var(--ball)'));
  if(clutch && clutch.n >= 2) cards.push(card('🧊','Mr/Ms Clutch', fn(clutch.d), clutch.n + ' wins by ≤2 pts', 'var(--txt3)'));
  if(iron && iron.gp >= 3) cards.push(card('🛡️','Iron Player', fn(iron), iron.gp + ' games played', 'var(--court3)'));

  el.innerHTML = cards.join('');
}

function reportSummaryGrid(data) {
  const el = document.getElementById('report-summary-grid');
  if(!el) return;
  const active     = data.filter(d => d.gp > 0);
  const totalRounds = state.schedule.length;
  const doneMatches = state.schedule.flat().filter(m => m.complete).length;
  const leader      = active.length ? active.reduce((a,b) => b.wins>a.wins?b:a) : null;
  const topScorer   = active.length ? active.reduce((a,b) => b.pf>a.pf?b:a) : null;
  const bestPct     = active.length ? active.reduce((a,b) => b.winPct>a.winPct?b:a) : null;
  const cards = [
    { val: state.players.length,  lbl: 'Players' },
    { val: totalRounds,           lbl: 'Rounds' },
    { val: doneMatches,           lbl: 'Matches Played' },
    { val: leader ? leader.player.name.split(' ')[0] : '—',  lbl: 'Most Wins (' + (leader?.wins||0) + ')' },
    { val: topScorer ? topScorer.player.name.split(' ')[0] : '—', lbl: 'Top Scorer (' + (topScorer?.pf||0) + ' pts)' },
    { val: bestPct ? bestPct.player.name.split(' ')[0] : '—', lbl: 'Best Win% (' + (bestPct?.winPct||0) + '%)' },
  ];
  el.innerHTML = cards.map(c =>
    '<div class="card" style="padding:1rem;text-align:center;margin:0">'
    + '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:1.8rem;color:var(--lime);line-height:1">' + escHtml(c.val) + '</div>'
    + '<div style="font-size:0.75rem;color:var(--txt3);margin-top:4px;text-transform:uppercase;letter-spacing:0.5px">' + c.lbl + '</div>'
    + '</div>'
  ).join('');
}

// Variety report: surfaces things worth knowing — repeat pairings, matchups that
// never happened, and how many distinct partners/opponents each player got.
// (A flat "most frequent" list isn't useful: with good rotation, almost every
// pairing is 1x-2x, so it just restates that everyone played everyone.)


function reportExportCSV() {
  const stats = buildPlayerStats();
  if(!stats.length) { toast('No stats to export', 'err'); return; }
  const rows = [
    ['Rank','Name','Gender','Club','DUPR','CR','GP','W','L','T','Win%','PF','PA','+/-','Avg','Best','Worst']
  ];
  const data = stats.map(s => {
    const g    = s.games;
    const pf   = g.reduce((a,x)=>a+Number(x.pts),0);
    const pa   = g.reduce((a,x)=>a+Number(x.opponentPts),0);
    const wins = g.filter(x=>x.won).length;
    const loss = g.filter(x=>!x.won&&!x.tied).length;
    const ties = g.filter(x=>x.tied).length;
    const gp   = g.length;
    const avg  = gp ? (pf/gp).toFixed(1) : 0;
    const best = gp ? Math.max(...g.map(x=>Number(x.pts))) : 0;
    const worst= gp ? Math.min(...g.map(x=>Number(x.pts))) : 0;
    return { name:s.player.name, gender:s.player.gender, club:s.player.club||'',
             dupr:s.player.dupr??'', cr:s.player.clubRating||'', pf, pa, wins, loss, ties, gp, avg, best, worst,
             winPct: gp?Math.round((wins/gp)*100):0, diff:pf-pa, totalPts:pf };
  }).sort((a,b)=>b.totalPts-a.totalPts);

  data.forEach((d,i) => rows.push([
    i+1, d.name, d.gender, d.club, d.dupr, d.cr, d.gp, d.wins, d.loss, d.ties,
    d.winPct+'%', d.pf, d.pa, (d.diff>0?'+':'')+d.diff, d.avg, d.best, d.worst
  ]));

  const csv  = rows.map(r => r.map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = (getTournamentName() || 'Tournament').replace(/\s+/g,'_') + '_Report.csv';
  a.click();
  URL.revokeObjectURL(url);
  toast('📥 CSV exported!');
}

// ── SMS / Twilio ────────────────────────────────────────────
var TW_STORE = 'pb_tw';
var smsLog = [];
var smsCurRound = null;

// ── Helpers ───────────────────────────────────────
// Accurate SMS segment count. GSM-7: 160 chars single / 153 per segment when split.
// Any char outside the GSM 03.38 set (e.g. emoji 🏓) forces UCS-2: 70 single / 67 split.
// GSM extended chars (^{}\[]~|€) cost 2 chars each.
var GSM_BASIC = '@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&\'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà';
var GSM_EXT   = '^{}\\[]~|€';
function smsSegInfo(msg) {
  let units = 0, gsm = true;
  for(const ch of msg) {
    if(GSM_BASIC.includes(ch))    units += 1;
    else if(GSM_EXT.includes(ch)) units += 2;
    else { gsm = false; break; }
  }
  if(!gsm) {
    const len = [...msg].length; // code points
    return { encoding: 'UCS-2', units: len, segments: len <= 70 ? 1 : Math.ceil(len / 67) };
  }
  return { encoding: 'GSM-7', units: units, segments: units <= 160 ? 1 : Math.ceil(units / 153) };
}

// Normalize a phone number to E.164 for Twilio (assumes North America for 10-digit numbers).
function normalizePhone(raw) {
  if(!raw) return '';
  const d = raw.replace(/[^\d]/g, '');
  if(raw.trim().startsWith('+'))        return '+' + d;
  if(d.length === 10)                   return '+1' + d;
  if(d.length === 11 && d[0] === '1')   return '+' + d;
  return '+' + d; // best effort — Twilio will reject if invalid
}

// Escape user-supplied text before inserting into innerHTML.
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Small delay between batch sends — keeps us comfortably under Twilio's
// default 1 message-segment-per-second rate limit per long code number, and
// avoids bursting the local relay server with back-to-back requests.
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
const SEND_PACING_MS = 350;

// ── Entry point ───────────────────────────────────
function renderSmsTab() {
  smsLoadSenderLabel();
  smsLoadIncludeDateTime();
  smsLoadAutoSend();
  smsPopRounds();
  twLoad();
  if(window.location.protocol === 'file:') {
    const w = document.getElementById('sms-file-warning');
    if(w) w.style.display = 'block';
  }
  smsRenderLog();
}

function smsPopRounds() {
  const sel = document.getElementById('sms-round');
  if(!sel) return;
  const prev = sel.value;
  sel.innerHTML = '<option value="">— pick a round —</option>';
  state.schedule.forEach((round, i) => {
    if(!round.length) return;
    const done  = round.filter(m => !m.isRiverMatch && m.complete).length;
    const total = round.filter(m => !m.isRiverMatch).length;
    const tag   = done === total && total > 0 ? ' ✅' : done > 0 ? ' (' + done + '/' + total + ')' : '';
    const o = document.createElement('option');
    o.value = String(i);
    o.textContent = 'Round ' + (i + 1) + tag;
    sel.appendChild(o);
  });
  sel.value = (prev !== '' && sel.querySelector('[value="' + prev + '"]')) ? prev
    : state.schedule.length > 0 ? String(state.schedule.length - 1) : '';
  smsCurRound = sel.value !== '' ? parseInt(sel.value) : null;
  smsShowCards();
}

function smsUpdate() {
  const sel = document.getElementById('sms-round');
  smsCurRound = sel && sel.value !== '' ? parseInt(sel.value) : null;
  smsShowCards();
}

// ── Show/hide cards and build previews ───────────
// Track the last auto-generated message so we know if user has edited it
var _smsGeneratedMsg = '';

// ── Show/hide cards and build previews ───────────────────────────
function smsShowCards() {
  const hasRound  = smsCurRound !== null && !!state.schedule[smsCurRound];
  const players   = state.players.filter(p => p.phone && p.phone.trim());
  const preCard   = document.getElementById('sms-preview-card');
  const twCard    = document.getElementById('sms-tw-card');

  [preCard, twCard].forEach(el => { if(el) el.style.display = hasRound ? '' : 'none'; });
  if(!hasRound) return;

  const type       = document.getElementById('sms-type')?.value || 'personal';
  const isPersonal = type === 'personal';

  // Show/hide the preview player dropdown
  const ppWrap = document.getElementById('sms-preview-player-wrap');
  if(ppWrap) ppWrap.style.display = isPersonal ? '' : 'none';

  // Populate the preview player dropdown (all active players, not just those with phones)
  const ppSel = document.getElementById('sms-preview-player');
  if(ppSel && isPersonal) {
    const activePlayers = state.players.filter(p => p.active !== false);
    const curId = String(ppSel.value || '');
    ppSel.innerHTML = activePlayers.map(p =>
      '<option value="' + p.id + '">'
      + escHtml(p.name) + (p.phone ? '' : ' (no phone)') + '</option>'
    ).join('');
    // Restore previous selection if still valid
    if(curId && activePlayers.find(p => String(p.id) === curId)) {
      ppSel.value = curId;
    }
  }

  // Pick the sample player for preview
  const selId    = ppSel?.value;
  const sampleP  = (isPersonal && selId)
    ? state.players.find(p => String(p.id) === selId) || state.players[0]
    : (players[0] || state.players[0]);

  const previewMsg = isPersonal
    ? (sampleP ? smsBuildPersonal(sampleP, smsCurRound) : '(no players)')
    : smsBuildSummary(smsCurRound);

  const pre      = document.getElementById('sms-preview-text');
  const note     = document.getElementById('sms-preview-note');
  const resetBtn = document.getElementById('sms-reset-msg');

  // Only overwrite textarea when the generated message itself changes (round/type switch),
  // not on every re-render — so manual edits survive tab switches.
  if(previewMsg !== _smsGeneratedMsg) {
    _smsGeneratedMsg = previewMsg;
    if(pre) pre.value = previewMsg;
    if(resetBtn) resetBtn.style.display = 'none';
  }

  if(note) note.dataset.typeNote = isPersonal
    ? 'Preview for ' + (sampleP?.name || 'player')
    : 'Same message sent to all players';

  smsUpdateSegCount();

  const twl = document.getElementById('tw-log');
  if(twl && !twl.textContent.startsWith('✓') && !twl.textContent.startsWith('✗')) {
    twl.textContent = players.length + ' players have phone numbers.';
  }
  smsRenderPlayerList();
}

function smsPreviewEdited() {
  const pre      = document.getElementById('sms-preview-text');
  const resetBtn = document.getElementById('sms-reset-msg');
  if(resetBtn) resetBtn.style.display = (pre?.value !== _smsGeneratedMsg) ? '' : 'none';
  smsUpdateSegCount();
}

function smsResetMessage() {
  const pre = document.getElementById('sms-preview-text');
  if(pre) pre.value = _smsGeneratedMsg;
  const resetBtn = document.getElementById('sms-reset-msg');
  if(resetBtn) resetBtn.style.display = 'none';
  smsUpdateSegCount();
}

function smsUpdateSegCount() {
  const pre  = document.getElementById('sms-preview-text');
  const note = document.getElementById('sms-preview-note');
  if(!pre || !note) return;
  const lines = (pre.value || '').split('\n').filter(l => l.trim());
  const representative = lines[0] || pre.value || '';
  const seg = smsSegInfo(representative);
  const segNote = seg.segments > 1
    ? ' ⚠️ ' + seg.units + ' chars (' + seg.encoding + ') = ' + seg.segments + ' SMS segments'
    : ' ✅ ' + seg.units + ' chars (' + seg.encoding + ', 1 SMS)';
  note.textContent = (note.dataset.typeNote ? note.dataset.typeNote + ' · ' : '') + segNote;
}
function smsSaveSenderLabel() {
  const val = document.getElementById('sms-sender-label')?.value.trim() || '';
  try { localStorage.setItem('pb_sms_label', val); } catch(e) {}
}

function smsLoadSenderLabel() {
  try {
    const val = localStorage.getItem('pb_sms_label') || '';
    const el  = document.getElementById('sms-sender-label');
    if(el) el.value = val;
  } catch(e) {}
}

function smsSaveIncludeDateTime() {
  const val = document.getElementById('sms-include-datetime')?.checked || false;
  try { localStorage.setItem('pb_sms_include_dt', val ? '1' : '0'); } catch(e) {}
}
function smsLoadIncludeDateTime() {
  try {
    const val = localStorage.getItem('pb_sms_include_dt') === '1';
    const el  = document.getElementById('sms-include-datetime');
    if(el) el.checked = val;
  } catch(e) {}
}

function smsSaveAutoSend() {
  const val = document.getElementById('sms-auto-send')?.checked || false;
  try { localStorage.setItem('pb_sms_auto_send', val ? '1' : '0'); } catch(e) {}
}
function smsLoadAutoSend() {
  try {
    const val = localStorage.getItem('pb_sms_auto_send') === '1';
    const el  = document.getElementById('sms-auto-send');
    if(el) el.checked = val;
  } catch(e) {}
}
async function smsAutoSendIfEnabled(roundIdx) {
  const el = document.getElementById('sms-auto-send');
  if(!el || !el.checked) return;
  // Twilio credentials live server-side on the relay Worker now — nothing
  // client-side left to check before attempting a send.
  const players = state.players.filter(p => p.active !== false && p.checkedIn !== false && p.phone && p.phone.trim());
  if(!players.length) return;
  smsCurRound = roundIdx;
  toast('⚡ Auto-sending round ' + (roundIdx + 1) + ' SMS…');
  await twSendBatch(players, null, '📡 Send to All');
}

// Short date/time for SMS, e.g. "Jun 20 9am" — compact to save characters/segments.
function smsShortDateTime() {
  const raw = getTournamentDateTime();
  if(!raw) return '';
  const d = new Date(raw);
  if(isNaN(d.getTime())) return '';
  return d.toLocaleDateString(undefined, { month:'short', day:'numeric' }); // "Jun 20"
}

// Optional date prefix when "Include event date/time" is checked.
// Date only (no time) — keeps messages short and GSM-7 safe.
function smsDateTimePrefix() {
  if(!document.getElementById('sms-include-datetime')?.checked) return '';
  const dt = smsShortDateTime();
  return dt ? dt + ' - ' : '';
}

function smsGetLabel() {
  const val = document.getElementById('sms-sender-label')?.value.trim();
  return val || getTournamentName() || 'Pickleball Pro';
}

function smsBuildSummary(roundIdx) {
  const round    = state.schedule[roundIdx];
  const roundNum = roundIdx + 1;
  const label    = smsGetLabel() || 'Pickleball';
  const dtStr    = smsDateTimePrefix(); // e.g. "Jun 20 - " or ""

  if(!round || !round.length) {
    return label + ' | ' + dtStr + 'Round ' + roundNum + ' courts coming shortly!';
  }

  const courts = round
    .filter(m => m.teamA && m.teamB)
    .sort((a, b) => a.court - b.court)
    .map(m => {
      const name = p => state.players[p]?.name || '?';
      const tA = m.teamA.map(name).join(' & ');
      const tB = m.teamB.map(name).join(' & ');
      return 'Court ' + m.court + ': ' + tA + ' vs ' + tB;
    });

  // Bye players for this round
  const byeIdxs = (state.byeRounds || [])[roundIdx] || [];
  const byeNames = byeIdxs.map(i => state.players[i]?.name).filter(Boolean);
  const byeStr = byeNames.length ? ' | Sitting out: ' + byeNames.join(', ') : '';
  const byeStrFn = byeNames.length ? ' | Sitting out: ' + byeIdxs.map(i => state.players[i]?.name.split(' ')[0]).filter(Boolean).join(', ') : '';

  // Full version
  const header = label + ' | ' + dtStr + 'Round ' + roundNum + ': ';
  const full = header + courts.join(' | ') + byeStr;
  if(smsSegInfo(full).units <= 160) return full;

  // Too long with full names: fall back to first names
  const courtsFn = round
    .filter(m => m.teamA && m.teamB)
    .sort((a, b) => a.court - b.court)
    .map(m => {
      const fn = i => (state.players[i]?.name.split(' ')[0] || '?');
      return 'Court ' + m.court + ': ' + m.teamA.map(fn).join(' & ') + ' vs ' + m.teamB.map(fn).join(' & ');
    });
  const med = header + courtsFn.join(' | ') + byeStrFn;
  if(smsSegInfo(med).units <= 160) return med;

  // Still too long: one court per line, bye on last line
  const lines = courtsFn.map(c => {
    const line = dtStr + 'Round ' + roundNum + ' | ' + c;
    return smsSegInfo(line).units <= 160 ? line : line.slice(0, 160);
  });
  if(byeNames.length) {
    const byeLine = 'Sitting out: ' + byeIdxs.map(i => state.players[i]?.name.split(' ')[0]).filter(Boolean).join(', ');
    lines.push(smsSegInfo(byeLine).units <= 160 ? byeLine : byeLine.slice(0, 160));
  }
  return lines.join('\n');
}

function smsBuildPersonal(player, roundIdx) {
  const round    = state.schedule[roundIdx];
  const roundNum = roundIdx + 1;
  const fn       = player.name.split(' ')[0];
  const pidx     = state.players.findIndex(p => p.id === player.id);
  const label    = smsGetLabel() || 'Pickleball';
  const dtStr    = smsDateTimePrefix();

  if(pidx === -1 || !round) {
    return label + ' | ' + dtStr + 'Hi ' + fn + '! Round ' + roundNum + ': check your court!';
  }

  const match = round.find(m => m.teamA && m.teamB && (m.teamA.includes(pidx) || m.teamB.includes(pidx)));
  if(!match) {
    // Player is on a bye — tell them who else is sitting out with them
    const byeIdxs = (state.byeRounds || [])[roundIdx] || [];
    const otherByes = byeIdxs
      .filter(i => i !== pidx)
      .map(i => state.players[i]?.name.split(' ')[0])
      .filter(Boolean);
    const byeMsg = otherByes.length
      ? 'Hi ' + fn + '! Round ' + roundNum + ': you have a bye this round. Sitting out with you: ' + otherByes.join(', ') + '.'
      : 'Hi ' + fn + '! Round ' + roundNum + ': you have a bye this round. Rest up!';
    return label + ' | ' + dtStr + byeMsg;
  }

  const isA      = match.teamA.includes(pidx);
  const myTeam   = isA ? match.teamA : match.teamB;
  const opTeam   = isA ? match.teamB : match.teamA;
  const partnerIdx = myTeam.find(i => i !== pidx);
  const partner  = state.players[partnerIdx];
  const opp1     = state.players[opTeam[0]];
  const opp2     = state.players[opTeam[1]];
  const podStr   = match.podLabel ? ' (' + match.podLabel.split('·')[0].trim() + ')' : '';

  // Full version with full names
  const full = label + ' | ' + dtStr
    + 'Hi ' + fn + '! Round ' + roundNum + ', Court ' + match.court + podStr
    + ': Partner ' + (partner?.name || '?')
    + ' vs ' + (opp1?.name || '?') + ' & ' + (opp2?.name || '?') + '. Good luck!';
  if(smsSegInfo(full).units <= 160) return full;

  // Medium: first names only
  const med = label + ' | ' + dtStr
    + 'Hi ' + fn + '! R' + roundNum + ' C' + match.court + podStr
    + ': w/' + (partner?.name.split(' ')[0] || '?')
    + ' vs ' + (opp1?.name.split(' ')[0] || '?') + ' & ' + (opp2?.name.split(' ')[0] || '?');
  if(smsSegInfo(med).units <= 160) return med;

  // Bare minimum
  const short = dtStr + fn + ' R' + roundNum + ' C' + match.court
    + ': w/' + (partner?.name.split(' ')[0] || '?')
    + ' vs ' + (opp1?.name.split(' ')[0] || '?') + '&' + (opp2?.name.split(' ')[0] || '?');
  return smsSegInfo(short).units <= 160 ? short : short.slice(0, 160);
}


// Twilio credentials are now held server-side by the relay Worker — there is
// nothing left for the browser to collect, save, or load for SMS sending.
function twLoad() {}

function twGetCfg() {
  try {
    var raw = localStorage.getItem(TW_STORE);
    return raw ? JSON.parse(raw) : null;
  } catch(e){ return null; }
}

async function twCheckServer() {
  var el = document.getElementById('tw-status');
  if(el) el.textContent = 'Checking...';
  try {
    var r = await fetch(RELAY_BASE + '/health', {method:'GET'});
    if(r.ok) {
      if(el) el.innerHTML = '<span style="color:var(--lime)">✅ Relay connected</span>';
      toast('✅ Relay server connected!');
    } else {
      if(el) el.innerHTML = '<span style="color:var(--red)">✗ Server error ' + r.status + '</span>';
    }
  } catch(e) {
    if(el) el.innerHTML = '<span style="color:var(--red)">✗ Cannot reach relay — check your connection</span>';
  }
}

async function twTest() {
  var cfg = twGetCfg();
  var num = prompt('Your phone number for the test (include country code e.g. +16471234567):');
  if(!num || !num.trim()) return;
  var result = await twCallRelay(normalizePhone(num), 'Pickleball Pro test message - ' + new Date().toLocaleTimeString(), cfg);
  toast(result.ok ? '✅ Test sent!' : '❌ Failed — check the error log below');
}

// ── SMS player checklist ─────────────────────────
function smsRenderPlayerList() {
  const el = document.getElementById('sms-player-list');
  if(!el) return;
  const withPhone = state.players.filter(p => p.active !== false && p.phone && p.phone.trim());
  if(!withPhone.length) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem;grid-column:1/-1">No players have phone numbers yet.</div>';
    return;
  }
  if(!state._smsSelected) state._smsSelected = new Set();
  // Default select everyone the first time
  if(!state._smsSelectedInit) {
    withPhone.forEach(p => state._smsSelected.add(p.id));
    state._smsSelectedInit = true;
  }
  el.innerHTML = withPhone.map(p => {
    const checked = state._smsSelected.has(p.id) ? 'checked' : '';
    return '<label style="display:flex;align-items:center;gap:0.4rem;font-size:0.82rem;background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.35rem 0.55rem;cursor:pointer">'
      + '<input type="checkbox" ' + checked + ' onchange="smsToggleSelected(' + p.id + ', this.checked)">'
      + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escHtml(p.name) + '</span>'
      + '</label>';
  }).join('');
}

function smsToggleSelected(id, checked) {
  if(!state._smsSelected) state._smsSelected = new Set();
  if(checked) state._smsSelected.add(id); else state._smsSelected.delete(id);
}

function smsSelectAll(on) {
  const withPhone = state.players.filter(p => p.active !== false && p.phone && p.phone.trim());
  state._smsSelected = new Set(on ? withPhone.map(p => p.id) : []);
  smsRenderPlayerList();
}

async function twSendSelected() {
  if(smsCurRound === null) { toast('Pick a round first', 'err'); return; }
  var sel = state._smsSelected || new Set();
  var players = state.players.filter(p => p.active !== false && p.phone && p.phone.trim() && sel.has(p.id));
  if(!players.length) { toast('No players selected', 'err'); return; }
  await twSendBatch(players, '[onclick="twSendSelected()"]', '📡 Send to Selected');
}

async function twSendAll() {
  if(smsCurRound === null) { toast('Pick a round first', 'err'); return; }
  var players = state.players.filter(function(p){ return p.active !== false && p.checkedIn !== false && p.phone && p.phone.trim(); });
  if(!players.length) { toast('No players have phone numbers', 'err'); return; }
  await twSendBatch(players, '[onclick="twSendAll()"]', '📡 Send to All');
}

async function twSendBatch(players, btnSelector, btnLabel) {
  var cfg = twGetCfg();
  var msgType = document.getElementById('sms-type')?.value || 'personal';
  var summaryMsg = msgType === 'summary'
    ? (document.getElementById('sms-preview-text')?.value || smsBuildSummary(smsCurRound))
    : null;

  var btn = document.querySelector(btnSelector);
  var log = document.getElementById('tw-log');
  if(btn) { btn.disabled = true; btn.textContent = '\u23f3 Sending\u2026'; }
  if(log) log.textContent = '';

  var sent = 0, failed = 0;
  for(var i = 0; i < players.length; i++) {
    var p   = players[i];
    var msg = msgType === 'summary' ? summaryMsg : smsBuildPersonal(p, smsCurRound);
    var result = await twCallRelay(normalizePhone(p.phone), msg, cfg);
    var ts  = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
    if(result.ok) sent++; else failed++;
    smsLog.unshift({ts:ts, name:p.name, phone:p.phone, msg:msg, via:'Twilio', ok:result.ok});
    if(log) log.textContent = sent + ' sent, ' + failed + ' failed of ' + players.length;
    smsRenderLog();
    // If the relay server itself is unreachable, every remaining attempt will
    // fail the same way — stop now instead of repeating the same timeout for
    // every other player in the batch.
    if(result.unreachable) {
      failed += players.length - i - 1;
      if(log) log.innerHTML = '<span style="color:var(--red)">Cannot reach relay server — stopped after 1 attempt. Check your connection and try again.</span>';
      break;
    }
    // Pace sends to stay under Twilio's default rate limit (skip after the last player)
    if(i < players.length - 1) await sleep(SEND_PACING_MS);
  }

  if(btn) { btn.disabled = false; btn.textContent = btnLabel; }
  if(log) {
    if(failed === 0) log.innerHTML = '<span style="color:var(--lime)">\u2713 All ' + sent + ' sent successfully!</span>';
    else log.innerHTML = '<span style="color:var(--lime)">' + sent + ' sent</span>, <span style="color:var(--red)">' + failed + ' failed</span>';
  }
  toast('\ud83d\udce1 ' + sent + ' sent' + (failed ? ', ' + failed + ' failed' : ''));
}

async function twCallRelay(to, body, cfg) {
  try {
    var r = await fetch(RELAY_BASE + '/api/sms', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({ to: to, body: body })
    });
    var data = await r.json().catch(function(){ return {}; });
    if(!data.ok && data.error) {
      var el = document.getElementById('tw-log');
      if(el) el.innerHTML = '<span style="color:var(--red)">SMS error: ' + escHtml(data.error) + '</span>';
    }
    return { ok: data.ok === true, unreachable: false };
  } catch(e) {
    // fetch() itself threw — the relay is unreachable, as opposed to it
    // responding with a provider-side error above.
    var el = document.getElementById('tw-log');
    if(el) el.innerHTML = '<span style="color:var(--red)">Cannot reach relay server. Check your connection and try again.</span>';
    return { ok: false, unreachable: true };
  }
}

// ── Log ───────────────────────────────────────────
function smsRenderLog() {
  var el = document.getElementById('sms-log-el');
  if(!el) return;
  if(!smsLog.length) { el.textContent = 'No messages sent yet.'; return; }
  el.innerHTML = smsLog.slice(0, 50).map(function(e) {
    var ok = e.ok !== false;
    return '<div style="padding:2px 0;border-bottom:1px solid var(--border)">'
      + '<span style="color:var(--txt3);margin-right:6px">' + e.ts + '</span>'
      + '<span style="background:var(--surface);border-radius:3px;padding:0 5px;font-size:0.72rem;margin-right:6px;color:' + (e.via==='WA'?'#25d366':e.via==='GV'?'#4285f4':'var(--ball)') + '">' + e.via + '</span>'
      + '<span style="font-weight:600;margin-right:6px">' + escHtml(e.name) + '</span>'
      + '<span style="color:var(--txt3);margin-right:6px">' + escHtml(e.phone) + '</span>'
      + '<span style="color:var(--txt2)">' + escHtml(e.msg.replace(/\n/g,' · ').substring(0,60)) + '</span>'
      + '</div>';
  }).join('');
}


// ═══════════════════════════════════════════════

// ── Email / SMTP ────────────────────────────────────────────
//  EMAIL RESULTS (SMTP via relay server)
// ═══════════════════════════════════════════════
var EM_STORE = 'pb_email';

// Default email subject, optionally including the event date/time if set
// (e.g. "Your results — Spring Open (Jun 20, 2026, 9:00 AM)").
function emDefaultSubject() {
  const tname = getTournamentName() || 'Pickleball Tournament';
  const when = formatTournamentDateTime();
  return 'Your results — ' + tname + (when ? ' (' + when + ')' : '');
}

// Manually insert/replace the event date+time in the subject field, regardless of
// whether the subject has been customized. One click, always works.
function emInsertDateTime() {
  const when = formatTournamentDateTime();
  const subjEl = document.getElementById('em-subject');
  if(!subjEl) return;
  if(!when) {
    toast('No event date/time set — add one on the Tournament tab first', 'err');
    return;
  }
  // Strip any existing trailing "(...)" date stamp we may have previously inserted,
  // then append the current date/time.
  const base = subjEl.value.replace(/\s*\([^()]*\)\s*$/, '').trim() || emDefaultSubject().replace(/\s*\([^()]*\)\s*$/, '');
  subjEl.value = base + ' (' + when + ')';
  subjEl.dataset.lastDefault = subjEl.value;
  toast('📅 Added: ' + when);
  emUpdateSubjectHint();
}

function emUpdateSubjectHint() {
  const hint = document.getElementById('em-subject-hint');
  if(!hint) return;
  const when = formatTournamentDateTime();
  hint.textContent = when
    ? 'Event date/time: ' + when + ' — click "Insert date/time" to add it to the subject above.'
    : 'No event date/time set. Add one on the Tournament tab, then click "Insert date/time".';
}

// ═══════════════════════════════════════════════

// ── Season board ─────────────────────────────────────────────
//  SEASON BOARD
//  Aggregates player history across all tournaments in a date range.
//  Points: 3 per win, 1 per loss, 0 bye.  Season = running total.
// ═══════════════════════════════════════════════
function seasonClearFilter() {
  const f = document.getElementById('season-from');
  const t = document.getElementById('season-to');
  if(f) f.value = '';
  if(t) t.value = '';
  renderSeasonBoard();
}

// ═══════════════════════════════════════════════

// ── Live court display ───────────────────────────────────────
//  LIVE COURT DISPLAY
//  Full-screen overlay showing current round's court assignments,
//  live clock, and standings. Designed for projecting at the venue.
// ═══════════════════════════════════════════════
var _ldTimer = null;
var _ldClockTimer = null;
var _ldRoundStartTime = null; // tracks when current round started for match duration

function shareWhatsApp() {
  if(!state.schedule.length) { toast('Generate a schedule first', 'err'); return; }

  // Find the current active round
  let activeRound = null, activeRoundIdx = -1;
  for(let i = 0; i < state.schedule.length; i++) {
    if(state.schedule[i].some(m => m.teamA && m.teamB && !m.complete)) {
      activeRound = state.schedule[i]; activeRoundIdx = i; break;
    }
  }
  if(!activeRound) {
    activeRoundIdx = state.schedule.length - 1;
    activeRound = state.schedule[activeRoundIdx];
  }

  const name = getTournamentName();
  const lines = [`🏓 ${name} — Round ${activeRoundIdx + 1}`, ''];
  activeRound.filter(m => m.teamA && m.teamB).forEach(m => {
    const a = matchTeamName(m.teamA), b = matchTeamName(m.teamB);
    lines.push(`🏟 Court ${m.court}: ${a} vs ${b}`);
  });
  const byePlayers = (state.byeRounds || [])[activeRoundIdx] || [];
  if(byePlayers.length) {
    lines.push('');
    lines.push('🪑 Sitting out: ' + byePlayers.map(i => state.players[i]?.name.split(' ')[0] || '?').join(', '));
  }
  lines.push('');
  lines.push('Good luck! 🎉');

  const text = lines.join('\n');
  const url = 'https://wa.me/?text=' + encodeURIComponent(text);
  window.open(url, '_blank');
}

// ═══════════════════════════════════════════════
//  MOBILE SYNC
//  Talks to the Cloudflare Worker (cf-worker/) so players/scorekeepers
//  can claim a court on their phone and submit scores, which sync back
//  into this app's state automatically.
// ═══════════════════════════════════════════════
var MS_CONFIG_KEY = 'pb_mobile_sync_config';
var msState = {
  workerUrl: '',
  code: '',
  autoPush: true,
  syncing: false,
  pollTimer: null,
  lastSyncAt: null,
};

function msLoadConfig() {
  try {
    const raw = localStorage.getItem(MS_CONFIG_KEY);
    if(!raw) return;
    const cfg = JSON.parse(raw);
    msState.workerUrl = cfg.workerUrl || '';
    msState.code = cfg.code || '';
    msState.autoPush = cfg.autoPush !== false;
  } catch(e) {}
}

function msSaveConfig() {
  msState.workerUrl = (document.getElementById('ms-worker-url')?.value || '').trim().replace(/\/+$/, '');
  msState.code = (document.getElementById('ms-code')?.value || '').trim().toUpperCase();
  msState.autoPush = !!document.getElementById('ms-auto-push')?.checked;
  try {
    localStorage.setItem(MS_CONFIG_KEY, JSON.stringify({
      workerUrl: msState.workerUrl, code: msState.code, autoPush: msState.autoPush,
    }));
  } catch(e) {}
  msRenderShareCard();
}

function msGenerateCode() {
  const name = getTournamentName().replace(/[^A-Za-z0-9]/g, '').slice(0, 6).toUpperCase() || 'PB';
  const rand = Math.floor(10 + Math.random() * 90);
  const code = name + rand;
  document.getElementById('ms-code').value = code;
  msSaveConfig();
}

function msSetStatus(msg, isErr) {
  const el = document.getElementById('ms-status');
  if(!el) return;
  el.textContent = msg;
  el.style.color = isErr ? 'var(--red)' : 'var(--txt3)';
}

function msRenderShareCard() {
  const shareCard = document.getElementById('ms-share-card');
  const qrCard = document.getElementById('ms-qr-card');
  const smsCard = document.getElementById('ms-sms-card');
  if(!msState.workerUrl || !msState.code) {
    if(shareCard) shareCard.style.display = 'none';
    if(qrCard) qrCard.style.display = 'none';
    if(smsCard) smsCard.style.display = 'none';
    return;
  }
  const link = `${msState.workerUrl}/?code=${encodeURIComponent(msState.code)}`;
  if(shareCard) {
    shareCard.style.display = '';
    const linkInput = document.getElementById('ms-share-link');
    if(linkInput) linkInput.value = link;
  }
  if(qrCard) {
    qrCard.style.display = '';
    msRenderQRCodes();
  }
  if(smsCard) {
    smsCard.style.display = '';
    msSmsRenderPlayerList();
  }
}

function msCopyLink() {
  const linkInput = document.getElementById('ms-share-link');
  if(!linkInput) return;
  linkInput.select();
  navigator.clipboard?.writeText(linkInput.value).then(
    () => toast('Link copied!'),
    () => document.execCommand('copy')
  );
}

// ── Send the scorekeeper link by SMS ──────────────────────────────────
// Reuses the same Twilio credentials/relay as the 📱 SMS tab (twGetCfg,
// twCallRelay) but is otherwise independent of that tab's round-message
// logic, since this just sends one fixed link, not a per-round schedule.
function msSmsRenderPlayerList() {
  const el = document.getElementById('ms-sms-player-list');
  if(!el) return;
  const withPhone = state.players.filter(p => p.active !== false && p.phone && p.phone.trim());
  if(!withPhone.length) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem;grid-column:1/-1">No players have phone numbers yet.</div>';
    return;
  }
  if(!state._msSmsSelected) state._msSmsSelected = new Set();
  if(!state._msSmsSelectedInit) {
    withPhone.forEach(p => state._msSmsSelected.add(p.id));
    state._msSmsSelectedInit = true;
  }
  el.innerHTML = withPhone.map(p => {
    const checked = state._msSmsSelected.has(p.id) ? 'checked' : '';
    return '<label style="display:flex;align-items:center;gap:0.4rem;font-size:0.82rem;background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.35rem 0.55rem;cursor:pointer">'
      + '<input type="checkbox" ' + checked + ' onchange="msSmsToggleSelected(' + p.id + ', this.checked)">'
      + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">' + escHtml(p.name) + '</span>'
      + '<button type="button" title="Text just this player" onclick="event.preventDefault();msSmsSendOne(' + p.id + ')" '
      + 'style="background:none;border:none;cursor:pointer;font-size:0.85rem;padding:0 0.15rem;line-height:1">📤</button>'
      + '</label>';
  }).join('');
}

function msSmsToggleSelected(id, checked) {
  if(!state._msSmsSelected) state._msSmsSelected = new Set();
  if(checked) state._msSmsSelected.add(id); else state._msSmsSelected.delete(id);
}

function msSmsSelectAll(on) {
  const withPhone = state.players.filter(p => p.active !== false && p.phone && p.phone.trim());
  state._msSmsSelected = new Set(on ? withPhone.map(p => p.id) : []);
  msSmsRenderPlayerList();
}

function msSmsBuildMessage() {
  if(!msState.workerUrl || !msState.code) return '';
  const link = `${msState.workerUrl}/?code=${encodeURIComponent(msState.code)}`;
  const name = getTournamentName();
  return `🏓 ${name}: tap to enter your court's score → ${link}\nCode: ${msState.code}`;
}

function msSmsSetStatus(msg, isErr) {
  const el = document.getElementById('ms-sms-status');
  if(!el) return;
  el.textContent = msg;
  el.style.color = isErr ? 'var(--red)' : 'var(--txt3)';
}

async function msSmsSendBatch(players) {
  if(!players.length) { msSmsSetStatus('No players selected', true); return; }
  // Twilio credentials are held server-side by the relay Worker now (see
  // the main SMS tab's twCallRelay()) — there's nothing left to check
  // client-side here. This used to gate on a locally-stored Twilio config
  // object that no longer exists since that rebuild.
  msSaveConfig();
  if(!msState.workerUrl || !msState.code) { msSmsSetStatus('Set Worker URL and tournament code first', true); return; }

  const msg = msSmsBuildMessage();
  const log = document.getElementById('ms-sms-log');
  if(log) log.textContent = '';
  let sent = 0, failed = 0;
  for(let i = 0; i < players.length; i++) {
    const p = players[i];
    const result = await twCallRelay(normalizePhone(p.phone), msg, null);
    if(result.ok) sent++; else failed++;
    if(log) log.textContent = sent + ' sent, ' + failed + ' failed of ' + players.length;
    if(result.unreachable) {
      failed += players.length - i - 1;
      if(log) log.innerHTML = '<span style="color:var(--red)">Cannot reach relay server — check the 📱 SMS tab\'s relay setup.</span>';
      break;
    }
    if(i < players.length - 1) await sleep(SEND_PACING_MS);
  }
  msSmsSetStatus(`${sent} sent${failed ? ', ' + failed + ' failed' : ''} — ${new Date().toLocaleTimeString()}`, failed > 0 && sent === 0);
  toast(`📤 ${sent} link${sent===1?'':'s'} sent` + (failed ? `, ${failed} failed` : ''));
}

function msSmsSendSelected() {
  const sel = state._msSmsSelected || new Set();
  const players = state.players.filter(p => p.active !== false && p.phone && p.phone.trim() && sel.has(p.id));
  msSmsSendBatch(players);
}

function msSmsSendAll() {
  const players = state.players.filter(p => p.active !== false && p.phone && p.phone.trim());
  msSmsSendBatch(players);
}

function msSmsSendOne(playerId) {
  const p = state.players.find(pl => pl.id === playerId);
  if(!p || !p.phone || !p.phone.trim()) { msSmsSetStatus('That player has no phone number', true); return; }
  msSmsSendBatch([p]);
}

// Builds one QR code per active court, deep-linking to that court's score page
// and (if a PIN is set for that court) baking the PIN into the link so a scan
// auto-fills it. Each card also has an editable PIN field — type a PIN, click
// "Save PINs" to push it to the Worker, which is what actually enforces it.
var msPinsCache = {}; // { [court]: "1234" } — local cache so PIN fields don't reset on refresh

function msRenderQRCodes() {
  const grid = document.getElementById('ms-qr-grid');
  if(!grid || !msState.workerUrl || !msState.code) return;
  grid.innerHTML = '';
  const courts = msGetCurrentCourtsPayload();
  if(!courts.length) {
    grid.innerHTML = '<div style="grid-column:1/-1;color:var(--txt3);font-size:0.85rem">Generate a schedule first to see court QR codes.</div>';
    return;
  }
  courts.forEach(c => {
    const cell = document.createElement('div');
    cell.style.cssText = 'background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:0.6rem;text-align:center';
    const qrDiv = document.createElement('div');
    qrDiv.id = 'ms-qr-' + c.court;
    qrDiv.style.cssText = 'display:flex;justify-content:center;margin-bottom:0.4rem';
    cell.appendChild(qrDiv);
    const label = document.createElement('div');
    label.style.cssText = 'font-family:"Space Grotesk",sans-serif;font-weight:700;font-size:0.85rem;color:var(--lime);margin-bottom:0.4rem';
    label.textContent = 'Court ' + c.court;
    cell.appendChild(label);
    const pinInput = document.createElement('input');
    pinInput.type = 'text';
    pinInput.id = 'ms-pin-' + c.court;
    pinInput.placeholder = 'No PIN';
    pinInput.value = msPinsCache[c.court] || '';
    pinInput.inputMode = 'numeric';
    pinInput.style.cssText = 'width:100%;box-sizing:border-box;text-align:center;font-family:monospace;font-size:0.85rem;padding:0.3rem;border-radius:6px;border:1px solid var(--border);background:var(--card);color:var(--lime)';
    pinInput.addEventListener('input', () => {
      msPinsCache[c.court] = pinInput.value.trim();
      msRenderSingleQR(c.court); // live-update this court's QR as the PIN is typed
    });
    cell.appendChild(pinInput);
    grid.appendChild(cell);
    msRenderSingleQR(c.court);
  });
}

function msRenderSingleQR(court) {
  const qrDiv = document.getElementById('ms-qr-' + court);
  if(!qrDiv) return;
  qrDiv.innerHTML = '';
  const pin = (msPinsCache[court] || '').trim();
  let link = `${msState.workerUrl}/?code=${encodeURIComponent(msState.code)}&court=${court}`;
  if(pin) link += `&pin=${encodeURIComponent(pin)}`;
  if(window.QRCode) {
    new QRCode(qrDiv, { text: link, width: 110, height: 110, colorDark: '#0A0F0A', colorLight: '#E8F5E9' });
  } else {
    qrDiv.textContent = link;
    qrDiv.style.fontSize = '0.65rem';
    qrDiv.style.wordBreak = 'break-all';
  }
}

// Pushes the PIN cache to the Worker — this is the step that actually makes
// PINs enforced. Until this runs, typed PINs only exist locally / in the QR link.
async function msSavePins() {
  try {
    msSaveConfig();
    const pins = {};
    Object.keys(msPinsCache).forEach(court => { pins[court] = msPinsCache[court] || ''; });
    await msApi('/setpins', { method:'POST', body: JSON.stringify({ pins }) });
    const statusEl = document.getElementById('ms-pins-status');
    if(statusEl) statusEl.textContent = '✓ PINs saved — ' + new Date().toLocaleTimeString();
    msRenderQRCodes();
  } catch(e) {
    const statusEl = document.getElementById('ms-pins-status');
    if(statusEl) { statusEl.textContent = '✗ Failed: ' + e.message; statusEl.style.color = 'var(--red)'; }
  }
}

// Convenience: fill every court with a random 4-digit PIN, ready to Save.
function msRandomizePins() {
  const courts = msGetCurrentCourtsPayload();
  courts.forEach(c => {
    msPinsCache[c.court] = String(Math.floor(1000 + Math.random() * 9000));
  });
  msRenderQRCodes();
  toast('Random PINs generated — click Save to apply them');
}

// Finds the current "active" round (first round with an incomplete, assigned match;
// falls back to the last round) and returns it as a court-keyed payload for the Worker.
function msGetCurrentActiveRound() {
  if(!state.schedule.length) return { roundIdx: -1, matches: [] };
  let activeRound = null, activeRoundIdx = -1;
  for(let i = 0; i < state.schedule.length; i++) {
    if(state.schedule[i].some(m => m.teamA && m.teamB && !m.complete)) {
      activeRound = state.schedule[i]; activeRoundIdx = i; break;
    }
  }
  if(!activeRound) {
    activeRoundIdx = state.schedule.length - 1;
    activeRound = state.schedule[activeRoundIdx] || [];
  }
  // Don't surface a round to scorekeepers' phones until the organizer has
  // explicitly clicked "▶ Start Round" for it. This is the ONLY gate —
  // deliberately not also checking for already-completed scores in the
  // round, even though that might seem like a reasonable fallback ("if
  // there's a real score, play must have started"). The actual desired
  // behavior is stricter than that: Start Round is the single source of
  // truth for whether a round may reach phones at all, full stop, with no
  // other implicit path in.
  const hasStarted = !!(state.startedRounds && state.startedRounds.has(activeRoundIdx));
  if(!hasStarted) return { roundIdx: activeRoundIdx, matches: [] };
  return { roundIdx: activeRoundIdx, matches: activeRound.filter(m => m.teamA && m.teamB && !m.isRiverMatch) };
}

function msGetCurrentCourtsPayload() {
  const { matches } = msGetCurrentActiveRound();
  return matches.map(m => ({
    court: m.court,
    matchId: m.id,
    teamA: (m.teamA || []).map(i => state.players[i]?.name || '?'),
    teamB: (m.teamB || []).map(i => state.players[i]?.name || '?'),
    scoreA: m.scoreA,
    scoreB: m.scoreB,
    complete: !!m.complete,
    submittedBy: m._submittedBy || '',
    submittedAt: m._submittedAt || null,
  }));
}

// Names of players sitting out the current round (a "bye") — kept
// separate from msGetCurrentCourtsPayload() rather than folded into it,
// since a bye player isn't on any court at all. Mirrors the same
// started-round gating as the courts themselves: if the round hasn't
// actually started yet, there's nothing meaningful to report as "sitting
// out" either, so this returns an empty list in that case too, same as
// msGetCurrentActiveRound() does for matches.
function msGetCurrentByePlayers() {
  const { roundIdx, matches } = msGetCurrentActiveRound();
  if (!matches.length) return []; // round hasn't started — nothing to report
  const byeIdxs = (state.byeRounds || [])[roundIdx] || [];
  return byeIdxs.map(i => state.players[i]?.name || '?');
}

async function msApi(path, opts) {
  if(!msState.workerUrl || !msState.code) throw new Error('Set Worker URL and tournament code first');
  const res = await fetch(`${msState.workerUrl}/api/${encodeURIComponent(msState.code)}${path}`,
    Object.assign({ headers: { 'Content-Type': 'application/json' } }, opts));
  let body;
  try { body = await res.json(); } catch(e) { body = { ok:false, error:'Bad response from server' }; }
  if(!body.ok) throw new Error(body.error || 'Request failed');
  return body;
}

async function msPushNow() {
  try {
    msSaveConfig();
    const { roundIdx } = msGetCurrentActiveRound();
    const courts = msGetCurrentCourtsPayload();
    const byePlayers = msGetCurrentByePlayers();
    await msApi('/push', { method:'POST', body: JSON.stringify({
      tournamentName: getTournamentName(),
      round: roundIdx + 1,
      courts,
      byePlayers,
    })});
    msState.lastSyncAt = new Date();
    msSetStatus('✓ Pushed round ' + (roundIdx+1) + ' to phones — ' + msState.lastSyncAt.toLocaleTimeString());
    msRenderCourtStatus(courts);
    msRenderShareCard();
  } catch(e) {
    msSetStatus('✗ Push failed: ' + e.message, true);
  }
}

// Pulls any score submissions phones have made and applies them via the
// existing saveScoreInline-style logic, then acks them so they aren't reapplied.
// Also refreshes the claims cache every tick so "Claimed by" stays current
// even on ticks with no new score (e.g. someone just claimed a court).
async function msPullNow() {
  try {
    msSaveConfig();
    const data = await msApi('/updates', { method:'GET' });
    const updates = data.updates || [];
    await msFetchClaims();
    if(!updates.length) {
      msSetStatus('No new scores — last checked ' + new Date().toLocaleTimeString());
      msRenderCourtStatus(msGetCurrentCourtsPayload());
      return;
    }
    flattenSchedule();
    const appliedIds = [];
    updates.forEach(u => {
      const m = _currentMatchFlat.find(mm => mm.id === u.matchId);
      if(!m || m.complete) { appliedIds.push(u.matchId); return; } // already applied or stale — ack anyway
      const prevSa = m.scoreA, prevSb = m.scoreB, prevComplete = m.complete;
      m.scoreA = u.scoreA; m.scoreB = u.scoreB; m.complete = true;
      m._submittedBy = u.submittedBy || '';
      m._submittedAt = u.submittedAt || Date.now();
      pushUndo(m.id, prevSa, prevSb, prevComplete);

      const winners = u.scoreA > u.scoreB ? [...m.teamA] : [...m.teamB];
      const losers  = u.scoreA > u.scoreB ? [...m.teamB] : [...m.teamA];
      const rh = state.roundHistory;
      const roundEntry = rh.find(e => e.round === m.round);
      if(roundEntry) { roundEntry.winners.push(...winners); roundEntry.losers.push(...losers); }
      else rh.push({ round: m.round, winners, losers });

      appliedIds.push(u.matchId);
    });
    autoSave();
    await msApi('/ack', { method:'POST', body: JSON.stringify({ matchIds: appliedIds }) });

    renderSchedule();
    updateProgress();
    updateStandings();
    checkRoundComplete();
    if(document.getElementById('sec-playerstats')?.classList.contains('active')) { renderPlayerStats(); renderH2H(); }
    updateReportIfActive();
    if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
    _liveBroadcast();

    msState.lastSyncAt = new Date();
    msSetStatus(`✓ Applied ${updates.length} score${updates.length>1?'s':''} — ${msState.lastSyncAt.toLocaleTimeString()}`);
    toast(`📲 ${updates.length} score${updates.length>1?'s':''} synced from phones!`);
    msRenderCourtStatus(msGetCurrentCourtsPayload());
  } catch(e) {
    msSetStatus('✗ Sync failed: ' + e.message, true);
  }
}

function msRenderCourtStatus(courts) {
  const card = document.getElementById('ms-status-card');
  const grid = document.getElementById('ms-court-status-grid');
  const lastSync = document.getElementById('ms-last-sync');
  if(!card || !grid) return;
  if(!courts || !courts.length) { card.style.display = 'none'; return; }
  card.style.display = '';
  if(lastSync) lastSync.textContent = msState.lastSyncAt ? 'Updated ' + msState.lastSyncAt.toLocaleTimeString() : '';
  grid.innerHTML = courts.map(c => {
    const statusColor = c.complete ? 'var(--lime)' : 'var(--ball)';
    const statusText = c.complete ? `${c.scoreA}–${c.scoreB}` : 'In progress';
    const claimedBy = msClaimsCache[c.court]?.name || '';
    const submittedBy = c.submittedBy || '';
    // "Claimed by" gets a prominent colored pill — it's the thing an organizer
    // scans for at a glance (who's covering this court / is it unclaimed).
    // "Submitted by" stays a quiet text line since it only matters once the
    // score is already in, which the bold score color above already signals.
    const claimedLine = claimedBy
      ? `<div style="display:inline-flex;align-items:center;gap:0.3rem;background:rgba(198,255,0,0.12);border:1px solid rgba(198,255,0,0.4);border-radius:99px;padding:0.18rem 0.6rem;margin-top:0.35rem">
           <span style="font-size:0.78rem">📲</span>
           <span style="font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:0.78rem;color:var(--lime)">${escHtml(claimedBy)}</span>
         </div>`
      : `<div style="display:inline-flex;align-items:center;gap:0.3rem;background:rgba(239,83,80,0.1);border:1px solid rgba(239,83,80,0.35);border-radius:99px;padding:0.18rem 0.6rem;margin-top:0.35rem">
           <span style="font-family:'DM Sans',sans-serif;font-weight:600;font-size:0.74rem;color:var(--red)">Unclaimed</span>
         </div>`;
    const submittedLine = submittedBy
      ? `<div style="font-size:0.7rem;color:var(--txt3);margin-top:0.3rem">✓ Submitted by ${escHtml(submittedBy)}</div>`
      : '';
    return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:0.6rem 0.75rem">
      <div style="font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:0.85rem;color:var(--txt)">Court ${c.court}</div>
      <div style="font-size:0.75rem;color:var(--txt3);margin:0.2rem 0">${c.teamA.join(' & ')} vs ${c.teamB.join(' & ')}</div>
      <div style="font-size:0.8rem;font-weight:700;color:${statusColor}">${statusText}</div>
      ${claimedLine}
      ${submittedLine}
    </div>`;
  }).join('');
}

// Cache of court -> claim info, refreshed by msFetchClaims(). Kept separate
// from msGetCurrentCourtsPayload() since claims live server-side only.
var msClaimsCache = {};

async function msFetchClaims() {
  if(!msState.workerUrl || !msState.code) return;
  try {
    const data = await msApi('/state', { method:'GET' });
    msClaimsCache = data.claims || {};
    // Piggyback announcements off this same /state call rather than firing
    // a second request just for them — /state already returns both.
    msAnnouncements = data.announcements || [];
    msRenderAnnounceList();
  } catch(e) { /* non-fatal — claimed-by/announcement lines just stay as last known */ }
}

// ── Announcements: organizer posts one-way messages to every phone ───────
var msAnnouncements = [];

function msSetAnnounceStatus(msg, isErr) {
  const el = document.getElementById('ms-announce-status');
  if(!el) return;
  el.textContent = msg;
  el.style.color = isErr ? 'var(--red)' : 'var(--txt3)';
}

function msRelTime(ms) {
  const diff = Math.max(0, Date.now() - ms);
  const mins = Math.round(diff / 60000);
  if(mins < 1) return 'just now';
  if(mins === 1) return '1 min ago';
  if(mins < 60) return mins + ' min ago';
  const hrs = Math.round(mins / 60);
  if(hrs === 1) return '1 hr ago';
  if(hrs < 24) return hrs + ' hrs ago';
  return new Date(ms).toLocaleDateString();
}

function msRenderAnnounceList() {
  const card = document.getElementById('ms-announce-card');
  const list = document.getElementById('ms-announce-list');
  if(!card || !list) return;
  card.style.display = '';
  if(!msAnnouncements.length) {
    list.innerHTML = '<div style="font-size:0.8rem;color:var(--txt3)">No announcements posted yet.</div>';
    return;
  }
  list.innerHTML = msAnnouncements.map(a => `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.6rem;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:0.55rem 0.7rem">
      <div style="flex:1;min-width:0">
        <div style="font-size:0.85rem;color:var(--txt)">${escHtml(a.text)}</div>
        <div style="font-size:0.7rem;color:var(--txt3);margin-top:0.15rem">${msRelTime(a.postedAt)}</div>
      </div>
      <button class="btn btn-secondary btn-sm" onclick="msDeleteAnnouncement('${a.id}')" title="Remove">✕</button>
    </div>`).join('');
}

async function msPostAnnouncement() {
  const textEl = document.getElementById('ms-announce-text');
  const text = (textEl?.value || '').trim();
  if(!text) { msSetAnnounceStatus('Type a message first', true); return; }
  try {
    msSaveConfig();
    await msApi('/announce', { method:'POST', body: JSON.stringify({ text }) });
    if(textEl) textEl.value = '';
    msSetAnnounceStatus('✓ Posted — ' + new Date().toLocaleTimeString());
    toast('📢 Announcement posted to all phones');
    msFetchClaims();
  } catch(e) {
    msSetAnnounceStatus('✗ Failed: ' + e.message, true);
  }
}

async function msDeleteAnnouncement(id) {
  try {
    await msApi('/announce-delete', { method:'POST', body: JSON.stringify({ id }) });
    msFetchClaims();
  } catch(e) {
    msSetAnnounceStatus('✗ Could not remove: ' + e.message, true);
  }
}

function msToggleAutoSync() {
  const btn = document.getElementById('ms-autosync-btn');
  if(msState.pollTimer) {
    clearInterval(msState.pollTimer);
    msState.pollTimer = null;
    if(btn) { btn.textContent = '▶️ Start live sync'; }
    msSetStatus('Live sync stopped');
  } else {
    msSaveConfig();
    if(!msState.workerUrl || !msState.code) { msSetStatus('Set Worker URL and tournament code first', true); return; }
    msPullNow();
    msState.pollTimer = setInterval(msPullNow, 5000);
    if(btn) { btn.textContent = '⏸ Stop live sync'; }
    msSetStatus('Live sync running — checking every 5s');
  }
}

function renderMobileSyncTab() {
  msLoadConfig();
  const urlEl = document.getElementById('ms-worker-url');
  const codeEl = document.getElementById('ms-code');
  const autoEl = document.getElementById('ms-auto-push');
  if(urlEl) urlEl.value = msState.workerUrl;
  if(codeEl) codeEl.value = msState.code;
  if(autoEl) autoEl.checked = msState.autoPush;
  msRenderShareCard();
  msRenderCourtStatus(msGetCurrentCourtsPayload());
  msLoadPins();
  msFetchClaims().then(() => msRenderCourtStatus(msGetCurrentCourtsPayload()));
}

// Pulls existing PIN values from the Worker (e.g. after a page reload) so the
// organizer's PIN fields aren't blank just because the local cache reset.
async function msLoadPins() {
  if(!msState.workerUrl || !msState.code) return;
  try {
    const data = await msApi('/pins', { method:'GET' });
    msPinsCache = Object.assign({}, data.pins || {});
    msRenderQRCodes();
  } catch(e) { /* non-fatal — PIN fields just stay blank until typed */ }
}

// Auto-push hook: called after a score is saved or a new round starts,
// if the organizer has "auto-push" enabled and a Worker is configured.
function msAutoPushIfEnabled() {
  msLoadConfig();
  if(msState.autoPush && msState.workerUrl && msState.code) msPushNow();
}


// ── Live display themes ───────────────────────────────────────────────────
const LD_THEMES = [
  { bg: '#080d08', accent: '#C6FF00', name: 'Green'  },
  { bg: '#080d14', accent: '#60A5FA', name: 'Blue'   },
  { bg: '#0d080d', accent: '#C084FC', name: 'Purple' },
];
let _ldThemeIdx = 0;
try { _ldThemeIdx = parseInt(localStorage.getItem('pb_ld_theme')||'0')||0; } catch(e) {}

function ldApplyTheme() {
  const t = LD_THEMES[_ldThemeIdx % LD_THEMES.length];
  const el = document.getElementById('live-display');
  if(!el) return;
  el.style.background = t.bg;
  el.style.setProperty('--ld-accent', t.accent);
  // Update all accent-coloured elements
  el.querySelectorAll('[data-ld-accent]').forEach(n => n.style.color = t.accent);
  const btn = document.getElementById('ld-theme-btn');
  if(btn) btn.textContent = t.name.toUpperCase();
}

function ldCycleTheme() {
  _ldThemeIdx = (_ldThemeIdx + 1) % LD_THEMES.length;
  try { localStorage.setItem('pb_ld_theme', _ldThemeIdx); } catch(e) {}
  ldApplyTheme();
  renderLiveDisplay();
}

// ── Round-complete celebration sound mute ──────────────────────────────────
let _ldMuted = false;
try { _ldMuted = localStorage.getItem('pb_ld_mute') === '1'; } catch(e) {}

function ldApplyMuteIcon() {
  const btn = document.getElementById('ld-mute-btn');
  if(btn) btn.textContent = _ldMuted ? '🔇' : '🔊';
}

function ldToggleMute() {
  _ldMuted = !_ldMuted;
  try { localStorage.setItem('pb_ld_mute', _ldMuted ? '1' : '0'); } catch(e) {}
  ldApplyMuteIcon();
}

// ── True fullscreen (hides browser chrome) ─────────────────────────────────
function ldIsFullscreen() {
  return !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
}

function ldUpdateFullscreenControls() {
  const isFs = ldIsFullscreen();
  const btn = document.getElementById('ld-fullscreen-btn');
  const exitBtn = document.getElementById('ld-exit-fullscreen-btn');
  if(btn) {
    btn.textContent = isFs ? '⛶ Fullscreen On' : '⛶ Fullscreen';
    btn.style.color = isFs ? '#C6FF00' : 'rgba(255,255,255,0.4)';
  }
  if(exitBtn) {
    exitBtn.style.display = 'inline-flex';
    exitBtn.style.opacity = isFs ? '1' : '0.72';
    exitBtn.title = isFs ? 'Exit browser fullscreen but keep TV mode open' : 'Not currently fullscreen';
  }
}

function ldEnterFullscreen() {
  const el = document.getElementById('live-display');
  if(!el) return;
  const request = el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen;
  if(!request) { toast('Fullscreen not supported in this browser', 'err'); return; }
  try {
    const result = request.call(el);
    if(result && result.catch) result.catch(() => toast('Fullscreen not supported in this browser', 'err'));
  } catch(e) {
    toast('Fullscreen not supported in this browser', 'err');
  }
}

function ldExitFullscreenOnly() {
  if(!ldIsFullscreen()) { ldUpdateFullscreenControls(); return; }
  const exit = document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen;
  if(exit) {
    try {
      const result = exit.call(document);
      if(result && result.catch) result.catch(()=>{});
    } catch(e) {}
  }
  setTimeout(ldUpdateFullscreenControls, 150);
}

function ldToggleFullscreen() {
  if(ldIsFullscreen()) ldExitFullscreenOnly();
  else ldEnterFullscreen();
}

function ldBackToApp() {
  ldExitFullscreenOnly();
  closeLiveDisplay();
  setTimeout(() => { try { showTab('dashboard'); } catch(e) {} }, 80);
}

document.addEventListener('fullscreenchange', ldUpdateFullscreenControls);
document.addEventListener('webkitfullscreenchange', ldUpdateFullscreenControls);
document.addEventListener('msfullscreenchange', ldUpdateFullscreenControls);

function ldGetAccent() { return LD_THEMES[_ldThemeIdx % LD_THEMES.length].accent; }

// ── Generate next round from live display ─────────────────────────────────
// ── Announcement banner ─────────────────────────────────────────────────
function ldOpenAnnouncePrompt() {
  const modal = document.getElementById('announce-modal');
  const ta    = document.getElementById('announce-text');
  if(!modal || !ta) return;
  ta.value = state._ldAnnouncement || '';
  document.getElementById('announce-charcount').textContent = ta.value.length;
  modal.style.display = 'flex';
  setTimeout(() => ta.focus(), 50);
}

function closeAnnounceModal() {
  const modal = document.getElementById('announce-modal');
  if(modal) modal.style.display = 'none';
}

function ldPostAnnouncement() {
  const ta = document.getElementById('announce-text');
  if(!ta) return;
  const text = ta.value.trim();
  if(!text) { toast('Type a message first', 'err'); return; }
  state._ldAnnouncement = text;
  autoSave();
  if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  _liveBroadcast();
  closeAnnounceModal();
  toast('📢 Announcement posted to live display');
}

function ldClearAnnouncement() {
  state._ldAnnouncement = '';
  autoSave();
  if(document.getElementById('live-display')?.style.display !== 'none') renderLiveDisplay();
  _liveBroadcast();
  toast('Announcement cleared');
}

// Live char counter for the announce textarea
document.addEventListener('input', (e) => {
  if(e.target?.id === 'announce-text') {
    const cc = document.getElementById('announce-charcount');
    if(cc) cc.textContent = e.target.value.length;
  }
});

function ldGenerateNext() {
  closeLiveDisplay();
  // Small delay so the live display closes before the generate modal opens
  setTimeout(() => {
    showTab('schedule');
    askGenerateSchedule();
  }, 150);
}

// ── Round complete celebration ─────────────────────────────────────────────
let _ldRoundCompleteShown = -1;
function ldShowRoundComplete(roundNum) {
  if(_ldRoundCompleteShown === roundNum) return; // don't repeat
  _ldRoundCompleteShown = roundNum;
  const overlay = document.getElementById('ld-round-complete');
  const label   = document.getElementById('ld-rc-round');
  if(!overlay || !label) return;
  label.textContent = roundNum;
  overlay.style.display = 'flex';
  overlay.style.animation = 'ldRcFadeIn 0.4s ease';
  _ldCelebrationChime();
  _ldFireConfetti();
  setTimeout(() => {
    overlay.style.animation = 'ldRcFadeOut 0.6s ease';
    setTimeout(() => { overlay.style.display = 'none'; }, 600);
  }, 3000);
}

function openLiveDisplay() {
  if(!state.schedule.length) { toast('Generate a schedule first', 'err'); return; }
  const el = document.getElementById('live-display');
  if(el) el.style.display = 'flex';
  ldApplyTheme();
  ldApplyMuteIcon();
  ldUpdateFullscreenControls();
  _ldRoundCompleteShown = -1;
  _ldRoundStartTime = Date.now();
  renderLiveDisplay();
  // Clock + timer sync every second
  _ldClockTimer = setInterval(() => {
    const cl = document.getElementById('ld-clock');
    if(cl) cl.textContent = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
    const ldT = document.getElementById('ld-timer-display');
    if(ldT) {
      const secs = _timerGetRemaining();
      const abs = Math.abs(secs), m = Math.floor(abs/60), s = Math.floor(abs%60);
      ldT.textContent = `${secs<0?'+':''}${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      ldT.style.color = secs<=0?'#EF5350':secs<=120?'#FF8F00':'rgba(255,255,255,0.45)';
    }
    const timerBtn = document.getElementById('ld-timer-btn');
    if(timerBtn) timerBtn.textContent = _timerRunning ? '⏸ PAUSE' : '▶ START';
    // Refresh court cards every minute to update match duration
    if(new Date().getSeconds() === 0) renderLiveDisplay();
  }, 1000);
  document.body.style.overflow = 'hidden';
}

function closeLiveDisplay() {
  const el = document.getElementById('live-display');
  if(el) el.style.display = 'none';
  clearInterval(_ldTimer); clearInterval(_ldClockTimer);
  document.body.style.overflow = '';
  if(document.fullscreenElement) {
    (document.exitFullscreen?.() || document.webkitExitFullscreen?.())?.catch(()=>{});
  }
}

function renderLiveDisplay() {
  const titleEl    = document.getElementById('ld-title');
  const subtitleEl = document.getElementById('ld-subtitle');
  const courtsEl   = document.getElementById('ld-courts');
  const standEl    = document.getElementById('ld-standings');
  const clockEl    = document.getElementById('ld-clock');
  const progBar    = document.getElementById('ld-progress-bar');
  const progLabel  = document.getElementById('ld-progress-label');
  const ldTimer    = document.getElementById('ld-timer-display');
  const byeEl      = document.getElementById('ld-bye');
  const byeNames   = document.getElementById('ld-bye-names');
  const nextEl     = document.getElementById('ld-next');

  if(titleEl)  titleEl.textContent  = getTournamentName();
  if(clockEl)  clockEl.textContent  = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

  // Announcement banner
  const announceEl     = document.getElementById('ld-announce');
  const announceTextEl = document.getElementById('ld-announce-text');
  if(announceEl && announceTextEl) {
    if(state._ldAnnouncement) {
      announceEl.style.display = 'block';
      announceTextEl.textContent = state._ldAnnouncement;
    } else {
      announceEl.style.display = 'none';
    }
  }

  if(ldTimer) {
    const secs = _timerGetRemaining();
    const abs = Math.abs(secs), m = Math.floor(abs/60), s = Math.floor(abs%60);
    ldTimer.textContent = `${secs<0?'+':''}${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    ldTimer.style.color = secs<=0?'#EF5350':secs<=120?'#FF8F00':'rgba(255,255,255,0.45)';
  }

  let activeRound = null, activeRoundIdx = -1;
  for(let i = 0; i < state.schedule.length; i++) {
    if(state.schedule[i].some(m => m.teamA && m.teamB && !m.complete)) {
      activeRound = state.schedule[i]; activeRoundIdx = i; break;
    }
  }
  if(!activeRound) { activeRoundIdx = state.schedule.length-1; activeRound = state.schedule[activeRoundIdx]; }

  // Round badge — needs activeRoundIdx
  const roundNumEl   = document.getElementById('ld-round-num');
  const roundTotalEl = document.getElementById('ld-round-total');
  if(roundNumEl && activeRoundIdx >= 0) {
    roundNumEl.textContent = activeRoundIdx + 1;
    if(roundTotalEl) roundTotalEl.textContent = `of ${state.schedule.length}`;
  }

  const accent = ldGetAccent();

  const totalDone     = state.schedule.flat().filter(m => m.complete).length;
  const totalAll      = state.schedule.flat().filter(m => m.teamA && m.teamB).length;
  const allThisRound  = activeRound.filter(m => m.teamA && m.teamB);
  const doneThisRound = allThisRound.filter(m => m.complete).length;
  const roundDone     = doneThisRound === allThisRound.length && allThisRound.length > 0;

  if(subtitleEl) subtitleEl.textContent =
    `${doneThisRound}/${allThisRound.length} courts done  ·  ${totalDone}/${totalAll} matches total`;
  if(progBar)   progBar.style.width   = totalAll ? Math.round(totalDone/totalAll*100)+'%' : '0%';
  if(progLabel) progLabel.textContent = totalAll ? `${totalDone}/${totalAll} complete` : '';

  // Round complete celebration — find the LAST round (by index) that is fully
  // complete, independent of activeRound. activeRound deliberately skips past
  // finished rounds to show the next in-progress one, so when every round is
  // pregenerated upfront, finishing round N (with round N+1 already pending)
  // would never trigger a celebration if we only checked activeRound/roundDone.
  let lastCompletedRoundIdx = -1;
  for(let i = 0; i < state.schedule.length; i++) {
    const matches = state.schedule[i].filter(m => m.teamA && m.teamB);
    if(matches.length > 0 && matches.every(m => m.complete)) lastCompletedRoundIdx = i;
  }
  if(lastCompletedRoundIdx >= 0) {
    ldShowRoundComplete(lastCompletedRoundIdx + 1);
  }
  // Track when this round started (reset if it changed)
  if(!window._ldLastRoundIdx || window._ldLastRoundIdx !== activeRoundIdx) {
    window._ldLastRoundIdx = activeRoundIdx;
    if(!roundDone) _ldRoundStartTime = Date.now();
  }

  // Generate next round button
  const genWrap    = document.getElementById('ld-gen-wrap');
  const genRoundEl = document.getElementById('ld-gen-round-num');
  const hasNext    = !!state.schedule[activeRoundIdx+1];
  const allSessionDone = totalAll > 0 && totalDone === totalAll;
  if(genWrap) {
    // Show if round is done and either a next round exists (to view) or session is not finished
    genWrap.style.display = (roundDone && !allSessionDone && !hasNext) ? 'block' : 'none';
    if(genRoundEl) genRoundEl.textContent = activeRoundIdx + 2;
  }

  // Win streaks
  const streakMap = {};
  state.players.forEach((_,i) => { streakMap[i] = 0; });
  state.schedule.flat().filter(m => m.complete && m.teamA && m.teamB).forEach(m => {
    const [a,b] = m.teamA, [c,d] = m.teamB;
    const aWon = m.scoreA > m.scoreB;
    [a,b].forEach(i => { if(i!=null) streakMap[i] = aWon ? (streakMap[i]||0)+1 : 0; });
    [c,d].forEach(i => { if(i!=null) streakMap[i] = !aWon ? (streakMap[i]||0)+1 : 0; });
  });

  // Court cards — vw-based sizing for TV readability
  const n = allThisRound.length;
  if(courtsEl) {
    const nameFontSize  = n<=2?'2.8vw':n<=4?'2vw':n<=6?'1.6vw':'1.3vw';
    const scoreFontSize = n<=2?'7vw':n<=4?'5vw':n<=6?'4vw':'3.2vw';
    const courtFontSize = n<=4?'0.95vw':'0.8vw';
    const inputSize     = n<=4?'2.5vw':'1.8vw';
    const btnSize       = n<=4?'0.85vw':'0.7vw';

    if(!allThisRound.length) {
      courtsEl.innerHTML = '<div style="color:rgba(255,255,255,0.25);font-size:2vw;grid-column:1/-1;text-align:center;padding:3rem 0;font-weight:500">No matches this round</div>';
    } else {
      courtsEl.innerHTML = allThisRound.map(m => {
        const done       = m.complete;
        const needsScore = !done && doneThisRound > 0;
        const winA = done && m.scoreA > m.scoreB;
        const winB = done && m.scoreB > m.scoreA;

        // Depth via layered gradients + glow on active courts
        const cardBg = done
          ? 'linear-gradient(155deg, rgba(255,255,255,0.025), rgba(255,255,255,0.005))'
          : needsScore
            ? 'linear-gradient(155deg, rgba(255,143,0,0.1), rgba(255,143,0,0.02))'
            : `linear-gradient(155deg, rgba(198,255,0,0.09), rgba(198,255,0,0.015))`;
        const border      = done?'rgba(255,255,255,0.07)':needsScore?'rgba(255,143,0,0.45)':'rgba(198,255,0,0.4)';
        const cardShadow  = done?'none':needsScore?'0 4px 28px rgba(255,143,0,0.12), inset 0 1px 0 rgba(255,255,255,0.04)':'0 4px 28px rgba(198,255,0,0.12), inset 0 1px 0 rgba(255,255,255,0.04)';
        const statusColor = done?'rgba(255,255,255,0.25)':needsScore?'#FFB74D':accent;
        const statusTxt   = done?'COMPLETE':needsScore?'ENTER SCORE':'IN PLAY';
        const statusDot   = done?'':`<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:currentColor;margin-right:5px;${!needsScore?'box-shadow:0 0 6px currentColor;animation:ldPulse 1.6s ease infinite':''}"></span>`;
        const nameA = escHtml(matchTeamName(m.teamA));
        const nameB = escHtml(matchTeamName(m.teamB));

        const scoreBlock = done
          ? `<div class="ld-score-appear" style="display:flex;align-items:center;justify-content:center;gap:1.6vw;margin-top:0.6vw">
               <div style="font-family:'Anton',sans-serif;font-size:${scoreFontSize};color:${winA?accent:'rgba(255,255,255,0.22)'};line-height:0.9;${winA?`text-shadow:0 0 30px ${accent}66`:''}">${m.scoreA}</div>
               <div style="font-family:'Anton',sans-serif;font-size:${scoreFontSize};color:rgba(255,255,255,0.12);line-height:0.9">–</div>
               <div style="font-family:'Anton',sans-serif;font-size:${scoreFontSize};color:${winB?accent:'rgba(255,255,255,0.22)'};line-height:0.9;${winB?`text-shadow:0 0 30px ${accent}66`:''}">${m.scoreB}</div>
             </div>`
          : `<div style="display:flex;align-items:center;justify-content:center;gap:0.6rem;margin-top:0.85vw" onclick="event.stopPropagation()">
               <input type="number" min="0" max="99" placeholder="0" id="ld-score-a-${m.id}"
                 style="width:5vw;min-width:42px;font-family:'Anton',sans-serif;font-size:${inputSize};text-align:center;background:rgba(0,0,0,0.25);border:1.5px solid rgba(255,255,255,0.12);border-radius:9px;color:#fff;padding:0.25rem"
                 onkeydown="if(event.key==='Enter')ldSaveScore(${m.id})">
               <span style="font-size:${courtFontSize};color:rgba(255,255,255,0.2);font-weight:600">VS</span>
               <input type="number" min="0" max="99" placeholder="0" id="ld-score-b-${m.id}"
                 style="width:5vw;min-width:42px;font-family:'Anton',sans-serif;font-size:${inputSize};text-align:center;background:rgba(0,0,0,0.25);border:1.5px solid rgba(255,255,255,0.12);border-radius:9px;color:#fff;padding:0.25rem"
                 onkeydown="if(event.key==='Enter')ldSaveScore(${m.id})">
               <button onclick="ldSaveScore(${m.id})" style="background:linear-gradient(135deg,#D4FF33,#A8E000);color:#0a1206;border:none;border-radius:9px;padding:0.45vw 1.1vw;font-weight:700;font-size:${btnSize};cursor:pointer;white-space:nowrap;letter-spacing:0.5px;box-shadow:0 4px 14px rgba(198,255,0,0.25)">SAVE</button>
             </div>`;

        const courtNumSize = n<=2?'4vw':n<=4?'3vw':n<=6?'2.4vw':'2vw';

        // Match duration — minutes since round started
        const elapsedMin = _ldRoundStartTime ? Math.floor((Date.now() - _ldRoundStartTime) / 60000) : 0;
        const durationStr = !done && elapsedMin > 0 ? ` · ${elapsedMin}m` : '';

        return `<div style="background:${cardBg};border:1.5px solid ${border};border-radius:16px;padding:1.25vw 1.5vw;box-shadow:${cardShadow};backdrop-filter:blur(2px)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.85vw">
            <div style="display:flex;align-items:baseline;gap:0.6vw">
              <span style="font-family:'Anton',sans-serif;font-size:${courtNumSize};color:${accent};letter-spacing:0.5px;line-height:1">${m.court}</span>
              <span style="font-family:'Space Grotesk',sans-serif;font-weight:600;font-size:${courtFontSize};color:rgba(255,255,255,0.3);letter-spacing:1.5px">COURT</span>
              ${m.podLabel?`<span style="font-family:'Space Grotesk',sans-serif;font-weight:600;font-size:${courtFontSize};color:${accent};letter-spacing:1px;opacity:0.65">${escHtml(m.podLabel.split('·')[0].trim())}</span>`:''}
            </div>
            <div style="font-size:${courtFontSize};font-weight:700;color:${statusColor};letter-spacing:1.5px;display:flex;align-items:center">${statusDot}${statusTxt}${durationStr}</div>
          </div>
          <div style="display:flex;align-items:center;gap:1vw">
            <div style="flex:1;text-align:right">
              <div class="${done&&winA?'ld-win-flash':''}" style="font-size:${nameFontSize};font-weight:700;color:${winA?accent:'#fff'};line-height:1.2;letter-spacing:-0.2px">${nameA}</div>
            </div>
            <div style="font-family:'Space Grotesk',sans-serif;font-weight:600;font-size:${courtFontSize};color:rgba(255,255,255,0.15);flex-shrink:0;letter-spacing:1px">VS</div>
            <div style="flex:1;text-align:left">
              <div class="${done&&winB?'ld-win-flash':''}" style="font-size:${nameFontSize};font-weight:700;color:${winB?accent:'#fff'};line-height:1.2;letter-spacing:-0.2px">${nameB}</div>
            </div>
          </div>
          ${scoreBlock}
        </div>`;
      }).join('');
    }
  }

  // Player → Court lookup
  const lookupEl   = document.getElementById('ld-lookup');
  const lookupRows = document.getElementById('ld-lookup-rows');
  const byePlayers = (state.byeRounds||[])[activeRoundIdx]||[];
  if(lookupEl && lookupRows) {
    const lookupData = [];
    allThisRound.forEach(m => {
      const court = m.court;
      [...(m.teamA||[]), ...(m.teamB||[])].forEach(pi => {
        const p = state.players[pi];
        if(p) lookupData.push({ name: p.name, court });
      });
    });
    byePlayers.forEach(pi => {
      const p = state.players[pi];
      if(p) lookupData.push({ name: p.name, court: null });
    });
    lookupData.sort((a,b) => a.name.localeCompare(b.name));
    if(lookupData.length) {
      lookupEl.style.display = 'block';
      const nameSize = n <= 4 ? '1.4vw' : n <= 6 ? '1.2vw' : '1vw';
      lookupRows.innerHTML = lookupData.map(d =>
        `<div style="display:flex;align-items:baseline;justify-content:space-between;padding:0.2rem 0;border-bottom:1px solid rgba(255,255,255,0.04)">
          <span style="font-size:${nameSize};font-weight:600;color:rgba(255,255,255,0.7)">${escHtml(d.name)}</span>
          <span style="font-family:'Anton',sans-serif;font-size:${nameSize};color:${d.court?accent:'rgba(255,143,0,0.75)'};margin-left:0.75rem;white-space:nowrap">${d.court?'C'+d.court:'BYE'}</span>
        </div>`
      ).join('');
    } else {
      lookupEl.style.display = 'none';
    }
  }
  if(byeEl && byeNames) {
    if(byePlayers.length) {
      byeEl.style.display = 'block';
      byeNames.textContent = byePlayers.map(i => state.players[i]?.name||'?').join('  ·  ');
    } else {
      byeEl.style.display = 'none';
    }
  }

  // Next round preview
  const nextRound = state.schedule[activeRoundIdx+1];
  if(nextEl) {
    if(roundDone && nextRound) {
      nextEl.style.display = 'block';
      document.getElementById('ld-next-round-num').textContent = activeRoundIdx+2;
      const nextMatches = nextRound.filter(m => m.teamA && m.teamB);
      document.getElementById('ld-next-matches').innerHTML = nextMatches.map(m =>
        `<div style="font-size:1vw;color:rgba(255,255,255,0.4);padding:0.3rem 0;border-bottom:1px solid rgba(255,255,255,0.06)">
          <span style="color:rgba(255,255,255,0.25);font-size:0.85vw">C${m.court}</span>
          <span style="margin:0 0.4rem;color:rgba(255,255,255,0.6);font-weight:600">${escHtml(matchTeamName(m.teamA))}</span>
          <span style="color:rgba(255,255,255,0.2)">vs</span>
          <span style="margin:0 0.4rem;color:rgba(255,255,255,0.6);font-weight:600">${escHtml(matchTeamName(m.teamB))}</span>
        </div>`
      ).join('');
    } else {
      nextEl.style.display = 'none';
    }
  }

  // Standings sidebar with hot streak 🔥
  if(standEl) {
    const stats = buildPlayerStats().map(s => {
      const g = s.games;
      const pf = g.reduce((a,x)=>a+Number(x.pts),0);
      const pa = g.reduce((a,x)=>a+Number(x.opponentPts),0);
      const wins = g.filter(x=>x.won).length, gp = g.length;
      const streak = streakMap[s.playerIdx]||0;
      return { name: s.player.name.split(' ')[0], wins, gp, pf, diff: pf-pa, streak };
    }).filter(s => s.gp > 0).sort((a,b)=>b.wins-a.wins||b.diff-a.diff||b.pf-a.pf);

    standEl.innerHTML = stats.length ? stats.map((s,i) => {
      const medal    = i===0?'🥇':i===1?'🥈':i===2?'🥉':'';
      const diffStr  = s.diff>0?`+${s.diff}`:String(s.diff);
      const diffColor= s.diff>0?accent:s.diff<0?'#EF5350':'rgba(255,255,255,0.3)';
      const fire     = s.streak>=3?' 🔥':'';
      return `<div style="display:flex;align-items:center;justify-content:space-between;padding:0.5rem 0;border-bottom:1px solid rgba(255,255,255,0.045)">
        <div style="display:flex;align-items:center;gap:6px;min-width:0">
          <span style="font-size:0.85rem;flex-shrink:0;width:18px;text-align:center">${medal||`<span style='font-size:0.68rem;color:rgba(255,255,255,0.22);font-weight:600'>${i+1}</span>`}</span>
          <span style="font-size:0.88rem;font-weight:600;color:${i<3?'#fff':'rgba(255,255,255,0.55)'};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-0.1px">${escHtml(s.name)}${fire}</span>
        </div>
        <div style="text-align:right;flex-shrink:0;margin-left:6px">
          <div style="font-family:'Anton',sans-serif;font-size:1.1rem;color:${accent};line-height:1">${s.wins}<span style="font-size:0.6em;opacity:0.6;font-family:'Space Grotesk',sans-serif;font-weight:600">W</span></div>
          <div style="font-size:0.64rem;color:${diffColor};line-height:1;font-weight:600">${diffStr}</div>
        </div>
      </div>`;
    }).join('') : '<div style="color:rgba(255,255,255,0.2);font-size:0.8rem">No scores yet</div>';
  }
  const mvpEl = document.getElementById('ld-mvp');
  if(mvpEl) {
    const allDone = totalAll>0 && totalDone===totalAll;
    if(allDone) {
      const mvpData = buildPlayerStats()
        .filter(d => d.gamesPlayed>=2)
        .map(d => {
          const winRate  = d.gamesPlayed ? d.wins/d.gamesPlayed : 0;
          const diffNorm = d.diff/Math.max(1,d.gamesPlayed);
          return { ...d, mvpScore: winRate*50 + Math.max(0,diffNorm)*3 + (winRate>0.5?20:0) };
        })
        .sort((a,b)=>b.mvpScore-a.mvpScore)[0];
      if(mvpData) {
        mvpEl.style.display='block';
        document.getElementById('ld-mvp-name').textContent  = mvpData.player.name.toUpperCase();
        document.getElementById('ld-mvp-stats').textContent = `${mvpData.wins}W – ${mvpData.losses}L  ·  ${mvpData.diff>0?'+':''}${mvpData.diff} pts  ·  ${Math.round(mvpData.wins/mvpData.gamesPlayed*100)}% win rate`;
      }
    } else { mvpEl.style.display='none'; }
  }

  // QR (once)
  const qrEl = document.getElementById('ld-qr');
  if(qrEl && !qrEl.hasChildNodes()) {
    try { if(typeof QRCode!=='undefined') new QRCode(qrEl,{text:window.location.href.split('#')[0],width:90,height:90,colorDark:'#000',colorLight:'#fff'}); } catch(e) {}
  }
}

// Save score directly from the live display
function ldSaveScore(matchId) {
  const aEl = document.getElementById(`ld-score-a-${matchId}`);
  const bEl = document.getElementById(`ld-score-b-${matchId}`);
  if(!aEl || !bEl) return;
  const sa = parseInt(aEl.value), sb = parseInt(bEl.value);
  if(isNaN(sa) || isNaN(sb)) { toast('Enter both scores', 'err'); return; }
  const m = state.schedule.flat().find(x => x.id === matchId);
  if(!m) return;
  pushUndo(matchId, m.scoreA, m.scoreB, m.complete);
  m.scoreA = sa; m.scoreB = sb; m.complete = true;
  updateStandings(); checkRoundComplete();
  renderSchedule(); renderCourtsGrid(); updateProgress();
  if(document.getElementById('sec-playerstats')?.classList.contains('active')) { renderPlayerStats(); renderH2H(); }
  updateReportIfActive(); autoSave();
  renderLiveDisplay();
  _liveBroadcast();
  toast(`✅ Court ${m.court}: ${sa} – ${sb}`);
}


function seasonClearAll() {
  const hist = phLoad();
  const count = Object.keys(hist).length;
  if(!count) { toast('No season history to clear', 'err'); return; }
  const total = Object.values(hist).reduce((s,a)=>s+a.length,0);
  if(!confirm('Delete ALL season history? This removes ' + total + ' tournament record' + (total===1?'':'s') + ' for ' + count + ' player' + (count===1?'':'s') + '. Cannot be undone.')) return;
  phSave({});
  renderSeasonBoard();
  toast('Season history cleared');
}

function seasonDeleteTournament(tid) {
  const hist = phLoad();
  // Find tournament name for confirmation
  let tname = tid;
  for(const arr of Object.values(hist)) {
    const e = arr.find(e => e.tid === tid);
    if(e) { tname = e.tournament; break; }
  }
  const affected = Object.entries(hist).filter(([,arr]) => arr.some(e => e.tid === tid)).length;
  if(!confirm('Delete "' + tname + '" from season history? This removes data for ' + affected + ' player' + (affected===1?'':'s') + '.')) return;
  Object.keys(hist).forEach(key => {
    hist[key] = hist[key].filter(e => e.tid !== tid);
    if(!hist[key].length) delete hist[key];
  });
  phSave(hist);
  renderSeasonBoard();
  toast('Deleted "' + tname + '" from season history');
}

function seasonRenameTournament(tid) {
  const hist = phLoad();
  let current = '';
  for(const arr of Object.values(hist)) {
    const e = arr.find(e => e.tid === tid);
    if(e) { current = e.tournament; break; }
  }
  const newName = prompt('Rename tournament:', current);
  if(!newName || newName.trim() === current) return;
  const trimmed = newName.trim();
  Object.values(hist).forEach(arr => arr.forEach(e => { if(e.tid === tid) e.tournament = trimmed; }));
  phSave(hist);
  renderSeasonBoard();
  toast('Renamed to "' + trimmed + '"');
}

function renderSeasonBoard() {
  const hist = phLoad();
  const from = document.getElementById('season-from')?.value || '';
  const to   = document.getElementById('season-to')?.value   || '';

  // Collect every unique tournament within date range
  const tids = new Map(); // tid -> {date, tournament}
  Object.values(hist).forEach(arr => arr.forEach(e => {
    if(e.tid && !tids.has(e.tid)) {
      if(from && e.date < from) return;
      if(to   && e.date > to)   return;
      tids.set(e.tid, { date: e.date, tournament: e.tournament });
    }
  }));
  const sortedTids = [...tids.keys()].sort((a,b) => tids.get(a).date.localeCompare(tids.get(b).date));

  // Meta
  const metaEl = document.getElementById('season-meta');
  if(metaEl) metaEl.textContent = sortedTids.length + ' tournament' + (sortedTids.length===1?'':'s')
    + (from||to ? ' · filtered' + (from ? ' from ' + from : '') + (to ? ' to ' + to : '') : ' · all time');

  // Tournaments list
  const tListEl = document.getElementById('season-tournaments');
  if(tListEl) {
    if(!sortedTids.length) {
      tListEl.innerHTML = '<div style="color:var(--txt3);font-size:0.85rem">No tournament data found. Play some events and view the Report tab to start tracking.</div>';
    } else {
      tListEl.innerHTML = sortedTids.map(tid => {
        const info = tids.get(tid);
        const playerCount = Object.entries(hist).filter(([, arr]) => arr.some(e => e.tid === tid)).length;
        const safeTid = JSON.stringify(tid);
        return '<div style="display:flex;align-items:center;gap:0.5rem;padding:0.4rem 0;border-bottom:1px solid var(--border);font-size:0.85rem">'
          + '<span style="flex:1;font-weight:600" id="stname-'+escHtml(tid)+'">' + escHtml(info.tournament) + '</span>'
          + '<span style="color:var(--txt3);font-size:0.78rem">' + info.date + ' · ' + playerCount + ' player' + (playerCount===1?'':'s') + '</span>'
          + '<button class="btn btn-secondary btn-sm" onclick="seasonRenameTournament('+safeTid+')" title="Rename this tournament">✏</button>'
          + '<button class="btn btn-danger btn-sm" onclick="seasonDeleteTournament('+safeTid+')" title="Delete all data for this tournament">✕</button>'
          + '</div>';
      }).join('');
    }
  }

  // Aggregate stats per player
  const players = {}; // key(lower) -> {name, events, wins, losses, gp, duprDelta, clubRatings}
  Object.entries(hist).forEach(([key, arr]) => {
    const inRange = arr.filter(e => {
      if(from && e.date < from) return false;
      if(to   && e.date > to)   return false;
      return tids.has(e.tid);
    });
    if(!inRange.length) return;
    const lastName = inRange[inRange.length-1];
    const stats = players[key] || { name: '', events: 0, gp: 0, wins: 0, losses: 0, duprDelta: 0, firstDupr: null, lastDupr: null, clubRatings: [] };
    stats.name = stats.name || (key.replace(/\b\w/g, c => c.toUpperCase()));
    inRange.forEach(e => {
      stats.events++;
      stats.gp    += e.gp || 0;
      // Infer wins/losses from winPct and gp (winPct = wins/gp * 100)
      if(e.gp > 0 && e.winPct != null) {
        const w = Math.round((e.winPct / 100) * e.gp);
        stats.wins   += w;
        stats.losses += e.gp - w;
      }
      stats.duprDelta += (e.delta || 0);
      if(e.dupr != null) {
        if(stats.firstDupr == null) stats.firstDupr = e.dupr;
        stats.lastDupr = e.dupr;
      }
      if(e.clubRating) stats.clubRatings.push(e.clubRating);
    });
    players[key] = stats;
  });

  // Points: 3 per win, 1 per loss
  const rows = Object.entries(players).map(([key, s]) => ({
    ...s,
    key,
    points: s.wins * 3 + s.losses * 1,
    winPct: s.gp ? Math.round((s.wins / s.gp) * 100) : 0,
    duprChange: (s.firstDupr != null && s.lastDupr != null) ? +(s.lastDupr - s.firstDupr).toFixed(3) : null,
    lastCR: s.clubRatings.length ? s.clubRatings[s.clubRatings.length-1] : null,
    firstCR: s.clubRatings.length ? s.clubRatings[0] : null,
  }));

  const sortKey = document.getElementById('season-sort')?.value || 'points';
  rows.sort((a,b) => {
    if(sortKey==='wins')   return b.wins - a.wins || b.winPct - a.winPct;
    if(sortKey==='winpct') return b.winPct - a.winPct || b.gp - a.gp;
    if(sortKey==='dupr')   return (b.duprChange ?? -99) - (a.duprChange ?? -99);
    if(sortKey==='events') return b.events - a.events || b.wins - a.wins;
    return b.points - a.points || b.wins - a.wins; // default: points
  });

  // Leaderboard table
  const tbody = document.getElementById('season-tbody');
  if(tbody) {
    if(!rows.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--txt3);padding:2rem">No data yet.</td></tr>';
    } else {
      tbody.innerHTML = rows.map((r, i) => {
        const medal = i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1);
        const dStr = r.duprChange == null ? '—' : (r.duprChange>0?'+':'') + r.duprChange;
        const dCol = r.duprChange == null ? 'var(--txt3)' : r.duprChange>0 ? 'var(--lime)' : r.duprChange<0 ? 'var(--red)' : 'var(--txt3)';
        const crPart = r.lastCR
          ? (r.firstCR !== r.lastCR
            ? `<span style="color:var(--ball)">${escHtml(r.firstCR)} → ${escHtml(r.lastCR)} 🎉</span>`
            : `<span style="color:#FFD54F">${escHtml(r.lastCR)}</span>`)
          : '—';
        return `<tr>
          <td style="text-align:center">${medal}</td>
          <td style="font-weight:700">${escHtml(r.name)}</td>
          <td style="text-align:center">${r.events}</td>
          <td style="text-align:center;font-weight:700;color:var(--lime)">${r.wins}</td>
          <td style="text-align:center">${r.gp}</td>
          <td style="text-align:center">${r.winPct}%</td>
          <td style="text-align:center;font-weight:700;color:var(--ball)">${r.points}</td>
          <td style="text-align:center;color:${dCol};font-family:monospace">${dStr}</td>
          <td style="text-align:center">${crPart}</td>
        </tr>`;
      }).join('');
    }
  }

  // Season awards
  const awEl = document.getElementById('season-awards');
  if(awEl && rows.length) {
    const card = (icon, title, who, detail, color) =>
      `<div style="background:var(--surface);border:1px solid var(--border);border-left:3px solid ${color};border-radius:8px;padding:0.6rem 0.8rem">
        <div style="font-size:0.68rem;color:var(--txt3);text-transform:uppercase;letter-spacing:0.8px;margin-bottom:2px">${icon} ${title}</div>
        <div style="font-weight:700;font-size:0.92rem">${escHtml(who)}</div>
        <div style="font-size:0.72rem;color:var(--txt2)">${escHtml(detail)}</div>
      </div>`;

    const top = rows[0];
    const mostWins = [...rows].sort((a,b)=>b.wins-a.wins)[0];
    const bestPct  = [...rows].filter(r=>r.gp>=2).sort((a,b)=>b.winPct-a.winPct)[0];
    const mostEvts = [...rows].sort((a,b)=>b.events-a.events)[0];
    const bestDupr = [...rows].filter(r=>r.duprChange!=null).sort((a,b)=>b.duprChange-a.duprChange)[0];
    const promoted = rows.filter(r=>r.lastCR && r.firstCR && r.lastCR!==r.firstCR);
    const mostPts  = [...rows].sort((a,b)=>b.points-a.points)[0];

    const awards = [];
    if(top)       awards.push(card('🏆','Season Champion', top.name, top.points + ' pts · ' + top.wins + 'W', 'var(--gold)'));
    if(mostWins)  awards.push(card('🥊','Most Wins', mostWins.name, mostWins.wins + ' wins', 'var(--lime)'));
    if(bestPct && bestPct !== top) awards.push(card('🎯','Best Win %', bestPct.name, bestPct.winPct + '% over ' + bestPct.gp + ' games', 'var(--blue)'));
    if(mostEvts)  awards.push(card('🛡️','Iron Player', mostEvts.name, mostEvts.events + ' events', 'var(--txt3)'));
    if(bestDupr && bestDupr.duprChange > 0) awards.push(card('📈','Most Improved (DUPR)', bestDupr.name, '+' + bestDupr.duprChange + ' DUPR', 'var(--ball)'));
    promoted.forEach(r => awards.push(card('🎉','Promoted!', r.name, r.firstCR + ' → ' + r.lastCR + ' this season', 'var(--purple)')));

    awEl.innerHTML = awards.join('') || '<div style="color:var(--txt3);font-size:0.85rem">Play more events to unlock season awards.</div>';
  }
}

function renderEmailTab() {
  emLoad();
  if(window.location.protocol === 'file:') {
    const w = document.getElementById('email-file-warning');
    if(w) w.style.display = 'block';
  }
  emUpdateSubjectHint();
  emRenderPlayerList();
  emUpdatePreview();
}

// Checklist of players with email addresses, for individual/selected sending.
// Selection state persists across re-renders within the session via _emSelected.
function emRenderPlayerList() {
  const el = document.getElementById('em-player-list');
  if(!el) return;
  const withEmail = state.players.filter(p => p.email && p.email.trim());
  const count = document.getElementById('em-count');
  if(count) count.textContent = withEmail.length + ' player' + (withEmail.length===1?'':'s') + ' with an email address';
  if(!withEmail.length) {
    el.innerHTML = '<div style="color:var(--txt3);font-size:0.82rem;grid-column:1/-1">No players have an email address yet — add one on the Players tab.</div>';
    return;
  }
  if(!state._emSelected) state._emSelected = new Set();
  // Default: select everyone with an email the first time the list is shown
  if(state._emSelectedInit !== true) {
    withEmail.forEach(p => state._emSelected.add(p.id));
    state._emSelectedInit = true;
  }
  el.innerHTML = withEmail.map(p => {
    const checked = state._emSelected.has(p.id) ? 'checked' : '';
    return '<label style="display:flex;align-items:center;gap:0.4rem;font-size:0.82rem;background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:0.35rem 0.55rem;cursor:pointer">'
      + '<input type="checkbox" ' + checked + ' onchange="emToggleSelected(' + p.id + ', this.checked)">'
      + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escHtml(p.name) + '</span>'
      + '</label>';
  }).join('');
}

function emToggleSelected(playerId, checked) {
  if(!state._emSelected) state._emSelected = new Set();
  if(checked) state._emSelected.add(playerId); else state._emSelected.delete(playerId);
}

function emSelectAll(on) {
  const withEmail = state.players.filter(p => p.email && p.email.trim());
  state._emSelected = new Set(on ? withEmail.map(p => p.id) : []);
  emRenderPlayerList();
}

// SMTP host/port/security/user/pass are now held server-side by the relay
// Worker — nothing left for the browser to manage for those. Subject is
// intentionally NOT persisted here either — it's tournament-specific
// (includes the tournament name/date), so it's recomputed fresh each time
// the Email tab loads via emDefaultSubject(), rather than carrying over
// between events.
function emSave() {
  emUpdatePreview();
}

function emLoad() {
  const set = (id, v) => { const el = document.getElementById(id); if(el && v != null) el.value = v; };
  set('em-subject', emDefaultSubject());
  const subjEl = document.getElementById('em-subject');
  if(subjEl) subjEl.dataset.lastDefault = subjEl.value;
}

function emGetCfg() { return {}; }

// ── Build the per-player HTML email: personal card + full standings ──
function emBuildHtml(player) {
  const tname = getTournamentName() || 'Pickleball Tournament';
  const stats = buildPlayerStats().map(emDeriveRow);
  const ranked = [...stats].sort((a,b) => b.wins - a.wins || b.diff - a.diff || b.pf - a.pf);
  const mine = ranked.find(s => s.player.id === player.id);
  const myRank = mine ? ranked.indexOf(mine) + 1 : null;
  const fn = player.name.split(' ')[0];

  const esc = s => String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  // Personal card
  let personal = '';
  if(mine && mine.gp > 0) {
    const medal = myRank === 1 ? '🥇' : myRank === 2 ? '🥈' : myRank === 3 ? '🥉' : '#' + myRank;
    const stat = (label, val, color) =>
      `<td style="padding:8px 6px;text-align:center;border:1px solid #e0e0e0">
        <div style="font-size:20px;font-weight:700;color:${color||'#1B5E20'}">${esc(val)}</div>
        <div style="font-size:10px;color:#888;text-transform:uppercase;letter-spacing:0.5px">${esc(label)}</div>
      </td>`;
    personal = `
      <p style="font-size:15px;color:#333;margin:0 0 14px">Hi ${esc(fn)}, here's how your tournament went:</p>
      <div style="background:#f1f8e9;border-radius:10px;padding:16px;margin-bottom:18px">
        <div style="font-size:13px;color:#558B2F;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Your Finish</div>
        <div style="font-size:30px;font-weight:800;color:#1B5E20">${medal} ${esc(fn)}</div>
        <div style="font-size:13px;color:#666;margin-top:2px">out of ${ranked.filter(s=>s.gp>0).length} players</div>
        <table style="width:100%;border-collapse:collapse;margin-top:14px;background:#fff;border-radius:8px;overflow:hidden">
          <tr>
            ${stat('Played', mine.gp)}
            ${stat('Won', mine.wins, '#2E7D32')}
            ${stat('Lost', mine.losses, '#C62828')}
            ${stat('Win %', mine.winPct + '%')}
          </tr>
          <tr>
            ${stat('Pts For', mine.pf)}
            ${stat('Pts Against', mine.pa)}
            ${stat('Diff', (mine.diff>0?'+':'') + mine.diff, mine.diff>=0?'#2E7D32':'#C62828')}
            ${stat('Avg', mine.avg.toFixed(1))}
          </tr>
        </table>
      </div>`;
  } else {
    personal = `<p style="font-size:15px;color:#333;margin:0 0 14px">Hi ${esc(fn)}, thanks for playing in ${esc(tname)}! Here are the final standings:</p>`;
  }

  // Personal improvement trend (from stored cross-tournament history, if any)
  let trendBlock = '';
  if(mine && mine.gp > 0) {
    const key = player.name.trim().toLowerCase();
    const hist = phLoad();
    const arr = (hist[key] || []).slice().sort((a,b) => a.date.localeCompare(b.date) || a.tid.localeCompare(b.tid));
    const past = state._historyId ? arr.filter(e => e.tid !== state._historyId) : arr;
    if(past.length) {
      const nr = parseFloat(document.getElementById('dupr-nr-default')?.value || '3.5');
      const myStart = (player.dupr != null && !isNaN(player.dupr)) ? player.dupr : nr;
      const ratingOf = i => { const p = state.players[i]; return (p?.dupr != null && !isNaN(p.dupr)) ? p.dupr : nr; };
      let delta = 0;
      mine.games.forEach(g => {
        if(g.tied) return;
        const teamAvg = g.partnerIdx !== undefined ? (myStart + ratingOf(g.partnerIdx)) / 2 : myStart;
        const oppAvg  = g.opponentIdxs && g.opponentIdxs.length
          ? g.opponentIdxs.reduce((sum,oi) => sum + ratingOf(oi), 0) / g.opponentIdxs.length : myStart;
        delta += 0.1 * ((g.won ? 1 : 0) - duprExpectedScore(teamAvg, oppAvg));
      });
      const curDupr = +(myStart + delta).toFixed(3);
      const firstDupr = past.find(e => e.dupr != null)?.dupr ?? null;
      const overallChange = firstDupr != null ? curDupr - firstDupr : null;
      const lastPastWithDupr = [...past].reverse().find(e => e.dupr != null);
      const sinceLastChange = lastPastWithDupr ? curDupr - lastPastWithDupr.dupr : null;
      const winPctTrend = [...past.map(e => e.winPct).filter(v => typeof v === 'number'), mine.winPct];

      // Club Rating promotion (discrete level — show first-seen vs current)
      const firstCR = past.find(e => e.clubRating != null)?.clubRating ?? null;
      const curCR = player.clubRating || null;
      const crChanged = firstCR != null && curCR != null && firstCR !== curCR;

      const fmt = v => (v > 0 ? '+' : '') + v.toFixed(2);
      const ocColor = overallChange == null ? '#999' : overallChange > 0 ? '#2E7D32' : overallChange < 0 ? '#C62828' : '#999';
      const arrow = overallChange == null ? '' : overallChange > 0.01 ? '📈' : overallChange < -0.01 ? '📉' : '➡️';
      const eventCount = past.length + 1;

      const sparkPts = winPctTrend.length >= 2 ? winPctTrend.map((v,i) => {
        const max = Math.max(...winPctTrend, 1), min = Math.min(...winPctTrend, 0);
        const range = (max - min) || 1;
        const x = (i * (120 / (winPctTrend.length-1))).toFixed(1);
        const y = (28 - ((v-min)/range)*28).toFixed(1);
        return x + ',' + y;
      }).join(' ') : '';

      trendBlock = `
        <div style="background:#fff3e0;border-radius:10px;padding:14px 16px;margin-bottom:18px">
          <div style="font-size:13px;color:#E65100;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px">📊 Your Progress — ${eventCount} event${eventCount===1?'':'s'} tracked</div>
          <table style="width:100%;border-collapse:collapse"><tr>
            <td style="vertical-align:top;padding-right:14px">
              <div style="font-size:22px;font-weight:800;color:${ocColor}">${arrow} ${overallChange == null ? '—' : fmt(overallChange)}</div>
              <div style="font-size:11px;color:#888">DUPR since first tracked</div>
              ${sinceLastChange != null ? `<div style="font-size:11px;color:#888;margin-top:2px">since last event: ${fmt(sinceLastChange)}</div>` : ''}
            </td>
            <td style="vertical-align:top;text-align:right">
              ${sparkPts ? `<svg width="120" height="28"><polyline points="${sparkPts}" fill="none" stroke="#43A047" stroke-width="2"/></svg><div style="font-size:11px;color:#888">win% trend (${winPctTrend[winPctTrend.length-1]}% now)</div>` : `<div style="font-size:13px;font-weight:700;color:#1B5E20">${mine.winPct}% win rate</div>`}
            </td>
          </tr></table>
          ${curCR ? `<div style="font-size:11px;color:#888;margin-top:8px">Club Rating: ${
              crChanged
                ? `<span style="color:#E65100;font-weight:700">${esc(firstCR)} \u2192 ${esc(curCR)} 🎉</span>`
                : `<span style="font-family:'JetBrains Mono',monospace;font-weight:700;color:#555">${esc(curCR)}</span>`
            }</div>` : ''}
        </div>`;
    }
  }

  // Full standings table
  const rows = ranked.filter(s => s.gp > 0).map((s, i) => {
    const isMe = mine && s.player.id === player.id;
    const rk = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1);
    return `<tr style="${isMe ? 'background:#fff9c4;font-weight:700' : (i%2?'background:#fafafa':'')}">
      <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:center">${rk}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #eee">${esc(s.player.name)}${isMe ? ' ←' : ''}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:center">${s.wins}-${s.losses}${s.ties?('-'+s.ties):''}</td>
      <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:center">${s.winPct}%</td>
      <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:center;color:${s.diff>=0?'#2E7D32':'#C62828'}">${s.diff>0?'+':''}${s.diff}</td>
    </tr>`;
  }).join('');

  const standings = `
    <div style="font-size:13px;color:#558B2F;text-transform:uppercase;letter-spacing:1px;margin:0 0 8px">Final Standings</div>
    <table style="width:100%;border-collapse:collapse;font-size:13px;color:#333">
      <thead><tr style="background:#1B5E20;color:#C6FF00">
        <th style="padding:7px 8px;text-align:center">#</th>
        <th style="padding:7px 8px;text-align:left">Player</th>
        <th style="padding:7px 8px;text-align:center">W-L</th>
        <th style="padding:7px 8px;text-align:center">Win%</th>
        <th style="padding:7px 8px;text-align:center">Diff</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>`;

  return `<!DOCTYPE html><html><body style="margin:0;background:#f4f4f4;font-family:'Helvetica Neue',Arial,sans-serif">
    <div style="max-width:560px;margin:0 auto;background:#fff">
      <div style="background:linear-gradient(135deg,#1B5E20,#0D3B14);padding:22px 24px">
        <div style="font-size:22px;font-weight:800;color:#C6FF00;letter-spacing:1px">🏓 ${esc(tname)}</div>
        <div style="font-size:13px;color:#A5D6A7;margin-top:2px">Tournament Results</div>
      </div>
      <div style="padding:24px">
        ${personal}
        ${trendBlock}
        ${standings}
        <p style="font-size:12px;color:#999;margin:20px 0 0;text-align:center">Thanks for playing! 🏓</p>
      </div>
    </div>
</body></html>`;
}

// derive the same row fields renderReport uses
function emDeriveRow(s) {
  const g = s.games;
  const pf = g.reduce((a,x)=>a+Number(x.pts),0);
  const pa = g.reduce((a,x)=>a+Number(x.opponentPts),0);
  const wins = g.filter(x=>x.won).length;
  const losses = g.filter(x=>!x.won && !x.tied).length;
  const ties = g.filter(x=>x.tied).length;
  const gp = g.length;
  return { ...s, pf, pa, wins, losses, ties, gp,
    winPct: gp ? Math.round((wins/gp)*100) : 0, diff: pf - pa, avg: gp ? pf/gp : 0 };
}

function emUpdatePreview() {
  const all       = state.players.filter(p => p.active !== false);
  const withEmail = all.filter(p => p.email && p.email.trim());
  const frame     = document.getElementById('em-preview');
  const sel       = document.getElementById('em-preview-player');

  // Populate dropdown — all active players, flag those without email
  if(sel) {
    const curId = sel.value;
    sel.innerHTML = all.map(p =>
      '<option value="' + p.id + '">' + escHtml(p.name) + (p.email ? '' : ' (no email)') + '</option>'
    ).join('');
    if(curId && all.find(p => String(p.id) === curId)) {
      sel.value = curId;
    } else {
      const first = withEmail[0] || all[0];
      if(first) sel.value = String(first.id);
    }
  }

  // Render preview for selected player
  const selId  = sel?.value;
  const sample = (selId && all.find(p => String(p.id) === selId)) || withEmail[0] || all[0];
  if(frame && sample) {
    const doc = frame.contentDocument || frame.contentWindow.document;
    doc.open(); doc.write(emBuildHtml(sample)); doc.close();
  }
}

async function emCheckServer() {
  const el = document.getElementById('em-status');
  if(el) el.textContent = 'Checking...';
  try {
    const r = await fetch(RELAY_BASE + '/health', { method: 'GET' });
    if(el) el.innerHTML = r.ok
      ? '<span style="color:var(--lime)">✅ Relay connected</span>'
      : '<span style="color:var(--red)">✗ Server error ' + r.status + '</span>';
  } catch(e) {
    if(el) el.innerHTML = '<span style="color:var(--red)">✗ Cannot reach relay — check your connection</span>';
  }
}

function emValidate(cfg) {
  // SMTP host/user/pass now live as secrets on the relay Worker, not in the
  // browser, so there's nothing left for the client to validate before sending.
  return [];
}

async function emTest() {
  const cfg = emGetCfg();
  const to = prompt('Send a test email to which address?');
  if(!to || !to.trim()) return;
  const html = '<div style="font-family:sans-serif;padding:20px"><h2 style="color:#1B5E20">🏓 Test email</h2>'
    + '<p>Your email relay is working! Sent ' + new Date().toLocaleString() + '.</p></div>';
  const result = await emCallRelay(to.trim(), 'Pickleball Pro — test email', html, cfg);
  toast(result.ok ? '✅ Test sent! Check the inbox.' : '❌ Failed — check the error log below', result.ok ? 'ok' : 'err');
}

// Shared batch sender used by both "Send to All" and "Send to Selected".
async function emSendBatch(players, btnSelector, labelIdle) {
  const cfg = emGetCfg();
  const missing = emValidate(cfg);
  if(missing.length) { toast('Fill in: ' + missing.join(', '), 'err'); return; }
  if(!players.length) { toast('No players selected', 'err'); return; }
  if(!buildPlayerStats().some(s => s.games.length)) {
    if(!confirm('No match scores entered yet — players will only get the (empty) standings. Send anyway?')) return;
  }
  const subject = document.getElementById('em-subject')?.value.trim() || emDefaultSubject();

  const btn = document.querySelector(btnSelector);
  const log = document.getElementById('em-log');
  if(btn) { btn.disabled = true; btn.textContent = '⏳ Sending…'; }

  let sent = 0, failed = 0;
  for(let i = 0; i < players.length; i++) {
    const p = players[i];
    const html = emBuildHtml(p);
    const result = await emCallRelay(p.email.trim(), subject, html, cfg);
    if(result.ok) sent++; else failed++;
    if(log) log.textContent = sent + ' sent, ' + failed + ' failed of ' + players.length + '…';
    if(result.unreachable) {
      failed += players.length - sent - failed;
      if(log) log.innerHTML = '<span style="color:var(--red)">Cannot reach relay server — stopped after 1 attempt. Check your connection and try again.</span>';
      break;
    }
    // Pace sends so we don't hammer the SMTP relay/provider (skip after the last player)
    if(i < players.length - 1) await sleep(SEND_PACING_MS);
  }

  if(btn) { btn.disabled = false; btn.textContent = labelIdle; }
  if(log) log.innerHTML = failed === 0
    ? '<span style="color:var(--lime)">✓ All ' + sent + ' emails sent!</span>'
    : '<span style="color:var(--lime)">' + sent + ' sent</span>, <span style="color:var(--red)">' + failed + ' failed</span>';
  toast('📧 ' + sent + ' sent' + (failed ? ', ' + failed + ' failed' : ''), failed ? 'err' : 'ok');
}

async function emSendAll() {
  const players = state.players.filter(p => p.email && p.email.trim());
  await emSendBatch(players, '[onclick="emSendAll()"]', '📧 Send to All');
}

async function emSendSelected() {
  const selected = state._emSelected || new Set();
  const players = state.players.filter(p => p.email && p.email.trim() && selected.has(p.id));
  if(!players.length) { toast('No players selected — check the boxes for who should get an email', 'err'); return; }
  await emSendBatch(players, '[onclick="emSendSelected()"]', '📧 Send to Selected');
}

// Per-player email button for the report leaderboard
function emailBtnFor(player) {
  if(player.email && player.email.trim()) {
    return '<button class="btn btn-secondary btn-sm" title="Email results to ' + escHtml(player.name) + ' (' + escHtml(player.email) + ')" '
      + 'onclick="emSendOne(' + JSON.stringify(player.id) + ')" style="padding:2px 8px">📧</button>';
  }
  return '<span title="No email address — add one on the Players tab" style="color:var(--border);font-size:0.9rem;cursor:default">📧</span>';
}

// Send results to a single player
async function emSendOne(playerId) {
  const player = state.players.find(p => p.id === playerId);
  if(!player) return;
  if(!player.email || !player.email.trim()) { toast(player.name.split(' ')[0] + ' has no email address', 'err'); return; }
  const cfg = emGetCfg();
  const missing = emValidate(cfg);
  if(missing.length) { toast('Set up email first (Email tab) — missing: ' + missing.join(', '), 'err'); return; }

  const subject = (emGetCfg().subject || '').trim() || emDefaultSubject();
  const html = emBuildHtml(player);
  toast('📧 Sending to ' + player.name.split(' ')[0] + '…');
  const result = await emCallRelay(player.email.trim(), subject, html, cfg);
  toast(result.ok ? '✅ Sent to ' + player.name.split(' ')[0] : '❌ Failed — check email setup & relay server', result.ok ? 'ok' : 'err');
}

async function emCallRelay(to, subject, html, cfg) {
  try {
    const r = await fetch(RELAY_BASE + '/api/email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to, subject, html }),
    });
    const data = await r.json().catch(() => ({}));
    if(!data.ok && data.error) {
      const el = document.getElementById('em-log');
      if(el) el.innerHTML = '<span style="color:var(--red)">Email error: ' + escHtml(data.error) + '</span>';
    }
    return { ok: data.ok === true, unreachable: false };
  } catch(e) {
    // fetch() itself threw — the relay isn't reachable at all,
    // as opposed to it responding with a provider-side error above.
    const el = document.getElementById('em-log');
    if(el) el.innerHTML = '<span style="color:var(--red)">Cannot reach relay server. Check your connection and try again.</span>';
    return { ok: false, unreachable: true };
  }
}
// ── Terms & Conditions gate ────────────────────────────────────────
// The current version of the Terms. Bump this string whenever the
// Terms materially change — a version bump re-prompts everyone for
// acceptance, even people who already agreed to an earlier version.
const TOS_VERSION = (window.__ACCESS__ && window.__ACCESS__.tosVersion) || '2026-06-24';
const TOS_STORE_KEY = 'pb_tos_accepted';

function tosCheck() {
  let accepted = null;
  try { accepted = JSON.parse(localStorage.getItem(TOS_STORE_KEY) || 'null'); } catch(e) {}
  const gate = document.getElementById('tos-gate');
  if (!gate) return;
  if (accepted && accepted.version === TOS_VERSION) {
    gate.style.display = 'none';
    return;
  }
  // Not yet accepted (or accepted an older version) — block the app.
  gate.style.display = 'flex';
}

function tosUpdateButton() {
  const checked = document.getElementById('tos-checkbox')?.checked;
  const btn = document.getElementById('tos-accept-btn');
  if (!btn) return;
  btn.disabled = !checked;
  btn.style.opacity = checked ? '1' : '0.4';
  btn.style.cursor = checked ? 'pointer' : 'not-allowed';
}

async function tosAccept() {
  if (!document.getElementById('tos-checkbox')?.checked) return;
  const record = { version: TOS_VERSION, acceptedAt: new Date().toISOString() };
  try { localStorage.setItem(TOS_STORE_KEY, JSON.stringify(record)); } catch(e) {}

  const statusEl = document.getElementById('tos-status');
  // Best-effort server-side record via the relay, so acceptance is
  // durable even if the browser's local storage is later cleared.
  // This must never block the person from proceeding — if the relay
  // is briefly unreachable, the local acceptance above is still
  // honored and the app unlocks regardless.
  try {
    await fetch(RELAY_BASE + '/api/tos-accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record),
    });
  } catch(e) {
    // Non-fatal — local acceptance already recorded above.
  }
  if (statusEl) statusEl.textContent = '';
  document.getElementById('tos-gate').style.display = 'none';
}

tosCheck();
maybeEnterPublicMode();



// ═══════════════════════════════════════════════
//  PREMIUM ENHANCEMENTS: self check-in, admin lock, fairness
// ═══════════════════════════════════════════════
const PB_ADMIN_LOCK_KEY = 'pb_admin_lock_enabled';

function getSelfCheckinLink() {
  const base = window.location.origin + window.location.pathname;
  return base + '?view=checkin';
}
function renderSelfCheckinTools() {
  const link = getSelfCheckinLink();
  const box = document.getElementById('self-checkin-link-box');
  if(box) box.textContent = link;
  const qr = document.getElementById('self-checkin-qr');
  if(qr) {
    qr.innerHTML = '';
    try { if(window.QRCode) new QRCode(qr, { text: link, width:150, height:150, colorDark:'#000000', colorLight:'#ffffff' }); else qr.textContent = link; } catch(e) { qr.textContent = link; }
  }
  const list = document.getElementById('self-checkin-status-list');
  if(list) {
    const players = state.players || [];
    const checked = players.filter(p => p.checkedIn !== false).length;
    list.innerHTML = `<div class="premium-pill" style="display:inline-block;margin-bottom:.65rem">${checked}/${players.length} checked in</div>` +
      players.map(p => `<div style="display:flex;justify-content:space-between;gap:.75rem;border-bottom:1px solid var(--border);padding:.45rem 0"><span>${escHtml(p.name)}</span><strong style="color:${p.checkedIn === false ? 'var(--red)' : 'var(--lime)'}">${p.checkedIn === false ? 'Not in' : 'Checked in'}</strong></div>`).join('');
  }
}
function copySelfCheckinLink() {
  const link = getSelfCheckinLink();
  if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(link).then(()=>toast('Self check-in link copied'));
  else prompt('Copy self check-in link:', link);
}
function openSelfCheckin() { window.open(getSelfCheckinLink(), '_blank'); }
function selfCheckinPlayer(id) {
  const p = (state.players || []).find(x => x.id === id);
  if(!p) return;
  p.checkedIn = true;
  autoSave();
  renderSelfCheckinPublic();
  toast('Checked in: ' + p.name);
}
function renderSelfCheckinPublic() {
  const q = (document.getElementById('self-public-search')?.value || '').toLowerCase().trim();
  const list = document.getElementById('self-public-list');
  const status = document.getElementById('self-public-status');
  if(status) status.textContent = ((document.getElementById('tournament-name')?.value || '').trim() || 'Tournament') + ' · select your name to check in';
  if(!list) return;
  const players = (state.players || []).filter(p => !q || (p.name || '').toLowerCase().includes(q));
  list.innerHTML = players.length ? players.map(p => `<button class="quick-action admin-lock-safe" style="width:100%;margin-bottom:.55rem;text-align:left" onclick="selfCheckinPlayer('${String(p.id).replace(/'/g,'\\\'')}')"><span class="quick-action-icon">${p.checkedIn === false ? '⬜' : '✅'}</span><div class="quick-action-title">${escHtml(p.name)}</div><div class="quick-action-note">${p.checkedIn === false ? 'Tap to check in' : 'Already checked in'}</div></button>`).join('') : '<div class="empty-state">No matching player found.</div>';
}

function renderAdminLock() {
  const on = isAdminLocked();
  const title = document.getElementById('admin-lock-title');
  const note = document.getElementById('admin-lock-note');
  const btn = document.getElementById('admin-lock-toggle');
  if(title) title.textContent = 'Admin Lock is ' + (on ? 'ON' : 'OFF');
  if(note) note.textContent = on ? 'Live editing is blocked to prevent accidental changes.' : 'Editing is currently allowed.';
  if(btn) { btn.textContent = on ? 'Disable Lock' : 'Enable Lock'; btn.className = on ? 'btn btn-danger admin-lock-safe' : 'btn btn-primary admin-lock-safe'; }
}
function isAdminLocked() { try { return localStorage.getItem(PB_ADMIN_LOCK_KEY) === '1'; } catch(e) { return false; } }
function toggleAdminLock() {
  const next = !isAdminLocked();
  try { localStorage.setItem(PB_ADMIN_LOCK_KEY, next ? '1' : '0'); } catch(e) {}
  renderAdminLock();
  toast(next ? '🔒 Admin Lock enabled' : '🔓 Admin Lock disabled');
}
function isAdminLockAllowed(el) {
  if(!el) return true;
  if(el.closest && el.closest('.admin-lock-safe')) return true;
  if(el.closest && (el.closest('#sec-admin') || el.closest('#sec-display') || el.closest('#sec-public') || el.closest('nav') || el.closest('.mobile-bottom-nav') || el.closest('.user-menu-wrap'))) return true;
  const onclick = (el.getAttribute && el.getAttribute('onclick')) || '';
  if(onclick.includes('showTab(') || onclick.includes('renderDisplayTools') || onclick.includes('renderPublicStandings') || onclick.includes('copyPublic') || onclick.includes('openPublic') || onclick.includes('tvToggleFullscreen')) return true;
  return false;
}
document.addEventListener('click', function(e) {
  if(!isAdminLocked()) return;
  const ctl = e.target.closest && e.target.closest('button,a,input,select,textarea,label');
  if(!ctl || isAdminLockAllowed(ctl)) return;
  e.preventDefault(); e.stopPropagation();
  toast('Admin Lock is on — unlock before editing', 'err');
}, true);
document.addEventListener('change', function(e) {
  if(!isAdminLocked()) return;
  if(isAdminLockAllowed(e.target)) return;
  e.preventDefault(); e.stopPropagation();
  toast('Admin Lock is on — unlock before editing', 'err');
}, true);

function fairnessPairKey(a,b) { return [a,b].sort((x,y)=>String(x).localeCompare(String(y))).join('|'); }
function fairnessPlayerName(i) {
  const p = (state.players || [])[parseInt(i,10)];
  return p && p.name ? p.name : '?';
}
function pairNames(key) { return key.split('|').map(fairnessPlayerName).join(' / '); }
function buildFairnessAnalysis() {
  const partner = {}, opponent = {}, sits = {}, playerCourtUse = {}, courtTotals = {}, spreads = [], gameSpreads = [];
  const players = state.players || [];
  players.forEach((p,i)=>{ sits[i]=0; playerCourtUse[i]={}; });

  (state.byeRounds || []).forEach(arr => (arr || []).forEach(i => { sits[i] = (sits[i] || 0) + 1; }));

  (state.schedule || []).forEach((round, rIdx) => (round || []).forEach((m, mIdx) => {
    if(!m || !Array.isArray(m.teamA) || !Array.isArray(m.teamB)) return;
    const court = m.court || (mIdx + 1);
    courtTotals[court] = (courtTotals[court] || 0) + 1;
    const all = [].concat(m.teamA, m.teamB);
    all.forEach(i => {
      if(sits[i] == null) sits[i] = 0;
      playerCourtUse[i] = playerCourtUse[i] || {};
      playerCourtUse[i][court] = (playerCourtUse[i][court] || 0) + 1;
    });
    if(m.teamA.length > 1) {
      const k = fairnessPairKey(m.teamA[0], m.teamA[1]);
      partner[k] = (partner[k] || 0) + 1;
    }
    if(m.teamB.length > 1) {
      const k = fairnessPairKey(m.teamB[0], m.teamB[1]);
      partner[k] = (partner[k] || 0) + 1;
    }
    m.teamA.forEach(a => m.teamB.forEach(b => {
      const k = fairnessPairKey(a,b);
      opponent[k] = (opponent[k] || 0) + 1;
    }));

    const avgA = m.teamA.length ? (m.teamA.reduce((sum,i)=>sum+pRating(players[i]),0) / m.teamA.length) : 0;
    const avgB = m.teamB.length ? (m.teamB.reduce((sum,i)=>sum+pRating(players[i]),0) / m.teamB.length) : 0;
    const spread = Math.abs(avgA-avgB);
    spreads.push(spread);
    gameSpreads.push({ round: rIdx + 1, court, spread, teamA: m.teamA, teamB: m.teamB });
  }));

  const repeatsP = Object.entries(partner).filter(([k,c])=>c>1).sort((a,b)=>b[1]-a[1]);
  const repeatsO = Object.entries(opponent).filter(([k,c])=>c>1).sort((a,b)=>b[1]-a[1]);
  const sitEntries = Object.entries(sits).map(([i,c])=>({ idx: parseInt(i,10), name: fairnessPlayerName(i), c: Number(c)||0 })).sort((a,b)=>b.c-a.c || a.name.localeCompare(b.name));
  const sitVals = sitEntries.map(x=>x.c);
  const maxSit = sitVals.length ? Math.max(...sitVals) : 0;
  const minSit = sitVals.length ? Math.min(...sitVals) : 0;
  const sitGap = maxSit - minSit;
  const sitDistribution = sitEntries.reduce((acc,x)=>{ acc[x.c]=(acc[x.c]||0)+1; return acc; }, {});
  const mostSat = sitEntries.filter(x=>x.c===maxSit && maxSit>0);
  const leastSat = sitEntries.filter(x=>x.c===minSit);
  const avgSpread = spreads.length ? spreads.reduce((a,b)=>a+b,0)/spreads.length : 0;
  const bestSpread = spreads.length ? Math.min(...spreads) : 0;
  const worstSpread = spreads.length ? Math.max(...spreads) : 0;
  const worstGames = gameSpreads.slice().sort((a,b)=>b.spread-a.spread).slice(0,5);
  const courtEntries = Object.entries(courtTotals).map(([court,count])=>({ court, count })).sort((a,b)=>String(a.court).localeCompare(String(b.court), undefined, {numeric:true}));
  const courtVals = courtEntries.map(x=>x.count);
  const courtGap = courtVals.length ? Math.max(...courtVals)-Math.min(...courtVals) : 0;

  let score = 100;
  score -= Math.min(30, repeatsP.length * 8);
  score -= Math.min(25, repeatsO.length * 5);
  score -= Math.min(25, Math.max(0, sitGap - 1) * 12);
  score -= Math.min(10, Math.max(0, courtGap - 1) * 4);
  score -= Math.min(20, Math.max(0, avgSpread - 0.75) * 10);
  score = Math.max(0, Math.round(score));
  let grade = score >= 90 ? 'Excellent' : score >= 75 ? 'Good' : score >= 60 ? 'Needs attention' : 'Poor';

  const recommendations = [];
  if(repeatsP.length) recommendations.push('Avoid the repeated partner pairings shown below in the next round.');
  if(repeatsO.length) recommendations.push('Reduce repeated opponent matchups where possible.');
  if(sitGap > 1) recommendations.push('Prioritize players with the most sit-outs next round: ' + mostSat.slice(0,6).map(x=>x.name).join(', ') + '.');
  if(courtGap > 1) recommendations.push('Court usage is uneven; rotate assignments across courts more evenly.');
  if(avgSpread > 1.25) recommendations.push('Rating spread is high; use balanced/DUPR mode or swap players between games.');
  if(!recommendations.length) recommendations.push('Schedule looks balanced based on current data.');

  return { partner, opponent, repeatsP, repeatsO, sits, sitEntries, sitDistribution, mostSat, leastSat, playerCourtUse, courtEntries, courtGap, maxSit, minSit, sitGap, avgSpread, bestSpread, worstSpread, worstGames, games: spreads.length, score, grade, recommendations };
}
function fairnessBar(score) {
  return `<div style="height:10px;border-radius:999px;background:rgba(255,255,255,.10);overflow:hidden;margin-top:.35rem"><div style="height:100%;width:${Math.max(0,Math.min(100,score))}%;background:linear-gradient(90deg,var(--lime),var(--green));border-radius:999px"></div></div>`;
}

function ratingSpreadQuality(spread) {
  const v = Number(spread) || 0;
  if(v <= 0.25) return { icon:'🟢', label:'Excellent', text:'Teams are almost perfectly balanced.' };
  if(v <= 0.50) return { icon:'🟢', label:'Very Good', text:'Teams are very well balanced.' };
  if(v <= 0.75) return { icon:'🟡', label:'Good', text:'Small rating difference; usually fine.' };
  if(v <= 1.00) return { icon:'🟠', label:'Review', text:'Noticeable rating gap; review if better options exist.' };
  return { icon:'🔴', label:'Poor', text:'Large rating gap; try to rebalance this court.' };
}
function ratingBalanceSummary(a) {
  const avg = ratingSpreadQuality(a.avgSpread);
  const worst = ratingSpreadQuality(a.worstSpread);
  const reviewGames = (a.worstGames || []).filter(g => Number(g.spread) > 0.75);
  return { avg, worst, reviewGames };
}
function renderFairnessEngine() {
  const a = buildFairnessAnalysis();
  const summary = document.getElementById('fairness-summary');
  const report = document.getElementById('fairness-report');
  const statusIcon = a.score >= 90 ? '🟢' : (a.score >= 75 ? '🟡' : '🔴');
  const statusText = a.score >= 90 ? 'Excellent' : (a.score >= 75 ? 'Review' : 'Needs attention');
  const priority = a.mostSat || [];
  const hasPriority = a.maxSit > a.minSit && priority.length;
  const repeatOpponentMax = a.repeatsO.length ? Math.max(...a.repeatsO.map(x => x[1])) : 0;
  const highOpponentRepeats = a.repeatsO.filter(([k,c]) => c >= 3);
  const acceptableOpponentRepeats = a.repeatsO.filter(([k,c]) => c === 2);
  const ratingSummary = ratingBalanceSummary(a);
  const ratingReviewCount = ratingSummary.reviewGames.length;
  const repeatPartnerMax = a.repeatsP.length ? Math.max(...a.repeatsP.map(x => x[1])) : 0;
  const opponentStatus = highOpponentRepeats.length ? 'Review' : (acceptableOpponentRepeats.length ? 'Good' : 'Good');
  const opponentIcon = highOpponentRepeats.length ? '⚠️' : '✅';
  const checks = [
    { label:'Wait time balance', ok:a.sitGap <= 1, warn:a.sitGap === 2, detail:`Gap: ${a.sitGap} round${a.sitGap===1?'':'s'}` },
    { label:'Partner diversity', ok:a.repeatsP.length === 0, warn:repeatPartnerMax === 2, detail:a.repeatsP.length ? `${a.repeatsP.length} repeated partner pair${a.repeatsP.length===1?'':'s'}` : 'No repeated partners' },
    { label:'Opponent diversity', ok:!highOpponentRepeats.length, warn:!!acceptableOpponentRepeats.length, detail:a.repeatsO.length ? `${highOpponentRepeats.length} high repeat${highOpponentRepeats.length===1?'':'s'}, ${acceptableOpponentRepeats.length} acceptable repeat${acceptableOpponentRepeats.length===1?'':'s'}` : 'No repeated opponents' },
    { label:'Rating balance', ok:a.avgSpread <= 0.75 && a.worstSpread <= 1.00, warn:a.avgSpread <= 1.25, detail:`${ratingSummary.avg.label} · Avg ${a.avgSpread.toFixed(1)} · Worst ${a.worstSpread.toFixed(1)}` }
  ];
  if(summary) summary.innerHTML = `
    <div class="dashboard-kpi"><div class="dashboard-kpi-value">${a.score}</div><div class="dashboard-kpi-label">Fairness score · ${escHtml(statusText)}</div>${fairnessBar(a.score)}</div>
    <div class="dashboard-kpi"><div class="dashboard-kpi-value">${statusIcon}</div><div class="dashboard-kpi-label">Overall schedule status</div></div>
    <div class="dashboard-kpi"><div class="dashboard-kpi-value">${hasPriority ? priority.length : 0}</div><div class="dashboard-kpi-label">Priority players next round</div></div>
    <div class="dashboard-kpi"><div class="dashboard-kpi-value">${repeatOpponentMax || 0}x</div><div class="dashboard-kpi-label">Highest opponent repeat</div></div>`;
  if(!report) return;
  const headline = a.score >= 90
    ? 'Schedule is balanced. Only review the highlighted avoid-list if needed.'
    : (a.score >= 75 ? 'Schedule is mostly balanced. Review the yellow items before the next round.' : 'Schedule needs attention before the next round.');
  const priorityHtml = hasPriority
    ? `<div style="display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.65rem">${priority.slice(0,12).map(x=>`<span class="badge">${escHtml(x.name)}</span>`).join('')}${priority.length>12?`<span class="badge">+${priority.length-12} more</span>`:''}</div>
       <div style="color:var(--txt3);font-size:.85rem;margin-top:.6rem">These players have waited ${a.maxSit} round${a.maxSit===1?'':'s'}, while others have waited ${a.minSit}. Put them on court first next round if possible.</div>`
    : `<div class="notice">✅ No priority players. Everyone is balanced.</div>`;
  const checkHtml = checks.map(c => {
    const icon = c.ok ? '✅' : (c.warn ? '⚠️' : '❌');
    const state = c.ok ? 'Good' : (c.warn ? 'Review' : 'Problem');
    return `<div class="dashboard-card" style="padding:1rem"><div style="font-weight:800">${icon} ${escHtml(c.label)}</div><div style="color:var(--txt3);font-size:.85rem;margin-top:.25rem">${state} · ${escHtml(c.detail)}</div></div>`;
  }).join('');
  const sitDistRows = Object.entries(a.sitDistribution).sort((x,y)=>Number(x[0])-Number(y[0])).map(([c,n])=>`<tr><td>${c} round${Number(c)===1?'':'s'}</td><td>${n} player${n==1?'':'s'}</td></tr>`).join('');
  const repeatPartnerHtml = a.repeatsP.length
    ? `<table class="mini-table"><thead><tr><th>Players partnered together</th><th>Times</th><th>Status</th></tr></thead><tbody>${a.repeatsP.slice(0,10).map(([k,c])=>`<tr><td>${escHtml(pairNames(k))}</td><td>${c}</td><td>${c>=3?'Avoid next round':(c===2?'Watch':'OK')}</td></tr>`).join('')}</tbody></table>`
    : '<div class="notice">✅ No repeated partners detected.</div>';
  const opponentSummary = a.repeatsO.length
    ? `<div class="notice" style="margin-bottom:.75rem"><strong>${opponentIcon} Opponent diversity: ${escHtml(opponentStatus)}</strong><br>${highOpponentRepeats.length ? `${highOpponentRepeats.length} player pair${highOpponentRepeats.length===1?' has':'s have'} faced each other 3+ times. Avoid those matchups next round if possible.` : `${acceptableOpponentRepeats.length} player pair${acceptableOpponentRepeats.length===1?' has':'s have'} faced each other twice. This is usually acceptable in smaller events.`}</div>`
    : '<div class="notice">✅ No repeated opponent matchups detected.</div>';
  const highRows = highOpponentRepeats.length
    ? `<h5 style="margin:.75rem 0 .35rem;color:var(--warn)">Avoid next round</h5><table class="mini-table"><thead><tr><th>Players who faced each other</th><th>Times</th><th>Action</th></tr></thead><tbody>${highOpponentRepeats.slice(0,10).map(([k,c])=>`<tr><td>${escHtml(pairNames(k).replace(' / ', ' vs '))}</td><td>${c}</td><td>Try to separate</td></tr>`).join('')}</tbody></table>`
    : '';
  const acceptableRows = acceptableOpponentRepeats.length
    ? `<h5 style="margin:.75rem 0 .35rem;color:var(--lime)">Acceptable repeats</h5><table class="mini-table"><thead><tr><th>Players who faced each other</th><th>Times</th><th>Status</th></tr></thead><tbody>${acceptableOpponentRepeats.slice(0,12).map(([k,c])=>`<tr><td>${escHtml(pairNames(k).replace(' / ', ' vs '))}</td><td>${c}</td><td>Okay unless repeated again</td></tr>`).join('')}</tbody></table>`
    : '';
  const repeatOpponentHtml = opponentSummary + highRows + acceptableRows;
  const avoidList = highOpponentRepeats.slice(0,5).map(([k,c]) => pairNames(k).replace(' / ', ' vs '));
  const courtRows = a.courtEntries.length ? `<table class="mini-table"><thead><tr><th>Court</th><th>Games</th></tr></thead><tbody>${a.courtEntries.map(r=>`<tr><td>${escHtml(r.court)}</td><td>${r.count}</td></tr>`).join('')}</tbody></table>` : 'No court data yet.';
  const ratingRows = a.worstGames.length ? a.worstGames.slice(0,5).map(g=>{ const q = ratingSpreadQuality(g.spread); return `${q.icon} Round ${g.round}, Court ${escHtml(g.court)}: ${g.spread.toFixed(1)} spread — ${q.label}`; }).join('<br>') : 'No rating data yet.';
  const ratingOverview = `${ratingSummary.avg.icon} Overall: ${ratingSummary.avg.label}<br>Average spread: ${a.avgSpread.toFixed(1)}<br>Worst spread: ${a.worstSpread.toFixed(1)} (${ratingSummary.worst.label})<br>${ratingReviewCount ? `⚠️ ${ratingReviewCount} court${ratingReviewCount===1?'':'s'} should be reviewed.` : '✅ No rating-balance action needed.'}`;
  const recommendationParts = [];
  if(hasPriority) recommendationParts.push(`Schedule priority players first: ${priority.slice(0,6).map(x=>x.name).join(', ')}${priority.length>6?'…':''}.`);
  if(avoidList.length) recommendationParts.push(`Avoid these opponent rematches next round: ${avoidList.join('; ')}.`);
  if(a.repeatsP.length) recommendationParts.push('Avoid repeated partner pairings shown in advanced details.');
  if(a.courtGap > 1) recommendationParts.push('Use the lower-count courts first to balance court usage.');
  if(ratingReviewCount) recommendationParts.push(`${ratingReviewCount} rating matchup${ratingReviewCount===1?'':'s'} should be reviewed; consider regenerating or swapping one player between uneven courts.`);
  if(!recommendationParts.length) recommendationParts.push('Continue generating rounds normally.');
  report.innerHTML = `
    <h3 style="margin-top:0;color:var(--lime)">⚖️ Fairness</h3>
    <div class="notice" style="margin-bottom:1rem"><strong>${statusIcon} ${escHtml(statusText)} — ${a.score}/100</strong><br>${escHtml(headline)}</div>

    <div class="dashboard-card" style="margin-bottom:1rem">
      <h4 style="margin:.1rem 0 .5rem">⭐ Priority Next Round</h4>
      ${priorityHtml}
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:.75rem;margin-bottom:1rem">${checkHtml}</div>

    <div class="dashboard-card" style="margin-bottom:1rem">
      <h4 style="margin:.1rem 0 .5rem">⚔️ Opponent Avoid List</h4>
      ${avoidList.length ? `<div style="color:var(--txt3);font-size:.9rem;margin-bottom:.55rem">These players have already faced each other 3+ times. The next round should avoid these matchups when possible.</div><div style="display:flex;flex-wrap:wrap;gap:.4rem">${avoidList.map(x=>`<span class="badge">${escHtml(x)}</span>`).join('')}</div>` : '<div class="notice">✅ No high-repeat opponent matchups. Nothing to avoid right now.</div>'}
    </div>

    <div class="dashboard-card" style="margin-bottom:1rem">
      <h4 style="margin:.1rem 0 .5rem">📊 Rating Balance</h4>
      <div style="color:var(--txt3);font-size:.9rem">${ratingOverview}</div>
      ${ratingReviewCount ? `<div style="margin-top:.65rem;color:var(--txt3);font-size:.85rem"><strong>Worst courts to review:</strong><br>${ratingRows}</div>` : ''}
    </div>

    <div class="dashboard-card" style="margin-bottom:1rem">
      <h4 style="margin:.1rem 0 .5rem">💡 Smart Recommendation</h4>
      <div style="color:var(--txt3);font-size:.9rem">${recommendationParts.map(x=>'💡 '+escHtml(x)).join('<br>')}</div>
    </div>

    <details class="dashboard-card">
      <summary style="cursor:pointer;font-weight:800;color:var(--lime)">Show Advanced Details</summary>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1rem;margin-top:1rem">
        <div><strong>🏓 Wait details</strong><div style="color:var(--txt3);font-size:.85rem;margin-top:.4rem">Minimum wait: ${a.minSit}<br>Maximum wait: ${a.maxSit}<br>Gap: ${a.sitGap}<br><br><table class="mini-table"><thead><tr><th>Sat out</th><th>How many players</th></tr></thead><tbody>${sitDistRows || '<tr><td colspan="2">No sit-outs yet.</td></tr>'}</tbody></table></div></div>
        <div><strong>🤝 Partner diversity</strong><div style="color:var(--txt3);font-size:.85rem;margin-top:.4rem">${repeatPartnerHtml}</div></div>
        <div style="grid-column:span 2"><strong>⚔️ Opponent diversity</strong><div style="color:var(--txt3);font-size:.85rem;margin-top:.4rem">${repeatOpponentHtml}</div></div>
        <div><strong>🏟️ Court usage</strong><div style="color:var(--txt3);font-size:.85rem;margin-top:.4rem">${courtRows}<br>Usage gap: ${a.courtGap}</div></div>
        <div><strong>📊 Rating balance</strong><div style="color:var(--txt3);font-size:.85rem;margin-top:.4rem">${ratingOverview}<br><br><strong>Highest spread matches</strong><br>${ratingRows}</div></div>
      </div>
    </details>`;
}
function copyFairnessReport() {
  const a = buildFairnessAnalysis();
  const priority = a.mostSat || [];
  const hasPriority = a.maxSit > a.minSit && priority.length;
  const sitDistribution = Object.entries(a.sitDistribution).sort((x,y)=>Number(x[0])-Number(y[0])).map(([c,n])=>`${c} sit-out round${Number(c)===1?'':'s'}: ${n} player${n==1?'':'s'}`).join('\n');
  const priorityPlayers = hasPriority ? priority.slice(0,12).map(x=>x.name).join(', ') : 'None — everyone has waited the same amount.';
  const repeatedPartners = a.repeatsP.length ? a.repeatsP.slice(0,10).map(([k,c])=>`${pairNames(k)}: ${c}x`).join('\n') : 'None detected';
  const repeatedOpponents = a.repeatsO.length ? a.repeatsO.slice(0,10).map(([k,c])=>`${pairNames(k)}: ${c}x`).join('\n') : 'None detected';
  const courtUsage = a.courtEntries.length ? a.courtEntries.map(r=>`Court ${r.court}: ${r.count} games`).join('\n') : 'No court data';
  const waitSummary = a.sitGap <= 1
    ? `Excellent. Players are only ${a.sitGap} sit-out apart.`
    : `Needs attention. Players are ${a.sitGap} sit-outs apart.`;
  const text = `Fairness Report\nScore: ${a.score}/100 (${a.grade})\n\nWait time summary:\n${waitSummary}\nPlayers who have never waited: ${a.sitDistribution[0] || 0}\nPlayers who have waited once: ${a.sitDistribution[1] || 0}\nMaximum wait difference: ${a.sitGap}\n\nSit-out distribution:\n${sitDistribution}\n\nNext round priority:\n${priorityPlayers}\n\nRepeat partners:\n${repeatedPartners}\n\nRepeat opponents:\n${repeatedOpponents}\n\nCourt usage:\n${courtUsage}\n\nRating balance:\nAverage rating difference: ${a.avgSpread.toFixed(1)}\nBest matchup: ${a.bestSpread.toFixed(1)}\nWorst matchup: ${a.worstSpread.toFixed(1)}\n\nRecommendation:\n${hasPriority ? 'Schedule priority players first next round.' : 'Schedule looks balanced. Continue generating rounds normally.'}`;
  if(navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(()=>toast('Fairness report copied'));
  else prompt('Copy fairness report:', text);
}
function fairnessHighOpponentRepeats(a) {
  return (a && a.repeatsO ? a.repeatsO : []).filter(([k,c]) => Number(c) >= 3);
}
function fairnessMetricSnapshot(a) {
  return {
    score: Number(a.score) || 0,
    partnerRepeats: (a.repeatsP || []).length,
    opponentRepeats: (a.repeatsO || []).length,
    highOpponentRepeats: fairnessHighOpponentRepeats(a).length,
    sitGap: Number(a.sitGap) || 0,
    courtGap: Number(a.courtGap) || 0,
    avgSpread: Number(a.avgSpread) || 0,
    worstSpread: Number(a.worstSpread) || 0
  };
}
function fairnessScoreDelta(before, after) {
  const diff = after.score - before.score;
  return diff > 0 ? '+' + diff : String(diff);
}
function renderAutoFixSummary(before, after) {
  const box = document.getElementById('fairness-autofix-summary');
  if(!box) return;
  const improved = after.score > before.score || after.highOpponentRepeats < before.highOpponentRepeats || after.sitGap < before.sitGap;
  const highChange = before.highOpponentRepeats - after.highOpponentRepeats;
  const oppChange = before.opponentRepeats - after.opponentRepeats;
  const checks = [];
  if(highChange > 0) checks.push(`✓ Removed ${highChange} high-repeat opponent matchup${highChange===1?'':'s'}`);
  if(oppChange > 0) checks.push(`✓ Reduced opponent repeats from ${before.opponentRepeats} → ${after.opponentRepeats}`);
  if(after.partnerRepeats === 0) checks.push('✓ Kept partner repeats at 0');
  else checks.push(`⚠ Partner repeats now ${after.partnerRepeats}`);
  if(after.sitGap <= before.sitGap) checks.push(`✓ Preserved wait balance: gap ${before.sitGap} → ${after.sitGap}`);
  else checks.push(`⚠ Wait gap increased from ${before.sitGap} → ${after.sitGap}`);
  if(after.courtGap <= 1) checks.push(`✓ Court usage remains balanced: gap ${after.courtGap}`);
  if(after.avgSpread <= before.avgSpread + 0.25) checks.push(`✓ Rating balance maintained: avg ${after.avgSpread.toFixed(1)}`);
  box.style.display = 'block';
  box.innerHTML = `
    <h3 style="margin-top:0;color:var(--lime)">${improved ? '✅ Schedule Optimized' : 'ℹ️ Optimization Checked'}</h3>
    <div class="dashboard-kpis" style="margin-bottom:1rem">
      <div class="kpi-card"><div class="kpi-value">${before.score} → ${after.score}</div><div class="kpi-label">Fairness score (${fairnessScoreDelta(before, after)})</div></div>
      <div class="kpi-card"><div class="kpi-value">${before.highOpponentRepeats} → ${after.highOpponentRepeats}</div><div class="kpi-label">High opponent repeats</div></div>
      <div class="kpi-card"><div class="kpi-value">${before.sitGap} → ${after.sitGap}</div><div class="kpi-label">Wait gap</div></div>
      <div class="kpi-card"><div class="kpi-value">${after.avgSpread.toFixed(1)}</div><div class="kpi-label">Avg rating spread</div></div>
    </div>
    <div class="dashboard-card">
      <h4 style="margin:.1rem 0 .5rem">What changed</h4>
      <div style="color:var(--txt3);line-height:1.65">${checks.map(x=>escHtml(x)).join('<br>') || 'No meaningful improvement was found with the current players and constraints.'}</div>
    </div>
    <div class="dashboard-card" style="margin-top:1rem">
      <h4 style="margin:.1rem 0 .5rem">Next Round Status</h4>
      <div style="color:var(--txt3)">${after.score >= 90 ? '🟢 Ready to publish.' : after.score >= 75 ? '🟡 Review once, then publish if acceptable.' : '🔴 Still needs attention. Try regenerating or manually adjusting the next round.'}</div>
    </div>`;
}
function optimizeNextRoundFromFairness() {
  const beforeAnalysis = buildFairnessAnalysis();
  const before = fairnessMetricSnapshot(beforeAnalysis);
  const highRepeats = fairnessHighOpponentRepeats(beforeAnalysis);
  const msg = highRepeats.length
    ? 'This will optimize the next round and try to avoid high-repeat opponent matchups while preserving wait time, partner diversity, court balance, and rating balance. Continue?'
    : (before.sitGap > 1
      ? 'This will optimize the next round and prioritize players who have waited longest while preserving other fairness rules. Continue?'
      : 'This will optimize the next round using the current scheduling rules. Continue?');
  if(!confirm(msg)) return;
  try {
    if(typeof generateSchedule === 'function') {
      generateSchedule();
      const afterAnalysis = buildFairnessAnalysis();
      const after = fairnessMetricSnapshot(afterAnalysis);
      renderFairnessEngine();
      renderAutoFixSummary(before, after);
      toast(after.score > before.score ? `✅ Optimized: fairness ${before.score} → ${after.score}` : 'ℹ️ Optimization checked — schedule refreshed');
    } else {
      toast('Schedule generator not available', 'err');
    }
  } catch(err) {
    console.error(err);
    toast('Could not optimize schedule', 'err');
  }
}





function renderCommunicationsHub() {
  try {
    const mob = document.querySelector('#sec-communications [onclick*="mobilesync"]');
    const sms = document.querySelector('#sec-communications [onclick*="sms"]');
    const email = document.querySelector('#sec-communications [onclick*="email"]');
    if (mob) mob.style.display = (window.__CLIENT__ && window.__CLIENT__.features && window.__CLIENT__.features.mobileSync === false) ? 'none' : '';
    if (sms) sms.style.display = (window.__CLIENT__ && window.__CLIENT__.features && window.__CLIENT__.features.sms === false) ? 'none' : '';
    if (email) email.style.display = (window.__CLIENT__ && window.__CLIENT__.features && window.__CLIENT__.features.email === false) ? 'none' : '';
  } catch(e) { console.warn('Communications hub render warning:', e); }
}



// ═══════════════════════════════════════════════
//  TOURNAMENT HISTORY ARCHIVE
// ═══════════════════════════════════════════════
const TOURNAMENT_HISTORY_KEY = 'pb_tournament_history_v1';
let selectedHistoryId = null;

function historyGetAll() {
  try { return JSON.parse(localStorage.getItem(TOURNAMENT_HISTORY_KEY) || '[]'); }
  catch(e) { return []; }
}

function historySaveAll(items) {
  try { localStorage.setItem(TOURNAMENT_HISTORY_KEY, JSON.stringify(items || [])); }
  catch(e) { toast('Could not save tournament history. Browser storage may be full.', 'err'); }
}

function historySlug(text) {
  return String(text || 'Tournament').replace(/[^a-zA-Z0-9]+/g,'_').replace(/^_+|_+$/g,'') || 'Tournament';
}

function historyStatsFromSave(save) {
  const players = save?.state?.players || [];
  const games = (save?.state?.schedule || []).flat();
  const completed = games.filter(m => m && m.complete).length;
  const rounds = (save?.state?.schedule || []).length;
  let leader = '';
  try {
    const totals = {};
    players.forEach((p,i)=>{ totals[i] = { name:p.name || ('Player '+(i+1)), pts:0, wins:0, gp:0 }; });
    games.forEach(m => {
      if(!m || !m.complete) return;
      const a = Number(m.scoreA || 0), b = Number(m.scoreB || 0);
      (m.teamA || []).forEach(i => { if(totals[i]) { totals[i].pts += a; totals[i].wins += a>b ? 1 : 0; totals[i].gp++; } });
      (m.teamB || []).forEach(i => { if(totals[i]) { totals[i].pts += b; totals[i].wins += b>a ? 1 : 0; totals[i].gp++; } });
    });
    const ranked = Object.values(totals).filter(x=>x.gp).sort((x,y)=>y.wins-x.wins || y.pts-x.pts || x.name.localeCompare(y.name));
    leader = ranked[0]?.name || '';
  } catch(e) {}
  return { players: players.length, rounds, games: games.length, completed, leader };
}

function historyBuildEntry(note) {
  const save = buildSaveData();
  const stats = historyStatsFromSave(save);
  return {
    id: 'hist_' + Date.now() + '_' + Math.random().toString(16).slice(2),
    name: getTournamentName(),
    tournamentDateTime: getTournamentDateTime(),
    archivedAt: new Date().toISOString(),
    note: note || '',
    stats,
    save
  };
}

function historyArchiveCurrent() {
  const progress = typeof dashboardGetProgress === 'function' ? dashboardGetProgress() : { totalGames: 0, completeGames: 0 };
  const name = getTournamentName();
  const msg = progress.totalGames && progress.completeGames < progress.totalGames
    ? `Archive "${name}" now? Only ${progress.completeGames}/${progress.totalGames} games are complete.`
    : `Archive "${name}" in Tournament History?`;
  if(!confirm(msg)) return;
  const items = historyGetAll();
  const entry = historyBuildEntry();
  items.unshift(entry);
  historySaveAll(items);
  selectedHistoryId = entry.id;
  renderTournamentHistory();
  toast('🏆 Tournament archived');
}

function renderTournamentHistory() {
  const items = historyGetAll();
  const q = (document.getElementById('history-search')?.value || '').toLowerCase().trim();
  const filtered = q ? items.filter(x => (x.name||'').toLowerCase().includes(q) || (x.note||'').toLowerCase().includes(q)) : items;
  const summary = document.getElementById('tournament-history-summary');
  if(summary) {
    const totalPlayers = items.reduce((a,x)=>a+(x.stats?.players||0),0);
    const totalGames = items.reduce((a,x)=>a+(x.stats?.completed||0),0);
    summary.innerHTML = `
      <div class="card"><div style="font-size:1.6rem;color:var(--ball);font-weight:700">${items.length}</div><div style="color:var(--txt2)">Archived tournaments</div></div>
      <div class="card"><div style="font-size:1.6rem;color:var(--ball);font-weight:700">${totalGames}</div><div style="color:var(--txt2)">Completed games saved</div></div>
      <div class="card"><div style="font-size:1.6rem;color:var(--ball);font-weight:700">${totalPlayers}</div><div style="color:var(--txt2)">Player entries archived</div></div>`;
  }
  const list = document.getElementById('tournament-history-list');
  if(list) {
    if(!filtered.length) {
      list.innerHTML = '<div style="color:var(--txt2);padding:1rem;border:1px dashed var(--line);border-radius:12px">No archived tournaments yet. Use <strong>Archive Current Tournament</strong> after an event.</div>';
    } else {
      list.innerHTML = filtered.map(x => {
        const d = x.tournamentDateTime ? formatHistoryDate(x.tournamentDateTime) : formatHistoryDate(x.archivedAt);
        const s = x.stats || {};
        return `<div class="card" style="margin-bottom:.75rem;border-color:${selectedHistoryId===x.id?'var(--ball)':'var(--line)'}">
          <div style="display:flex;justify-content:space-between;gap:1rem;align-items:flex-start;flex-wrap:wrap">
            <div>
              <div style="font-weight:700;color:var(--txt);font-size:1rem">${escHtml(x.name || 'Tournament')}</div>
              <div style="color:var(--txt2);font-size:.82rem">${escHtml(d)} · ${s.players||0} players · ${s.rounds||0} rounds · ${s.completed||0}/${s.games||0} games complete${s.leader?' · Leader: '+escHtml(s.leader):''}</div>
            </div>
            <div style="display:flex;gap:.4rem;flex-wrap:wrap">
              <button class="btn btn-secondary btn-sm" onclick="historySelect('${x.id}')">View</button>
              <button class="btn btn-secondary btn-sm" onclick="historyExportOne('${x.id}')">Export</button>
              <button class="btn btn-primary btn-sm" onclick="historyRestore('${x.id}')">Restore</button>
              <button class="btn btn-danger btn-sm" onclick="historyDelete('${x.id}')">Delete</button>
            </div>
          </div>
        </div>`;
      }).join('');
    }
  }
  if(selectedHistoryId) historySelect(selectedHistoryId, true);
}

function formatHistoryDate(value) {
  if(!value) return '';
  const d = new Date(value);
  if(isNaN(d.getTime())) return String(value);
  return d.toLocaleString(undefined, { month:'short', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit' });
}

function historySelect(id, silent) {
  selectedHistoryId = id;
  const item = historyGetAll().find(x=>x.id===id);
  const detail = document.getElementById('tournament-history-detail');
  if(!item || !detail) return;
  const save = item.save || {};
  const stats = historyStatsFromSave(save);
  const players = save?.state?.players || [];
  const games = (save?.state?.schedule || []).flat();
  const totals = {};
  players.forEach((p,i)=>{ totals[i] = { name:p.name || ('Player '+(i+1)), pts:0, wins:0, gp:0 }; });
  games.forEach(m=>{
    if(!m || !m.complete) return;
    const a = Number(m.scoreA || 0), b = Number(m.scoreB || 0);
    (m.teamA||[]).forEach(i=>{ if(totals[i]) { totals[i].pts += a; totals[i].wins += a>b ? 1 : 0; totals[i].gp++; } });
    (m.teamB||[]).forEach(i=>{ if(totals[i]) { totals[i].pts += b; totals[i].wins += b>a ? 1 : 0; totals[i].gp++; } });
  });
  const top = Object.values(totals).filter(x=>x.gp).sort((a,b)=>b.wins-a.wins || b.pts-a.pts || a.name.localeCompare(b.name)).slice(0,8);
  detail.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:.75rem;margin-bottom:1rem">
      <div><strong>${escHtml(item.name || 'Tournament')}</strong><br><span style="color:var(--txt3)">${escHtml(formatHistoryDate(item.tournamentDateTime || item.archivedAt))}</span></div>
      <div><strong>${stats.players}</strong><br><span style="color:var(--txt3)">Players</span></div>
      <div><strong>${stats.rounds}</strong><br><span style="color:var(--txt3)">Rounds</span></div>
      <div><strong>${stats.completed}/${stats.games}</strong><br><span style="color:var(--txt3)">Games complete</span></div>
    </div>
    <div style="font-weight:700;color:var(--ball);margin-bottom:.5rem">Top standings snapshot</div>
    ${top.length ? `<table><thead><tr><th>Rank</th><th>Player</th><th>Wins</th><th>Points</th><th>Games</th></tr></thead><tbody>${top.map((r,i)=>`<tr><td>${i+1}</td><td>${escHtml(r.name)}</td><td>${r.wins}</td><td>${r.pts}</td><td>${r.gp}</td></tr>`).join('')}</tbody></table>` : '<div>No completed games in this archive.</div>'}
  `;
  if(!silent) renderTournamentHistory();
}

function historyRestore(id) {
  const item = historyGetAll().find(x=>x.id===id);
  if(!item || !item.save) return;
  if(!confirm(`Restore "${item.name}"? This replaces the current tournament on this device. Archive the current tournament first if needed.`)) return;
  restoreSaveData(item.save);
  renderPlayers(); renderTeams(); renderSchedule(); renderCourtsGrid(); updateCourtSelectorUI(); updateProgress(); renderStandings(); renderPlayoffs(); onModeChange(); showUndoButton(); renderDashboard();
  toast('Tournament restored from history');
  showTab('dashboard');
}

function historyDelete(id) {
  const items = historyGetAll();
  const item = items.find(x=>x.id===id);
  if(!item || !confirm(`Delete archived tournament "${item.name}"?`)) return;
  historySaveAll(items.filter(x=>x.id!==id));
  if(selectedHistoryId === id) selectedHistoryId = null;
  renderTournamentHistory();
  toast('Archived tournament deleted');
}

function historyExportOne(id) {
  const item = historyGetAll().find(x=>x.id===id);
  if(!item) return;
  const a = document.createElement('a');
  a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(item, null, 2));
  a.download = `${historySlug(item.name)}_history_${(item.archivedAt||new Date().toISOString()).slice(0,10)}.json`;
  a.click();
}

function historyExportAll() {
  const items = historyGetAll();
  if(!items.length) { toast('No tournament history to export', 'err'); return; }
  const a = document.createElement('a');
  a.href = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({ exportedAt:new Date().toISOString(), items }, null, 2));
  a.download = 'pickleball_tournament_history.json';
  a.click();
}

function historyImportAll(event) {
  const file = event.target.files && event.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      const incoming = Array.isArray(data) ? data : (data.items || []);
      if(!Array.isArray(incoming)) throw new Error('Invalid history file');
      const existing = historyGetAll();
      const byId = new Map(existing.map(x=>[x.id,x]));
      incoming.forEach(x => { if(x && x.id) byId.set(x.id, x); });
      historySaveAll(Array.from(byId.values()).sort((a,b)=>String(b.archivedAt||'').localeCompare(String(a.archivedAt||''))));
      renderTournamentHistory();
      toast('Tournament history imported');
    } catch(err) { toast('Could not import history: ' + err.message, 'err'); }
  };
  reader.readAsText(file);
  event.target.value = '';
}



// ═══════════════════════════════════════════════
// SESSION DIRECTOR TOOLS: health, lookup, end summary
// ═══════════════════════════════════════════════
function ppFlatMatches(){
  try { return (state.schedule || []).flat().filter(Boolean); } catch(e) { return []; }
}
function ppRoundCount(){ return (state.schedule || []).length || 0; }
function ppCompletedMatches(){ return ppFlatMatches().filter(m => m.complete); }
function ppIncompleteMatches(){ return ppFlatMatches().filter(m => m.teamA && m.teamB && !m.complete); }
function ppPlayerNameByIdx(i){ return (state.players && state.players[i] && state.players[i].name) ? state.players[i].name : 'Player'; }
function ppSitOutCounts(){
  const sits = {};
  (state.players || []).forEach((p,i)=>{ sits[i]=0; });
  (state.byeRounds || []).forEach(arr => (arr || []).forEach(i => { sits[i] = (sits[i] || 0) + 1; }));
  return sits;
}
function ppCurrentPlayerMatch(playerIdx){
  const matches = ppIncompleteMatches();
  return matches.find(m => (m.teamA || []).includes(playerIdx) || (m.teamB || []).includes(playerIdx)) || null;
}
function ppRankMap(){
  const rows = buildPlayerStats().slice().sort((a,b) => (b.wins-a.wins) || (b.diff-a.diff) || (b.totalPts-a.totalPts));
  const ranks = {};
  rows.forEach((r,i)=>{ ranks[r.playerIdx] = i + 1; });
  return { rows, ranks };
}
function ppHealthModel(){
  const players = (state.players || []).filter(p => p.waitlist !== true && p.active !== false);
  const checked = players.filter(p => p.checkedIn !== false);
  const totalMatches = ppFlatMatches().length;
  const missingScores = ppIncompleteMatches().length;
  const completed = ppCompletedMatches().length;
  let fairness = null;
  try { fairness = (typeof buildFairnessAnalysis === 'function') ? buildFairnessAnalysis() : null; } catch(e) {}
  const issues = [];
  const wins = [];
  if(players.length < 4) issues.push('Add at least 4 active players.'); else wins.push(`${checked.length} active/check-in eligible players`);
  if(!totalMatches) issues.push('No schedule generated yet.');
  else if(missingScores) issues.push(`${missingScores} match${missingScores===1?'':'es'} still need scores.`);
  else wins.push('All scheduled scores are entered.');
  if(fairness){
    if(fairness.sitGap > 1) {
      const waiting = (fairness.mostSat || []).slice(0,6).map(x=>x.name).join(', ');
      issues.push(`${(fairness.mostSat || []).length} player${(fairness.mostSat || []).length===1?'':'s'} have waited longer than the group${waiting ? ': ' + waiting : ''}.`);
    } else wins.push('Wait time is balanced.');
    if((fairness.repeatsP || []).length) issues.push(`${fairness.repeatsP.length} repeated partner pairing${fairness.repeatsP.length===1?'':'s'} detected.`); else wins.push('No repeated partners.');
    const highOpp = (fairness.repeatsO || []).filter(x => x[1] >= 3).length;
    if(highOpp) issues.push(`${highOpp} high-repeat opponent matchup${highOpp===1?'':'s'} to avoid.`); else wins.push('Opponent repeats are under control.');
    if((fairness.courtGap || 0) > 1) issues.push(`Court usage gap is ${fairness.courtGap}.`); else wins.push('Courts are balanced.');
  }
  let status = '🟢 Ready';
  let next = 'Generate or continue the next round.';
  if(players.length < 4){ status = '🔴 Setup needed'; next = 'Add more players before scheduling.'; }
  else if(!totalMatches){ status = '🟢 Ready to schedule'; next = 'Generate the first round.'; }
  else if(missingScores){ status = '🟡 Scores needed'; next = `Enter ${missingScores} missing score${missingScores===1?'':'s'}.`; }
  else if(issues.length){ status = '🟡 Review'; next = 'Review fairness items before the next round.'; }
  else { status = '🟢 Ready for next round'; next = 'Generate the next best round.'; }
  return { players, checked, totalMatches, missingScores, completed, fairness, issues, wins, status, next };
}
function ppDirectorAction(){
  const h = ppHealthModel();
  if(h.players.length < 4){ showTab('players'); return; }
  if(!h.totalMatches){ dashboardPrimaryAction(); return; }
  if(h.missingScores){ recordNextScore(); return; }
  if(h.fairness && ((h.fairness.sitGap || 0) > 1 || ((h.fairness.repeatsO || []).filter(x => x[1] >= 3).length) || (h.fairness.repeatsP || []).length)){
    showTab('fairness');
    return;
  }
  dashboardPrimaryAction();
}
function ppDirectorButtonLabel(){
  const h = ppHealthModel();
  if(h.players.length < 4) return '👥 Add / Check In Players';
  if(!h.totalMatches) return '🚀 Generate First Round';
  if(h.missingScores) return '📝 Enter Missing Scores';
  if(h.fairness && ((h.fairness.sitGap || 0) > 1 || ((h.fairness.repeatsO || []).filter(x => x[1] >= 3).length) || (h.fairness.repeatsP || []).length)) return '✨ Review Fairness';
  return '🚀 Generate Next Best Round';
}
function ppHealthHtml(compact){
  const h = ppHealthModel();
  const issueHtml = h.issues.length ? h.issues.slice(0, compact ? 3 : 8).map(x=>`<div style="padding:.35rem 0;color:var(--warn,#f59e0b)">⚠️ ${escHtml(x)}</div>`).join('') : '<div style="color:var(--ok,#22c55e)">✅ No blocking issues detected.</div>';
  const winHtml = h.wins.slice(0, compact ? 4 : 10).map(x=>`<div style="padding:.25rem 0;color:var(--txt2)">✅ ${escHtml(x)}</div>`).join('');
  const topIssue = h.issues[0] || 'Everything looks ready.';
  const reasonList = h.issues.length ? h.issues.slice(0, compact ? 2 : 5) : h.wins.slice(0, compact ? 3 : 6);
  const reasons = reasonList.map(x => `<div style="padding:.25rem 0;color:var(--txt2)">• ${escHtml(x)}</div>`).join('') || '<div style="color:var(--txt3)">No session data yet.</div>';
  const actionLabel = ppDirectorButtonLabel();
  return `<div class="premium-panel director-assistant" style="border:1px solid rgba(198,255,0,.22);border-radius:18px;padding:1rem;background:linear-gradient(135deg,rgba(198,255,0,.08),rgba(255,255,255,.025));box-shadow:0 12px 35px rgba(0,0,0,.18)">
    <div style="display:flex;justify-content:space-between;gap:1rem;align-items:flex-start;flex-wrap:wrap">
      <div>
        <div style="font-size:.82rem;text-transform:uppercase;letter-spacing:.08em;color:var(--ball);font-weight:800">🧠 Tournament Director Assistant</div>
        <div style="font-size:1.35rem;font-weight:900;color:var(--txt);margin-top:.25rem">${escHtml(h.status)}</div>
        <div style="color:var(--txt2);margin-top:.25rem"><strong>Next recommended action:</strong> ${escHtml(h.next)}</div>
      </div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;justify-content:flex-end">
        <span class="premium-pill">👥 ${h.checked.length}/${h.players.length} players</span>
        <span class="premium-pill">🏓 ${h.completed}/${h.totalMatches || 0} matches done</span>
        ${h.fairness ? `<span class="premium-pill">⚖️ ${h.fairness.score || 0}/100</span>` : ''}
      </div>
    </div>
    <div style="margin-top:1rem;display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem">
      <div style="border:1px solid var(--border);border-radius:14px;padding:.85rem;background:rgba(0,0,0,.14)">
        <strong style="color:var(--txt)">Why this action?</strong>
        <div style="margin-top:.4rem">${reasons}</div>
      </div>
      <div style="border:1px solid var(--border);border-radius:14px;padding:.85rem;background:rgba(0,0,0,.14)">
        <strong style="color:var(--txt)">${h.issues.length ? 'Needs attention' : 'Session health'}</strong>
        <div style="margin-top:.4rem">${h.issues.length ? issueHtml : winHtml}</div>
      </div>
    </div>
    <div style="margin-top:1rem;display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
      <button class="btn btn-primary" onclick="ppDirectorAction()">${escHtml(actionLabel)}</button>
      <button class="btn btn-secondary btn-sm" onclick="showTab('sessionhealth')">View Details</button>
      <button class="btn btn-secondary btn-sm" onclick="showTab('fairness')">Open Fairness</button>
      <button class="btn btn-secondary btn-sm" onclick="showTab('schedule')">Open Schedule</button>
    </div>
  </div>`;
}
function renderSessionHealthDashboard(){
  const home = document.getElementById('session-health-home');
  if(home) home.innerHTML = ppHealthHtml(true);
  const detail = document.getElementById('session-health-detail');
  if(detail) detail.innerHTML = ppHealthHtml(false);
}
function renderPlayerLookup(){
  const out = document.getElementById('pl-results');
  if(!out) return;
  const q = (document.getElementById('pl-search')?.value || '').toLowerCase().trim();
  const rankInfo = ppRankMap();
  const statsByIdx = {};
  rankInfo.rows.forEach(r => statsByIdx[r.playerIdx] = r);
  const sits = ppSitOutCounts();
  const matches = ppIncompleteMatches();
  const players = (state.players || []).map((p,i)=>({p,i})).filter(x => !q || (x.p.name || '').toLowerCase().includes(q));
  if(!players.length){ out.innerHTML = '<div class="empty-state"><div class="big">🔍</div>No matching player found.</div>'; return; }
  out.innerHTML = players.slice(0, q ? 12 : 8).map(({p,i}) => {
    const st = statsByIdx[i];
    const m = ppCurrentPlayerMatch(i);
    let assignment = 'Not currently assigned to an unfinished match.';
    if(m){
      const team = (m.teamA || []).includes(i) ? m.teamA : m.teamB;
      const opp = team === m.teamA ? m.teamB : m.teamA;
      const partner = team.find(x => x !== i);
      assignment = `Court ${escHtml(m.court || '')} · Partner: ${partner!=null ? escHtml(ppPlayerNameByIdx(partner)) : '—'} · Opponents: ${opp.map(ppPlayerNameByIdx).map(escHtml).join(' / ')}`;
    }
    return `<div class="premium-panel" style="margin-bottom:.75rem;padding:1rem;border:1px solid var(--border);border-radius:14px;background:rgba(255,255,255,.03)">
      <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap"><div><strong style="font-size:1.05rem;color:var(--txt)">${escHtml(p.name || 'Player')}</strong><div style="color:var(--txt2);margin-top:.25rem">${assignment}</div></div><span class="premium-pill">Rank ${rankInfo.ranks[i] ? '#'+rankInfo.ranks[i] : '—'}</span></div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.75rem"><span class="premium-pill">Record ${st ? `${st.wins}-${st.losses}` : '0-0'}</span><span class="premium-pill">Points ${st ? st.totalPts : 0}</span><span class="premium-pill">Diff ${st ? st.diff : 0}</span><span class="premium-pill">Sit-outs ${sits[i] || 0}</span><span class="premium-pill">${p.checkedIn === false ? 'Absent' : 'Checked in'}</span></div>
    </div>`;
  }).join('');
}
function renderEndSessionSummary(){
  const out = document.getElementById('end-session-summary');
  if(!out) return;
  const h = ppHealthModel();
  const stats = buildPlayerStats().slice().filter(s => s.gamesPlayed > 0).sort((a,b)=>(b.wins-a.wins)||(b.diff-a.diff)||(b.totalPts-a.totalPts));
  const top3 = stats.slice(0,3);
  const fairness = h.fairness;
  const topHtml = top3.length ? top3.map((s,i)=>`<div style="display:flex;justify-content:space-between;border-bottom:1px solid var(--border);padding:.45rem 0"><span>${['🥇','🥈','🥉'][i]} ${escHtml(s.player.name)}</span><span>${s.wins}-${s.losses} · ${s.totalPts} pts</span></div>`).join('') : '<div style="color:var(--txt3)">No completed scores yet.</div>';
  out.innerHTML = `<div class="premium-panel" style="border:1px solid var(--border);border-radius:16px;padding:1rem;background:rgba(255,255,255,.03)">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:.75rem;margin-bottom:1rem">
      <div class="dashboard-kpi"><div class="dashboard-kpi-value">${h.players.length}</div><div class="dashboard-kpi-label">Players</div></div>
      <div class="dashboard-kpi"><div class="dashboard-kpi-value">${ppRoundCount()}</div><div class="dashboard-kpi-label">Rounds</div></div>
      <div class="dashboard-kpi"><div class="dashboard-kpi-value">${h.completed}</div><div class="dashboard-kpi-label">Matches complete</div></div>
      <div class="dashboard-kpi"><div class="dashboard-kpi-value">${fairness ? fairness.score : '—'}</div><div class="dashboard-kpi-label">Fairness score</div></div>
    </div>
    <h3>🏆 Top 3</h3>${topHtml}
    <h3 style="margin-top:1rem">⚖️ Session quality</h3>
    <div style="color:var(--txt2)">${fairness ? `Fairness ${fairness.score}/100 · ${escHtml(fairness.grade || '')}. Wait gap ${fairness.sitGap || 0}, partner repeats ${(fairness.repeatsP||[]).length}, high opponent repeats ${(fairness.repeatsO||[]).filter(x=>x[1]>=3).length}.` : 'No fairness analysis available yet.'}</div>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:1rem"><button class="btn btn-primary" onclick="historyArchiveCurrent && historyArchiveCurrent()">💾 Save to Tournament History</button><button class="btn btn-secondary" onclick="exportEndSessionSummary()">📤 Export Summary</button><button class="btn btn-secondary" onclick="showTab('standings')">View Standings</button></div>
  </div>`;
}
function exportEndSessionSummary(){
  const h = ppHealthModel();
  const stats = buildPlayerStats().slice().filter(s=>s.gamesPlayed>0).sort((a,b)=>(b.wins-a.wins)||(b.diff-a.diff)||(b.totalPts-a.totalPts));
  const lines = [];
  lines.push('Pickleball Pro Session Summary');
  lines.push('Generated: ' + new Date().toLocaleString());
  lines.push('Players: ' + h.players.length);
  lines.push('Rounds: ' + ppRoundCount());
  lines.push('Matches complete: ' + h.completed);
  if(h.fairness) lines.push('Fairness: ' + h.fairness.score + '/100');
  lines.push(''); lines.push('Top players');
  stats.slice(0,10).forEach((s,i)=>lines.push(`${i+1}. ${s.player.name} - ${s.wins}-${s.losses}, ${s.totalPts} pts, diff ${s.diff}`));
  const blob = new Blob([lines.join('\n')], {type:'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'pickleball-session-summary.txt';
  a.click();
  URL.revokeObjectURL(a.href);
}

/* === HARDENED MENU FIX: inserted after all app code === */
(function(){
  function safeCall(name){
    try {
      var fn = window[name];
      if (typeof fn === 'function') fn();
    } catch (err) {
      console.error('Render failed for ' + name + ':', err);
    }
  }

  window.showTab = function(tab, evt){
    try {
      if (evt && typeof evt.preventDefault === 'function') evt.preventDefault();
      if (!tab) tab = 'dashboard'; if (tab === 'matchbuilder') tab = 'schedule';

      document.querySelectorAll('.section').forEach(function(section){
        section.classList.remove('active');
      });
      document.querySelectorAll('.tab-btn').forEach(function(button){
        button.classList.remove('active');
      });
      document.querySelectorAll('.nav-group').forEach(function(group){
        group.classList.remove('active');
        group.classList.remove('open');
      });

      var section = document.getElementById('sec-' + tab);
      if (!section) {
        console.warn('Missing section for tab:', tab);
        section = document.getElementById('sec-dashboard');
        tab = 'dashboard';
      }
      if (section) section.classList.add('active');

      var clicked = evt && evt.target ? evt.target.closest('.tab-btn') : null;
      if (clicked) clicked.classList.add('active');

      var group = document.querySelector('.nav-group[data-tabs~="' + tab + '"]');
      if (group) {
        group.classList.add('active');
        var primary = group.querySelector(':scope > .tab-btn');
        if (primary) primary.classList.add('active');
      }

      var renderMap = {
        dashboard: ['renderDashboard'],
        communications: ['renderCommunicationsHub'],
        players: ['renderPlayers'],
        teams: ['renderTeams'],
        courts: ['renderCourts'],
        schedule: ['renderMatchBuilderPanel','renderSchedule','updateTimerDisplay'],
        matchbuilder: ['renderMatchBuilderPanel'],
        standings: ['renderStandings'],
        display: ['renderDisplayTools'],
        public: ['renderPublicStandings'],
        checkin: ['renderCheckin'],
        selfcheckin: ['renderSelfCheckinTools'],
        fairness: ['renderFairnessEngine'],
        history: ['renderTournamentHistory'],
        admin: ['renderAdminLock'],
        selfcheckinpublic: ['renderSelfCheckinPublic'],
        playoffs: ['renderPlayoffs'],
        playerstats: ['renderPlayerStats','populateH2HDropdowns','renderH2H'],
        sms: ['renderSmsTab'],
        mobilesync: ['renderMobileSyncTab'],
        report: ['renderReport'],
        playerlookup: ['renderPlayerLookup'],
        sessionhealth: ['renderSessionHealthDashboard'],
        endsession: ['renderEndSessionSummary'],
        email: ['renderEmailTab'],
        season: ['renderSeasonBoard']
      };
      (renderMap[tab] || []).forEach(safeCall);
      return false;
    } catch (err) {
      console.error('showTab hard failure:', err);
      return false;
    }
  };

  // Capture menu clicks before old inline handlers can fail.
  document.addEventListener('click', function(e){
    var button = e.target.closest('button[onclick*="showTab("]');
    if (!button) return;
    var raw = button.getAttribute('onclick') || '';
    var match = raw.match(/showTab\(['\"]([^'\"]+)['\"]/);
    if (!match) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    window.showTab(match[1], e);
  }, true);

  // Make drop-down groups work on tap/mobile too.
  document.addEventListener('click', function(e){
    var primary = e.target.closest('.nav-group > .tab-btn');
    if (!primary) return;
    var group = primary.closest('.nav-group');
    if (!group || !group.querySelector('.nav-menu')) return;
    document.querySelectorAll('.nav-group.open').forEach(function(g){ if(g !== group) g.classList.remove('open'); });
    group.classList.toggle('open');
  }, false);
})();


(function(){
  function access(){ return window.__ACCESS__ || {}; }
  function notify(msg){
    try { if (typeof window.toast === 'function') return window.toast(msg, 'err'); } catch(e) {}
    try { console.warn(msg); } catch(e) {}
  }
  function isAdmin(){ return !!access().isAdmin; }
  function hideAdminUI(){
    if (isAdmin()) return;
    var selectors = [
      "button[onclick*=\"showTab('admin'\"]",
      "button[onclick*=\"showTab(\\\"admin\\\"\"]",
      "button[onclick*=\"/admin/\"]",
      "a[href^='/admin/']",
      "a[href^=\"/admin/\"]",
      "[data-admin-only]"
    ];
    selectors.forEach(function(sel){
      document.querySelectorAll(sel).forEach(function(el){
        var row = el.closest && el.closest('.quick-action');
        (row || el).style.display = 'none';
        (row || el).setAttribute('aria-hidden','true');
      });
    });
    var sec = document.getElementById('sec-admin');
    if (sec) sec.style.display = 'none';
  }
  function guardShowTab(){
    if (typeof window.showTab !== 'function' || window.__adminShowTabGuarded) return;
    var original = window.showTab;
    window.showTab = function(tab, evt){
      if (String(tab).toLowerCase() === 'admin' && !isAdmin()) {
        if (evt && typeof evt.preventDefault === 'function') evt.preventDefault();
        notify('Admin access only.');
        return false;
      }
      return original.apply(this, arguments);
    };
    window.__adminShowTabGuarded = true;
  }
  function init(){ hideAdminUI(); guardShowTab(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  setTimeout(init, 500);
})();


(function(){
  function isAdmin(){ return !!(window.__ACCESS__ && window.__ACCESS__.isAdmin); }
  function looksAdmin(el){
    if (!el) return false;
    if (el.matches && (el.matches('[data-admin-only]') || el.matches('#sec-admin') || el.matches('a[href^="/admin/"]'))) return true;
    var onclick = (el.getAttribute && (el.getAttribute('onclick') || '')) || '';
    var href = (el.getAttribute && (el.getAttribute('href') || '')) || '';
    var txt = (el.textContent || '').trim().toLowerCase();
    return onclick.indexOf("showTab('admin'") >= 0 || onclick.indexOf('showTab("admin"') >= 0 || onclick.indexOf('/admin/') >= 0 || href.indexOf('/admin/') === 0 || txt === 'admin lock' || txt === 'admin';
  }
  function hide(){
    if (isAdmin()) return;
    if (document.documentElement) document.documentElement.classList.add('pb-non-admin-root');
    if (document.body) document.body.classList.add('pb-non-admin');
    var nodes = Array.prototype.slice.call(document.querySelectorAll('button,a,[data-admin-only],#sec-admin'));
    nodes.forEach(function(el){
      if (!looksAdmin(el)) return;
      var target = (el.classList && el.classList.contains('quick-action')) ? el : el;
      target.style.setProperty('display','none','important');
      target.style.setProperty('visibility','hidden','important');
      target.setAttribute('aria-hidden','true');
    });
    var sec = document.getElementById('sec-admin');
    if (sec) sec.style.setProperty('display','none','important');
  }
  function guard(){
    if (typeof window.showTab === 'function' && !window.__adminShowTabHardGuarded) {
      var original = window.showTab;
      window.showTab = function(tab, evt){
        if (String(tab || '').toLowerCase() === 'admin' && !isAdmin()) {
          if (evt && evt.preventDefault) evt.preventDefault();
          try { if (window.toast) window.toast('Admin access only.', 'err'); } catch(e){}
          hide();
          return false;
        }
        return original.apply(this, arguments);
      };
      window.__adminShowTabHardGuarded = true;
    }
  }
  function init(){ hide(); guard(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  setTimeout(init, 100); setTimeout(init, 500); setTimeout(init, 1500); setInterval(init, 3000);
})();


/* === Schedule Builder Preview & Publish enhancement === */
(function(){
  function sbEsc(v){
    try { return typeof escHtml === 'function' ? escHtml(v == null ? '' : String(v)) : String(v == null ? '' : v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
    catch(e){ return String(v == null ? '' : v); }
  }
  function sbPlayerName(i){
    var p = (window.state && state.players) ? state.players[i] : null;
    return p && p.name ? p.name : '?';
  }
  function sbTeamName(team){
    return (team || []).map(sbPlayerName).join(' / ');
  }
  function sbNextRoundIndex(){
    if(!window.state || !Array.isArray(state.schedule) || !state.schedule.length) return -1;
    for(var i=0;i<state.schedule.length;i++){
      var round = state.schedule[i] || [];
      var started = state.startedRounds && typeof state.startedRounds.has === 'function' && state.startedRounds.has(i);
      var complete = round.length && round.every(function(m){ return !!m.complete; });
      if(!started && !complete) return i;
    }
    return state.schedule.length - 1;
  }
  function sbFairnessLabel(score){
    score = Number(score) || 0;
    if(score >= 90) return ['🟢','Excellent'];
    if(score >= 75) return ['🟡','Review'];
    if(score >= 60) return ['🟠','Needs work'];
    return ['🔴','Action needed'];
  }
  function sbAnalyze(){
    try { return (typeof buildFairnessAnalysis === 'function') ? buildFairnessAnalysis() : null; }
    catch(e){ console.warn('Preview fairness analysis failed', e); return null; }
  }
  function sbMixed(){
    try { return (typeof buildMixedComplianceReport === 'function') ? buildMixedComplianceReport() : null; }
    catch(e){ return null; }
  }
  window.renderSchedulePreviewPanel = function(){
    var box = document.getElementById('schedule-preview-panel');
    if(!box) return;
    if(!window.state || !Array.isArray(state.schedule) || !state.schedule.length){
      box.innerHTML = '<div style="background:rgba(255,255,255,.035);border:1px solid var(--border);border-radius:14px;padding:.9rem 1rem">'+
        '<div style="font-family:\'Bebas Neue\',sans-serif;font-size:1.15rem;color:var(--lime);letter-spacing:.3px">👀 Preview & Publish</div>'+
        '<div style="color:var(--txt2);font-size:.84rem;margin:.2rem 0 .75rem">Generate a schedule first, then review the next round before sending players to courts.</div>'+
        '<button class="btn btn-primary btn-sm" onclick="promptGenerateSchedule()">⚡ Generate Next Best Round</button>'+
      '</div>';
      return;
    }
    var idx = sbNextRoundIndex();
    var round = idx >= 0 ? (state.schedule[idx] || []) : [];
    var rn = round[0] && round[0].round ? round[0].round : (idx + 1);
    var a = sbAnalyze();
    var score = a && a.score != null ? a.score : null;
    var label = score == null ? ['⚪','Not analyzed'] : sbFairnessLabel(score);
    var mixed = sbMixed();
    var mixedLine = mixed && mixed.total ? (mixed.pct === 100 ? '✅ Mixed compliance: 100%' : '⚠️ Mixed compliance: '+mixed.pct+'% · best available schedule') : 'Mixed rules: not applicable';
    var bye = (state.byeRounds && state.byeRounds[idx]) ? state.byeRounds[idx] : [];
    var rows = round.slice(0,8).map(function(m){
      return '<tr><td style="padding:.45rem .55rem">'+sbEsc(m.court || '')+'</td><td style="padding:.45rem .55rem;font-weight:800">'+sbEsc(sbTeamName(m.teamA))+'</td><td style="padding:.45rem .55rem;font-weight:800">'+sbEsc(sbTeamName(m.teamB))+'</td></tr>';
    }).join('');
    var issueBits = [];
    if(a){
      if(a.sitGap > 1) issueBits.push('⚠️ Wait gap '+a.sitGap);
      if(a.repeatsP && a.repeatsP.length) issueBits.push('⚠️ '+a.repeatsP.length+' partner repeats');
      if(a.repeatsO && a.repeatsO.length) issueBits.push('⚠️ '+a.repeatsO.length+' opponent repeats');
      if(a.avgSpread > 1) issueBits.push('⚠️ Rating spread review');
    }
    if(!issueBits.length) issueBits.push('✅ No major preview warnings');
    var started = state.startedRounds && typeof state.startedRounds.has === 'function' && state.startedRounds.has(idx);
    box.innerHTML = '<div style="background:linear-gradient(135deg,rgba(198,255,0,.08),rgba(255,255,255,.025));border:1px solid rgba(198,255,0,.24);border-radius:14px;padding:.95rem 1rem">'+
      '<div style="display:flex;justify-content:space-between;gap:.8rem;align-items:flex-start;flex-wrap:wrap;margin-bottom:.75rem">'+
        '<div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:1.2rem;color:var(--lime);letter-spacing:.3px">👀 Preview & Publish Round '+sbEsc(rn)+'</div>'+
        '<div style="color:var(--txt2);font-size:.84rem;margin-top:.15rem">Review the next round before it goes live on the courts.</div></div>'+
        '<div style="text-align:right"><div style="font-weight:900;color:var(--txt)">'+label[0]+' '+(score==null?'—':score+'/100')+'</div><div style="font-size:.76rem;color:var(--txt3)">Fairness · '+sbEsc(label[1])+'</div></div>'+
      '</div>'+
      '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:.5rem;margin-bottom:.75rem">'+
        '<div style="background:rgba(0,0,0,.18);border:1px solid var(--border);border-radius:10px;padding:.65rem"><strong>'+mixedLine+'</strong></div>'+
        '<div style="background:rgba(0,0,0,.18);border:1px solid var(--border);border-radius:10px;padding:.65rem"><strong>'+issueBits.map(sbEsc).join('<br>')+'</strong></div>'+
        '<div style="background:rgba(0,0,0,.18);border:1px solid var(--border);border-radius:10px;padding:.65rem"><strong>🪑 Byes:</strong> '+(bye.length ? bye.map(sbPlayerName).map(sbEsc).join(', ') : 'None')+'</div>'+
      '</div>'+
      '<div class="tbl-wrap" style="margin-bottom:.75rem"><table><thead><tr><th>Court</th><th>Team A</th><th>Team B</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
      (round.length > 8 ? '<div style="font-size:.78rem;color:var(--txt3);margin:-.45rem 0 .7rem">Showing first 8 matches. Full schedule is below.</div>' : '')+
      '<div style="display:flex;gap:.5rem;flex-wrap:wrap">'+
        '<button class="btn btn-primary btn-sm" onclick="publishSchedulePreview()">✅ Publish / Start Round</button>'+
        '<button class="btn btn-orange btn-sm" onclick="regenerateSchedulePreview()">🔄 Regenerate Preview</button>'+
        '<button class="btn btn-secondary btn-sm" onclick="document.getElementById(\'schedule-container\')?.scrollIntoView({behavior:\'smooth\'});">View Full Schedule</button>'+
        (started ? '<span style="align-self:center;color:var(--lime);font-weight:800;font-size:.82rem">Already started</span>' : '')+
      '</div>'+
    '</div>';
  };
  window.publishSchedulePreview = function(){
    var idx = sbNextRoundIndex();
    if(idx < 0){ try{ toast('No round to publish yet','err'); }catch(e){} return; }
    try {
      if(typeof lockRound === 'function') lockRound(idx);
      else {
        state.startedRounds = state.startedRounds || new Set();
        if(typeof state.startedRounds.add === 'function') state.startedRounds.add(idx);
        if(typeof autoSave === 'function') autoSave();
      }
      if(typeof renderSchedule === 'function') renderSchedule();
      if(typeof updateProgress === 'function') updateProgress();
      try{ toast('✅ Round published to the live schedule'); }catch(e){}
    } catch(e){ console.error(e); try{ toast('Could not publish round','err'); }catch(_){} }
  };
  window.regenerateSchedulePreview = function(){
    try { promptGenerateSchedule(); setTimeout(function(){ try{ renderSchedulePreviewPanel(); }catch(e){} }, 350); }
    catch(e){ console.error(e); try{ toast('Could not regenerate preview','err'); }catch(_){} }
  };
  function wrapRenderSchedulePreview(){
    if(window.__schedulePreviewWrapped || typeof window.renderSchedule !== 'function') return;
    var old = window.renderSchedule;
    window.renderSchedule = function(){
      var res = old.apply(this, arguments);
      try { renderSchedulePreviewPanel(); } catch(e){ console.warn('Preview panel failed', e); }
      return res;
    };
    window.__schedulePreviewWrapped = true;
  }
  function init(){ wrapRenderSchedulePreview(); try{ renderSchedulePreviewPanel(); }catch(e){} }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  setTimeout(init, 500);
})();
